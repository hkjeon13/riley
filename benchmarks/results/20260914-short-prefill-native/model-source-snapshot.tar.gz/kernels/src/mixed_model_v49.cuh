#ifdef RILEY_CUDA_ENABLE_FA3
#include "../optional/fa3_api.h"
#endif
#ifdef RILEY_CUDA_ENABLE_FLASHINFER
#include "../optional/flashinfer_api.h"
#endif
#include "mixed_attention_v49.cuh"
#include "../optional/query_reuse_mixed_attention.cuh"
#include "../optional/gqa_staged_mixed_attention.cuh"
#include "mixed_rope_v49.cuh"
#pragma once
#include "../optional/context_split_mixed.cuh"
#include "prefill_shape_projection.cuh"
#include "prefill_fused_gate_v51.cuh"
#include "../optional/prefill_ffn_pipeline.cuh"
#include "../optional/prefill_projection_pipeline.cuh"
#include "../optional/prefill_ffn_adaptive.cuh"
#include "../optional/prefill_ffn_row_reuse.cuh"
#include "prefill_shape_rope_kv.cuh"
#include "prefill_shape_attention.cuh"
#include "prefill_shape_pointwise.cuh"
#include "decode_tiled.cuh"
// Borrowed 30-layer SmolLM2 BF16 prefill sequence. Caller must validate V7 packet,
// all allocation extents/aliases and hold the resource ledger until completion.
// This enqueues work; it does not authorize scheduler settlement or serving output.
__global__ void mixed_select_hidden_v7(const __nv_bfloat16* rows,__nv_bfloat16* selected,const uint32_t* meta,uint32_t capacity,const uint32_t* status,uint32_t* publish){
 uint32_t owner=blockIdx.x,active=meta[5],total=meta[9];bool ready=false;uint32_t at=0;
 if(active>=1&&active<=32&&owner<active&&total>0&&total<=capacity){const auto* shape=meta+32+owner*416;uint32_t n=shape[2],offset=shape[16],row=shape[11];ready=*status==0&&n>0&&offset<=total&&n<=total-offset&&row<n;at=offset+row;}
 if(publish&&threadIdx.x==0)publish[owner]=ready?1:0;
 for(uint32_t i=threadIdx.x;i<576;i+=blockDim.x)selected[owner*576+i]=ready?rows[at*576+i]:__float2bfloat16_rn(0.F);
}
template<uint32_t WireRows=8,bool PrefillFfnPipeline=false,bool Fa3=false,bool QueryReuse=false,bool GqaStaging=false,bool ProjectionPipeline=false,bool FfnAdaptive=false,bool FfnM32=false,bool ContextSplit=false,bool VerificationAttention=false,bool ShortPrefill=false>
inline cudaError_t enqueue_mixed_model_v7(cudaStream_t stream,void*const* scratch,const void*const* weights,
 const void* metadata,void* keys,void* values,const void* cos,const void* sin,void* selected,
 uint32_t* status,uint32_t* publish,uint32_t capacity,uint32_t physical,bool tiled=false,void* attention_workspace=nullptr,uint64_t attention_bytes=0,uint32_t context=4096,bool prefill_only=false,void* split_workspace=nullptr){
 if constexpr(ContextSplit) {if(!split_workspace)return cudaErrorInvalidValue;}
 static_assert(WireRows==8||WireRows==16||WireRows==32,"wire capacity");
 if(!scratch||!weights||!metadata||!keys||!values||!cos||!sin||!selected||!status||!capacity||capacity>1024||!physical||physical>4096)return cudaErrorInvalidValue;
 for(int i=0;i<12;++i)if(!scratch[i])return cudaErrorInvalidValue;
 for(int i=0;i<273;++i)if(!weights[i])return cudaErrorInvalidValue;
 auto b=[&](int i){return static_cast<__nv_bfloat16*>(scratch[i]);};
 auto w=[&](int i){return static_cast<const __nv_bfloat16*>(weights[i]);};
 const auto* meta=static_cast<const uint32_t*>(metadata);
 auto shape=meta+7; // shape[2] is total packed token count, not one owner count.
 auto pages=reinterpret_cast<const uint32_t*>(static_cast<const uint8_t*>(metadata)+256);
 auto tokens=reinterpret_cast<const uint32_t*>(static_cast<const uint8_t*>(metadata)+(128+WireRows*1664));
 auto err=cudaMemsetAsync(status,0,4,stream);if(err!=cudaSuccess)return err;
if constexpr(Fa3) {
#ifdef RILEY_CUDA_ENABLE_FA3
  err=static_cast<cudaError_t>(riley_fa3_model_metadata_prepare(stream,metadata,32*4+32*1664,attention_workspace,attention_bytes,physical,capacity,context,status));
  if(err!=cudaSuccess)return err;
  err=static_cast<cudaError_t>(riley_fa3_model_schedule(stream,attention_workspace,attention_bytes,capacity,context));
  if(err!=cudaSuccess)return err;
#else
  return cudaErrorNotSupported;
#endif
 } else {
#ifdef RILEY_CUDA_ENABLE_FLASHINFER
 if(attention_workspace){
  err=static_cast<cudaError_t>((prefill_only?riley_flashinfer_prefill_only_prepare(stream,metadata,attention_workspace,attention_bytes,physical,capacity,status):riley_flashinfer_mixed_prepare(stream,metadata,attention_workspace,attention_bytes,physical,context,capacity,status)));
  if(err!=cudaSuccess)return err;
 }
#else
 if(attention_workspace||attention_bytes)return cudaErrorNotSupported;
#endif
 }
 riley_prefill_pointwise::embedding_rows<<<capacity,256,0,stream>>>(w(0),tokens,b(0),shape,capacity,49152,status,nullptr);
 for(int layer=0;layer<30;++layer){int base=3+9*layer;
  if(layer==0)riley_prefill_pointwise::norm_rows<<<capacity,256,0,stream>>>(b(0),nullptr,w(base),nullptr,b(1),0,shape,capacity);
  if(capacity==1)enqueue_decode_projection<576,576,192>(stream,b(1),w(base+1),b(2),static_cast<float*>(scratch[7]));
  else if constexpr(ProjectionPipeline)riley_prefill_projection::project<576,576,192,2><<<dim3(36,(capacity+15)/16),64,0,stream>>>(b(1),w(base+1),b(2),capacity,shape+2);
  else gemm_prefill_shape_vector<576,576,192,2><<<dim3(36,(capacity+15)/16),64,0,stream>>>(b(1),w(base+1),b(2),capacity,shape+2);
  if(capacity==1)enqueue_decode_projection<192,576,192>(stream,b(1),w(base+2),b(5),static_cast<float*>(scratch[7]));
  else if constexpr(ProjectionPipeline)riley_prefill_projection::project<192,576,192,1><<<dim3(24,(capacity+15)/16),32,0,stream>>>(b(1),w(base+2),b(5),capacity,shape+2);
  else gemm_prefill_shape_vector<192,576,192,1><<<dim3(24,(capacity+15)/16),32,0,stream>>>(b(1),w(base+2),b(5),capacity,shape+2);
  if(capacity==1)enqueue_decode_projection<192,576,192>(stream,b(1),w(base+3),b(6),static_cast<float*>(scratch[7]));
  else if constexpr(ProjectionPipeline)riley_prefill_projection::project<192,576,192,1><<<dim3(24,(capacity+15)/16),32,0,stream>>>(b(1),w(base+3),b(6),capacity,shape+2);
  else gemm_prefill_shape_vector<192,576,192,1><<<dim3(24,(capacity+15)/16),32,0,stream>>>(b(1),w(base+3),b(6),capacity,shape+2);
  auto* lk=static_cast<__nv_bfloat16*>(keys)+uint64_t(layer)*physical*16*192;
  auto* lv=static_cast<__nv_bfloat16*>(values)+uint64_t(layer)*physical*16*192;
  mixed_rope_kv_v7<<<dim3(2,capacity),256,0,stream>>>(b(2),b(5),b(6),b(3),lk,lv,static_cast<const float*>(cos),static_cast<const float*>(sin),meta,capacity);
  if constexpr(Fa3) {
#ifdef RILEY_CUDA_ENABLE_FA3
   err=cudaMemsetAsync(b(4),0,uint64_t(capacity)*1152,stream);if(err!=cudaSuccess)return err;
   err=static_cast<cudaError_t>(riley_fa3_model_attention(stream,b(3),lk,lv,b(4),attention_workspace,attention_bytes,physical,capacity,context,0));
   if(err!=cudaSuccess)return err;
#endif
  } else {
  if constexpr(VerificationAttention)riley_verification_attention::mapped<<<dim3(32,9),32,0,stream>>>(b(3),lk,lv,b(4),capacity,meta);
  else if constexpr(GqaStaging)riley_gqa_staging::mapped<true><<<dim3(capacity,3),96,0,stream>>>(b(3),lk,lv,b(4),capacity,meta);
  else if constexpr(QueryReuse)riley_query_reuse::mapped<true><<<dim3(capacity,9),32,0,stream>>>(b(3),lk,lv,b(4),capacity,meta);
  else riley_mixed_attention::mapped_attention<ShortPrefill><<<dim3(capacity,9),32,0,stream>>>(b(3),lk,lv,b(4),capacity,meta,ContextSplit || (attention_workspace!=nullptr&&!prefill_only),attention_workspace!=nullptr&&prefill_only);
  if constexpr(ContextSplit) {
   err=riley_split_fp32::enqueue_mixed(stream,b(3),lk,lv,b(4),static_cast<float*>(scratch[7]),meta,static_cast<riley_split_fp32::MixedWorkspace*>(split_workspace),capacity,context);
   if(err!=cudaSuccess)return err;
  }
#ifdef RILEY_CUDA_ENABLE_FLASHINFER
  if(attention_workspace){
   err=static_cast<cudaError_t>((prefill_only?riley_flashinfer_prefill_run(stream,b(3),lk,lv,b(4),attention_workspace,attention_bytes):riley_flashinfer_mixed_run(stream,b(3),lk,lv,b(4),attention_workspace,attention_bytes)));
   if(err!=cudaSuccess)return err;
  }
#endif
  }
  if(capacity==1)enqueue_decode_projection<576,576,128>(stream,b(4),w(base+4),b(2),static_cast<float*>(scratch[7]));
  else if constexpr(ProjectionPipeline)riley_prefill_projection::project<576,576,128,2><<<dim3(36,(capacity+15)/16),64,0,stream>>>(b(4),w(base+4),b(2),capacity,shape+2);
  else gemm_prefill_shape_vector<576,576,128,2><<<dim3(36,(capacity+15)/16),64,0,stream>>>(b(4),w(base+4),b(2),capacity,shape+2);
  riley_prefill_pointwise::norm_rows<<<capacity,256,0,stream>>>(b(2),b(0),w(base+5),scratch[10],b(1),1,shape,capacity);
  if(capacity>1&&tiled){
   if constexpr(FfnM32)riley_prefill_ffn_row_reuse::gate_up<<<dim3(48,(capacity+31)/32),128,0,stream>>>(b(1),w(base+6),w(base+7),b(11),capacity,shape+2);
   else if constexpr(FfnAdaptive)riley_prefill_ffn_adaptive::gate_up<<<dim3(48,(capacity+15)/16),128,0,stream>>>(b(1),w(base+6),w(base+7),b(11),capacity,shape+2);
   else if constexpr(PrefillFfnPipeline)riley_prefill_ffn_pipeline::gate_up<<<dim3(48,(capacity+15)/16),128,0,stream>>>(b(1),w(base+6),w(base+7),b(11),capacity,shape+2);
   else riley_prefill51::gate_up<4><<<dim3(48,(capacity+15)/16),128,0,stream>>>(b(1),w(base+6),w(base+7),b(11),capacity,shape+2);
  }else{
  if(capacity==1&&tiled)enqueue_tile_projection<1536,576,0>(stream,b(1),w(base+6),b(8),static_cast<float*>(scratch[7]));
  else if(capacity==1)enqueue_decode_projection<1536,576,0>(stream,b(1),w(base+6),b(8),static_cast<float*>(scratch[7]));
  else if(tiled)gemm_prefill_shape_vector<1536,576,0,4,true><<<dim3(48,(capacity+15)/16),128,0,stream>>>(b(1),w(base+6),b(8),capacity,shape+2);
  else gemm_prefill_shape_vector<1536,576,0,4><<<dim3(48,(capacity+15)/16),128,0,stream>>>(b(1),w(base+6),b(8),capacity,shape+2);
  if(capacity==1&&tiled)enqueue_tile_projection<1536,576,0>(stream,b(1),w(base+7),b(9),static_cast<float*>(scratch[7]));
  else if(capacity==1)enqueue_decode_projection<1536,576,0>(stream,b(1),w(base+7),b(9),static_cast<float*>(scratch[7]));
  else if(tiled)gemm_prefill_shape_vector<1536,576,0,4,true><<<dim3(48,(capacity+15)/16),128,0,stream>>>(b(1),w(base+7),b(9),capacity,shape+2);
  else gemm_prefill_shape_vector<1536,576,0,4><<<dim3(48,(capacity+15)/16),128,0,stream>>>(b(1),w(base+7),b(9),capacity,shape+2);
  riley_prefill_pointwise::swiglu_rows<<<dim3(6,capacity),256,0,stream>>>(b(8),b(9),b(11),shape,capacity);
  }
  if(FfnM32 && capacity>1 && tiled)riley_prefill_ffn_row_reuse::down<<<dim3(36,(capacity+31)/32),64,0,stream>>>(b(11),w(base+8),b(4),capacity,shape+2);
  else if(FfnAdaptive && capacity>1 && tiled)riley_prefill_ffn_adaptive::down<<<dim3(36,(capacity+15)/16),64,0,stream>>>(b(11),w(base+8),b(4),capacity,shape+2);
  else if(PrefillFfnPipeline && capacity>1 && tiled)riley_prefill_ffn_pipeline::down<<<dim3(36,(capacity+15)/16),64,0,stream>>>(b(11),w(base+8),b(4),capacity,shape+2);
  else if(capacity==1&&tiled)enqueue_tile_projection<576,1536,320>(stream,b(11),w(base+8),b(4),static_cast<float*>(scratch[7]));
  else if(capacity==1)enqueue_decode_projection<576,1536,320>(stream,b(11),w(base+8),b(4),static_cast<float*>(scratch[7]));
  else if(tiled)gemm_prefill_shape_vector<576,1536,320,2,true><<<dim3(36,(capacity+15)/16),64,0,stream>>>(b(11),w(base+8),b(4),capacity,shape+2);
  else gemm_prefill_shape_vector<576,1536,320,2><<<dim3(36,(capacity+15)/16),64,0,stream>>>(b(11),w(base+8),b(4),capacity,shape+2);
  riley_prefill_pointwise::norm_rows<<<capacity,256,0,stream>>>(b(4),scratch[10],w(layer+1<30?base+9:1),b(0),b(1),2,shape,capacity);
 }
 mixed_select_hidden_v7<<<32,256,0,stream>>>(b(1),static_cast<__nv_bfloat16*>(selected),meta,capacity,status,publish);
 return cudaGetLastError();
}
