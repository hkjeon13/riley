from pathlib import Path
import os,subprocess,json,hashlib
r=Path('/data/riley-serving-260913-recovery');out=r/'speculative-shared-wide-build-v2';out.mkdir()
env=os.environ.copy();cuda=r/'toolchain130/nvidia/cu13'
env.update(PATH=f'{cuda}/bin:/home/psyche/.cargo/bin:/usr/bin:/bin',CUDA_HOME=str(cuda),CUDAToolkit_ROOT=str(cuda),CMAKE='/data/cmake-3.31.12/bin/cmake',CMAKE_BUILD_PARALLEL_LEVEL='4',CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(r/'target'),RILEY_FA3_SOURCE=str(r/'deps/flash-attention'),LD_LIBRARY_PATH=str(cuda/'lib'))
with (out/'cargo.jsonl').open('w') as stdout,(out/'build.log').open('w') as stderr:
 p=subprocess.run(['cargo','test','-p','riley-scheduler','--features','cuda','--test','speculative_serving_gpu','--no-run','--message-format=json'],cwd=r/'source',env=env,stdout=stdout,stderr=stderr)
(out/'exit.json').write_text(json.dumps({'exit_code':p.returncode}));print('build exit',p.returncode,flush=True)
assert p.returncode==0
for line in (out/'cargo.jsonl').read_text().splitlines():
 j=json.loads(line)
 if j.get('executable') and j.get('target',{}).get('name')=='speculative_serving_gpu':
  path=Path(j['executable']);(out/'binary.json').write_text(json.dumps({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}));print('binary recorded',flush=True)
