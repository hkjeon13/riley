// Research only: classify native same-SM80 M1 vs batched GEMM equality.
#include <cuda_runtime_api.h>
#include <cublas_v2.h>
#include <cublasLt.h>
#include <algorithm>
#include <openssl/sha.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <stdexcept>
#include <filesystem>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <unistd.h>
#include <cuda_bf16.h>
using U=uint16_t;
#define CU(x) do{if((x)!=cudaSuccess)throw std::runtime_error("CUDA API failed");}while(0)
#define BL(x) do{if((x)!=CUBLAS_STATUS_SUCCESS)throw std::runtime_error("cuBLAS API failed");}while(0)
std::string sha(const std::vector<U>&x){unsigned char d[32];SHA256((const unsigned char*)x.data(),x.size()*2,d);static const char*h="0123456789abcdef";std::string s;for(auto c:d){s+=h[c>>4];s+=h[c&15];}return s;}
std::vector<U>read(const std::string&p,size_t bytes,const std::string&digest){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f||uint64_t(f.tellg())!=bytes||bytes%2||bytes>(1ull<<30))throw std::runtime_error("input size");std::vector<U>x(bytes/2);f.seekg(0);f.read((char*)x.data(),bytes);if(!f||sha(x)!=digest)throw std::runtime_error("input SHA256");return x;}
float cv(U x){uint32_t b=uint32_t(x)<<16;float f;memcpy(&f,&b,4);return f;}
U bf(float f){uint32_t b;memcpy(&b,&f,4);return U((b+0x7fff+((b>>16)&1))>>16);}
void save(const std::string&p,const std::vector<U>&x){if(std::filesystem::exists(p))throw std::runtime_error("raw exists");std::ofstream f(p,std::ios::binary);f.write((const char*)x.data(),x.size()*2);if(!f)throw std::runtime_error("raw save");}

__global__ void compare(const U*a,const U*b,int n,unsigned*c){int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n&&a[i]!=b[i])atomicAdd(c,1u);}

#include <set>
#include <array>
int main(int argc,char**argv){try{
 if(argc!=2)return 1;cudaDeviceProp prop;CU(cudaGetDeviceProperties(&prop,0));int rt;CU(cudaRuntimeGetVersion(&rt));if(prop.major!=8||prop.minor!=0||prop.multiProcessorCount!=108||rt!=12040)throw std::runtime_error("SM80");
 cudaStream_t s;CU(cudaStreamCreateWithFlags(&s,cudaStreamNonBlocking));cublasHandle_t h;BL(cublasCreate(&h));int ver;BL(cublasGetVersion(h,&ver));if(ver!=120405)throw std::runtime_error("cuBLAS");BL(cublasSetStream(h,s));BL(cublasSetMathMode(h,CUBLAS_DEFAULT_MATH));BL(cublasSetAtomicsMode(h,CUBLAS_ATOMICS_NOT_ALLOWED));
 cublasLtHandle_t lt;BL(cublasLtCreate(&lt));void*ws;size_t wsbytes=16ul<<20;CU(cudaMalloc(&ws,wsbytes));std::ifstream plan(argv[1]);std::string line;
 while(std::getline(plan,line)){
 std::vector<std::string>v;std::stringstream ss(line);std::string f;while(std::getline(ss,f,'\t'))v.push_back(f);if(v.size()!=8)throw std::runtime_error("plan");int n=std::stoi(v[1]),k=std::stoi(v[2]);auto seed=read(v[3],128ul*k*2,v[4]),w=read(v[5],size_t(n)*k*2,v[6]);U *dw,*dx,*gold,*y;unsigned*bad;CU(cudaMalloc(&dw,w.size()*2));CU(cudaMalloc(&dx,640ul*k*2));CU(cudaMalloc(&gold,640ul*n*2));CU(cudaMalloc(&y,640ul*n*2));CU(cudaMalloc(&bad,4));CU(cudaMemcpy(dw,w.data(),w.size()*2,cudaMemcpyHostToDevice));float alpha=1,beta=0;
 auto native=[&](int m,const U*x,U*out){BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,n,m,k,&alpha,dw,CUDA_R_16BF,k,x,CUDA_R_16BF,k,&beta,out,CUDA_R_16BF,n,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));};
 cublasLtMatmulDesc_t op;cublasLtMatrixLayout_t A,B[641]{},C[641]{};cublasLtMatmulPreference_t pref;BL(cublasLtMatmulDescCreate(&op,CUBLAS_COMPUTE_32F,CUDA_R_32F));cublasOperation_t trans=CUBLAS_OP_T;BL(cublasLtMatmulDescSetAttribute(op,CUBLASLT_MATMUL_DESC_TRANSA,&trans,sizeof(trans)));BL(cublasLtMatrixLayoutCreate(&A,CUDA_R_16BF,k,n,k));
 for(int m=64;m<=576;m++){BL(cublasLtMatrixLayoutCreate(&B[m],CUDA_R_16BF,k,m,k));BL(cublasLtMatrixLayoutCreate(&C[m],CUDA_R_16BF,n,m,n));}BL(cublasLtMatmulPreferenceCreate(&pref));BL(cublasLtMatmulPreferenceSetAttribute(pref,CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES,&wsbytes,sizeof(wsbytes)));

 std::vector<cublasLtMatmulAlgo_t>algos(1);auto&a=algos[0];int cfg[7];if(n==4096){int c[]={6,18,12,0,0,1,0};memcpy(cfg,c,sizeof(c));}else if(n==1024){int c[]={6,18,12,4,4,1,0};memcpy(cfg,c,sizeof(c));}else{int c[]={6,20,11,5,4,0,0};memcpy(cfg,c,sizeof(c));} BL(cublasLtMatmulAlgoInit(lt,CUBLAS_COMPUTE_32F,CUDA_R_32F,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,cfg[0],&a));int ai=1;for(auto at:{CUBLASLT_ALGO_CONFIG_TILE_ID,CUBLASLT_ALGO_CONFIG_STAGES_ID,CUBLASLT_ALGO_CONFIG_SPLITK_NUM,CUBLASLT_ALGO_CONFIG_REDUCTION_SCHEME,CUBLASLT_ALGO_CONFIG_CTA_SWIZZLING,CUBLASLT_ALGO_CONFIG_CUSTOM_OPTION})BL(cublasLtMatmulAlgoConfigSetAttribute(&a,at,&cfg[ai++],4));
 std::vector<std::vector<U>>xs(6),gs(6);for(int st=0;st<6;st++){auto&x=xs[st];x.resize(640ul*k);for(size_t i=0;i<x.size();i++)x[i]=st==0?seed[i%seed.size()]:st==1?0:st==3?bf((int(i%17)-8)*0.03125f):st==4?(i%7==0?seed[(i*31)%seed.size()]:0):st==5?bf(cv(seed[(i*7+11)%seed.size()])*(i%2?-2.f:0.25f)):bf(cv(seed[(i*13+37)%seed.size()])*(i%3==0?-0.5f:1.5f));CU(cudaMemcpy(dx,x.data(),x.size()*2,cudaMemcpyHostToDevice));for(int b=0;b<640;b+=128)native(128,dx+b*k,gold+b*n);CU(cudaStreamSynchronize(s));gs[st].resize(640ul*n);CU(cudaMemcpy(gs[st].data(),gold,gs[st].size()*2,cudaMemcpyDeviceToHost));}
 int state=-1;auto setstate=[&](int st){if(state==st)return;CU(cudaMemcpy(dx,xs[st].data(),xs[st].size()*2,cudaMemcpyHostToDevice));CU(cudaMemcpy(gold,gs[st].data(),gs[st].size()*2,cudaMemcpyHostToDevice));state=st;};
 auto run=[&](const cublasLtMatmulAlgo_t&a,int m){return cublasLtMatmul(lt,op,&alpha,dw,A,dx,B[m],&beta,y,C[m],y,C[m],&a,ws,wsbytes,s)==0;};
 auto test=[&](const cublasLtMatmulAlgo_t&a,int m,int st){cublasLtMatmulHeuristicResult_t ch{};if(cublasLtMatmulAlgoCheck(lt,op,A,B[m],C[m],C[m],&a,&ch)!=0||ch.state!=0||ch.workspaceSize>wsbytes)return false;setstate(st);if(!run(a,m))return false;CU(cudaMemsetAsync(bad,0,4,s));compare<<<(m*n+255)/256,256,0,s>>>(gold,y,m*n,bad);CU(cudaStreamSynchronize(s));unsigned count;CU(cudaMemcpy(&count,bad,4,cudaMemcpyDeviceToHost));return count==0;};
 cudaEvent_t e0,e1;CU(cudaEventCreate(&e0));CU(cudaEventCreate(&e1));auto time=[&](auto fn){for(int i=0;i<3;i++)fn();CU(cudaEventRecord(e0,s));for(int i=0;i<20;i++)fn();CU(cudaEventRecord(e1,s));CU(cudaEventSynchronize(e1));float ms;CU(cudaEventElapsedTime(&ms,e0,e1));return ms*50;};
 printf("{\"case\":\"%s\",\"phase\":\"begin\",\"candidates\":%zu}\n",v[0].c_str(),algos.size());fflush(stdout);

 unsigned failures=0;int maximum=n==1024?512:576;for(int st=0;st<6;st++)for(int m=161;m<=maximum;m++){bool ok=test(a,m,st);if(!ok)failures++;printf("{\"case\":\"%s\",\"M\":%d,\"state\":%d,\"compared\":%d,\"exact\":%s}\n",v[0].c_str(),m,st,m*n,ok?"true":"false");}printf("{\"qualification_failures\":%u}\n",failures);fflush(stdout);if(failures)throw std::runtime_error("full qualification failed");
 auto graph_time=[&](auto fn){for(int z=0;z<3;z++)fn();CU(cudaStreamSynchronize(s));cudaGraph_t graph;cudaGraphExec_t exec;CU(cudaStreamBeginCapture(s,cudaStreamCaptureModeThreadLocal));for(int z=0;z<64;z++)fn();CU(cudaStreamEndCapture(s,&graph));CU(cudaGraphInstantiate(&exec,graph,nullptr,nullptr,0));CU(cudaEventRecord(e0,s));for(int z=0;z<8;z++)CU(cudaGraphLaunch(exec,s));CU(cudaEventRecord(e1,s));CU(cudaEventSynchronize(e1));float ms;CU(cudaEventElapsedTime(&ms,e0,e1));CU(cudaGraphExecDestroy(exec));CU(cudaGraphDestroy(graph));return ms*1000/512;};
 setstate(0);for(int rep=0;rep<3;rep++)for(int m:{256,384,512}){float nt,ct;auto old=[&]{for(int b=0;b<m;b+=128)native(128,dx+b*k,y+b*n);};auto merged=[&]{if(!run(a,m))throw std::runtime_error("time");};if(rep%2){ct=graph_time(merged);nt=graph_time(old);}else{nt=graph_time(old);ct=graph_time(merged);}printf("{\"case\":\"%s\",\"rep\":%d,\"rows\":%d,\"original_us\":%.4f,\"packed_us\":%.4f}\n",v[0].c_str(),rep,m,nt,ct);fflush(stdout);}
 for(int m=64;m<=576;m++){BL(cublasLtMatrixLayoutDestroy(B[m]));BL(cublasLtMatrixLayoutDestroy(C[m]));}BL(cublasLtMatrixLayoutDestroy(A));BL(cublasLtMatmulDescDestroy(op));BL(cublasLtMatmulPreferenceDestroy(pref));for(auto p:{dw,dx,gold,y})CU(cudaFree(p));CU(cudaFree(bad));puts("{\"phase\":\"complete\"}");fflush(stdout);
 }sleep(2);return 0;}catch(const std::exception&e){fprintf(stderr,"%s\n",e.what());return 1;}}
