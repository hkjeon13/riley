from pathlib import Path
import json,re,time
p=Path(__file__).resolve().parent;rows=[]
for c in [16,32]:
 modes={}
 for mode in ['owned-before','owned-after']:
  a=json.loads((p/f'runs/profile-c{c}/c{c}-r0-{mode}/trace.sqlite.analysis.json').read_text());projections={}
  for label,n,k in [('Q',4096,2560),('KV',1024,2560),('O',2560,4096),('GateUp',9728,2560),('Down',2560,9728)]:
   v=[r for key,r in a['matmul_geometries'].items()if re.search(r'/N'+str(n)+r'/M(\d+)/K'+str(k)+r'/B1$',key)and int(re.search(r'/M(\d+)/',key)[1])>32];projections[label]=dict(kernels=sum(r['count']for r in v),ms=sum(r['ms']for r in v))
  modes[mode]=dict(kernel_count=a['kernel_count'],kernel_sum_ms=a['kernel_sum_ms'],kernel_union_ms=a['kernel_union_ms'],gpu_kernel_span_ms=a['gpu_kernel_span_ms'],kernel_busy_fraction=a['kernel_busy_fraction'],identified_prefill_projections=projections,categories=a['categories'],cuda_api=a['cuda_api'])
 before=modes['owned-before'];after=modes['owned-after'];targets=['Q','KV','O'];bt=sum(before['identified_prefill_projections'][k]['ms']for k in targets);at=sum(after['identified_prefill_projections'][k]['ms']for k in targets)
 rows.append(dict(concurrency=c,modes=modes,target_prefill_before_ms=bt,target_prefill_after_ms=at,target_prefill_percent_change=100*(at/bt-1),all_kernel_percent_change=100*(after['kernel_count']/before['kernel_count']-1),all_gpu_kernel_time_percent_change=100*(after['kernel_sum_ms']/before['kernel_sum_ms']-1)))
x=dict(time_ns=time.time_ns(),scope='Separate64warm64keep NVTX/Nsight diagnostics, not normal throughput samples; GPU times exclude CPU API waits; anonymous captured native GEMMs are not assigned to projections; partial correlation and scheduling changes limit attribution',runs=rows);(p/'profile-comparison.json').write_text(json.dumps(x,indent=2));print([(r['concurrency'],r['target_prefill_percent_change'],r['all_kernel_percent_change'],r['all_gpu_kernel_time_percent_change'])for r in rows])
