from pathlib import Path
import json,subprocess
W=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020');R=W.parent/'riley-w0-a100-gpu67-20261019';out=W/'rejected-ipc-attempt';out.mkdir(exist_ok=False)
assert json.loads((W/'finish-state.json').read_text())['phase']=='failed'
for c,pid,ticks in [(16,2027914,'6083215119'),(32,2027915,'6083215121')]:
 name=f'final-c{c}';assert json.loads((W/f'{name}.state.json').read_text())['status']=='failed';i=6 if c==16 else 7;h=json.loads((R/f'leases-v2/gpu{i}.status.json').read_text());assert h['phase']=='idle'and h['pid']==pid and h['start_ticks']==ticks and h['allocation_bytes']==21474836480
 raw=subprocess.check_output(['nvidia-smi','-i',str(i),'--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True);assert raw.strip()==str(pid),raw
 (W/'runs'/name).rename(out/name)
 for suffix in ['.state.json','.log']:(W/(name+suffix)).rename(out/(name+suffix))
(W/'finish-state.json').rename(out/'finish-state.json')
s=(W/'finish-campaign.py').read_text();start=s.index(' run([\'python3\',str(W/\'audit-packed-paths.py\')');end=s.index(" state['phase']='normal-five-fresh'",start);s=s[:start]+s[end:];(W/'finish-normal-retry.py').write_text(s)
