from pathlib import Path
import shutil
A=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020');B=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020');B.mkdir(exist_ok=False)
for name in ['tmp','cache','runs']:(B/name).mkdir()
shutil.copytree(A/'source',B/'source')
for p in A.iterdir():
 if p.suffix in ['.py','.sh','.rs']and p.is_file():
  s=p.read_text().replace(str(A),str(B)).replace('riley-packed-v12b','riley-packed-v12bb');# path replace already gives v12b; avoid duplicate b
  s=s.replace('riley-packed-v12bbb-20261020','riley-packed-v12b-20261020');(B/p.name).write_text(s);shutil.copymode(p,B/p.name)
for name in ['final-c16.argv.json','final-c32.argv.json','profile-c16.argv.json','profile-c32.argv.json']:
 s=(A/name).read_text().replace(str(A),str(B)).replace('riley-packed-v12b"','riley-packed-v12bb"');(B/name).write_text(s)
shutil.copy2(A/'call-inspection-nvtx.so',B/'call-inspection-nvtx.so')
