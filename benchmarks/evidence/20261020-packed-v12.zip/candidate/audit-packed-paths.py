from pathlib import Path
import json,sqlite3,re,time
p=Path(__file__).resolve().parent;proof=[]
for c in [16,32]:
 root=p/f'runs/profile-c{c}';counts={}
 for mode in ['owned-before','owned-after']:
  f=root/f'c{c}-r0-{mode}/trace.sqlite';d=sqlite3.connect(f);labels={r[0]:r[1]for r in d.execute('select id,value from StringIds')};nv=[(r[0]or labels.get(r[1],''),r[2])for r in d.execute('select text,textId,count(*) from NVTX_EVENTS group by text,textId')];counts[mode]={}
  for n,k in [(4096,2560),(1024,2560),(2560,4096)]:
   v={name:num for name,num in nv if re.fullmatch(r'W0/LtMatmul/N'+str(n)+r'/M(?:\d+)/K'+str(k)+r'/B1',name)and int(re.search(r'/M(\d+)/',name)[1])>130};counts[mode][f'N{n}K{k}']=v
   assert bool(v)==(mode=='owned-after'),(c,mode,n,k,v)
  counts[mode]['all_kernel_count']=d.execute('select count(*) from CUPTI_ACTIVITY_KIND_KERNEL').fetchone()[0];counts[mode]['all_kernel_sum_ms']=d.execute('select sum(end-start)/1e6 from CUPTI_ACTIVITY_KIND_KERNEL').fetchone()[0]
  calls=[dict(name=labels[r[0]],count=r[1])for r in d.execute('select nameId,count(*) from CUPTI_ACTIVITY_KIND_RUNTIME group by nameId')if'GraphLaunch'in labels[r[0]]];assert sum(v['count']for v in calls)>0;counts[mode]['graph_launches']=calls;d.close()
 proof.append(dict(concurrency=c,actual_calls=counts))
x=dict(time_ns=time.time_ns(),passed=True,scope='Actual integrated NVTX Lt geometry for all three packed prefill shape families; baseline has none; Graph path still selected',runs=proof);(p/'packed-paths-audit.json').write_text(json.dumps(x,indent=2));print(json.dumps(x,indent=2))
