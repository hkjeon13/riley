from pathlib import Path
import json
W=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020');E=Path('/mnt/efs/nlp/psyche/riley-batched-v11e-20261020')
for c in [16,32]:
 a=json.loads((E/f'profile-c{c}.argv.json').read_text());a=[v.replace(str(E),str(W)).replace('riley-batched-v11e','riley-packed-v12b') for v in a];a[a.index('--baseline-server')+1]=str(E/'riley-batched-v11e');a[a.index('--baseline-extra')+1]=a[a.index('--candidate-extra')+1];(W/f'profile-c{c}.argv.json').write_text(json.dumps(a,indent=2))
s=(W/'audit-complete.py').read_text().replace("['final-c16','final-c32','profile-c16','profile-c32','profile-stock']","['final-c16','final-c32','profile-c16','profile-c32']");(W/'audit-complete.py').write_text(s)
