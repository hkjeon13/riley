from pathlib import Path
import subprocess,json,time,traceback
W=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020');state=dict(phase='waiting-cpu',started_ns=time.time_ns())
def save():(W/'advance-state.json').write_text(json.dumps(state,indent=2))
def run(cmd,log):
 with(W/log).open('x')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(cmd,r.returncode,log)
try:
 save()
 while not(W/'native-kv-build-and-cpu.exit').exists():time.sleep(5)
 log=(W/'native-kv-regression.log').read_text();assert (W/'riley-packed-v12b').is_file()
 # The existing four EFS ownership fixture failures are the only allowed failures.
 failures=[l.strip().split(' ... ')[0][5:]for l in log.splitlines()if l.startswith('test ')and l.endswith(' ... FAILED')]
 expected=['tests::c02_audit_directory_is_private_held_and_descriptor_relative','tests::c02_generation_audit_writer_creates_a_bound_leaf_and_marker_once','tests::c02_generation_audit_writer_refuses_schema_oversize_without_evidence','tests::c02_shutdown_writer_binds_raw_final_metrics_to_a_nonhidden_marker']
 assert sorted(failures)==sorted(expected),(failures,expected)
 state['phase']='c02';save();run(['python3',str(W/'recheck-c02.py'),'--allow-test-tmp'],'c02.outer.log')
 state['phase']='teacher';save();run(['python3',str(W/'build-teacher-final.py')],'teacher-build.outer.log')
 while not(W/'final-teacher-state.json').exists()or json.loads((W/'final-teacher-state.json').read_text())['status']=='running':time.sleep(5)
 assert json.loads((W/'final-teacher-state.json').read_text())['status']=='complete'
 state['phase']='teacher-body';save();run(['python3',str(W/'prepare-body-teacher.py')],'teacher-body.outer.log')
 while not(W/'observed-teacher-body-allR.json').exists()or json.loads((W/'observed-teacher-body-allR.json').read_text())['status']=='running':time.sleep(5)
 assert json.loads((W/'observed-teacher-body-allR.json').read_text())['status']=='complete'
 run(['python3',str(W/'audit-teachers-e.py')],'teacher-audit.outer.log')
 state['phase']='profiles';save()
 jobs=[subprocess.Popen(['python3',str(W/'run-job.py'),f'profile-c{c}'])for c in [16,32]]
 codes=[j.wait()for j in jobs];assert codes==[0,0],codes
 state.update(phase='profiles-complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
