from pathlib import Path
import json,subprocess,time
W=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020');E=Path('/mnt/efs/nlp/psyche/riley-batched-v11e-20261020');a=json.loads((E/'profile-stock.argv.json').read_text());a=[v.replace(str(E),str(W)).replace('riley-batched-v11e','riley-packed-v12b')for v in a];a[a.index('--baseline-server')+1]=str(E/'riley-batched-v11e');a[a.index('--baseline-extra')+1]=a[a.index('--candidate-extra')+1];(W/'profile-stock.argv.json').write_text(json.dumps(a,indent=2))
while json.loads((W/'final-c32.state.json').read_text())['status']=='running':time.sleep(5)
assert json.loads((W/'final-c32.state.json').read_text())['status']=='complete'
r=subprocess.run(['python3',str(W/'run-job.py'),'profile-stock']);assert r.returncode==0
f=W/'runs/profile-stock/c32-r0-vllm/trace.sqlite'
with(W/'profile-stock-analysis.outer.log').open('x')as log:r=subprocess.run(['/usr/bin/taskset','-c','48-51','python3',str(W/'analyze-profiles.py'),str(f)],stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
