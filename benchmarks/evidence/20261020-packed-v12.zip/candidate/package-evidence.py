from pathlib import Path
import json,hashlib,shutil,zipfile,time
W=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020');A=W.parent/'riley-packed-v12-20261020';out=W/'evidence-v12';out.mkdir(exist_ok=False)
assert json.loads((W/'finish-state.json').read_text())['phase']=='complete';assert json.loads((W/'profile-stock.state.json').read_text())['status']=='complete';assert json.loads((W/'final-holder-audit.json').read_text())['passed']
allowed={'.json','.jsonl','.py','.sh','.rs','.cu','.tsv','.stdout','.stderr','.log','.txt','.sha256','.patch','.md'};skip={'source','target','cache','tmp','ipc6','ipc7','vllm-cache','torch_compile_cache','__pycache__','evidence-v12'};heavy=[];copied=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def walk(root,prefix):
 for f in root.rglob('*'):
  if not f.is_file()or f.is_symlink():continue
  rel=f.relative_to(root)
  if any(v in skip for v in rel.parts):continue
  if f.suffix=='.bf16':continue
  size=f.stat().st_size
  if f.suffix in allowed and size<=16<<20:
   dest=out/prefix/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest);copied.append(dict(path=str(dest.relative_to(out)),source=str(f),size=size,sha256=sha(dest)))
  elif f.suffix in {'.sqlite','.nsys-rep','.qdrep'}or f.name in ['riley-packed-v12b','teacher-probe-final','teacher-body']:
   heavy.append(dict(path=str(f),bytes=size,sha256=sha(f)))
walk(W,Path('candidate'));walk(A/'research',Path('research'))
for name in ['source-manifest.json','qualification-binary.sha256','advance-state.json','final-teacher-state.json','observed-final-teacher-allR-Graph.json','observed-final-teacher-allR-Graph.stdout','observed-final-teacher-allR-Graph.stderr','observed-final-teacher-C1-eager.json']:
 f=A/name
 if f.exists():
  d=out/'rejected-unprepared-query'/name;d.parent.mkdir(exist_ok=True);shutil.copy2(f,d)
heavy.append(dict(path=str(W/'teacher-body-allR'),files=2048,per_file_SHA256_ledger=str(W/'final-teacher-audit.json'),scope='Full vocabulary BF16 bytes retained on EFS, not duplicated into compact archive'))
heavy.append(dict(path=str(W/'source'),files=935,per_file_SHA256_ledger=str(W/'source-manifest.json')))
(out/'heavy-files-index.json').write_text(json.dumps(heavy,indent=2));(out/'collection-receipt.json').write_text(json.dumps(dict(time_ns=time.time_ns(),source_candidate=str(W),source_research=str(A/'research'),small_files=copied,scope='Normal full SSE evidence, profile analyses, source/binary identities, exact byte-gate ledgers, rejected-attempt evidence and finite-resource receipts; heavy tensors/traces/binaries remain indexed on EFS'),indent=2))
files=sorted(f for f in out.rglob('*')if f.is_file());(out/'CHECKSUMS.sha256').write_text(''.join(sha(f)+'  '+str(f.relative_to(out))+'\n'for f in files))
archive=W/'evidence-v12.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for f in sorted(out.rglob('*')):
  if f.is_file():z.write(f,str(f.relative_to(out)))
receipt=dict(time_ns=time.time_ns(),archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),hashed_files=len(files),archive_members=len(files)+1);(W/'evidence-v12-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(receipt)
