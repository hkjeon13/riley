from pathlib import Path
import subprocess,os,json
p=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020');s=(p/'teacher-probe-final.rs').read_text();a=s.index('            for (i, case) in model_case["cases"]');b=s.index('                let prompt =',a)
s=s[:a]+'''            let body_case=model_case["cases"].as_array().ok_or("cases missing")?.iter().find(|v|v["id"]=="natural-128").ok_or("natural128 missing")?;
            let body_cases=(1..=32).map(|r|{let mut v=body_case.clone();v["id"]=json!(format!("natural-128-r{r}"));v}).collect::<Vec<_>>();
            for (i,case) in body_cases.iter().enumerate() {
'''+s[b:]
a=s.index('                    let active = if all_counts');b=s.index('                    if all_counts && step > 0',a);s=s[:a]+'                    let active=i+1;\n                    if step==0 { println!("RILEY_TEACHER_BODY_COUNT active={active}"); }\n'+s[b:];s=s.replace('json!({"scope":"teacher-forced numerical diagnostic, not quality acceptance"','json!({"all_body_counts":true,"scope":"R1..32 natural128, original full-vocabulary byte gate"');(p/'teacher-body.rs').write_text(s)
s=(p/'build-teacher-final.py').read_text();a=s.index("with(n/'teacher-final-launch.log')");s=s[:a];s=s.replace('teacher-probe-final.rs','teacher-body.rs').replace('teacher-probe-final','teacher-body').replace('teacher-final-build','teacher-body-build').replace('teacher-final-binary','teacher-body-binary').replace('teacher-final-build.argv','teacher-body-build.argv');(p/'build-teacher-body.py').write_text(s)
with(p/'teacher-body-build.outer.log').open('x')as f:r=subprocess.run(['python3',str(p/'build-teacher-body.py')],stdout=f,stderr=f)
assert r.returncode==0
r=p.parent/'riley-w0-a100-gpu67-20261019';old=p.parent/'riley-qkv-gateup-v214-20261019';name='teacher-body-allR';env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(p/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(p/name),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES='32',RILEY_TEACHER_SHRINK='',RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH='segments-v1',RILEY_OWNED_BATCH='native-prefill-sm80-v5');env.pop('CUBLAS_WORKSPACE_CONFIG',None)
a=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','/usr/bin/taskset','-c','32-39','python3',str(p/'observe-finite.py'),'--out',str(p/('observed-'+name)),'--',str(p/'teacher-body'),'--ignored','--exact','owned_batch_teacher_forced_logits_are_finite_and_reported','--nocapture','--test-threads=1']
(p/(name+'.argv.json')).write_text(json.dumps(a,indent=2))
with(p/(name+'.launch.log')).open('x')as f:proc=subprocess.Popen(a,env=env,stdout=f,stderr=f,start_new_session=True)
print(proc.pid)
