from pathlib import Path
import json,subprocess,time,traceback,hashlib
W=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020');state=dict(phase='waiting-profiles',started_ns=time.time_ns())
def save():(W/'finish-state.json').write_text(json.dumps(state,indent=2))
def run(cmd,log):
 with(W/log).open('x')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(cmd,r.returncode,log)
try:
 save()
 while json.loads((W/'advance-state.json').read_text())['phase']not in ['profiles-complete','failed']:time.sleep(5)
 assert json.loads((W/'advance-state.json').read_text())['phase']=='profiles-complete'
 run(['python3',str(W/'audit-packed-paths.py')],'packed-paths.outer.log')
 state['phase']='normal-five-fresh';save();jobs=[subprocess.Popen(['python3',str(W/'run-job.py'),f'final-c{c}'])for c in [16,32]];codes=[j.wait()for j in jobs];assert codes==[0,0],codes
 state['phase']='independent-audit';save();run(['python3',str(W/'audit-complete.py')],'audit-complete.outer.log')
 audit=json.loads((W/'independent-audit.json').read_text());matrix=[]
 for c in [16,32]:
  rows=[dict(v['record'],campaign=v['run'])for v in audit['arms']if v['run']==f'final-c{c}'];assert len(rows)==15
  assert {(r['repeat'],r['mode'])for r in rows}=={(r,m)for r in range(5)for m in ['owned-before','owned-after','vllm']};matrix.append(dict(concurrency=c,records=rows))
 (W/'primary-matrix-audit.json').write_text(json.dumps(matrix,indent=2));run(['python3',str(W/'analyze-final.py')],'analyze-final.outer.log')
 frozen=json.loads((W/'frozen-identity.json').read_text());assert all(hashlib.sha256((W/k).read_bytes()).hexdigest()==h for k,h in frozen['files'].items());m=json.loads((W/'source-manifest.json').read_text());assert all(hashlib.sha256((W/'source'/k).read_bytes()).hexdigest()==h for k,h in m.items())
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
