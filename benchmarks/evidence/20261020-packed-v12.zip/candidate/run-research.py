from pathlib import Path
import subprocess,os,json,concurrent.futures
W=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020'); R='/mnt/efs/nlp/psyche/riley-w0-a100-gpu67-20261019';os.environ['TMPDIR']=str(W/'tmp')
def run(name,index,uuid):
 p=subprocess.run(['/usr/local/cuda-12.4/bin/nvcc','-O3','-std=c++17','-arch=sm_80',str(W/'research'/f'{name}.cu'),'-lcublas','-lcublasLt','-lcrypto','-o',str(W/'research'/name)],stdout=(W/'research'/f'{name}.compile.log').open('w'),stderr=subprocess.STDOUT)
 if p.returncode:return p.returncode
 cmd=['python3',R+'/control.py','--lease-dir',R+'/leases-v2','--index',str(index),'run','--','env','CUDA_VISIBLE_DEVICES='+uuid,'LD_LIBRARY_PATH=/usr/local/cuda-12.4/lib64','TMPDIR='+str(W/'tmp'),'RILEY_DIVERGENCE_NATIVE_OUTPUT='+str(W/'research'/f'{name}-output'),'taskset','-c','24-31'if index==6 else'32-39','python3',str(W/'observe-finite.py'),'--out',str(W/'research'/f'{name}-observer'),'--timeout','2400','--',str(W/'research'/name),str(W/'research/plan.tsv')]
 (W/'research'/f'{name}.argv.json').write_text(json.dumps(cmd));p=subprocess.run(cmd,stdout=(W/'research'/f'{name}.run.log').open('w'),stderr=subprocess.STDOUT);(W/'research'/f'{name}.state.json').write_text(json.dumps(dict(returncode=p.returncode)));return p.returncode
with concurrent.futures.ThreadPoolExecutor(2)as ex: print(list(ex.map(lambda a:run(*a),[('family',6,'GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7'),('search',7,'GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0')])))
