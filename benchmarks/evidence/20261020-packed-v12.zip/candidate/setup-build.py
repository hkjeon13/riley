from pathlib import Path
import shutil,json,hashlib
W=Path('/mnt/efs/nlp/psyche/riley-packed-v12b-20261020');E=Path('/mnt/efs/nlp/psyche/riley-batched-v11e-20261020');shutil.copytree(E/'source',W/'source');(W/'cache').mkdir();(W/'runs').mkdir()
for name in ['build.sh','recheck-c02.py','build-teacher-final.py','teacher-probe-final.rs','run-teacher-final.py','prepare-body-teacher.py','audit-teachers-e.py','measure-matched.py','measure-profile.py','analyze-profiles.py','audit-final.py','audit-complete.py','analyze-final.py','stock-runtime-proof.py','run-job.py','call-inspection-nvtx.so']:
 p=E/name
 if not p.exists():print('missing',name);continue
 if name.endswith(('.py','.sh','.rs')):
  s=p.read_text().replace(str(E),str(W)).replace('riley-batched-v11e','riley-packed-v12b');(W/name).write_text(s);shutil.copymode(p,W/name)
 else:shutil.copy2(p,W/name)
for c in [16,32]:
 a=json.loads((E/f'final-c{c}.argv.json').read_text());a=[v.replace(str(E),str(W)).replace('riley-batched-v11e','riley-packed-v12b') for v in a];a[a.index('--baseline-server')+1]=str(E/'riley-batched-v11e');a[a.index('--baseline-extra')+1]=a[a.index('--candidate-extra')+1];(W/f'final-c{c}.argv.json').write_text(json.dumps(a,indent=2))
