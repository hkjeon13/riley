from pathlib import Path
import json,time,subprocess,traceback,sqlite3,re,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16f-20261021');s=dict(phase='waiting-normal',started_ns=time.time_ns())
def save():(w/'diagnostics-state.json').write_text(json.dumps(s,indent=2))
def run(args,name):
 with(w/name).open('x')as f:r=subprocess.run(args,stdout=f,stderr=f)
 assert r.returncode==0,(args,r.returncode)
try:
 save()
 while True:
  p=w/'campaign-state.json';a=json.loads(p.read_text())if p.exists()else{};assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 for c in [16,32]:
  s.update(phase='profiling',current=c);save();run(['python3',str(w/'run-job.py'),f'profile-c{c}'],f'profile-c{c}.outer.log')
 traces=[str(w/f'runs/profile-c{c}/c{c}-r0-owned-{mode}/trace.sqlite')for c in [16,32]for mode in ['before','after']];proof=[]
 for path in [Path(x)for x in traces if 'owned-after'in x]:
  d=sqlite3.connect(path);d.row_factory=sqlite3.Row;strings=dict(d.execute('select id,value from StringIds'));texts=list(strings.values());tables={r[0]for r in d.execute("select name from sqlite_master where type='table'")}
  if 'NVTX_EVENTS'in tables:texts += [r['text']or strings.get(r['textId'],'')for r in d.execute('select * from NVTX_EVENTS')]
  labels=sorted({x for x in texts if re.search(r'W0/.*/N19456/M(\d+)/K2560/B1',x)and 65<=int(re.search(r'/M(\d+)/K',x).group(1))<=576});rows=sorted({int(re.search(r'/M(\d+)/K',x).group(1))for x in labels});assert any(r>130 for r in rows),(path,'no coalesced multi-prefill execution')
  proof.append(dict(trace=str(path),trace_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),merged_prefill_labels=labels,actual_merged_rows=rows,scope='Nsight start/stop brackets only separate64keep after correctness and64warm; source pins21/20/11/0/0/0/0; not normal192keep timing'))
 (w/'actual-coalesced-dispatch-proof.json').write_text(json.dumps(proof,indent=2))
 run(['python3',str(w/'attribute-graphs.py'),*traces],'graph-diagnostics.log');run(['python3',str(w/'analyze-profile-v15.py'),*traces],'profile-diagnostics.log');run(['python3',str(w/'audit-complete.py')],'audit-complete.outer.log')
 a=json.loads((w/'independent-audit.json').read_text());assert len(a['arms'])==34;normal=[v['record']for v in a['arms']if v['run']in ['final-c16','final-c32']];assert {(v['concurrency'],v['repeat'],v['mode'])for v in normal}=={(c,r,m)for c in [16,32]for r in range(5)for m in ['owned-before','owned-after','vllm']}
 s.update(phase='complete',finished_ns=time.time_ns(),traces=traces);save()
except BaseException as err:s.update(phase='failed',error=repr(err),traceback=traceback.format_exc());save();raise
