from pathlib import Path
import json,hashlib,shutil,tarfile,subprocess,time
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16f-20261021');c=w.parent/'riley-mlp-prefill-v16c-20261021';v=w.parent/'riley-prefill-host-v15c-20261021';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(w/'target').exists();assert json.loads((c/'diagnostics-r5-state.json').read_text())['phase']=='complete'
for n in ['source','tmp','cache','ipc6','ipc7']:(w/n).mkdir(mode=0o700,exist_ok=True)
m=json.loads((c/'source-manifest.json').read_text());assert len(m)==937
for f,h in m.items():
 p=c/'source'/f;assert sha(p)==h;q=w/'source'/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
changed=['crates/riley-cuda/src/gemm.rs','crates/riley-cuda/tests/sm80_prefill_alignment_gpu.rs','crates/riley-runtime/src/llama/executor/dispatch.rs','crates/riley-runtime/src/llama/executor/owner.rs','crates/riley-runtime/src/llama/forward.rs','kernels/src/cublas_gemm_probe.cu']
with tarfile.open(w/'candidate-f-changes-r2.tar.gz')as z:
 assert sorted(z.getnames())==changed
 for t in z.getmembers():assert t.isfile()
 z.extractall(w/'source')
base=json.loads((v/'source-manifest.json').read_text());post={f:sha(w/'source'/f)for f in sorted(base)};assert [f for f,h in post.items()if h!=base[f]]==changed
(w/'pre-build-source.json').write_text(json.dumps(dict(time_ns=time.time_ns(),sources=937,changed_from_v15C=changed,source_sha256=post),indent=2))
files=['build.sh','queue-build-extra.py','queue-accuracy.py','build-gpu-c.sh','recheck-c02.py','build-teacher-final.py','teacher-probe-final.rs','teacher-body.rs','teacher-mixed.rs','build-teacher-body.py','build-teacher-mixed.py','measure-matched.py','measure-profile.py','analyze-profiles.py','audit-complete.py','analyze-final.py','run-job.py','stock-runtime-proof.py','holder.py','observe-finite.py','audit-tail-b.py','pointer-inspection.cpp','analyze-profile-v15.py','attribute-graphs.py','audit-teachers-r3.py','audit-mixed-r3.py']
for n in files:
 s=(c/n).read_text().replace('riley-mlp-prefill-v16c','riley-mlp-batch-v16f');(w/n).write_text(s)
for n in ['pointer-inspection.so','call-inspection-nvtx.so']:shutil.copy2(c/n,w/n)
for conc in [16,32]:
 s=(c/f'final-c{conc}.argv.json').read_text().replace('riley-mlp-prefill-v16c','riley-mlp-batch-v16f');a=json.loads(s);assert a[a.index('--repeats')+1]=='5'and a[a.index('--repeat-start')+1]=='0';(w/f'final-c{conc}.argv.json').write_text(json.dumps(a,indent=2))
 a=json.loads((c/f'profile-c{conc}.argv.json').read_text().replace('riley-mlp-prefill-v16c','riley-mlp-batch-v16f'));a[a.index('--modes')+1]='owned-before,owned-after';(w/f'profile-c{conc}.argv.json').write_text(json.dumps(a,indent=2))
for name,cmd in [('build',['bash',str(w/'build.sh')]),('build-extra',['python3',str(w/'queue-build-extra.py')]),('accuracy',['python3',str(w/'queue-accuracy.py')])]:
 with(w/(name+'.outer.log')).open('x')as f:p=subprocess.Popen(cmd,stdout=f,stderr=f,start_new_session=True)
 print(name,p.pid)
