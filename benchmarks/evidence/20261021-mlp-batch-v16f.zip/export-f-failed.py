from pathlib import Path
import json,time,hashlib,re,zipfile,difflib
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16f-20261021');v=w.parent/'riley-prefill-host-v15c-20261021';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((w/'accuracy-r3-state.json').read_text())['phase']=='complete';assert json.loads((w/'bounded576-state.json').read_text())['phase']=='failed';assert not(w/'runs').exists()
m=json.loads((w/'pre-build-source.json').read_text())['source_sha256'];assert len(m)==937 and all(sha(w/'source'/f)==h for f,h in m.items());base=json.loads((v/'source-manifest.json').read_text());changed=[f for f,h in m.items()if h!=base[f]];assert len(changed)==6
(w/'source-manifest.json').write_text(json.dumps(m,indent=2));binary=w/'riley-mlp-batch-v16f';assert sha(binary)==(w/'qualification-binary.sha256').read_text().split()[0]
(w/'source-lineage.json').write_text(json.dumps(dict(time_ns=time.time_ns(),baseline_commit='57502e7a0fafd165966071e88b3e8a56cdea0e3d',baseline_binary=str(v/'riley-prefill-host-v15c'),baseline_sha256=sha(v/'riley-prefill-host-v15c'),binary=str(binary),binary_sha256=sha(binary),qualified_source_count=937,changed_sources=changed,source_manifest_sha256=sha(w/'source-manifest.json'),scope='Original numerical suite passed; serving-capacity constructor failed before output or normal benchmark; source matches prebuild snapshot'),indent=2))
patch=''.join(''.join(difflib.unified_diff((v/'source'/f).read_text().splitlines(True),(w/'source'/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f))for f in changed);(w/'candidate.patch').write_text(patch)
runs=json.loads((w/'final-teacher-r3-audit.json').read_text())['runs'];mixed=json.loads((w/'mixed-byte-r3-audit.json').read_text())['runs'];assert sum(r['files']for r in runs)+sum(r['rows']for r in mixed)==4480
receipts=[];gpu_functions=0
for name in ['final-teacher-C1-eager-r3','final-teacher-allR-Graph-r3','teacher-body-allR-r3','teacher-mixed-r3','teacher-mixed-no-output-r3','memory_gpu','owned_hf_command_batch_gpu','host_runtime_gpu','sm80_prefill_alignment_gpu','bounded576']:
 p=w/('observed-'+name+'.json');a=json.loads(p.read_text());assert a['returncode']==(101 if name=='bounded576'else 0)
 samples=[json.loads(l)for l in p.with_suffix('.samples.jsonl').read_text().splitlines()];peak=max(s['device_memory_mib']for s in samples);assert peak<=22528
 receipts.append(dict(name=name,returncode=a['returncode'],status=a['status'],peak_whole_device_MiB=peak,receipt_sha256=sha(p)))
 if name in ['memory_gpu','owned_hf_command_batch_gpu','host_runtime_gpu','sm80_prefill_alignment_gpu']:gpu_functions+=int(re.search(r'test result: ok\. (\d+) passed',p.with_suffix('.stdout').read_text()).group(1))
assert gpu_functions==6;error=(w/'observed-bounded576.stderr').read_text();assert 'native_prefill_merged_scratch'in error and 'raw scratch must be sized before Graph preparation'in error
assert not list((w/'teacher-bounded576-output').glob('*.bf16'))
(w/'qualification-decision.json').write_text(json.dumps(dict(time_ns=time.time_ns(),adopted=False,original_native_HF_files4480_all_equal=True,GPU_contract_functions=gpu_functions,new_merged_raw_cases=66,CPU_passed=524,CPU_ignored=40,normal_arms=0,bounded_constructor_rejected_before_any_logits=True,reason='Guard incorrectly treated preallocated empty OwnedDecodeSegment slots as prepared Graphs; .is_empty() conflated slots with graph handles. G changes guard to actual graph/warmed/replayed state and rebuilds independently.',resources=receipts),indent=2))
heavy={};files=[];skip={'source','target','tmp','cache','__pycache__','ipc6','ipc7'};allowed={'.json','.jsonl','.log','.txt','.py','.sh','.stdout','.stderr','.cu','.cuh','.cpp','.sse','.h','.hpp','.exit','.sha256','.rs','.patch'}
for p in w.rglob('*'):
 if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
 with p.open('rb')as f:magic=f.read(4)
 if p.suffix=='.bf16'or magic==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
 if p.suffix in allowed and p.name not in ['heavy-evidence-index.json','evidence-archive-receipt.json']:files.append(p)
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2));files.append(w/'heavy-evidence-index.json');manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)};z=w/'evidence-archive.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as f:
 for p in sorted(files):f.write(p,str(p.relative_to(w)))
 f.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
r=dict(archive=str(z),bytes=z.stat().st_size,entries=len(files)+1,sha256=sha(z));(w/'evidence-archive-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
