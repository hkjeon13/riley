from pathlib import Path
import json,time,subprocess,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');b=w.parent/'riley-prefill-host-v15b-20261021';state=dict(phase='waiting-basic-teachers-and-B-profiles',started_ns=time.time_ns())
def save():(w/'campaign-r3-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  a=json.loads((w/'accuracy-r3-state.json').read_text());assert a['phase']!='failed',a
  if all(n in a['completed']for n in ['final-teacher-C1-eager','final-teacher-allR-Graph']):break
  time.sleep(3)
 rows=[]
 for line in(w/'ledger-gpu-build.jsonl').read_text().splitlines():
  try:rows.append(json.loads(line))
  except ValueError:pass
 assert any(a.get('reason')=='build-finished'and a['success']for a in rows),'GPU contract tests must compile before final normal comparison'
 with(w/'freeze-r2.outer.log').open('x')as f:p=subprocess.run(['python3',str(w/'freeze.py')],stdout=f,stderr=f)
 assert p.returncode==0
 for name in ['final-c16','final-c32']:
  state.update(phase='measuring',current=name);save()
  with(w/(name+'.orchestrator.log')).open('x')as f:p=subprocess.run(['python3',str(w/'run-job.py'),name],stdout=f,stderr=f)
  assert p.returncode==0,(name,p.returncode)
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
