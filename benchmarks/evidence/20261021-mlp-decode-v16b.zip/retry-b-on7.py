from pathlib import Path
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021')
s=(w/'queue-accuracy.py').read_text().replace('accuracy-r2-state','accuracy-r3-state').replace("'-r2'","'-r3'").replace('audit-teachers-r2.py','audit-teachers-r3.py').replace('audit-mixed-r2.py','audit-mixed-r3.py').replace('GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7','GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0').replace("'--index','6'","'--index','7'").replace("'24-31'","'32-39'");(w/'queue-accuracy-r3.py').write_text(s)
for name in ['audit-teachers','audit-mixed']:
 p=w/(name+'-r2.py');s=p.read_text().replace('-r2','-r3');(w/(name+'-r3.py')).write_text(s)
s=(w/'queue-normal.py').read_text().replace('accuracy-r2-state','accuracy-r3-state').replace('campaign-r2-state','campaign-r3-state');(w/'queue-normal-r3.py').write_text(s)
s=(w/'queue-normal-analysis.py').read_text().replace('campaign-r2-state','campaign-r3-state').replace('normal-analysis-state','normal-analysis-r3-state');(w/'queue-normal-analysis-r3.py').write_text(s)
