from pathlib import Path
import json,time,subprocess,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');s=dict(phase='waiting-c32-profile',started_ns=time.time_ns())
def save():(w/'diagnostics-state.json').write_text(json.dumps(s,indent=2))
def run(args,name):
 with(w/name).open('x')as f:r=subprocess.run(args,stdout=f,stderr=f)
 assert r.returncode==0,(args,r.returncode)
try:
 save()
 while True:
  p=w/'dispatch-proof-r4-state.json';a=json.loads(p.read_text())if p.exists()else{}
  assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 s['phase']='c16-profile';save();run(['python3',str(w/'run-job.py'),'profile-c16'],'profile-c16.outer.log')
 traces=[str(w/f'runs/profile-c{c}/c{c}-r0-owned-{mode}/trace.sqlite')for c in [16,32]for mode in ['before','after']]
 run(['python3',str(w/'attribute-graphs.py'),*traces],'graph-diagnostics.log')
 run(['python3',str(w/'analyze-profile-v15.py'),*traces],'profile-diagnostics.log')
 run(['python3',str(w/'audit-complete.py')],'audit-complete.outer.log')
 s.update(phase='complete',finished_ns=time.time_ns(),traces=traces);save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
