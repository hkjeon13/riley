from pathlib import Path
import json,time,subprocess,traceback,sqlite3,collections,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');state=dict(phase='waiting-normal',started_ns=time.time_ns())
def save():(w/'dispatch-proof-r4-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  a=json.loads((w/'campaign-r4-state.json').read_text());assert a['phase']!='failed',a
  if a['phase']=='complete':break
  time.sleep(3)
 state['phase']='profiling';save()
 with(w/'profile-c32.outer.log').open('x')as f:p=subprocess.run(['python3',str(w/'run-job.py'),'profile-c32'],stdout=f,stderr=f)
 assert p.returncode==0
 path=w/'runs/profile-c32/c32-r0-owned-after/trace.sqlite';d=sqlite3.connect(path);d.row_factory=sqlite3.Row;s=dict(d.execute('select id,value from StringIds'));ks=d.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL').fetchall();proof={}
 for token in ['sm80_batched_qk_dispatch','sm80_batched_softmax','sm80_batched_pv_dispatch']:
  rs=[r for r in ks if token in s[r['demangledName']]];assert rs;grids=collections.Counter((r['gridX'],r['gridY'],r['gridZ'],r['blockX'],r['blockY'],r['blockZ'])for r in rs)
  if token=='sm80_batched_pv_dispatch':assert all(v[0]==2 and v[1]==16 and v[3:]==(128,1,1)for v in grids)
  proof[token]=dict(count=len(rs),kernel_sum_ms=sum(r['end']-r['start']for r in rs)/1e6,grids=[dict(geometry=k,count=v)for k,v in grids.items()])
 assert len({v['count']for v in proof.values()})==1
 sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();lineage=json.loads((w/'source-lineage.json').read_text());assert sha(w/'riley-mlp-decode-v16b')==lineage['binary_sha256']
 (w/'actual-decode-dispatch-proof.json').write_text(json.dumps(dict(scope='Separate64-keep C32 profile of exact candidate binary; not normal timing or a before/stock comparison',binary_sha256=lineage['binary_sha256'],trace=str(path),trace_sha256=sha(path),actual_decode_kernels=proof,no_hot_device_allocation_change='checked independently by native/HF and GPU contracts'),indent=2))
 with(w/'audit-final.outer.log').open('x')as f:p=subprocess.run(['python3',str(w/'audit-final.py')],stdout=f,stderr=f)
 assert p.returncode==0
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
