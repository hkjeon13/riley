from pathlib import Path
import json,time,subprocess,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');c=w.parent/'riley-mlp-prefill-v16c-20261021';state=dict(phase='waiting-library-component',started_ns=time.time_ns())
def save():(w/'campaign-r4-state.json').write_text(json.dumps(state,indent=2))
try:
 save();assert json.loads((w/'accuracy-r3-state.json').read_text())['phase']=='complete'
 while True:
  p=c/'down-lt-search-state.json'
  if p.exists():
   a=json.loads(p.read_text());assert a['phase']!='failed',a
   if a['phase']=='complete':break
  time.sleep(3)
 for name in ['final-c16','final-c32']:
  state.update(phase='measuring',current=name);save()
  with(w/(name+'.orchestrator.log')).open('x')as f:p=subprocess.run(['python3',str(w/'run-job.py'),name],stdout=f,stderr=f)
  assert p.returncode==0,(name,p.returncode)
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
