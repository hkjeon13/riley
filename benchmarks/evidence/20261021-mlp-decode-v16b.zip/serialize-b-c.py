from pathlib import Path
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');s=(w/'freeze.py').read_text();prefix='''from pathlib import Path
import json,time
b=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021')
c=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021')
while True:
 a=json.loads((b/'accuracy-r3-state.json').read_text());assert a['phase']!='failed',a
 if a['phase']=='complete':break
 time.sleep(2)
while True:
 p=c/'prefill-lt-r3-state.json'
 if p.exists():
  a=json.loads(p.read_text());assert a['phase']!='failed',a
  if a['phase']=='complete':break
 time.sleep(2)
''';(w/'freeze.py').write_text(prefix+s)
