from pathlib import Path
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021')
s=(w/'queue-normal-analysis-r3.py').read_text().replace('campaign-r3-state','campaign-r4-state').replace('normal-analysis-r3-state','normal-analysis-r4-state');(w/'queue-normal-analysis-r4.py').write_text(s)
s=(w/'queue-b-profile.py').read_text().replace('campaign-r3-state','campaign-r4-state').replace('dispatch-proof-state','dispatch-proof-r4-state');(w/'queue-b-profile-r4.py').write_text(s)
