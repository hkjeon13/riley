from pathlib import Path
import json,time
b=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021')
c=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021')
while True:
 a=json.loads((b/'accuracy-r3-state.json').read_text());assert a['phase']!='failed',a
 if a['phase']=='complete':break
 time.sleep(2)
while True:
 p=c/'prefill-lt-r3-state.json'
 if p.exists():
  a=json.loads(p.read_text());assert a['phase']!='failed',a
  if a['phase']=='complete':break
 time.sleep(2)
from pathlib import Path
import json,hashlib,time
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');v=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();base=json.loads((v/'source-manifest.json').read_text());files=list(base);m={f:sha(w/'source'/f)for f in sorted(files)};assert len(m)==937
(w/'source-manifest.json').write_text(json.dumps(m,indent=2));binary=w/'riley-mlp-decode-v16b';assert sha(binary)==(w/'qualification-binary.sha256').read_text().split()[0]
inputs={str(p):sha(p)for p in [binary,w/'measure-matched.py',w/'final-c16.argv.json',w/'final-c32.argv.json']}
(w/'source-lineage.json').write_text(json.dumps(dict(time_ns=time.time_ns(),baseline_binary=str(v/'riley-prefill-host-v15c'),baseline_sha256=sha(v/'riley-prefill-host-v15c'),binary=str(binary),binary_sha256=sha(binary),qualified_source_count=937,changed_sources=[f for f,h in m.items()if base.get(f)!=h],source_manifest_sha256=sha(w/'source-manifest.json'),normal_inputs_sha256=inputs),indent=2));print('source937 and normal inputs frozen')
