from pathlib import Path
import json
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');c=w.parent/'riley-prefill-host-v15c-20261021'
s=(c/'queue-accuracy-r2-c.py').read_text().replace(str(c),str(w)).replace(" while json.loads((b/'post-inplace-state.json').read_text())['phase']!='complete':time.sleep(2)"," while not (w/'build-extra-state.json').exists() or json.loads((w/'build-extra-state.json').read_text())['phase'] not in ['complete','failed']:time.sleep(2)\n assert json.loads((w/'build-extra-state.json').read_text())['phase']=='complete'")
(w/'queue-accuracy.py').write_text(s)
s=(c/'freeze-c.py').read_text().replace(str(c),str(w)).replace("v=w.parent/'riley-piecewise-v13b-20261020'",f"v=Path({str(c)!r})").replace("files=list(base)+['kernels/src/command_batch_index.hpp','crates/riley-cuda/tests/sm80_prefill_alignment_gpu.rs']","files=list(base)").replace("riley-prefill-host-v15c","riley-mlp-decode-v16b").replace("v/'riley-piecewise-v13b'","v/'riley-prefill-host-v15c'");(w/'freeze.py').write_text(s)
s=(c/'queue-normal-r2-c.py').read_text().replace(str(c),str(w));a=s.index('  a=json.loads(');b=s.index('  time.sleep(3)',a)
s=s[:a]+"  a=json.loads((w/'accuracy-r2-state.json').read_text());assert a['phase']!='failed',a\n  if all(n in a['completed']for n in ['final-teacher-C1-eager','final-teacher-allR-Graph']):break\n"+s[b:];s=s.replace("w/'freeze-c.py'","w/'freeze.py'");(w/'queue-normal.py').write_text(s)
# Normal analysis inherited the actual source/binary checks; no helper changes frozen normal inputs.
s=(w/'queue-normal-analysis-c.py').read_text();(w/'queue-normal-analysis.py').write_text(s)
