from pathlib import Path
import hashlib,json,time
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');v=w.parent/'riley-prefill-host-v15c-20261021';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((w/'accuracy-r3-state.json').read_text())['phase']=='complete'
base=json.loads((v/'source-manifest.json').read_text());assert len(base)==937
m={f:sha(w/'source'/f)for f in sorted(base)};changed=[f for f,h in m.items()if h!=base[f]];assert changed==['kernels/src/cublas_gemm_probe.cu'],changed
(w/'source-manifest.json').write_text(json.dumps(m,indent=2));binary=w/'riley-mlp-decode-v16b';assert sha(binary)==(w/'qualification-binary.sha256').read_text().split()[0]
for c in [16,32]:
 a=json.loads((w/f'final-c{c}.argv.json').read_text());assert a[a.index('--baseline-server')+1]==str(v/'riley-prefill-host-v15c');assert a[a.index('--candidate-binary')+1]==str(binary)
 for key,value in [('--concurrency',str(c)),('--repeats','5'),('--warm','64'),('--keep','192'),('--gpu','GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0')]:assert a[a.index(key)+1]==value,(key,a)
inputs={str(p):sha(p)for p in [binary,w/'measure-matched.py',w/'final-c16.argv.json',w/'final-c32.argv.json']}
a=dict(time_ns=time.time_ns(),baseline_binary=str(v/'riley-prefill-host-v15c'),baseline_sha256=sha(v/'riley-prefill-host-v15c'),binary=str(binary),binary_sha256=sha(binary),qualified_source_count=937,changed_sources=changed,source_manifest_sha256=sha(w/'source-manifest.json'),normal_inputs_sha256=inputs)
assert a['baseline_sha256']=='233c3a6a81bad76d65577bacd5837d59e2ebe1dd52a8fde73f3cd07a38cf937a'
(w/'source-lineage.json').write_text(json.dumps(a,indent=2));print('qualified source937, exact v15C baseline and normal inputs frozen')
