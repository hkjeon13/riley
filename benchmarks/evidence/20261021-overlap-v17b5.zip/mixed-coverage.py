from pathlib import Path
import sqlite3,json,collections,sys,hashlib
w=Path(sys.argv[1]);proof=json.loads((w/'actual-candidate-dispatch.json').read_text());result=[]
for p in proof:
 path=Path(p['trace']);db=sqlite3.connect(path);db.row_factory=sqlite3.Row;rows=list(db.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL order by start'));names=dict(db.execute('select id,value from StringIds'));mixed={x['graph']for x in p['mixed_full_body_graphs']};total_ms=sum(r['end']-r['start']for r in rows)/1e6;selected=[r for r in rows if r['graphId']in mixed];ms=sum(r['end']-r['start']for r in selected)/1e6;graphs=[]
 for gid in sorted(mixed):
  gr=[r for r in selected if r['graphId']==gid];counts=collections.Counter(r['graphNodeId']for r in gr);freq=sorted(set(counts.values()));graphs.append(dict(graph=gid,nodes=len(counts),node_execution_counts=freq,observed_complete_launches=freq[0]if len(freq)==1 else None,kernel_sum_ms=sum(r['end']-r['start']for r in gr)/1e6,scope='Uniform node execution counts establish complete launches; nonuniform counts remain unaggregated.'))
 result.append(dict(trace=str(path),trace_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),all_kernel_sum_ms=total_ms,detected_mixed_root_kernel_sum_ms=ms,detected_mixed_root_fraction_of_kernel_sum=ms/total_ms if total_ms else 0,detected_mixed_graphs=graphs,actual_mixed_graph_hit=bool(mixed),scope='Only separate measured64keep; startup/correctness/warmup not captured. Sums over actual detected Graph IDs, not an estimate of normal192keep causal speedup or all eligible mixed batches. No hardware counters.'))
 db.close()
(w/'mixed-graph-coverage.json').write_text(json.dumps(result,indent=2));print([(x['detected_mixed_root_fraction_of_kernel_sum'],len(x['detected_mixed_graphs']))for x in result])
