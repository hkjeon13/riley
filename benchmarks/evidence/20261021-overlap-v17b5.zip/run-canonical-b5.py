from pathlib import Path
import json,time,subprocess,os,traceback,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-overlap-v17b5-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';old=w.parent/'riley-qkv-gateup-v214-20261019';s=dict(phase='waiting-accuracy',started_ns=time.time_ns());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(w/'canonical-state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 while True:
  p=w/'build-extra-state.json';a=json.loads(p.read_text())if p.exists()else{};assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 text=(w/'teacher-mixed.rs').read_text();old_slot='order.iter().enumerate().filter(|(j,r)|*j>idx&&(!no_output_prefill||tick!=**r)).count()';assert text.count(old_slot)==2
 new_slot='if tick==copy {active-1}else{order[..idx].iter().filter(|&&r|r!=tick).count()}'
 text=text.replace(old_slot,'('+new_slot+')');(w/'teacher-canonical.rs').write_text(text)
 builder=(w/'build-teacher-mixed.py').read_text().replace('teacher-mixed','teacher-canonical');(w/'build-teacher-canonical.py').write_text(builder)
 with(w/'canonical-build.outer.log').open('x')as f:q=subprocess.run(['python3',str(w/'build-teacher-canonical.py')],stdout=f,stderr=f)
 assert q.returncode==0
 s['phase']='numerical';save()
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'teacher-canonical-output'),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES='32',RILEY_TEACHER_SHRINK='',RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH='segments-v1',RILEY_OWNED_BATCH='native-prefill-sm80-v5');env.pop('CUBLAS_WORKSPACE_CONFIG',None);env.pop('RILEY_MIXED_NO_OUTPUT_PREFILL',None)
 cmd=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'observed-canonical'),'--',str(w/'teacher-canonical'),'--ignored','--exact','owned_batch_teacher_forced_logits_are_finite_and_reported','--nocapture','--test-threads=1'];(w/'canonical.argv.json').write_text(json.dumps(cmd,indent=2))
 with(w/'canonical.launch.log').open('x')as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=f)
 assert q.returncode==0
 files=list((w/'teacher-canonical-output').glob('*.bf16'));assert len(files)==1024
 result=json.loads((w/'teacher-canonical-output/result.json').read_text());rows=[row for model in result['models']for case in model['cases']for row in case['rows']];assert len(rows)==1024 and all(row['bytes_equal']for row in rows)
 hashes={p.name:sha(p)for p in files};(w/'canonical-byte-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),files=1024,all_literal_equal_to_original_HF_native=True,scope='Original mixed natural128 forced tokens and permuted request order, only output-slot assignment changed to decode-first canonical, references/tolerance unchanged. Exercises eligible startup mixed Graph keys; original reversed-slot and no-output cases remain independently required.',raw_file_sha256=hashes,teacher_binary_sha256=sha(w/'teacher-canonical')),indent=2));s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as err:s.update(phase='failed',error=repr(err),traceback=traceback.format_exc());save();raise
