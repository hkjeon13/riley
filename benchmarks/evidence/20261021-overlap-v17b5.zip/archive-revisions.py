from pathlib import Path
import sys,json,hashlib,shutil,difflib,time
w=Path(sys.argv[1]);mode=sys.argv[2];r=w.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();index={}
if mode=='A':
 old=r/'riley-projection-v17a2-20261021';assert json.loads((old/'research-state.json').read_text())['phase']=='complete'
 dest=w/'operand-staging-screen';dest.mkdir(exist_ok=True)
 for p in [old/'research-state.json',*list((old/'research').glob('*'))]:
  if not p.is_file():continue
  with p.open('rb')as f:magic=f.read(4)
  if magic==b'\x7fELF':index[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
  shutil.copy2(p,dest/p.name)
else:
 base=json.loads((r/'riley-prefill-host-v15c-20261021/source-manifest.json').read_text())
 for rev in ['b2','b3']:
  old=r/f'riley-overlap-v17{rev}-20261021';assert json.loads((old/'accuracy-r3-state.json').read_text())['phase']=='complete'
  dest=w/'prior-qualified-revisions'/rev;dest.mkdir(parents=True,exist_ok=True)
  m=json.loads((old/'pre-build-source.json').read_text())['source_sha256'];changed=[f for f,h in m.items()if h!=base[f]];assert len(changed)==7
  patch=''.join(''.join(difflib.unified_diff((r/'riley-prefill-host-v15c-20261021/source'/f).read_text().splitlines(True),(old/'source'/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f))for f in changed);(dest/'candidate.patch').write_text(patch)
  for p in old.iterdir():
   if p.is_file()and p.suffix in ['.json','.jsonl','.py','.sh','.log','.stdout','.stderr','.exit','.sha256','.rs']:
    shutil.copy2(p,dest/p.name)
  for n in ['final-teacher-r3-audit.json','mixed-byte-r3-audit.json','bounded576-byte-audit.json','canonical-byte-audit.json']:
   p=old/n
   if p.exists():index[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p),scope='Contains literal BF16 file hashes; raw outputs stay at this revision EFS path')
  binary=old/old.name.replace('-20261021','');index[str(binary)]=dict(bytes=binary.stat().st_size,sha256=sha(binary))
  if rev=='b3':assert json.loads((old/'canonical-state.json').read_text())['phase']=='complete'
if mode=='B':
 old=r/'riley-overlap-v17b4-20261021'
 assert json.loads((old/'experiment-state.json').read_text())['phase']=='complete'
 for name in ['evidence-archive.zip','evidence-archive-receipt.json','source-lineage.json','final-statistics.json']:
  p=old/name;index[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p),scope='Completed, rejected B4; separate normal campaign, not pooled')
(w/'prior-revision-EFS-index.json').write_text(json.dumps(dict(time_ns=time.time_ns(),entries=index,scope='Preserved negative operand screen or superseded pre-normal executor revisions; not pooled into current normal comparisons'),indent=2))
