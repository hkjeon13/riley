from pathlib import Path
import shutil,subprocess,json,time,traceback
r=Path('/mnt/efs/nlp/psyche');w=r/'riley-overlap-v17b5-20261021';a=r/'riley-projection-v17a-20261021'
shutil.copy2(w/'export-v17-b5.py',w/'export-v17.py');shutil.copy2(w/'queue-experiment-b5.py',w/'queue-experiment.py');shutil.copy2(a/'audit-holders.py',w/'audit-holders.py')
for n,args in [('canonical',['python3',str(w/'run-canonical-b5.py')]),('experiment',['python3',str(w/'queue-experiment.py'),str(w),'B'])]:
 with(w/(n+'.outer.log')).open('x')as f:p=subprocess.Popen(args,stdout=f,stderr=f,start_new_session=True)
 print(n,p.pid,flush=True)
checks=[(w,n)for n in ['accuracy-r3-state.json','canonical-state.json','build-extra-state.json','bounded576-state.json']]
s=dict(phase='waiting-qualification',started_ns=time.time_ns())
def save():(w/'sequence-state.json').write_text(json.dumps(s,indent=2))
try:
 while True:
  states={str(root/name):json.loads((root/name).read_text())if(root/name).exists()else{} for root,name in checks}
  s['dependencies']={k:v.get('phase')for k,v in states.items()};save()
  assert not any(v.get('phase')=='failed'for v in states.values()),states
  if all(v.get('phase')=='complete'for v in states.values()):break
  time.sleep(5)
 proof=dict(time_ns=time.time_ns(),reason='All finite qualification and compilation complete, no concurrent experiment build or GPU work. Internal sequencing only.',dependencies=s['dependencies'])
 for root in [w]:(root/'normal-ready.json').write_text(json.dumps(proof,indent=2))
 s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
