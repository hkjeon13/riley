from pathlib import Path
import os,json,time,subprocess,traceback,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-overlap-v17b2-20261021');b=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';old=w.parent/'riley-qkv-gateup-v214-20261019';state={'phase': 'resuming-auditor', 'completed': ['final-teacher-C1-eager', 'final-teacher-allR-Graph', 'teacher-body-allR', 'teacher-mixed', 'teacher-mixed-no-output'], 'started_ns': 1792573724660421566, 'current': 'teacher-mixed-no-output-r3', 'error': "AssertionError(('audit-teachers-r3.py', 1))", 'traceback': 'Traceback (most recent call last):\n  File "/mnt/efs/nlp/psyche/riley-overlap-v17b2-20261021/queue-accuracy.py", line 30, in <module>\n    for name in [\'audit-teachers-r3.py\',\'audit-mixed-r3.py\']:script(name)\n  File "/mnt/efs/nlp/psyche/riley-overlap-v17b2-20261021/queue-accuracy.py", line 7, in script\n    assert p.returncode==0,(name,p.returncode)\nAssertionError: (\'audit-teachers-r3.py\', 1)\n', 'resumed_ns': 1792575539505137080}
def save():(w/'accuracy-r3-state.json').write_text(json.dumps(state,indent=2))
def script(name,args=[]):
 with(w/(name+'.resumed.outer.log')).open('x')as f:p=subprocess.run(['python3',str(w/name)]+args,stdout=f,stderr=f)
 assert p.returncode==0,(name,p.returncode)
try:
 for name in ['audit-teachers-r3.py','audit-mixed-r3.py']:script(name)
 artifacts=[]
 for line in(w/'ledger-gpu-build.jsonl').read_text().splitlines():
  try:a=json.loads(line)
  except ValueError:continue
  if a.get('reason')=='compiler-artifact'and a.get('executable')and a['target']['name']in ['host_runtime_gpu','memory_gpu','owned_hf_command_batch_gpu','sm80_prefill_alignment_gpu']:artifacts.append(a)
 assert len(artifacts)==4,[a['target']['name']for a in artifacts]
 for item in artifacts:
  name=item['target']['name'];state.update(phase='gpu-contracts',current=name);save();cmd=[item['executable'],'--ignored','--nocapture','--test-threads=1']
  if name in ['host_runtime_gpu','memory_gpu']:cmd+=['command_batch']
  env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/('gpu-contract-'+name)))
  a=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/('observed-'+name)),'--']+cmd;(w/(name+'.argv.json')).write_text(json.dumps(a,indent=2))
  with(w/(name+'.launch.log')).open('x')as f:p=subprocess.run(a,env=env,stdout=f,stderr=f)
  assert p.returncode==0,(name,p.returncode);state['completed'].append(name);save()
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
