from pathlib import Path
import json,time,subprocess,hashlib,sys,traceback,sqlite3,re
w=Path(sys.argv[1]);mode=sys.argv[2];v=w.parent/'riley-prefill-host-v15c-20261021';s=dict(phase='waiting-accuracy',started_ns=time.time_ns());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(w/'experiment-state.json').write_text(json.dumps(s,indent=2))
def run(argv,name):
 with(w/name).open('x')as f:r=subprocess.run(argv,stdout=f,stderr=f)
 assert r.returncode==0,(argv,r.returncode,name)
def wait(path):
 while True:
  a=json.loads(path.read_text())if path.exists()else{};assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':return
  time.sleep(3)
try:
 save();wait(w/'accuracy-r3-state.json');wait(w/'bounded576-state.json')
 s['phase']='waiting-quiet-builds';save()
 # This is an internal sequencing marker, not a new user permission gate.
 # All compilation and finite accuracy work must be quiet before normal timing.
 while not(w/'normal-ready.json').exists():time.sleep(3)
 if mode=='B':wait(w.parent/'riley-projection-v17a-20261021/experiment-state.json')
 m=json.loads((w/'pre-build-source.json').read_text())['source_sha256'];assert len(m)==937 and all(sha(w/'source'/f)==h for f,h in m.items());base=json.loads((v/'source-manifest.json').read_text());changed=[f for f in m if m[f]!=base[f]];assert len(changed)==(1 if mode=='A'else 7)
 (w/'source-manifest.json').write_text(json.dumps(m,indent=2));binary=w/w.name.replace('-20261021','');assert sha(binary)==(w/'qualification-binary.sha256').read_text().split()[0]
 inputs={str(p):sha(p)for p in[binary,w/'measure-matched.py',w/'final-c16.argv.json',w/'final-c32.argv.json']}
 assert sha(v/'riley-prefill-host-v15c')=='233c3a6a81bad76d65577bacd5837d59e2ebe1dd52a8fde73f3cd07a38cf937a'
 for c in[16,32]:
  a=json.loads((w/f'final-c{c}.argv.json').read_text())
  for k,val in[('--baseline-server',str(v/'riley-prefill-host-v15c')),('--candidate-binary',str(binary)),('--repeats','5'),('--repeat-start','0'),('--warm','64'),('--keep','192'),('--concurrency',str(c))]:assert a[a.index(k)+1]==val,(k,a)
 (w/'source-lineage.json').write_text(json.dumps(dict(time_ns=time.time_ns(),baseline_commit='57502e7a0fafd165966071e88b3e8a56cdea0e3d',baseline_binary=str(v/'riley-prefill-host-v15c'),baseline_sha256=sha(v/'riley-prefill-host-v15c'),binary=str(binary),binary_sha256=sha(binary),qualified_source_count=937,changed_sources=changed,source_manifest_sha256=sha(w/'source-manifest.json'),normal_inputs_sha256=inputs),indent=2))
 for n in['final-c16','final-c32']:
  s.update(phase='measuring',current=n);save();run(['python3',str(w/'run-job.py'),n],n+'.outer.log')
 (w/'campaign-state.json').write_text(json.dumps(dict(phase='complete',time_ns=time.time_ns())))
 run(['python3',str(w/'queue-g-analysis.py')],'normal-analysis.outer.log');assert json.loads((w/'normal-analysis-state.json').read_text())['phase']=='complete'
 traces=[]
 for c in[16,32]:
  s.update(phase='profiling',current=c);save();run(['python3',str(w/'run-job.py'),f'profile-c{c}'],f'profile-c{c}.outer.log')
  traces.extend([str(w/f'runs/profile-c{c}/c{c}-r0-owned-{x}/trace.sqlite')for x in['before','after']])
 proof=[]
 for path in[Path(p)for p in traces if 'owned-after'in p]:
  db=sqlite3.connect(path);db.row_factory=sqlite3.Row;strings=dict(db.execute('select id,value from StringIds'));rows=list(db.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL'))
  if mode=='A':
   kernels={}
   for row in rows:
    name=strings[row['demangledName']]
    if 'v17_gateup'in name or'v17_down'in name:
     k=kernels.setdefault(name,dict(count=0,ms=0.0));k['count']+=1;k['ms']+=(row['end']-row['start'])/1e6
   assert kernels,(path,'new projection kernels not executed')
   proof.append(dict(trace=str(path),trace_sha256=sha(path),candidate_kernels=kernels))
  else:
   graphs={}
   for row in rows:
    if row['graphId']and row['graphNodeId'] is not None:graphs.setdefault(row['graphId'],{}).setdefault(row['graphNodeId'],strings[row['demangledName']])
   mixed=[]
   for gid,nodes in graphs.items():
    names=list(nodes.values());res=sum('residual_add_kernel'in n for n in names);gather=sum('kv_gather'in n for n in names)
    if res==72 and gather and any('sm80_batched_qk'in n for n in names):mixed.append(dict(graph=gid,nodes=len(nodes),residuals=res,prefill_KV_gathers=gather,node_names=names))
   proof.append(dict(trace=str(path),trace_sha256=sha(path),mixed_full_body_graphs=mixed,actual_mixed_graph_hit=bool(mixed)))
  db.close()
 (w/'actual-candidate-dispatch.json').write_text(json.dumps(proof,indent=2))
 # Opaque GEMMs in a mixed body cannot inherit the pure-decode stage parser.
 attribute=(w/'attribute-graphs.py').read_text()
 if mode=='B':
  old="if kind=='unknown':audit.append";new="if kind=='body' and any('kv_gather'in n for n in names):kind='mixed-opaque'\n  if kind in ['unknown','mixed-opaque']:audit.append";assert old in attribute;attribute=attribute.replace(old,new)
 (w/'attribute-v17.py').write_text(attribute);run(['python3',str(w/'attribute-v17.py'),*traces],'graph-diagnostics.log')
 analyzer=(w/'analyze-profile-v15.py').read_text().replace("[('sm80_batched_lm_head'","[('v17_gateup','linear-GateUp'),('v17_down','linear-Down'),('sm80_batched_lm_head'")
 (w/'analyze-profile-v17.py').write_text(analyzer);run(['python3',str(w/'analyze-profile-v17.py'),*traces],'profile-diagnostics.log');run(['python3',str(w/'audit-complete.py')],'audit-complete.outer.log')
 audit=json.loads((w/'independent-audit.json').read_text());assert len(audit['arms'])==34
 (w/'diagnostics-state.json').write_text(json.dumps(dict(phase='complete',time_ns=time.time_ns(),traces=traces)))
 run(['python3',str(w/'audit-holders.py'),str(w)],'holder-audit.outer.log')
 s.update(phase='exporting');save();run(['python3',str(w/'export-v17.py'),str(w),mode],'export.outer.log')
 s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as err:s.update(phase='failed',error=repr(err),traceback=traceback.format_exc());save();raise
