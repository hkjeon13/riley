from pathlib import Path
import json,ast,math,time
w=Path('/mnt/efs/nlp/psyche/riley-overlap-v17b2-20261021');out=[]
for c in [16,32]:
 root=w/f'runs/final-c{c}';data=json.loads((root/'result.json').read_text())['records']
 for rep in range(5):
  pair={};indices=set()
  for mode in ['owned-before','owned-after']:
   p=root/f'c{c}-r{rep}-{mode}';rows=json.loads((p/'w0/requests.json').read_text());start=min(r['start']for r in rows);brackets={}
   for metric in ['ttft_ms','tpot_ms']:
    order=sorted(enumerate(rows),key=lambda z:z[1][metric])
    for q in [.95,.99]:
     j=(len(order)-1)*q;b=[]
     for rank in sorted({math.floor(j),math.ceil(j)}):
      index,row=order[rank];indices.add(index);b.append(dict(rank=rank,request_ordinal=index,id=row['id'],prompt_tokens=row['value']['usage']['prompt_tokens'],completion_tokens=row['value']['usage']['completion_tokens'],start_offset_ms=(row['start']-start)*1000,ttft_ms=row['ttft_ms'],tpot_ms=row['tpot_ms'],e2e_ms=row['e2e_ms']))
     brackets[f'{metric}_p{int(q*100)}']=dict(interpolation_index=j,brackets=b)
   before=json.loads(ast.literal_eval((p/'metrics-before.txt').read_text())[1])['batch_shapes'];after=json.loads(ast.literal_eval((p/'w0/metrics-after.txt').read_text())[1])['batch_shapes']
   pair[mode]=dict(record=next(r for r in data if r['repeat']==rep and r['mode']==mode),brackets=brackets,batch_shape_before=before,batch_shape_after=after,requests=rows)
  comparable=[]
  for i in sorted(indices):
   a=pair['owned-before']['requests'][i];b=pair['owned-after']['requests'][i];assert a['id']==b['id'] and a['value']==b['value']
   comparable.append(dict(request_ordinal=i,id=a['id'],completion_tokens=a['value']['usage']['completion_tokens'],before={k:a[k]for k in ['ttft_ms','tpot_ms','e2e_ms']},after={k:b[k]for k in ['ttft_ms','tpot_ms','e2e_ms']},percent_change={k:100*(b[k]/a[k]-1)for k in ['ttft_ms','tpot_ms','e2e_ms']}))
  for a in pair.values():del a['requests']
  out.append(dict(concurrency=c,repeat=rep,arms=pair,same_ordinal_bracket_requests=comparable))
(w/'tail-request-and-shape-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),pairs=out,scope='All normal5repeat tail brackets and same-ordinal request latencies. Shape snapshots bracket correctness/recovery/warm/measurement combined, not an isolated measured-window trace. TPOT is request-average generation latency, not token ITL.'),indent=2));print('tail brackets and same-request latencies verified',len(out))
