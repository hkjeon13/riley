from pathlib import Path
import hashlib,json,shutil,time,re
w=Path('/mnt/efs/nlp/psyche/riley-projection-v17a-20261021');assert not(w/'graph-diagnostics.log').exists();p=w/'attribute-graphs.py';s=p.read_text();assert 'v17_gateup'not in s;shutil.copy2(p,w/'attribute-graphs.original-v15.py')
t=re.sub(r"'fused_gateup'in (name|n)\b",lambda m:"('fused_gateup'in "+m[1]+" or 'v17_gateup'in "+m[1]+")",s);compile(t,str(p),'exec');p.write_text(t)
(w/'profile-attribution-correction.json').write_text(json.dumps(dict(time_ns=time.time_ns(),old_sha256=hashlib.sha256(s.encode()).hexdigest(),new_sha256=hashlib.sha256(t.encode()).hexdigest(),scope='Recognize actual v17 fused GateUp kernel as MLP anchor and transition to Down. Avoid misclassifying unchanged opaque Lt Down as GateUp. Changes diagnostics only; original normal records/source/binary/accuracy references unchanged.'),indent=2));print('new GateUp anchor installed before analysis')
