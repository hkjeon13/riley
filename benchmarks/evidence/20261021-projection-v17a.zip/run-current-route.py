from pathlib import Path
import subprocess,os,json,time,hashlib,traceback
w=Path('/mnt/efs/nlp/psyche/riley-projection-v17a-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';d=w/'current-route';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();state=dict(phase='compiling',started_ns=time.time_ns())
def save():(w/'current-route-state.json').write_text(json.dumps(state,indent=2))
save()
try:
 env=dict(os.environ,TMPDIR=str(w/'tmp'),CUDA_VISIBLE_DEVICES='',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64')
 argv=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-O3','-std=c++17','-arch=sm_80',str(d/'probe-current.cu'),'-lcublasLt','-o',str(d/'probe-current')]
 (d/'build.argv.json').write_text(json.dumps(argv,indent=2))
 with(d/'build.log').open('x')as f:q=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert q.returncode==0,'current-route compile failed'
 state['phase']='screening';save();env.update(RILEY_DIVERGENCE_NATIVE_OUTPUT=str(d/'probe-output'))
 argv=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(d/'observed-probe'),'--timeout','900','--',str(d/'probe-current')];(d/'argv.json').write_text(json.dumps(argv,indent=2))
 with(d/'run.log').open('x')as f:q=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert q.returncode==0,'current-route screen execution failed'
 cases=[json.loads(line)for line in(d/'observed-probe.stdout').read_text().splitlines()];assert len(cases)==156
 receipt=json.loads((d/'observed-probe.json').read_text());assert receipt['status']=='complete'and receipt['returncode']==0
 samples=[json.loads(line)for line in(d/'observed-probe.samples.jsonl').read_text().splitlines()];peak=max(x['device_memory_mib']for x in samples);assert 0<peak<=22528
 summary=dict(time_ns=time.time_ns(),cases=len(cases),mismatch_cases=[x for x in cases if x['mismatch']],matched=sum(x['mismatch']==0 for x in cases),state0_timings=[x for x in cases if 'old_us'in x],source_sha256=sha(d/'probe-current.cu'),binary_sha256=sha(d/'probe-current'),whole_device_peak_MiB=peak,control='Gate/UpR2..16 current native fused; R17..32 mergedLt31/15/17/0/0/0/0+original BF16SiLU. DownR2..32 currentLt31/15/18/2/4/1/0. Original six finite states. Not old customDown or old R17GateUp.',scope='Component current-route screen only. Nonzero mismatches are preserved negative outcomes; no tolerance/reference changes. Does not change tested server source/binary or original full-model gate.')
 (w/'current-route-screen.json').write_text(json.dumps(summary,indent=2));state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
