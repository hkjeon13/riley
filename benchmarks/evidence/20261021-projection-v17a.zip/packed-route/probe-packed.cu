#include "probe-kernels.cuh"
#include <cublas_v2.h>
#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"CUDA line%d %s\n",__LINE__,cudaGetErrorString(e));return 2;}}while(0)
#define BL(x) do{auto e=(x);if(e!=CUBLAS_STATUS_SUCCESS){fprintf(stderr,"BL line%d status%d\n",__LINE__,int(e));return 3;}}while(0)
__global__ void fill_p(U*p,size_t n,int st){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n){uint32_t z=uint32_t(i)*1664525u+1013904223u+st*1237;float v=float(int(z%2047)-1023)/32768.f;if(st%6==1)v*=8;if(st%6==2)v*=.0078125f;if(st%6==3)v=i%7?0:v;if(st%6==4)v=i%2?-v:v;if(st%6==5)v*=32;p[i]=__float2bfloat16_rn(v);}}
__global__ void compare_p(const U*a,const U*b,size_t n,unsigned*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n&&__bfloat16_as_ushort(a[i])!=__bfloat16_as_ushort(b[i]))atomicAdd(p,1u);}
// Keep each native K32 chain contiguous; do not add an intermediate BF16.
__global__ void pack_p(const U*input,U*out,int n){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<size_t(n)*2560){int k=i%1280,row=(i/1280)%n,part=i/(size_t(n)*1280);out[i]=input[size_t(row)*2560+(k/32)*64+part*32+k%32];}}
__global__ void reduce_p(const float*raw,U*y,int rows){int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<rows*9728){int row=i/9728,j=i%9728;size_t a=size_t(row)*19456+j,b=size_t(rows)*19456;float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(raw[a],raw[b+a]),0.f)));a+=9728;float u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(raw[a],raw[b+a]),0.f)));float act=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[i]=__float2bfloat16_rn(__fmul_rn(act,u));}}
int main(){cudaStream_t stream;CU(cudaStreamCreate(&stream));cublasHandle_t handle;BL(cublasCreate(&handle));BL(cublasSetStream(handle,stream));BL(cublasSetMathMode(handle,CUBLAS_TENSOR_OP_MATH));auto alloc=[](size_t n){void*p;if(cudaMalloc(&p,n)!=cudaSuccess)throw std::runtime_error("alloc");return p;};void*workspace=alloc(4u*1024u*1024u);BL(cublasSetWorkspace(handle,workspace,4u*1024u*1024u));U*w=(U*)alloc(19456ul*2560*2),*pw=(U*)alloc(19456ul*2560*2),*x=(U*)alloc(16ul*2560*2),*px=(U*)alloc(16ul*2560*2),*gold=(U*)alloc(16ul*9728*2),*y=(U*)alloc(16ul*9728*2);float*raw=(float*)alloc(2ul*16*19456*4);unsigned*bad=(unsigned*)alloc(4);
 std::vector<int>algos={int(CUBLAS_GEMM_DEFAULT_TENSOR_OP)};for(int a=int(CUBLAS_GEMM_ALGO0_TENSOR_OP);a<=int(CUBLAS_GEMM_ALGO15_TENSOR_OP);a++)algos.push_back(a);
 for(int rows=2;rows<=16;rows++)for(int state=0;state<6;state++){
  fill_p<<<(19456ul*2560+255)/256,256,0,stream>>>(w,19456ul*2560,state);fill_p<<<(16ul*2560+255)/256,256,0,stream>>>(x,16ul*2560,state+2);pack_p<<<(19456ul*2560+255)/256,256,0,stream>>>(w,pw,19456);
  auto old=[&](){sm80_fused_gateup<4,16,16,2><<<304,128,0,stream>>>(w,w+9728ul*2560,x,gold,rows);};old();
  for(int algo:algos){auto run=[&](){pack_p<<<(rows*2560+255)/256,256,0,stream>>>(x,px,rows);float alpha=1,beta=0;auto status=cublasGemmStridedBatchedEx(handle,CUBLAS_OP_T,CUBLAS_OP_N,19456,rows,1280,&alpha,pw,CUDA_R_16BF,1280,19456ll*1280,px,CUDA_R_16BF,1280,(long long)rows*1280,&beta,raw,CUDA_R_32F,19456,(long long)rows*19456,2,CUBLAS_COMPUTE_32F,cublasGemmAlgo_t(algo));if(status==CUBLAS_STATUS_SUCCESS)reduce_p<<<(rows*9728+255)/256,256,0,stream>>>(raw,y,rows);return status;};auto status=run();CU(cudaStreamSynchronize(stream));
   printf("{\"rows\":%d,\"state\":%d,\"algo\":%d,\"status\":%d",rows,state,algo,int(status));
   if(status==CUBLAS_STATUS_SUCCESS){CU(cudaMemsetAsync(bad,0,4,stream));compare_p<<<(rows*9728+255)/256,256,0,stream>>>(gold,y,rows*9728,bad);unsigned count;CU(cudaMemcpyAsync(&count,bad,4,cudaMemcpyDeviceToHost,stream));CU(cudaStreamSynchronize(stream));printf(",\"mismatch\":%u",count);
    if(state==0&&count==0){float us[2];for(int which=0;which<2;which++){cudaGraph_t graph;cudaGraphExec_t exe;CU(cudaStreamBeginCapture(stream,cudaStreamCaptureModeThreadLocal));for(int k=0;k<32;k++){if(which)run();else old();}CU(cudaStreamEndCapture(stream,&graph));CU(cudaGraphInstantiate(&exe,graph,0));for(int k=0;k<3;k++)CU(cudaGraphLaunch(exe,stream));cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaEventRecord(a,stream));for(int k=0;k<8;k++)CU(cudaGraphLaunch(exe,stream));CU(cudaEventRecord(b,stream));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));us[which]=ms*1000/256;CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));CU(cudaGraphExecDestroy(exe));CU(cudaGraphDestroy(graph));}printf(",\"old_us\":%.3f,\"new_us\":%.3f",us[0],us[1]);}}
   puts("}");fflush(stdout);
  }
 }
 BL(cublasDestroy(handle));return 0;
}
