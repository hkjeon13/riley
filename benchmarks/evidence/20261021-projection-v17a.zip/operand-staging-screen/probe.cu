#include "probe-kernels.cuh"
#include "mma-backend.cuh"
#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"CUDA line%d %s\n",__LINE__,cudaGetErrorString(e));return 2;}}while(0)
__global__ void fill(U*p,size_t n,int st){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n){uint32_t z=uint32_t(i)*1664525u+1013904223u+st*1237;float v=float(int(z%2047)-1023)/32768.f;if(st%6==1)v*=8;if(st%6==2)v*=.0078125f;if(st%6==3)v=i%7?0:v;if(st%6==4)v=i%2?-v:v;if(st%6==5)v*=32;p[i]=__float2bfloat16_rn(v);}}
__global__ void cmp(const U*a,const U*b,size_t n,unsigned*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n&&__bfloat16_as_ushort(a[i])!=__bfloat16_as_ushort(b[i]))atomicAdd(p,1u);}
int main(){cudaStream_t stream;CU(cudaStreamCreate(&stream));auto alloc=[](size_t n){void*p;auto e=cudaMalloc(&p,n);if(e)throw std::runtime_error("alloc");return p;};U*wg=(U*)alloc(19456ul*2560*2),*wu=wg+9728ul*2560,*wd=(U*)alloc(2560ul*9728*2),*x=(U*)alloc(32ul*9728*2),*gold=(U*)alloc(32ul*9728*2),*y=(U*)alloc(32ul*9728*2);float*parts=(float*)alloc(4*32*2560*4);unsigned*bad=(unsigned*)alloc(4);
 for(int rows:{2,3,4,5,6,7,8,9,12,16,17,24,32})for(int st=0;st<6;st++){
  fill<<<(19456ul*2560+255)/256,256,0,stream>>>(wg,19456ul*2560,st);fill<<<(2560ul*9728+255)/256,256,0,stream>>>(wd,2560ul*9728,st+1);fill<<<(32ul*9728+255)/256,256,0,stream>>>(x,32ul*9728,st+2);
  auto run=[&](int op,int v){
   if(op==0){if(v==0){if(rows<=16)sm80_fused_gateup<4,16,16,2><<<304,128,0,stream>>>(wg,wu,x,y,rows);else sm80_fused_gateup<4,32,8,2><<<304,128,0,stream>>>(wg,wu,x,y,rows);}
    else{if(rows<=8)v17_gateup<4,8,16,2><<<304,128,0,stream>>>(wg,wu,x,y,rows);else if(rows<=16)v17_gateup<4,16,16,2><<<304,128,0,stream>>>(wg,wu,x,y,rows);else v17_gateup<4,32,8,2><<<304,128,0,stream>>>(wg,wu,x,y,rows);}}
   else{if(v==0){if(rows<=16)sm80_v9_down<8,16,8,4><<<dim3(20,1,4),256,0,stream>>>(wd,x,parts,rows);else sm80_v9_down<4,32,16,4><<<dim3(40,1,4),128,0,stream>>>(wd,x,parts,rows);}
    else{if(rows<=8)v17_down<8,8,8,4><<<dim3(20,1,4),256,0,stream>>>(wd,x,parts,rows);else if(rows<=16)v17_down<8,16,8,4><<<dim3(20,1,4),256,0,stream>>>(wd,x,parts,rows);else v17_down<4,32,16,4><<<dim3(40,1,4),128,0,stream>>>(wd,x,parts,rows);}
    sm80_v9_down_reduce<<<(rows*2560+255)/256,256,0,stream>>>(parts,y,rows*2560);}
  };
  for(int op=0;op<2;op++){
   size_t n=rows*(op==0?9728:op==1?2560:1024);run(op,0);CU(cudaMemcpyAsync(gold,y,n*2,cudaMemcpyDeviceToDevice,stream));
   for(int v=1;v<=1;v++){run(op,v);CU(cudaMemsetAsync(bad,0,4,stream));cmp<<<(n+255)/256,256,0,stream>>>(gold,y,n,bad);unsigned count;CU(cudaMemcpyAsync(&count,bad,4,cudaMemcpyDeviceToHost,stream));CU(cudaStreamSynchronize(stream));printf("{\"rows\":%d,\"state\":%d,\"op\":%d,\"variant\":%d,\"mismatch\":%u",rows,st,op,v,count);if(count){puts("");return 4;}
    if(st==0){float us[2];for(int z=0;z<2;z++){cudaGraph_t graph;cudaGraphExec_t exe;CU(cudaStreamBeginCapture(stream,cudaStreamCaptureModeThreadLocal));for(int i=0;i<32;i++)run(op,z?v:0);CU(cudaStreamEndCapture(stream,&graph));CU(cudaGraphInstantiate(&exe,graph,0));for(int i=0;i<3;i++)CU(cudaGraphLaunch(exe,stream));cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaEventRecord(a,stream));for(int i=0;i<8;i++)CU(cudaGraphLaunch(exe,stream));CU(cudaEventRecord(b,stream));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));us[z]=ms*1000/256;CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));CU(cudaGraphExecDestroy(exe));CU(cudaGraphDestroy(graph));}printf(",\"old_us\":%.3f,\"new_us\":%.3f",us[0],us[1]);}
    puts("}");fflush(stdout);
   }
  }
 }
 return 0;
}
