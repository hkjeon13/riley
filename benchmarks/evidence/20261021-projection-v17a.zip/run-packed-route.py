from pathlib import Path
import subprocess,os,json,time,hashlib,traceback
w=Path('/mnt/efs/nlp/psyche/riley-projection-v17a-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';d=w/'packed-route';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=dict(phase='compiling',started_ns=time.time_ns())
def save():(w/'packed-route-state.json').write_text(json.dumps(s,indent=2))
try:
 save();env=dict(os.environ,TMPDIR=str(w/'tmp'),CUDA_VISIBLE_DEVICES='',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64')
 argv=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-O3','-std=c++17','-arch=sm_80',str(d/'probe-packed.cu'),'-lcublas','-o',str(d/'probe-packed')];(d/'build.argv.json').write_text(json.dumps(argv,indent=2))
 with(d/'build.log').open('x')as f:q=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert q.returncode==0,'packed route compile failed'
 s['phase']='screening';save();env.update(RILEY_DIVERGENCE_NATIVE_OUTPUT=str(d/'probe-output'))
 argv=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(d/'observed-probe'),'--timeout','900','--',str(d/'probe-packed')];(d/'argv.json').write_text(json.dumps(argv,indent=2))
 with(d/'run.log').open('x')as f:q=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert q.returncode==0,'packed route screen failed'
 rows=[json.loads(l)for l in(d/'observed-probe.stdout').read_text().splitlines()];assert len(rows)==1530
 groups={a:[x for x in rows if x['algo']==a]for a in sorted({x['algo']for x in rows})};qualified={a:[x for x in rs if 'old_us'in x]for a,rs in groups.items()if len(rs)==90 and all(x['status']==0 and x['mismatch']==0 for x in rs)}
 receipt=json.loads((d/'observed-probe.json').read_text());assert receipt['status']=='complete'and receipt['returncode']==0
 samples=[json.loads(l)for l in(d/'observed-probe.samples.jsonl').read_text().splitlines()];peak=max(x['device_memory_mib']for x in samples);assert 0<peak<=22528
 (w/'packed-route-screen.json').write_text(json.dumps(dict(time_ns=time.time_ns(),cases=1530,algorithm_selectors=17,cases_per_selector=90,matched=sum(x.get('mismatch',1)==0 and x['status']==0 for x in rows),qualified_variants=qualified,all_outcomes=rows,whole_device_peak_MiB=peak,source_sha256=sha(d/'probe-packed.cu'),binary_sha256=sha(d/'probe-packed'),scope='Native two K32 chains cold-packed independently into two BF16 K1280 operands, cuBLAS strided-batched FP32 outputs, FP32 chain add then original BF16 Gate/Up/SiLU boundaries. Timings include input packing+two-chain GEMM+reduce, exclude cold weight packing. R2..16 current native fused control, 6finite states, 17library algorithm selectors; selectors may resolve to the same Ampere implementation. No native/HF reference or server source changes.'),indent=2));s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
