from pathlib import Path
import json,subprocess,time,hashlib,shutil,traceback
w=Path('/mnt/efs/nlp/psyche/riley-overlap-v18b4-20261021');s=dict(phase='repair-ipc-directory',started_ns=time.time_ns())
def save():(w/'ipc-resume-state.json').write_text(json.dumps(s,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 save()
 for n in ['ipc6','ipc7']:(w/n).mkdir(exist_ok=False)
 for n in ['pipeline-state.json','experiment-state.json','export-state.json','final-c16.state.json']:
  shutil.copy2(w/n,w/(n+'.attempt1'))
 root=w/'runs/final-c16';original=json.loads((root/'result.json').read_text());assert len(original['records'])==2
 assert {r['mode']for r in original['records']}=={'owned-before','owned-after'}and all(r['repeat']==0 for r in original['records'])
 failed=root/'c16-r0-vllm';assert not(failed/'w0/requests.json').exists()and not(failed/'gpu-samples.json').exists()
 dest=w/'failed-startup-c16-r0-vllm';failed.rename(dest)
 original_sha=sha(root/'result.json');shutil.copy2(root/'result.json',w/'final-c16-partial-result.json.attempt1')
 argv=json.loads((w/'final-c16.argv.json').read_text());chunks=[];records=list(original['records'])
 continuation=w/'continuations';continuation.mkdir()
 for tag,modes,start,repeats in [('r0-stock','vllm','0','1'),('r1-r4','owned-before,owned-after,vllm','1','5')]:
  out=continuation/tag;a=list(argv)
  for key,value in [('--out',str(out)),('--modes',modes),('--repeat-start',start),('--repeats',repeats)]:a[a.index(key)+1]=value
  (w/('continue-c16-'+tag+'.argv.json')).write_text(json.dumps(a,indent=2));s.update(phase='remaining-normal-arms',current=tag);save()
  with(w/('continue-c16-'+tag+'.log')).open('x')as log:q=subprocess.run(a,stdout=log,stderr=log)
  assert q.returncode==0,(tag,q.returncode)
  data=json.loads((out/'result.json').read_text());assert data['plan']['runner_sha256']==original['plan']['runner_sha256']==sha(w/'measure-matched.py')
  records.extend(data['records']);chunks.append(dict(tag=tag,argv=a,result_sha256=sha(out/'result.json'),arms=len(data['records'])))
  for rec in data['records']:
   name=f"c16-r{rec['repeat']}-{rec['mode']}";arm=out/name;target=root/name;assert not target.exists();arm.rename(target);arm.symlink_to(target,target_is_directory=True)
 assert len(records)==15 and len({(r['repeat'],r['mode'])for r in records})==15
 original['records']=records;(root/'result.json').write_text(json.dumps(original,indent=2));(root/'complete.json').write_text(json.dumps(dict(arms=15,finished_ns=time.time_ns(),completed_through_continuation=True),indent=2))
 state=json.loads((w/'final-c16.state.json').read_text());state.update(status='complete',original_process_returncode=state['returncode'],returncode=0,completion_source='Original two completed arms plus unchanged-runner continuation13 arms; aggregate status, original process rc1 retained in attempt1',finished_ns=time.time_ns());(w/'final-c16.state.json').write_text(json.dumps(state,indent=2))
 (w/'ipc-startup-correction.json').write_text(json.dumps(dict(reason='New EFS IPC parent directory was missing; stock server failed before warm/measured requests',created_directories=[str(w/'ipc6'),str(w/'ipc7')],failed_stock_measured_arms=0,original_completed_arms_retained=2,completed_normal_arms_repeated=0,unchanged_runner_sha256=sha(w/'measure-matched.py'),original_partial_result_sha256=original_sha,continuations=chunks,raw_failed_startup=str(dest),moved_arms_have_original_path_symlinks=True),indent=2))
 s.update(phase='c16-complete',finished_ns=time.time_ns());save()
 # Preserve original runner, inputs and C16 completed arms. Resume at C32,
 # then execute the original analysis/profile/audit tail without modification.
 text=(w/'queue-experiment-v18-final.py').read_text();prefix=text[:text.index('try:\n')];tail=text[text.index(" (w/'campaign-state.json').write_text"):]
 body="try:\n expected=937\n s.update(phase='measuring',current='final-c32');save()\n run(['python3',str(w/'run-job.py'),'final-c32'],'final-c32.outer.log')\n"
 script=w/'resume-normal-and-profile.py';script.write_text(prefix+body+tail)
 with(w/'resume-normal-and-profile.log').open('x')as log:q=subprocess.run(['python3',str(script),str(w),'B'],stdout=log,stderr=log)
 assert q.returncode==0
 pipeline=json.loads((w/'pipeline-state.json').read_text());pipeline.update(phase='measured-and-audited',original_failure_preserved='pipeline-state.json.attempt1',resumed_without_repeating_completed_arms=True,finished_ns=time.time_ns());(w/'pipeline-state.json').write_text(json.dumps(pipeline,indent=2))
 s.update(phase='measured-and-audited',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
