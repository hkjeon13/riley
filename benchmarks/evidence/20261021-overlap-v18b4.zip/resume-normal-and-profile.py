from pathlib import Path
import sys,json,time,hashlib,subprocess,os,traceback
w=Path(sys.argv[1]);mode=sys.argv[2];assert mode in ['A','B'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();v=w.parent/'riley-prefill-host-v15c-20261021';s=dict(phase='waiting-qualification',started_ns=time.time_ns())
def save():
 p=w/'experiment-state.json';t=p.with_suffix('.json.pending');t.write_text(json.dumps(s,indent=2));t.replace(p)
def read(p):
 for i in range(20):
  try:return json.loads(p.read_text())
  except(FileNotFoundError,json.JSONDecodeError):time.sleep(.25)
 return {}
def wait(p):
 while True:
  a=read(p);assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':return
  time.sleep(3)
def run(argv,name,extra=None):
 with(w/name).open('x')as f:r=subprocess.run(argv,stdout=f,stderr=f,env=dict(os.environ,**(extra or {})))
 assert r.returncode==0,(argv,r.returncode,name)
try:
 expected=937
 s.update(phase='measuring',current='final-c32');save()
 run(['python3',str(w/'run-job.py'),'final-c32'],'final-c32.outer.log')
 (w/'campaign-state.json').write_text(json.dumps(dict(phase='complete',time_ns=time.time_ns())))
 # Generalize only the exact source-count assertion; native/SSE gates are unchanged.
 p=w/'queue-g-analysis.py';t=p.read_text();assert 'assert len(m)==937'in t;t=t.replace('assert len(m)==937',f'assert len(m)=={expected}').replace('source937_all_equal=True',f'source_count={expected},all_sources_equal=True');(w/'queue-analysis-v18.py').write_text(t)
 run(['python3',str(w/'queue-analysis-v18.py')],'normal-analysis.outer.log');assert read(w/'normal-analysis-state.json')['phase']=='complete'
 traces=[]
 for c in [16,32]:
  s.update(phase='profiling',current=c);save();run(['python3',str(w/'run-job.py'),f'profile-c{c}'],f'profile-c{c}.outer.log',{'RILEY_HOST_STEP_TRACE':'1'})
  traces.extend(str(w/f'runs/profile-c{c}/c{c}-r0-owned-{x}/trace.sqlite')for x in ['before','after'])
 (w/'profile-run-environment.json').write_text(json.dumps(dict(RILEY_HOST_STEP_TRACE='1',scope='Profiles only, both before/after; normal timing unchanged',traces=traces),indent=2))
 run(['python3',str(w/'analyze-v18.py'),str(w),mode],'actual-dispatch-analysis.log')
 # New fixed-address pieces contain only MLP operations; SiLU is the source
 # stage anchor. Never attribute a mixed full body through the pure-decode parser.
 t=(w/'attribute-graphs.py').read_text();old="if kind=='unknown':audit.append";assert old in t;t=t.replace(old,"if any('piecewise_prefill_rows'in n for n in names):kind='prefill-mlp' if res==0 and any('silu'in n for n in names) else 'unknown'\n  if kind=='unknown':audit.append");(w/'attribute-v18.py').write_text(t)
 run(['python3',str(w/'attribute-v18.py'),*traces],'graph-diagnostics.log')
 t=(w/'analyze-profile-v15.py').read_text().replace("[('sm80_batched_lm_head'","[('piecewise_prefill_rows','prefill-row-copy'),('sm80_batched_lm_head'");(w/'analyze-profile-v18.py').write_text(t);run(['python3',str(w/'analyze-profile-v18.py'),*traces],'profile-diagnostics.log')
 run(['python3',str(w/'audit-complete.py')],'audit-complete.outer.log');audit=read(w/'independent-audit.json');assert len(audit['arms'])==34
 run(['python3',str(w/'audit-holders.py'),str(w)],'holder-audit.outer.log')
 (w/'diagnostics-state.json').write_text(json.dumps(dict(phase='complete',time_ns=time.time_ns(),traces=traces)))
 s.update(phase='measured-and-audited',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
