from pathlib import Path
import json,subprocess,time,traceback,shutil
w=Path('/mnt/efs/nlp/psyche/riley-overlap-v18b4-20261021');p=w.parent;s=dict(phase='waiting-build',started_ns=time.time_ns())
def save():
 q=w/'pipeline-state.json';t=q.with_suffix('.pending');t.write_text(json.dumps(s,indent=2));t.replace(q)
def run(script,tag=None):
 s.update(phase=tag or script);save()
 with(w/((tag or script)+'.pipeline.log')).open('x')as f:q=subprocess.run(['python3',str(w/script)],stdout=f,stderr=f)
 assert q.returncode==0,(script,q.returncode)
try:
 save();shutil.copy2(p/'setup-v18b4.py',w/'setup-v18b4.py')
 run('queue-build-extra.py','build-extra')
 run('run-bounded-g.py','bounded576')
 run('queue-accuracy.py','original-accuracy')
 run('run-canonical.py','canonical')
 old=p/'riley-overlap-v18b3-functional-20261021';pilot=p/'riley-overlap-v18b4-functional-20261021';pilot.mkdir()
 for q in old.iterdir():
  if q.is_file()and(q.suffix=='.py'or q.name in ['pilot-c16.argv.json','pilot-c32.argv.json']):
   (pilot/q.name).write_text(q.read_text().replace('riley-overlap-v18b3','riley-overlap-v18b4'))
 s['phase']='functional-pilot';save()
 with(pilot/'pilot.queue.log').open('x')as f:q=subprocess.run(['python3',str(pilot/'run-pilot.py')],stdout=f,stderr=f)
 assert q.returncode==0
 (w/'normal-ready.json').write_text(json.dumps(dict(time_ns=time.time_ns(),all_compilation_and_finite_qualification_quiet=True,exact_binary_functional_pilot=True),indent=2))
 s['phase']='normal-and-profile';save()
 with(w/'experiment.queue.log').open('x')as f:q=subprocess.run(['python3',str(w/'queue-experiment-v18-final.py'),str(w),'B'],stdout=f,stderr=f)
 assert q.returncode==0
 s.update(phase='measured-and-audited',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
