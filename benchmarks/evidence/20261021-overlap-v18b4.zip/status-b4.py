from pathlib import Path
import json,time
w=Path('/mnt/efs/nlp/psyche/riley-overlap-v18b4-20261021')
for n in ['pipeline','build-extra','bounded576','accuracy-r3','canonical','experiment']:
 p=w/(n+'-state.json')
 if p.exists():
  try:print(n,json.dumps(json.loads(p.read_text()),ensure_ascii=False))
  except ValueError:print(n,'writer updating')
for c in [16,32]:
 p=w/f'final-c{c}.log'
 if p.exists():print(c,p.read_text()[-900:])
p=w/'final-statistics.json'
if p.exists():
 for c in json.loads(p.read_text())['cells']:print('MEDIANS',c['concurrency'],c['median_percent_change'],c['tail_over_two_percent_flags'])

for n in ['ipc-resume-state.json','export-state.json']:
 p=w/n
 if p.exists():print(n,p.read_text())
for path in [w/'runs/final-c16',w/'continuations/r0-stock',w/'continuations/r1-r4',w/'runs/final-c32']:
 p=path/'result.json'
 if p.exists():
  a=json.loads(p.read_text());print('ARMS',path.name,[(r['repeat'],r['mode'],round(r['output_tok_s'],3))for r in a['records']])
