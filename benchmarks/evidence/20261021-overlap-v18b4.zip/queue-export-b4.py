from pathlib import Path
import json,time,subprocess,traceback,os
w=Path(__file__).resolve().parent;s=dict(phase='waiting-experiment',pid=os.getpid(),started_ns=time.time_ns())
def save():
 p=w/'export-state.json';t=p.with_suffix('.pending');t.write_text(json.dumps(s,indent=2));t.replace(p)
try:
 save()
 while True:
  try:a=json.loads((w/'pipeline-state.json').read_text())
  except(FileNotFoundError,json.JSONDecodeError):a={}
  assert a.get('phase')!='failed',a
  if a.get('phase')=='measured-and-audited':break
  time.sleep(3)
 s['phase']='exporting';save()
 with(w/'export.outer.log').open('x')as f:q=subprocess.run(['python3',str(w/'export-v18.py'),str(w),'B'],stdout=f,stderr=f)
 assert q.returncode==0
 s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
