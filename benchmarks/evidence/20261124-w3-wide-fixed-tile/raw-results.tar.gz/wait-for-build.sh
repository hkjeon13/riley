#!/usr/bin/env bash
set -euo pipefail
umask 077
cd -- "$(dirname -- "$0")"
stage=$(pwd -P)
pid=899144
test "$(cat build-wait.pid)" = "$pid"
test "$(cat build-wait.started)" = 2026-11-24T05:25:44Z
trap 'printf "%s\n" "$?" >campaign-wait.exit.tmp; mv -- campaign-wait.exit.tmp campaign-wait.exit' EXIT
printf 'WAITING_FOR_BUILD %s %s\n' "$pid" "$(date -u +%FT%TZ)"
deadline=$((SECONDS + 9000))
until test -s build-wait.exit; do
    if [[ $(readlink "/proc/$pid/cwd" 2>/dev/null || true) != "$stage" ]] ||
        ! ps -p "$pid" -o args= | grep -Fxq 'bash wait-for-soak.sh' ||
        (( SECONDS >= deadline )); then
        test -s build-wait.exit && break
        exit 75
    fi
    sleep 8
done
test "$(cat build-wait.exit)" = 0
test "$(cat build.exit)" = 0
printf 'CAMPAIGN_RELEASED %s\n' "$(date -u +%FT%TZ)"
bash campaign.sh
