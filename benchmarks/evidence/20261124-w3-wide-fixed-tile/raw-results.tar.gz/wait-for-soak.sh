#!/usr/bin/env bash
set -euo pipefail
umask 077
cd -- "$(dirname -- "$0")"
stage=$(pwd -P)
soak="$(dirname "$stage")/w5-pointer-soak-20261124.wa1UJ2ZB"
pid=787131
test "$(cat "$soak/campaign.pid")" = "$pid"
test "$(cat "$soak/campaign.started")" = 2026-11-24T05:05:53Z
trap 'printf "%s\n" "$?" >build-wait.exit.tmp; mv -- build-wait.exit.tmp build-wait.exit' EXIT
printf 'WAITING %s %s\n' "$pid" "$(date -u +%FT%TZ)"
deadline=$((SECONDS + 7200))
until test -s "$soak/campaign.exit"; do
    if [[ $(readlink "/proc/$pid/cwd" 2>/dev/null || true) != "$soak" ]] ||
        ! ps -p "$pid" -o args= | grep -Fxq 'bash campaign.sh' ||
        (( SECONDS >= deadline )); then
        test -s "$soak/campaign.exit" && break
        exit 75
    fi
    sleep 8
done
test "$(cat "$soak/campaign.exit")" = 0
test "$(cat "$soak/recovery/campaign.exit")" = 0
printf 'BUILD_RELEASED %s\n' "$(date -u +%FT%TZ)"
bash build.sh
