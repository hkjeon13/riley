from pathlib import Path
import json,subprocess,time,traceback,hashlib,shutil
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19a-20261022');p=w.parent;s=dict(phase='waiting-final-build',started_ns=time.time_ns())
def save():(w/'pipeline-state.json').write_text(json.dumps(s,indent=2))
def run(name,args=[]):
 s.update(phase=name);save()
 with(w/(name+'.pipeline.log')).open('x')as f:q=subprocess.run(['python3',str(w/name)]+args,stdout=f,stderr=f)
 assert q.returncode==0,(name,q.returncode)
try:
 save()
 while True:
  f=w/'revision-state.json';a=json.loads(f.read_text())if f.exists()else{};assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 for n in ['resume-gpu-contracts.py','run-canonical.py']:run(n)
 # Audit all finite resource receipts before permitting any HTTP run.
 audits=[]
 for f in [w/('observed-'+name+'.samples.jsonl')for name in ['bounded576', 'final-teacher-C1-eager-r3', 'final-teacher-allR-Graph-r3', 'teacher-body-allR-r3', 'teacher-mixed-r3', 'teacher-mixed-no-output-r3', 'canonical', 'contracts-r4-host_runtime_gpu', 'contracts-r4-memory_gpu', 'contracts-r4-owned_hf_command_batch_gpu', 'contracts-r4-sm80_prefill_alignment_gpu']]:
  a=[json.loads(l)for l in f.read_text().splitlines()];assert a
  peak=max(x['device_memory_mib']for x in a);assert peak<=22528,(f,peak)
  for x in a:
   assert all(t['pid']==2027914 or str(t['pid'])in x['verified_owned_start_ticks']for t in x['processes']),(f,x)
  audits.append(dict(name=f.name,samples=len(a),whole_device_peak_MiB=peak,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
 assert len(audits)==11,len(audits)
 (w/'qualification-resource-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),GPU=6,cap_MiB=22528,runs=audits),indent=2))
 # Create fresh functional-only two-arm pilot; normal comparison is separate.
 old=p/'riley-overlap-v18b4-functional-20261021';d=p/'riley-weight-layout-v19a-functional-20261022';d.mkdir()
 for n in ['run-pilot.py','run-job.py','measure-matched.py','audit-complete.py','holder.py']:
  text=(old/n).read_text().replace(old.name,d.name).replace('riley-overlap-v18b4-20261021',w.name).replace('riley-overlap-v18b4','riley-weight-layout-v19a');(d/n).write_text(text)
 for c in [16,32]:
  a=json.loads((old/f'pilot-c{c}.argv.json').read_text());a=[x.replace(old.name,d.name).replace('riley-overlap-v18b4-20261021',w.name).replace('riley-overlap-v18b4','riley-weight-layout-v19a').replace('GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0','GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7')for x in a];a[a.index('--index')+1]='6';(d/f'pilot-c{c}.argv.json').write_text(json.dumps(a,indent=2))
 s['phase']='functional-pilot';save()
 with(d/'outer.log').open('x')as f:q=subprocess.run(['python3',str(d/'run-pilot.py')],stdout=f,stderr=f)
 assert q.returncode==0
 (w/'normal-ready.json').write_text(json.dumps(dict(time_ns=time.time_ns(),all_compilation_and_finite_qualification_quiet=True,exact_binary_functional_pilot=True,physical_GPU=6),indent=2));s.update(phase='qualified-and-functional',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
