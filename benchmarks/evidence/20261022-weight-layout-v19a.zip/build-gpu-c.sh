#!/bin/bash
set -euo pipefail
RUN=/mnt/efs/nlp/psyche/riley-weight-layout-v19a-20261022
export RUSTUP_HOME=/home/nlp/riley-261013/rustup CARGO_HOME=/home/nlp/riley-261013/cargo RUSTUP_TOOLCHAIN=1.85.0
export PATH="$CARGO_HOME/bin:/usr/local/cuda-12.4/bin:/usr/local/bin:/usr/bin:/bin"
export CMAKE=/usr/local/bin/cmake CARGO_BUILD_JOBS=2 CMAKE_BUILD_PARALLEL_LEVEL=2 CUDA_HOME=/usr/local/cuda-12.4 CUDAToolkit_ROOT=/usr/local/cuda-12.4 CUDACXX=/usr/local/cuda-12.4/bin/nvcc RILEY_CUDA_ARCHITECTURES=80 CUDA_VISIBLE_DEVICES=
export LD_LIBRARY_PATH=/usr/local/cuda-12.4/lib64 CARGO_TARGET_DIR="$RUN/target" TMPDIR="$RUN/tmp" XDG_CACHE_HOME="$RUN/cache"
unset RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
cd "$RUN/source"
taskset -c 48-51 cargo test --locked --offline --release -p riley-cuda --features cuda,cuda-cublas-gemm-probe --test host_runtime_gpu --test memory_gpu --test owned_hf_command_batch_gpu --test sm80_prefill_alignment_gpu --no-run --message-format=json > "$RUN/ledger-gpu-build.jsonl" 2>&1
