from pathlib import Path
import json,hashlib,shutil,subprocess,os,signal,time
p=Path('/mnt/efs/nlp/psyche');old=p/'riley-overlap-v18b3-20261021';w=p/'riley-weight-layout-v19a-20261022';assert not w.exists()
pid=2751704;proc=Path(f'/proc/{pid}');cmd=(proc/'cmdline').read_bytes().split(b'\0');assert cmd[:4]==[b'python3',str(old/'queue-experiment-v18-final.py').encode(),str(old).encode(),b'B'];ticks=(proc/'stat').read_text().rsplit(')',1)[1].split()[19];assert not(old/'normal-ready.json').exists()and not(old/'runs').exists();os.kill(pid,signal.SIGTERM)
(old/'superseded-before-normal.json').write_text(json.dumps(dict(pid=pid,start_ticks=ticks,argv=[x.decode()for x in cmd if x],normal_arms=0,numerical_and_functional_GPU_runs_retained=True,reason='B4 fixes GPU-pending CPU error paths and gates preview on queued admissions/lifecycle',time_ns=time.time_ns()),indent=2))
w.mkdir();shutil.copytree(old/'source',w/'source')
subprocess.run(['tar','-xzf',str(p/'candidate-overlap-v18b4.tar.gz'),'-C',str(w/'source')],check=True)
for name in ['tmp','cache']: (w/name).mkdir()
# Immutable source-only inputs and harnesses; no output/state files are reused.
for q in old.iterdir():
 if not q.is_file()or q.suffix not in ['.py','.sh','.rs']:continue
 if q.name.startswith(('analyze-profile-v18','attribute-v18','queue-analysis-v18','export-v18')):continue
 text=q.read_text().replace('riley-overlap-v18b3','riley-weight-layout-v19a')
 if q.name=='queue-build-extra.py':text=text.replace('==(525,4,40)','==(526,4,40)')
 if q.name=='run-canonical.py':text=text.replace('Exercises canonical output routing and eligible fixed-address MLP pieces','Exercises canonical output routing and existing decode Graph numerical regression; serving overlap is verified separately')
 (w/q.name).write_text(text)
for q in old.glob('*.argv.json'):
 if q.name not in ['final-c16.argv.json','final-c32.argv.json','profile-c16.argv.json','profile-c32.argv.json']:continue
 (w/q.name).write_text(q.read_text().replace('riley-overlap-v18b3','riley-weight-layout-v19a'))
base=json.loads((old/'pre-build-source.json').read_text())['source_sha256'];m={f:hashlib.sha256((w/'source'/f).read_bytes()).hexdigest()for f in base};assert len(m)==937
v=json.loads((p/'riley-prefill-host-v15c-20261021/source-manifest.json').read_text());assert len([f for f in m if m[f]!=v[f]])==10
(w/'pre-build-source.json').write_text(json.dumps(dict(source_sha256=m,time_ns=time.time_ns()),indent=2))
with(w/'build.outer.log').open('x')as log:q=subprocess.Popen(['bash',str(w/'build.sh')],stdout=log,stderr=log,start_new_session=True)
(w/'build-started.json').write_text(json.dumps(dict(pid=q.pid,time_ns=time.time_ns()),indent=2));print(w,q.pid)
