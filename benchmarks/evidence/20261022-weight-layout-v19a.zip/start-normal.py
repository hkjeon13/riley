from pathlib import Path
import json,hashlib,time,subprocess
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19a-20261022');root=w.parent/'riley-projection-layout-v19-20261022';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f,key,val in [(w/'pipeline-state.json','phase','qualified-and-functional'),(w/'packed-contract-v3/state.json','phase','complete'),(root/'lossless/screen-state.json','phase','complete')]:assert json.loads(f.read_text())[key]==val
# Verify the exact extracted input bytes after all operator screens.
x=json.loads((root/'weight-extraction.json').read_text());proof=[]
for row in x['weights']:
 p=root/'weights'/row['file'];assert p.stat().st_size==row['bytes']and sha(p)==row['sha256'];proof.append(row)
(root/'post-screen-weight-input-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),all_input_bytes_equal_to_original_extraction=True,weights=proof),indent=2))
m=json.loads((w/'pre-build-source.json').read_text())['source_sha256'];assert len(m)==937 and all(sha(w/'source'/f)==s for f,s in m.items());assert sha(w/'riley-weight-layout-v19a')==(w/'qualification-binary.sha256').read_text().split()[0]
a=json.loads((w/'normal-ready.json').read_text());a.update(time_ns=time.time_ns(),all_compilation_and_finite_qualification_quiet=True,lossless_screen_complete=True,lossless_screen_adopted=False,all_post_screen_weight_bytes_reverified=True);(w/'normal-ready.json').write_text(json.dumps(a,indent=2))
assert not(w/'runs').exists()
with(w/'experiment-final.queue.log').open('x')as f:q=subprocess.Popen(['python3',str(w/'queue-experiment-v19.py'),str(w),'B'],stdout=f,stderr=f,start_new_session=True)
print(q.pid)
