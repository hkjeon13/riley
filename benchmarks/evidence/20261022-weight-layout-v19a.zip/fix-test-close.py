from pathlib import Path
import json,hashlib,time,shutil,subprocess
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19a-20261022');p=w/'source/crates/riley-cuda/tests/sm80_prefill_alignment_gpu.rs';s=p.read_text();needle='2,&mut s).is_err());p.close()?;';assert s.count(needle)==1
old=json.loads((w/'pre-build-source.json').read_text());before=hashlib.sha256(p.read_bytes()).hexdigest();assert old['source_sha256'][str(p.relative_to(w/'source'))]==before
shutil.copy2(w/'pre-build-source.json',w/'pre-test-amendment-source.json');p.write_text(s.replace(needle,'2,&mut s).is_err());assert!(p.close().is_err());'));after=hashlib.sha256(p.read_bytes()).hexdigest();old['source_sha256'][str(p.relative_to(w/'source'))]=after;old['test_amendment_ns']=time.time_ns();(w/'pre-build-source.json').write_text(json.dumps(old,indent=2));assert all(hashlib.sha256((w/'source'/f).read_bytes()).hexdigest()==h for f,h in old['source_sha256'].items())
(w/'test-amendment.json').write_text(json.dumps(dict(time_ns=time.time_ns(),file=str(p),before_sha256=before,after_sha256=after,reason='Invalid packed spans correctly reject and poison the plan. The test must also require close() to report poisoned state, matching existing close contract. Numerical/unaligned original120 checks passed; no native or model execution source changed.',production_binary_unchanged=hashlib.sha256((w/'riley-weight-layout-v19a').read_bytes()).hexdigest()),indent=2))
d=w/'failed-first-packed-contract-test';d.mkdir()
for n in ['ledger-gpu-build.jsonl','build-gpu.outer.log','observed-sm80_prefill_alignment_gpu.stdout','observed-sm80_prefill_alignment_gpu.stderr','observed-sm80_prefill_alignment_gpu.samples.jsonl','sm80_prefill_alignment_gpu.launch.log','accuracy-r3-state.json','pipeline-state.json']:
 if(w/n).exists():shutil.copy2(w/n,d/n)
with(w/'gpu-contract-test-amendment-build.log').open('x')as out:q=subprocess.run(['bash',str(w/'build-gpu-c.sh')],stdout=out,stderr=out)
assert q.returncode==0
print('test-only amendment GPU binaries built; production binary unchanged')
