from pathlib import Path
import os,json,subprocess,time,hashlib
w=Path(__file__).resolve().parent;r=w.parent/'riley-w0-a100-gpu67-20261019'
while True:
 f=w/'fix-test-close.outer.log'
 if f.exists()and 'production binary unchanged'in f.read_text():break
 time.sleep(3)
items=[]
for l in(w/'ledger-gpu-build.jsonl').read_text().splitlines():
 try:a=json.loads(l)
 except ValueError:continue
 if a.get('reason')=='compiler-artifact'and a.get('executable')and a['target']['name']in ['host_runtime_gpu','memory_gpu','owned_hf_command_batch_gpu','sm80_prefill_alignment_gpu']:items.append(a)
assert len(items)==4
for a in items:
 name=a['target']['name'];tag='contracts-r4-'+name;cmd=[a['executable'],'--ignored','--nocapture','--test-threads=1']
 if name in ['host_runtime_gpu','memory_gpu']:cmd+=['command_batch']
 env=dict(os.environ,LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/('gpu-contract-recheck-'+name)))
 argv=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/('observed-'+tag)),'--']+cmd;(w/(tag+'.argv.json')).write_text(json.dumps(argv))
 with(w/(tag+'.launch.log')).open('x')as f:q=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert q.returncode==0,(name,q.returncode)
a=json.loads((w/'failed-first-packed-contract-test/accuracy-r3-state.json').read_text());a.update(phase='complete',current=None,completed=['final-teacher-C1-eager','final-teacher-allR-Graph','teacher-body-allR','teacher-mixed','teacher-mixed-no-output']+[a['target']['name']for a in items],production_execution_sources_unchanged=True,test_only_amendment=json.loads((w/'test-amendment.json').read_text()),finished_ns=time.time_ns());a.pop('error',None);a.pop('traceback',None);(w/'accuracy-r3-state.json').write_text(json.dumps(a,indent=2))
