from pathlib import Path
import json,time,subprocess,os,hashlib,shutil,traceback
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19a-20261022');r=w.parent/'riley-w0-a100-gpu67-20261019';s=dict(phase='gpu7-numerical',started_ns=time.time_ns())
def save():(w/'gpu7-confirmation-state.json').write_text(json.dumps(s,indent=2))
try:
 save();d=w/'zero-arm-gpu6-admission';d.mkdir();assert not(w/'runs').exists()
 for n in ['experiment-state.json','experiment-final.queue.log','pre-timing-holder-audit.outer.log','audit-pre-timing-holders.py','final-c16.argv.json','final-c32.argv.json','profile-c16.argv.json','profile-c32.argv.json']:
  if(w/n).exists():shutil.copy2(w/n,d/n)
 assert json.loads((d/'experiment-state.json').read_text())['phase']=='failed'
 f=w/'audit-holders.py';f.write_text(f.read_text().replace('if i==6:assert len(ps)==1,ps','if i==7:assert len(ps)==1,ps').replace('GPU6 finite jobs complete and exclusive; GPU7 foreign work observed and untouched','GPU7 normal/profile lane exclusive; GPU6 foreign work observed and untouched'))
 for n in ['final-c16','final-c32','profile-c16','profile-c32']:
  a=json.loads((w/(n+'.argv.json')).read_text());a[a.index('--index')+1]='7';a[a.index('--gpu')+1]='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0';(w/(n+'.argv.json')).write_text(json.dumps(a,indent=2))
 old=w.parent/'riley-qkv-gateup-v214-20261019';out=w/'gpu7-allR-confirmation-output';env=dict(os.environ,LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(out),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES='32',RILEY_TEACHER_SHRINK='all-v1',RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH='segments-v1',RILEY_OWNED_BATCH='native-prefill-sm80-v5');env.pop('CUBLAS_WORKSPACE_CONFIG',None)
 a=json.loads((w/'final-teacher-allR-Graph-r3.argv.json').read_text());a[a.index('--index')+1]='7';a[a.index('--out')+1]=str(w/'observed-gpu7-allR-confirmation');(w/'gpu7-allR-confirmation.argv.json').write_text(json.dumps(a,indent=2))
 with(w/'gpu7-allR-confirmation.launch.log').open('x')as f:q=subprocess.run(a,env=env,stdout=f,stderr=f)
 assert q.returncode==0
 source=w/'final-teacher-allR-Graph-r3';names=sorted(p.name for p in source.glob('*.bf16'));assert names and names==sorted(p.name for p in out.glob('*.bf16'));hashes={}
 for n in names:assert(source/n).read_bytes()==(out/n).read_bytes(),n;hashes[n]=hashlib.sha256((out/n).read_bytes()).hexdigest()
 samples=[json.loads(l)for l in(w/'observed-gpu7-allR-confirmation.samples.jsonl').read_text().splitlines()];peak=max(x['device_memory_mib']for x in samples);assert peak<=22528
 for x in samples:assert all(p['pid']==2027915 or str(p['pid'])in x['verified_owned_start_ticks']for p in x['processes'])
 (w/'gpu7-allR-byte-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),files=len(names),all_literal_equal_to_original_GPU6_native_HF_qualified_values=True,whole_device_peak_MiB=peak,raw_file_sha256=hashes),indent=2))
 s['phase']='gpu7-functional';save();old=w.parent/'riley-weight-layout-v19a-functional-20261022';p=w.parent/'riley-weight-layout-v19a-functional-gpu7-20261022';p.mkdir()
 for n in ['run-pilot.py','run-job.py','measure-matched.py','audit-complete.py','holder.py']:(p/n).write_text((old/n).read_text().replace(old.name,p.name))
 for c in [16,32]:
  a=json.loads((old/f'pilot-c{c}.argv.json').read_text());a=[x.replace(old.name,p.name)for x in a];a[a.index('--index')+1]='7';a[a.index('--gpu')+1]='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0';(p/f'pilot-c{c}.argv.json').write_text(json.dumps(a,indent=2))
 with(p/'outer.log').open('x')as f:q=subprocess.run(['python3',str(p/'run-pilot.py')],stdout=f,stderr=f)
 assert q.returncode==0
 a=json.loads((w/'normal-ready.json').read_text());a.update(time_ns=time.time_ns(),physical_GPU=7,GPU7_fullmodel_numerical_and_functional=True,normal_GPU6_arms=0,normal_GPU_switch_reason='Unadmitted GPU6 job detected before any normal arm; all normal before/after/stock arms freshly measured on isolated GPU7. Both original holders unchanged.');(w/'normal-ready.json').write_text(json.dumps(a,indent=2))
 s.update(phase='complete',files=len(names),finished_ns=time.time_ns());save()
 # Existing failed pre-check logs are archived; no normal arm exists or is replaced.
 (w/'pre-timing-holder-audit.outer.log').rename(d/'archived-pre-timing-holder-audit.outer.log')
 with(w/'experiment-gpu7.queue.log').open('x')as f:q=subprocess.Popen(['python3',str(w/'queue-experiment-v19.py'),str(w),'B'],stdout=f,stderr=f,start_new_session=True)
 print('normal GPU7 queue',q.pid)
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
