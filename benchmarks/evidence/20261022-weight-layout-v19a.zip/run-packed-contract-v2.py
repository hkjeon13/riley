from pathlib import Path
import json,os,time,subprocess,hashlib,shutil,traceback
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19a-20261022');d=w/'packed-contract-v2';d.mkdir(exist_ok=False);r=w.parent/'riley-w0-a100-gpu67-20261019';s=dict(phase='compiling',started_ns=time.time_ns())
def save():(d/'state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 for name in ['observe-finite.py','holder.py']:shutil.copy2(w/name,d/name)
 assert hashlib.sha256((d/'observe-finite.py').read_bytes()).hexdigest()=='c0aad9d71eab4071eefb1f94d809c17ced2652d571e662e2af16bab765097947'
 # Reuse exact final rlib lineage; standalone contract adds no production source mutation.
 rows=[]
 for l in(w/'native-kv-regression.log').read_text().splitlines():
  try:rows.append(json.loads(l))
  except ValueError:pass
 row=next(x for x in reversed(rows)if x.get('reason')=='compiler-artifact'and x.get('target',{}).get('name')=='riley_cuda'and any(f.endswith('.rlib')for f in x.get('filenames',[])));lib=next(f for f in row['filenames']if f.endswith('.rlib'))
 argv=['taskset','-c','48-51','/home/nlp/riley-261013/cargo/bin/rustc','--edition=2024','-O','-C','lto=thin',str(w/'packed-graph-contract.rs'),'--extern','riley_cuda='+lib,'-L','dependency='+str(w/'target/release/deps'),'-o',str(d/'probe')]
 for x in rows:
  if x.get('reason')=='build-script-executed'and'riley-cuda'in x.get('package_id',''):
   for p in x['linked_paths']:argv+=['-L',p]
 env=dict(os.environ,RUSTUP_HOME='/home/nlp/riley-261013/rustup',CARGO_HOME='/home/nlp/riley-261013/cargo',RUSTUP_TOOLCHAIN='1.85.0',CUDA_VISIBLE_DEVICES='',TMPDIR=str(w/'tmp'),LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64')
 (d/'build.argv.json').write_text(json.dumps(dict(argv=argv,rlib_sha256=hashlib.sha256(Path(lib).read_bytes()).hexdigest()),indent=2))
 with(d/'build.log').open('x')as f:q=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert q.returncode==0
 s['phase']='waiting-primary-validation';save()
 while not(w/'normal-ready.json').exists():
  a=json.loads((w/'pipeline-state.json').read_text());assert a.get('phase')!='failed',a;time.sleep(3)
 s['phase']='running';save();env['RILEY_DIVERGENCE_NATIVE_OUTPUT']=str(d/'native-output')
 cmd=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','32-39','python3',str(d/'observe-finite.py'),'--out',str(d/'observed-contract'),'--',str(d/'probe')];(d/'run.argv.json').write_text(json.dumps(cmd))
 with(d/'run.log').open('x')as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=f)
 assert q.returncode==0
 assert 'PACKED_GRAPH_CONTRACT passed' in(d/'observed-contract.stdout').read_text()
 rows=[json.loads(l)for l in(d/'observed-contract.samples.jsonl').read_text().splitlines()];peak=max(x['device_memory_mib']for x in rows);assert peak<=22528
 s.update(phase='complete',whole_device_peak_MiB=peak,binary_sha256=hashlib.sha256((d/'probe').read_bytes()).hexdigest(),finished_ns=time.time_ns());save()
 # Refresh quiet receipt after this additional finite qualification; normal queue is explicitly stopped with zero arms.
 a=json.loads((w/'normal-ready.json').read_text());a.update(time_ns=time.time_ns(),additional_packed_graph_contract=s);(w/'normal-ready.json').write_text(json.dumps(a,indent=2))
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
