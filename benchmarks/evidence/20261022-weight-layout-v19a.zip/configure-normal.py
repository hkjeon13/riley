from pathlib import Path
import json
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19a-20261022');old=w.parent/'riley-overlap-v18b4-20261021'
for n in ['final-c16','final-c32','profile-c16','profile-c32']:
 a=json.loads((old/(n+'.argv.json')).read_text());a=[x.replace(old.name,w.name).replace('riley-overlap-v18b4','riley-weight-layout-v19a').replace('GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0','GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7')for x in a];a[a.index('--index')+1]='6';(w/(n+'.argv.json')).write_text(json.dumps(a,indent=2))
f=w/'audit-holders.py';s=f.read_text().replace('if i==7:assert len(ps)==1,ps','if i==6:assert len(ps)==1,ps').replace('GPU7 finite jobs complete; GPU6 foreign work observed and untouched','GPU6 finite jobs complete and exclusive; GPU7 foreign work observed and untouched');f.write_text(s)
# Generalize source/date/actual GPU; preserve all normal requests and numerical/latency gates.
s=(w/'queue-experiment-v18-final.py').read_text().replace(".removesuffix('-20261021')",".removesuffix('-20261022')").replace('assert len(changed)==10','assert len(changed)==8')
a=s.index(" run(['python3',str(w/'analyze-v18.py')");b=s.index(" run(['python3',str(w/'audit-complete.py')",a)
s=s[:a]+''' run(['python3',str(w/'attribute-v19.py'),*traces],'graph-diagnostics.log')
 run(['python3',str(w/'analyze-profile-v19.py'),*traces],'profile-diagnostics.log')
 run(['python3',str(w/'dispatch-v19.py'),*traces],'actual-dispatch-analysis.log')
'''+s[b:];(w/'queue-experiment-v19.py').write_text(s)
s=(w/'attribute-graphs.py').read_text().replace("'fused_gateup'in n for", "('fused_gateup'in n or 'v19_kmajor_gate'in n) for").replace("'fused_gateup'in name:", "'fused_gateup'in name or 'v19_kmajor_gate'in name:");(w/'attribute-v19.py').write_text(s)
s=(w/'analyze-profile-v15.py').read_text().replace("[('sm80_batched_lm_head'","[('v19_kmajor_gate','linear-GateUp'),('sm80_batched_lm_head'");(w/'analyze-profile-v19.py').write_text(s)
