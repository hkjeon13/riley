from pathlib import Path
import sys,json,time,hashlib,subprocess,os,traceback
w=Path(sys.argv[1]);mode=sys.argv[2];assert mode in ['A','B'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();v=w.parent/'riley-prefill-host-v15c-20261021';s=dict(phase='waiting-qualification',started_ns=time.time_ns())
def save():
 p=w/'experiment-state.json';t=p.with_suffix('.json.pending');t.write_text(json.dumps(s,indent=2));t.replace(p)
def read(p):
 for i in range(20):
  try:return json.loads(p.read_text())
  except(FileNotFoundError,json.JSONDecodeError):time.sleep(.25)
 return {}
def wait(p):
 while True:
  a=read(p);assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':return
  time.sleep(3)
def run(argv,name,extra=None):
 with(w/name).open('x')as f:r=subprocess.run(argv,stdout=f,stderr=f,env=dict(os.environ,**(extra or {})))
 assert r.returncode==0,(argv,r.returncode,name)
try:
 save()
 for name in ['accuracy-r3-state','bounded576-state','canonical-state']+(['canonical576-state','multi576-state','copy-contract-state']if mode=='A'else[]):wait(w/(name+'.json'))
 s['phase']='waiting-quiet';save()
 while not(w/'normal-ready.json').exists():time.sleep(3)
 ready=read(w/'normal-ready.json');assert ready['all_compilation_and_finite_qualification_quiet'] is True
 (w/'audit-pre-timing-holders.py').write_text((w/'audit-holders.py').read_text().replace('final-holder-audit.json','pre-timing-holder-audit.json'))
 run(['python3',str(w/'audit-pre-timing-holders.py'),str(w)],'pre-timing-holder-audit.outer.log')
 m=read(w/'pre-build-source.json')['source_sha256'];expected=938 if mode=='A'else 937;assert len(m)==expected and all(sha(w/'source'/f)==h for f,h in m.items())
 base=read(v/'source-manifest.json');changed=[f for f in m if f not in base or m[f]!=base[f]];assert len(changed)==8
 (w/'source-manifest.json').write_text(json.dumps(m,indent=2));binary=w/w.name.removesuffix('-20261022');assert sha(binary)==(w/'qualification-binary.sha256').read_text().split()[0]
 assert sha(v/'riley-prefill-host-v15c')=='233c3a6a81bad76d65577bacd5837d59e2ebe1dd52a8fde73f3cd07a38cf937a'
 assert sha(w/'observe-finite.py')=='c0aad9d71eab4071eefb1f94d809c17ced2652d571e662e2af16bab765097947'
 inputs={str(p):sha(p)for p in [binary,w/'measure-matched.py',w/'final-c16.argv.json',w/'final-c32.argv.json']}
 for c in [16,32]:
  a=read(w/f'final-c{c}.argv.json')
  for k,val in [('--baseline-server',str(v/'riley-prefill-host-v15c')),('--candidate-binary',str(binary)),('--repeats','5'),('--repeat-start','0'),('--warm','64'),('--keep','192'),('--concurrency',str(c))]:assert a[a.index(k)+1]==val,(k,a)
 (w/'source-lineage.json').write_text(json.dumps(dict(time_ns=time.time_ns(),baseline_commit='57502e7a0fafd165966071e88b3e8a56cdea0e3d',baseline_binary=str(v/'riley-prefill-host-v15c'),baseline_sha256=sha(v/'riley-prefill-host-v15c'),binary=str(binary),binary_sha256=sha(binary),qualified_source_count=expected,changed_sources=changed,new_sources=[f for f in changed if f not in base],source_manifest_sha256=sha(w/'source-manifest.json'),normal_inputs_sha256=inputs),indent=2))
 for n in ['final-c16','final-c32']:
  s.update(phase='measuring',current=n);save();run(['python3',str(w/'run-job.py'),n],n+'.outer.log')
 (w/'campaign-state.json').write_text(json.dumps(dict(phase='complete',time_ns=time.time_ns())))
 # Generalize only the exact source-count assertion; native/SSE gates are unchanged.
 p=w/'queue-g-analysis.py';t=p.read_text();assert 'assert len(m)==937'in t;t=t.replace('assert len(m)==937',f'assert len(m)=={expected}').replace('source937_all_equal=True',f'source_count={expected},all_sources_equal=True');(w/'queue-analysis-v18.py').write_text(t)
 run(['python3',str(w/'queue-analysis-v18.py')],'normal-analysis.outer.log');assert read(w/'normal-analysis-state.json')['phase']=='complete'
 traces=[]
 for c in [16,32]:
  s.update(phase='profiling',current=c);save();run(['python3',str(w/'run-job.py'),f'profile-c{c}'],f'profile-c{c}.outer.log',{'RILEY_HOST_STEP_TRACE':'1'})
  traces.extend(str(w/f'runs/profile-c{c}/c{c}-r0-owned-{x}/trace.sqlite')for x in ['before','after'])
 (w/'profile-run-environment.json').write_text(json.dumps(dict(RILEY_HOST_STEP_TRACE='1',scope='Profiles only, both before/after; normal timing unchanged',traces=traces),indent=2))
 run(['python3',str(w/'attribute-v19.py'),*traces],'graph-diagnostics.log')
 run(['python3',str(w/'analyze-profile-v19.py'),*traces],'profile-diagnostics.log')
 run(['python3',str(w/'dispatch-v19.py'),*traces],'actual-dispatch-analysis.log')
 run(['python3',str(w/'audit-complete.py')],'audit-complete.outer.log');audit=read(w/'independent-audit.json');assert len(audit['arms'])==34
 run(['python3',str(w/'audit-holders.py'),str(w)],'holder-audit.outer.log')
 (w/'diagnostics-state.json').write_text(json.dumps(dict(phase='complete',time_ns=time.time_ns(),traces=traces)))
 s.update(phase='measured-and-audited',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
