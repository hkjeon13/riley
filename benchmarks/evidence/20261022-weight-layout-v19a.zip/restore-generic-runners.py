from pathlib import Path
import json,hashlib,time,shutil,subprocess
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19a-20261022');old=w.parent/'riley-overlap-v18b4-20261021';assert not(w/'runs').exists();d=w/'zero-arm-runner-allowlist';d.mkdir()
for n in ['final-c16.log','final-c16.outer.log','final-c16.state.json','source-lineage.json','source-manifest.json','pre-timing-holder-audit.outer.log','pre-timing-holder-audit.json','experiment-state.json','experiment-gpu7.queue.log']:
 if(w/n).exists():shutil.move(w/n,d/n)
proof=[]
for n in ['measure-matched.py','measure-profile.py','audit-complete.py','audit-tail-b.py','analyze-final.py','queue-g-analysis.py']:
 a=(w/n).read_bytes();shutil.copy2(w/n,d/n);s=(old/n).read_text().replace(old.name,w.name).replace('riley-overlap-v18b4','riley-weight-layout-v19a');(w/n).write_text(s);proof.append(dict(name=n,before_sha256=hashlib.sha256(a).hexdigest(),after_sha256=hashlib.sha256((w/n).read_bytes()).hexdigest(),change='Restore original generic GPU6/GPU7 support; only campaign path/binary names changed from completed B4 harness. No workload/numerical/latency criteria changed.'))
(w/'normal-runner-amendment.json').write_text(json.dumps(dict(time_ns=time.time_ns(),completed_normal_arms=0,reason='Initial template-wide GPU7-to-GPU6 replacement accidentally duplicated the generic supported GPU allowlist. Failure occurred before output directory/server/normal requests. Restore generic original harness, freeze new runner identities before first arm.',files=proof),indent=2))
with(w/'experiment-final-gpu7.queue.log').open('x')as f:q=subprocess.Popen(['python3',str(w/'queue-experiment-v19.py'),str(w),'B'],stdout=f,stderr=f,start_new_session=True)
print(q.pid)
