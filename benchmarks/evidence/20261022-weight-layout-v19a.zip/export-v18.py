from pathlib import Path
import sys,json,hashlib,re,time,zipfile,difflib,shutil
w=Path(sys.argv[1]);mode=sys.argv[2];assert mode in ['A','B'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());v=w.parent/'riley-prefill-host-v15c-20261021'
assert read(w/'experiment-state.json')['phase']=='measured-and-audited'
for n in ['normal-analysis-state','accuracy-r3-state','bounded576-state','canonical-state','diagnostics-state']+(['canonical576-state','multi576-state','copy-contract-state']if mode=='A'else[]):assert read(w/(n+'.json'))['phase']=='complete',n
m=read(w/'source-manifest.json');base=read(v/'source-manifest.json');expected=938 if mode=='A'else 937;assert len(m)==expected and len(base)==937
assert m==read(w/'pre-build-source.json')['source_sha256']and all(sha(w/'source'/f)==h for f,h in m.items())
l=read(w/'source-lineage.json');assert l['qualified_source_count']==expected and len(l['changed_sources'])==10
assert all(sha(Path(p))==h for p,h in l['normal_inputs_sha256'].items())and sha(Path(l['binary']))==l['binary_sha256']
assert sha(w/'observe-finite.py')=='c0aad9d71eab4071eefb1f94d809c17ced2652d571e662e2af16bab765097947'
assert sha(v/'riley-prefill-host-v15c')=='233c3a6a81bad76d65577bacd5837d59e2ebe1dd52a8fde73f3cd07a38cf937a'
def patch(root,changed):
 text=''
 for f in changed:
  old=(v/'source'/f).read_text().splitlines(True)if f in base else[]
  text+=''.join(difflib.unified_diff(old,(root/'source'/f).read_text().splitlines(True),fromfile='a/'+f if f in base else'/dev/null',tofile='b/'+f))
 return text
(w/'candidate.patch').write_text(patch(w,l['changed_sources']))
assert not set(m)-set(base)if mode=='B'else set(m)-set(base)=={'crates/riley-cuda/src/prefill_piece.rs'}
teachers=read(w/'final-teacher-r3-audit.json')['runs'];mixed=read(w/'mixed-byte-r3-audit.json')['runs'];assert sum(x['files']for x in teachers)+sum(x['rows']for x in mixed)==4480
assert all(x['all_bytes_equal_to_original_native_and_HF']for x in teachers)and all(x['all_literal_equal_to_original_native_and_HF']for x in mixed)
bounded=read(w/'bounded576-byte-audit.json');assert bounded['files']==2048 and bounded['all_equal_to_original_native_and_HF']
for n in ['canonical']+(['canonical576','multi576']if mode=='A'else[]):
 a=read(w/(n+'-byte-audit.json'));assert a['files']==1024 and a['all_literal_equal_to_original_HF_native']
regression=(w/'native-kv-regression.log').read_text();cpu=[tuple(map(int,x))for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',regression)];passed=522 if mode=='A'else 526;assert tuple(sum(x[i]for x in cpu)for i in range(3))==(passed,4,40)
c02=read(w/'recheck-c02.py.outer.log');assert c02['all_passed']and len(c02['tests'])==4 and all(x['returncode']==0 for x in c02['tests'])
functions=sum(int(re.search(r'test result: ok\. (\d+) passed',(w/('observed-'+n+'.stdout')).read_text()).group(1))for n in ['memory_gpu','owned_hf_command_batch_gpu','host_runtime_gpu','sm80_prefill_alignment_gpu']);assert functions==5
resources=[]
names=['final-teacher-C1-eager-r3','final-teacher-allR-Graph-r3','teacher-body-allR-r3','teacher-mixed-r3','teacher-mixed-no-output-r3','memory_gpu','owned_hf_command_batch_gpu','host_runtime_gpu','sm80_prefill_alignment_gpu','bounded576','canonical']+(['canonical576','multi576','copy-contract']if mode=='A'else[])
for name in names:
 a=read(w/('observed-'+name+'.json'));assert a['status']=='complete'and a['returncode']==0
 rows=[json.loads(s)for s in(w/('observed-'+name+'.samples.jsonl')).read_text().splitlines()];peak=max(s['device_memory_mib']for s in rows);assert 0<peak<=22528
 resources.append(dict(name=name,samples=len(rows),whole_device_peak_MiB=peak,receipt_sha256=sha(w/('observed-'+name+'.json'))))
proof=read(w/'actual-candidate-dispatch.json');assert len(proof)==2
assert all(x['actual_multi_prefill_graph_replay']for x in proof)if mode=='A'else all(x['actual_CPU_GPU_overlap']for x in proof)
if mode=='A':
 x=read(w/'copy-contract-audit.json');assert x['same_graph_R_replays']==33 and x['rejected_invalid_or_busy_calls']==75 and x['final_allocation_zero']and x['hostile_device_offset_no_write']
(w/'extended-accuracy-audit.json').write_text(json.dumps(dict(original_BF16_files=4480,bounded576_files=2048,canonical4096_files=1024,canonical576_files=1024 if mode=='A'else 0,two_prefill576_files=1024 if mode=='A'else 0,total_literal_BF16_files=9600 if mode=='A'else 7552,reference_and_tolerance_unchanged=True,CPU_passed=passed+4,CPU_ignored=40,approved_C02_tmp_rechecks=4,GPU_contract_functions=functions,existing_alignment_view_cases=120,new_copy_ABI_same_graph_R_replays=33 if mode=='A'else 0,new_copy_ABI_invalid_or_busy_rejections=75 if mode=='A'else 0,scope='Full-vocabulary/native BF16 regression gates; does not use stock vLLM as numerical oracle'),indent=2))
audit=read(w/'independent-audit.json');normal=[x for x in audit['arms']if x['run']in ['final-c16','final-c32']];assert len(audit['arms'])==34 and len(normal)==30
assert read(w/'final-holder-audit.json')['passed']
(w/'resource-audit-final.json').write_text(json.dumps(dict(time_ns=time.time_ns(),resource_runs=resources,qualified_source_count=expected,all_source_hashes_equal=True,binary_sha256=l['binary_sha256'],normal_arms=30,separate_profile_arms=4,total_stored_SSE_structures_verified=audit['total_full_SSE_values_verified'],Riley_native_HF_values_literal_equal=True,stock_HF_matches_reported_per_arm=True,normal_profile_peak_MiB=max(x['peak_whole_device_MiB']for x in audit['arms']),whole_device_cap_MiB=22528,qualification_GPU=7,extra_canonical_GPU=6,normal_profile_GPU=7,original_GPU6_7_holder_PID_and_context_retained=True),indent=2))
stock=[]
for p in(w/'runs').glob('final-*/c*-vllm/server.log'):
 text=p.read_text();assert 'FLASH_ATTN'in text and 'FULL_AND_PIECEWISE'in text and ('version 2'in text or'version=2'in text),p
 stock.append(dict(log=str(p),sha256=sha(p),FLASH_ATTN=True,FULL_AND_PIECEWISE=True,version2=True))
assert len(stock)==10;(w/'stock-startup-proof.json').write_text(json.dumps(stock,indent=2))
stats=read(w/'final-statistics.json');eligible=all(not x['tail_over_two_percent_flags']and x['median_percent_change']['output_tok_s']>0 for x in stats['cells'])
(w/'adoption-decision.json').write_text(json.dumps(dict(time_ns=time.time_ns(),eligible_for_integration=eligible,integrated_into_main=False,normal_completed_arms_excluded=0,accuracy_threshold_changed=False,tail_flags={str(x['concurrency']):x['tail_over_two_percent_flags']for x in stats['cells']},throughput_changes={str(x['concurrency']):x['median_percent_change']['output_tok_s']for x in stats['cells']},reason='Require positive median throughput at both C16/C32 and no paired TTFT/TPOT p95/p99 regression greater than2%; original accuracy/resource/actual-dispatch gates passed. Main integration is a separate verified step.'),indent=2))
if mode=='B':
 # Retain functional pilot separately; never mix its64keep timings with192normal.
 pilot=w.parent/'riley-weight-layout-v19a-functional-20261021';assert read(pilot/'pilot-state.json')['phase']=='complete';assert len(read(pilot/'audit-partial.json')['arms'])==2
 destination=w/'functional-preflight';destination.mkdir(exist_ok=False)
 for p in pilot.rglob('*'):
  if not p.is_file()or any(x in ['tmp','cache','__pycache__']for x in p.relative_to(pilot).parts)or p.suffix not in ['.json','.log','.py','.txt']:continue
  q=destination/p.relative_to(pilot);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 counters=[]
 pattern=r'RILEY_DECODE_OVERLAP submitted=(\d+) reused=(\d+) discarded=(\d+) cpu_callbacks=(\d+) planned_ahead=(\d+) deferred_cancels=(\d+) considered=(\d+) no_preview=(\d+) early_publications=(\d+) pending_batch_skips=(\d+) queued_admission_skips=(\d+)'
 for p in(w/'runs').glob('final-*/c*-owned-after/server.log'):
  found=re.findall(pattern,p.read_text());assert found,p;values=tuple(map(int,found[-1]));assert values[0]==values[3]==values[8]and values[4]<=values[3]and values[1]>0 and values[0]==values[1]+values[2]
  counters.append(dict(log=str(p),sha256=sha(p),**dict(zip(['submitted','reused','discarded','cpu_callbacks','planned_ahead','deferred_cancels','considered','no_preview','early_publications','pending_batch_skips','queued_admission_skips'],values)),scope='Whole process includes correctness/warm/recovery, not measured-window hit rate or causal speedup'))
 assert len(counters)==10;(w/'overlap-handoff-proof.json').write_text(json.dumps(counters,indent=2))
 prototypes=[]
 for label in ['riley-overlap-v18b','riley-overlap-v18b2']:
  old=w.parent/(label+'-20261021');oldm=read(old/'pre-build-source.json')['source_sha256'];assert len(oldm)==937 and all(sha(old/'source'/f)==h for f,h in oldm.items());assert not list(old.glob('observed-*.json'))and not(old/'runs').exists()
  changed=[f for f in oldm if oldm[f]!=base[f]];dest=w/('prototype-'+label);dest.mkdir()
  (dest/'candidate.patch').write_text(patch(old,changed))
  for n in ['pre-build-source.json','native-kv-server-build.log','native-kv-regression.log','native-kv-build-and-cpu.exit','qualification-binary.sha256','superseded-before-GPU.json','setup-attempt1.json']:
   if(old/n).exists():shutil.copy2(old/n,dest/n)
  prototypes.append(dict(root=str(old),qualified_source_count=937,changed_sources=changed,GPU_arms=0,scope='CPU-only prototypes superseded before any GPU serving/numerical experiment; no measured arm excluded'))
 # B3 completed numerical and functional preflight, then was superseded
 # before any normal comparison. Preserve it explicitly, never label GPU0.
 old=w.parent/'riley-overlap-v18b3-20261021';oldm=read(old/'pre-build-source.json')['source_sha256'];assert len(oldm)==937 and all(sha(old/'source'/f)==h for f,h in oldm.items())
 assert not(old/'runs').exists()and read(old/'accuracy-r3-state.json')['phase']=='complete'
 changed=[f for f in oldm if oldm[f]!=base[f]];dest=w/'prototype-riley-overlap-v18b3';dest.mkdir()
 (dest/'candidate.patch').write_text(patch(old,changed))
 for n in ['pre-build-source.json','native-kv-server-build.log','native-kv-regression.log','native-kv-build-and-cpu.exit','qualification-binary.sha256','superseded-before-normal.json','accuracy-r3-state.json','bounded576-state.json','bounded576-byte-audit.json','canonical-state.json','canonical-byte-audit.json','final-teacher-r3-audit.json','mixed-byte-r3-audit.json']:
  if(old/n).exists():shutil.copy2(old/n,dest/n)
 pilotold=w.parent/'riley-overlap-v18b3-functional-20261021';assert read(pilotold/'pilot-state.json')['phase']=='complete'
 for p in pilotold.rglob('*'):
  if not p.is_file()or any(x in ['tmp','cache','__pycache__']for x in p.relative_to(pilotold).parts)or p.suffix not in ['.json','.log','.py','.txt']:continue
  q=dest/'functional-preflight'/p.relative_to(pilotold);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 prototypes.append(dict(root=str(old),qualified_source_count=937,changed_sources=changed,numerical_BF16_files=7552,functional_arms=2,functional_SSE_values=224,normal_comparison_arms=0,scope='Numerically and functionally qualified B3 prototype; superseded before normal comparison by pending-GPU error and queued-admission guards. All preflight receipts retained; no measured normal arm excluded.'))
 (w/'prototype-index.json').write_text(json.dumps(prototypes,indent=2))
# Do not index model/cache/source/target trees. Include all selected text receipts
# and every stored raw SSE request; heavy numerical/traces/binaries stay on EFS.
skip={'source','target','tmp','cache','vllm-cache','ipc6','ipc7','__pycache__','torch_compile_cache','torchinductor_cache'};allowed={'.json','.jsonl','.log','.txt','.py','.sh','.stdout','.stderr','.cu','.cuh','.cpp','.sse','.h','.hpp','.exit','.sha256','.rs','.patch'};files=[];heavy={}
for p in w.rglob('*'):
 if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
 with p.open('rb')as f:magic=f.read(4)
 if p.suffix in ['.bf16','.sqlite','.nsys-rep','.safetensors']or magic==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
 if (p.suffix in allowed or '.attempt' in p.name or p.name.endswith(('.wait-read-failure','.pre-copy-contract-build-fix'))) and p.name not in ['evidence-archive-receipt.json','heavy-evidence-index.json']:files.append(p)
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2));files.append(w/'heavy-evidence-index.json')
manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)};z=w/'evidence-archive.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as f:
 for p in sorted(files):f.write(p,str(p.relative_to(w)))
 f.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
receipt=dict(time_ns=time.time_ns(),archive=str(z),bytes=z.stat().st_size,entries=len(files)+1,sha256=sha(z),heavy_files=len(heavy));(w/'evidence-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
