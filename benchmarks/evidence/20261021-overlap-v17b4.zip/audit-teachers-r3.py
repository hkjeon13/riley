from pathlib import Path
import json,re,hashlib,time
p=Path('/mnt/efs/nlp/psyche/riley-overlap-v17b4-20261021');old=p.parent/'riley-qkv-gateup-v214-20261019';before=old/'v226-qwen3-4b-before-C1-eager';froot=old/'qwen3-4b-fresh-A100-HF-v222';fixture=json.loads((froot/'fixture.json').read_text());proof=[]
for name in ['final-teacher-C1-eager-r3','final-teacher-allR-Graph-r3','teacher-body-allR-r3']:
 receipt=json.loads((p/('observed-'+name+'.json')).read_text());assert receipt['status']=='complete'and receipt['returncode']==0,receipt
 folder=p/name;meta=json.loads((folder/'result.json').read_text());rows=[r for m in meta['models']for c in m['cases']for r in c['rows']];body=name=='teacher-body-allR-r3';assert len(rows)==(1024 if body else 104);assert all(r['max_abs']==r['mean_abs']==0 for r in rows)
 files={};raws=list(folder.glob('*.bf16'));assert len(raws)==(2048 if body else 208)
 for f in raws:
  ref=re.sub(r'-r\d+(?=-s\d+\.)','',f.name)if body else f.name
  b=f.read_bytes();assert b==(before/ref).read_bytes(),(name,f.name)
  files[f.name]=hashlib.sha256(b).hexdigest()
 for case in fixture['models'][0]['cases']:
  if body and case['id']!='natural-128':continue
  for step in case['steps']:
   ref=froot/step['file'];raw=ref.read_bytes();assert hashlib.sha256(raw).hexdigest()==fixture['files'][step['file']]['sha256']
   for count in(range(1,33)if body else[None]):
    leaf=case['id']+(f'-r{count}'if count is not None else'');f=folder/f'qwen3-4b-{leaf}-s{step["step"]}.native.bf16';assert f.read_bytes()==raw,(name,f.name)
 stderr=(p/('observed-'+name+'.stderr')).read_text();stdout=(p/('observed-'+name+'.stdout')).read_text();captures=stderr.count('RILEY_OWNED_SEGMENT capture=true');replays=stderr.count('RILEY_OWNED_SEGMENT replay=true');keys=sorted(set(map(int,re.findall(r'RILEY_OWNED_BODY_KEY active_rows=(\d+)',stderr))))
 if name=='final-teacher-allR-Graph-r3':assert 'RILEY_TEACHER_ALL_COUNTS verified=1..32 changed_contexts=true'in stdout and 0<replays<=captures<=2336 and captures-replays<=1 and keys
 mixed_startup_captures=0
 markers=list(re.finditer(r'RILEY_MIXED_BODY_WARMUP entries=(\d+) sealed=true',stderr))
 if markers:
  assert len(markers)==1 and int(markers[0][1])==24
  prefix=stderr[:markers[0].start()].splitlines();expected=['RILEY_OWNED_SEGMENT capture=true','RILEY_OWNED_SEGMENT replay=true']*24
  assert prefix[-48:]==expected,('mixed startup must be exactly24 capture/replay pairs',prefix[-48:])
  mixed_startup_captures=24
 if body:assert keys==list(range(2,33))and captures-mixed_startup_captures==replays-mixed_startup_captures==62 and set(map(int,re.findall(r'RILEY_TEACHER_BODY_COUNT active=(\d+)',stdout)))==set(range(1,33))
 proof.append(dict(name=name,files=len(raws),HF_full_vocabulary_rows=len(rows),all_bytes_equal_to_original_native_and_HF=True,raw_file_sha256=files,whole_body_actual_row_keys=keys,graph_captures=captures,graph_first_replays=replays,mixed_startup_captures=mixed_startup_captures,pure_body_captures=captures-mixed_startup_captures,allocations_closed=True))
(p/'final-teacher-r3-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),runs=proof,scope='Original native and HF full vocabulary byte equality, unchanged104HFrows eager/Graph plus1024rows natural128 R1..32; not full104x32Cartesian'),indent=2));print([(r['name'],r['files'],r['graph_captures'],r['graph_first_replays'])for r in proof])
