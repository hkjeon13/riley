from pathlib import Path
import json,shutil,tarfile,hashlib,subprocess,time
w=Path('/mnt/efs/nlp/psyche/riley-overlap-v17b4-20261021');g=w.parent/'riley-mlp-batch-v16g-20261021';v=w.parent/'riley-prefill-host-v15c-20261021';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(w/'target').exists();base=json.loads((v/'source-manifest.json').read_text());assert len(base)==937
for n in ['source','tmp','cache','ipc6','ipc7']:(w/n).mkdir(mode=0o700,exist_ok=True)
for f,h in base.items():
 p=v/'source'/f;assert sha(p)==h;q=w/'source'/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
with tarfile.open(w/'candidate-b4.tar.gz')as f:
 assert len(f.getnames())==7;f.extractall(w/'source')
m={f:sha(w/'source'/f)for f in sorted(base)};assert [f for f in m if m[f]!=base[f]]==sorted(tarfile.open(w/"candidate-b4.tar.gz").getnames());(w/'pre-build-source.json').write_text(json.dumps(dict(time_ns=time.time_ns(),source_sha256=m),indent=2))
files=['build.sh','queue-build-extra.py','queue-accuracy.py','build-gpu-c.sh','recheck-c02.py','build-teacher-final.py','teacher-probe-final.rs','teacher-body.rs','teacher-mixed.rs','build-teacher-body.py','build-teacher-mixed.py','measure-matched.py','measure-profile.py','analyze-profiles.py','audit-complete.py','analyze-final.py','run-job.py','stock-runtime-proof.py','holder.py','observe-finite.py','audit-tail-b.py','pointer-inspection.cpp','analyze-profile-v15.py','attribute-graphs.py','audit-teachers-r3.py','audit-mixed-r3.py','run-bounded-g.py','queue-g-analysis.py']
for n in files:
 s=(g/n).read_text().replace('riley-mlp-batch-v16g','riley-overlap-v17b4');(w/n).write_text(s)
for n in ['pointer-inspection.so','call-inspection-nvtx.so']:shutil.copy2(g/n,w/n)
for c in[16,32]:
 for mode in['final','profile']:
  a=json.loads((g/f'{mode}-c{c}.argv.json').read_text().replace('riley-mlp-batch-v16g','riley-overlap-v17b4'));assert a[a.index('--baseline-server')+1]==str(v/'riley-prefill-host-v15c');(w/f'{mode}-c{c}.argv.json').write_text(json.dumps(a,indent=2))
p=w/'run-bounded-g.py';t=p.read_text();mark=" assert json.loads((w.parent/'riley-mlp-batch-v16d-20261021/routes-state.json').read_text())['phase']=='complete'";assert mark in t;t=t.replace(mark,mark+"\n while True:\n  p=w.parent/'riley-projection-v17a-20261021/accuracy-r3-state.json';a=json.loads(p.read_text())if p.exists()else{};assert a.get('phase')!='failed',a\n  if a.get('phase')=='complete':break\n  time.sleep(3)");p.write_text(t)
for n in['queue-build-extra.py']:
 p=w/n;t=p.read_text().replace('(520,4,40)','(523,4,40)');p.write_text(t)
subprocess.run(['python3',str(w.parent/'upgrade-auditor-v17.py'),str(w),'fresh'],check=True)
for n,argv in [('build' ,['bash',str(w/'build.sh')]),('build-extra',['python3',str(w/'queue-build-extra.py')]),('bounded',['python3',str(w/'run-bounded-g.py')]),('accuracy',['python3',str(w/'queue-accuracy.py')])]:
 with(w/(n+'.outer.log')).open('x')as f:p=subprocess.Popen(argv,stdout=f,stderr=f,start_new_session=True)
 print(n,p.pid)
