from pathlib import Path
import subprocess,json,os,signal,time
r=Path('/mnt/efs/nlp/psyche');w=r/'riley-overlap-v17b4-20261021'
lines=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True).splitlines();pids=[int(l.split(',')[1])for l in lines if l.startswith('GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7')];assert pids==[2027914],pids
state=json.loads((w/'canonical-state.json').read_text());assert state['phase']=='waiting-accuracy';assert (w/'teacher-canonical').is_file();pid=1364441;assert str(w/'run-canonical-b4.py')in Path('/proc/'+str(pid)+'/cmdline').read_text();os.kill(pid,signal.SIGTERM)
(w/'canonical-wait-superseded.json').write_text(json.dumps(dict(time_ns=time.time_ns(),prior_state=state,waiting_pid=pid,reason='Run compiled independent canonical check concurrently on held GPU6; no source/binary changes and no normal timing active'),indent=2))
s=(w/'run-canonical-b4.py').read_text();a=s.index(" s['phase']='numerical'");tail=s[a:];header=s[:s.index('try:\n')];header=header.replace("s=dict(phase='waiting-accuracy',started_ns=time.time_ns())","s=dict(phase='numerical',started_ns=time.time_ns(),qualification_gpu=6)")
s=header+'try:\n'+tail;s=s.replace('GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0','GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7').replace("'--index','7'","'--index','6'");(w/'run-canonical-parallel.py').write_text(s)
with(w/'canonical-parallel.outer.log').open('x')as f:q=subprocess.Popen(['python3',str(w/'run-canonical-parallel.py')],stdout=f,stderr=f,start_new_session=True)
print(q.pid)
