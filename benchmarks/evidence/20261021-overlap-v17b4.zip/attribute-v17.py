from pathlib import Path
import sqlite3,collections,json,sys,hashlib
paths=[Path(p)for p in sys.argv[1:]]
results=[]
for path in paths:
 d=sqlite3.connect(path);d.row_factory=sqlite3.Row;strings=dict(d.execute('select id,value from StringIds'));rows=d.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL order by start').fetchall();graphs=collections.defaultdict(dict)
 for r in rows:
  if r['graphId'] is not None:graphs[r['graphId']].setdefault(r['graphNodeId'],r)
 mapping={};audit=[]
 for gid,nodes in graphs.items():
  nr=list(nodes.values());names=[strings[r['demangledName']]for r in nr];res=sum('residual_add_kernel'in n for n in names);kind='body'if res==72 else'mlp'if res==0 and len(nr)<=8 and any('silu'in n or 'fused_gateup'in n for n in names)else'unknown'
  if kind=='body' and any('kv_gather'in n for n in names):kind='mixed-opaque'
  if kind in ['unknown','mixed-opaque']:audit.append(dict(graph=gid,kind=kind,nodes=len(nr),residuals=res));continue
  stage='linear-QKV'if kind=='body'else'linear-GateUp';residuals=0;mapped=[]
  for r,name in zip(nr,names):
   if 'residual_add_kernel'in name:
    residuals+=1;stage='linear-GateUp'if residuals%2 else'linear-QKV'
   if residuals==72:stage='linear-LMhead'
   if 'silu'in name or 'fused_gateup'in name:stage='linear-Down'
   if 'batched_pv_dispatch'in name or 'chunk_paged_pv'in name or 'chunk_paged_wmma_pv'in name or 'fused_softpv'in name:stage='linear-O'
   if name.startswith('ampere_')or 'cutlass::Kernel2'in name or 'splitKreduce_kernel'in name:
    key=(gid,r['graphNodeId']);mapping[key]=stage;mapped.append(dict(node=r['graphNodeId'],stage=stage,name=name,grid=[r['gridX'],r['gridY'],r['gridZ']]))
  audit.append(dict(graph=gid,kind=kind,nodes=len(nr),residuals=res,mapped=mapped))
 totals=collections.defaultdict(lambda:dict(count=0,ms=0.0));unclassified=collections.defaultdict(lambda:dict(count=0,ms=0.0));graphms=0
 for r in rows:
  if r['graphId']is None:continue
  ms=(r['end']-r['start'])/1e6;graphms+=ms;k=(r['graphId'],r['graphNodeId'])
  if k in mapping:entry=totals[mapping[k]]
  else:entry=unclassified[strings[r['demangledName']]]
  entry['count']+=1;entry['ms']+=ms
 result=dict(trace=str(path),trace_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),scope='Graph GEMM attribution from first-execution node order and source stage anchors; no transfer from kernel-name/geometry alone. Eager NVTX attribution remains separate. Not hardware counters.',graph_count=len(graphs),graph_kernel_sum_ms=graphms,graph_linear_categories=dict(totals),remaining_graph_top=dict(sorted(unclassified.items(),key=lambda x:-x[1]['ms'])[:20]),node_audit=audit)
 out=path.parent/'graph-attribution-v15.json';out.write_text(json.dumps(result,indent=2));results.append({k:v for k,v in result.items()if k not in ['node_audit','remaining_graph_top']})
print(json.dumps(results,indent=2))
