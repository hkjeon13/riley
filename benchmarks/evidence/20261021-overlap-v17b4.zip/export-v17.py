from pathlib import Path
import argparse,hashlib,json,time,zipfile
p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('mode',choices=['A','B']);p.add_argument('--adopt',action='store_true');a=p.parse_args();w=Path(a.root);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['campaign-state','normal-analysis-state','accuracy-r3-state','diagnostics-state','bounded576-state']:
 assert json.loads((w/(n+'.json')).read_text())['phase']=='complete',n
m=json.loads((w/'source-manifest.json').read_text());assert len(m)==937 and all(sha(w/'source'/f)==h for f,h in m.items())
l=json.loads((w/'source-lineage.json').read_text());assert sha(Path(l['binary']))==l['binary_sha256']
assert all(sha(Path(f))==h for f,h in l['normal_inputs_sha256'].items())
assert sha(w/'observe-finite.py')=='c0aad9d71eab4071eefb1f94d809c17ced2652d571e662e2af16bab765097947'
import difflib,re
v=w.parent/'riley-prefill-host-v15c-20261021'
patch=''.join(''.join(difflib.unified_diff((v/'source'/f).read_text().splitlines(True),(w/'source'/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f))for f in l['changed_sources']);(w/'candidate.patch').write_text(patch)
teacher=json.loads((w/'final-teacher-r3-audit.json').read_text())['runs'];mixed=json.loads((w/'mixed-byte-r3-audit.json').read_text())['runs'];bounded=json.loads((w/'bounded576-byte-audit.json').read_text())
assert sum(r['files']for r in teacher)+sum(r['rows']for r in mixed)==4480
assert all(r['all_bytes_equal_to_original_native_and_HF']for r in teacher)
assert all(r['all_literal_equal_to_original_native_and_HF']for r in mixed)
assert bounded['files']==2048 and bounded['all_equal_to_original_native_and_HF']
functions=0
for name in ['memory_gpu','owned_hf_command_batch_gpu','host_runtime_gpu','sm80_prefill_alignment_gpu']:
 functions+=int(re.search(r'test result: ok\. (\d+) passed',(w/('observed-'+name+'.stdout')).read_text()).group(1))
assert functions==5
regression=(w/'native-kv-regression.log').read_text();cpu=[tuple(map(int,m))for m in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',regression)]
assert tuple(sum(r[i]for r in cpu)for i in range(3))==((520,4,40)if a.mode=='A'else(523,4,40))
c02=json.loads((w/'recheck-c02.py.outer.log').read_text());assert c02['all_passed'] and len(c02['tests'])==4 and all(t['returncode']==0 for t in c02['tests'])
assert m==json.loads((w/'pre-build-source.json').read_text())['source_sha256']

proof=json.loads((w/'actual-candidate-dispatch.json').read_text());assert len(proof)==2
if a.mode=='A':assert all(p['candidate_kernels']for p in proof)
assert json.loads((w/'final-holder-audit.json').read_text())['passed']
(w/'extra-coverage-scope.json').write_text(json.dumps(dict(files=2048,serving_capacity=576,same_original_HF_native_references=True,covers='natural128 R1..32/chunks4; prefill rows256/384/512; no new cold merged-scratch growth path exists in A/B',raw_template_scope_correction='bounded576-byte-audit.json inherited G template text mentioning a raw-buffer resize; that part does not apply to either A or B. Byte checks and reference hashes are unchanged.'),indent=2))
(w/'extended-accuracy-audit.json').write_text(json.dumps(dict(original_files=4480,extra_serving_capacity576_files=2048,total_literal_BF16_files=6528+(1024 if a.mode=='B'else 0),original_reference_and_tolerance_unchanged=True,GPU_contract_functions=functions,new_merged_raw_cases=0,existing_alignment_cases=120,CPU_passed=524 if a.mode=='A'else 527,CPU_ignored=40),indent=2))
stats=json.loads((w/'final-statistics.json').read_text());a.adopt=all(not c['tail_over_two_percent_flags']and c['median_percent_change']['output_tok_s']>0 for c in stats['cells']) and(a.mode=='A'or all(p['actual_mixed_graph_hit']for p in proof));audit=json.loads((w/'independent-audit.json').read_text());normal=[x for x in audit['arms']if x['run']in ['final-c16','final-c32']];assert len(normal)==30
if a.adopt:assert all(not c['tail_over_two_percent_flags'] and c['median_percent_change']['output_tok_s']>0 for c in stats['cells'])
res=[]
for n in ['final-teacher-C1-eager-r3','final-teacher-allR-Graph-r3','teacher-body-allR-r3','teacher-mixed-r3','teacher-mixed-no-output-r3','memory_gpu','owned_hf_command_batch_gpu','host_runtime_gpu','sm80_prefill_alignment_gpu','bounded576']+(['canonical']if a.mode=='B'else[]):
 r=json.loads((w/('observed-'+n+'.json')).read_text());assert r['status']=='complete'and r['returncode']==0
 ss=[json.loads(x)for x in(w/('observed-'+n+'.samples.jsonl')).read_text().splitlines()];peak=max(s['device_memory_mib']for s in ss);assert 0<peak<=22528
 res.append(dict(name=n,samples=len(ss),whole_device_peak_MiB=peak,receipt_sha256=sha(w/('observed-'+n+'.json'))))
(w/'resource-audit-final.json').write_text(json.dumps(dict(time_ns=time.time_ns(),resource_runs=res,source937_verified=True,binary_sha256=l['binary_sha256'],normal_arms=30,normal_profile_arms=len(audit['arms']),stored_SSE_verified=audit['total_full_SSE_values_verified'],normal_profile_peak_MiB=max(r['peak_whole_device_MiB']for r in audit['arms']),GPU6_foreign_work_preserved=True,all_finite_GPU_jobs_on_GPU7=False,qualification_GPU=7,extra_canonical_GPU=6,normal_profile_GPU=7),indent=2))
if a.mode=='B':
 import subprocess
 subprocess.run(['python3',str(w/'mixed-coverage.py'),str(w)],check=True)
 assert json.loads((w/'canonical-state.json').read_text())['phase']=='complete'
 assert json.loads((w/'canonical-byte-audit.json').read_text())['files']==1024
 publication=[]
 for p in(w/'runs').glob('final-*/c*-owned-after/server.log'):
  text=p.read_text();match=re.search(r'RILEY_OVERLAP_DELIVERY batches=(\d+) drained=true',text)
  assert 'RILEY_OVERLAP_DELIVERY started=true capacity_batches=2'in text and match and int(match[1])>0,p
  submitted=re.search(r'after_submit_batches=(\d+)',text);assert submitted and int(submitted[1])>0,p
  publication.append(dict(log=str(p),sha256=sha(p),delivered_batches=int(match[1]),after_submit_batches=int(submitted[1]),drained=True,scope='Whole process including correctness/warmup; proves deferred dispatch used but not measured-window causal contribution'))
 assert len(publication)==10;(w/'publication-worker-proof.json').write_text(json.dumps(publication,indent=2))
 old=w.parent/'riley-overlap-v17b-20261021';past=w/'preflight-b1';past.mkdir(exist_ok=True)
 import shutil
 for n in['preflight-block.json','pre-build-source.json','native-kv-server-build.log','native-kv-regression.log','native-kv-build-and-cpu.exit','build-extra-state.json']:
  if(old/n).exists():shutil.copy2(old/n,past/n)
 oldm=json.loads((old/'pre-build-source.json').read_text())['source_sha256'];assert all(sha(old/'source'/f)==h for f,h in oldm.items())
 oldchanged=[f for f,h in oldm.items()if h!=json.loads((v/'source-manifest.json').read_text())[f]]
 text=''.join(''.join(difflib.unified_diff((v/'source'/f).read_text().splitlines(True),(old/'source'/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f))for f in oldchanged);(past/'candidate.patch').write_text(text)
 assert not list(old.glob('observed-*.json'))
stock=[]
for p in(w/'runs').glob('final-*/c*-vllm/server.log'):
 s=p.read_text();assert 'FLASH_ATTN'in s and 'FULL_AND_PIECEWISE'in s and ('version 2'in s or'version=2'in s),p
 stock.append(dict(log=str(p),sha256=sha(p),FLASH_ATTN=True,FULL_AND_PIECEWISE=True,version2=True))
assert len(stock)==10;(w/'stock-startup-proof.json').write_text(json.dumps(stock,indent=2))
(w/'adoption-decision.json').write_text(json.dumps(dict(time_ns=time.time_ns(),adopted=a.adopt,accuracy_threshold_changed=False,normal_completed_arms_excluded=0,tail_flags={str(c['concurrency']):c['tail_over_two_percent_flags']for c in stats['cells']},throughput_changes={str(c['concurrency']):c['median_percent_change']['output_tok_s']for c in stats['cells']},scope='Same native/HF literal BF16 and lifetime/lease contracts; matched five fresh before/after/stock runs per concurrency; profiles separate',reason='Qualification decision only: apply to main separately after review. Adopt only with positive both-concurrency throughput and original tail gates; no hardware-counter or broad model claims'),indent=2))
import subprocess
subprocess.run(['python3',str(w/'archive-revisions.py'),str(w),a.mode],check=True)
skip={'source','target','tmp','cache','vllm-cache','ipc6','ipc7','__pycache__','torch_compile_cache','torchinductor_cache'};heavy={};files=[]
allowed={'.json','.jsonl','.log','.txt','.py','.sh','.stdout','.stderr','.cu','.cuh','.cpp','.sse','.h','.hpp','.exit','.sha256','.rs','.patch'}
for p in w.rglob('*'):
 if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
 with p.open('rb')as f:magic=f.read(4)
 if p.suffix in ['.bf16','.sqlite','.nsys-rep','.safetensors']or magic==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
 if p.suffix in allowed and p.name not in ['evidence-archive-receipt.json','heavy-evidence-index.json']:files.append(p)
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2));files.append(w/'heavy-evidence-index.json')
manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)};z=w/'evidence-archive.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as f:
 for p in sorted(files):f.write(p,str(p.relative_to(w)))
 f.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
r=dict(time_ns=time.time_ns(),archive=str(z),bytes=z.stat().st_size,entries=len(files)+1,sha256=sha(z),heavy_files=len(heavy));(w/'evidence-archive-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
