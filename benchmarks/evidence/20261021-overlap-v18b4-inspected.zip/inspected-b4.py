from pathlib import Path
import json,time,subprocess,shutil,traceback,os,hashlib
p=Path('/mnt/efs/nlp/psyche');w=p/'riley-overlap-v18b4-inspected-20261021';base=p/'riley-overlap-v18b4-20261021';a=p/'riley-piecewise-v18a-20261021';assert not w.exists();w.mkdir();s=dict(phase='setup',started_ns=time.time_ns());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(w/'supplement-state.json').write_text(json.dumps(s,indent=2))
def run(args,name):
 with(w/name).open('x')as log:q=subprocess.run(args,stdout=log,stderr=log,env=dict(os.environ,RILEY_HOST_STEP_TRACE='1'))
 assert q.returncode==0,(name,q.returncode)
try:
 save()
 for name in ['measure-profile.py','run-job.py','audit-complete.py','attribute-v18.py','analyze-profile-v18.py','analyze-v18.py','audit-holders.py']:shutil.copy2(base/name,w/name)
 libs={}
 for name in ['pointer-inspection.so','call-inspection-nvtx.so']:
  shutil.copy2(a/name,w/name);libs[name]=dict(origin=str(a/name),sha256=sha(w/name))
 (w/'inspection-correction.json').write_text(json.dumps(dict(scope='Supplemental diagnostic only; all30 normal and original4 CPU-overlap profile arms retained. Missing LD_PRELOAD files affected eager GEMM classification in original4 profiles, not normal timing/numerical gates or native CPU NVTX overlap proof.',original_archive_sha256=json.loads((base/'evidence-archive-receipt.json').read_text())['sha256'],candidate_binary_sha256=sha(base/'riley-overlap-v18b4'),instrumentation=libs,normal_completed_arms_repeated=0),indent=2))
 for c in [16,32]:
  args=json.loads((base/f'profile-c{c}.argv.json').read_text());args[args.index(str(base/'measure-profile.py'))]=str(w/'measure-profile.py');args[args.index('--out')+1]=str(w/f'runs/profile-c{c}');(w/f'profile-c{c}.argv.json').write_text(json.dumps(args,indent=2));s.update(phase='profiling',concurrency=c);save();run(['python3',str(w/'run-job.py'),f'profile-c{c}'],f'profile-c{c}.outer.log')
 traces=[str(w/f'runs/profile-c{c}/c{c}-r0-owned-{m}/trace.sqlite')for c in [16,32]for m in ['before','after']]
 run(['python3',str(w/'attribute-v18.py'),*traces],'graph-diagnostics.log');run(['python3',str(w/'analyze-profile-v18.py'),*traces],'profile-diagnostics.log');run(['python3',str(w/'analyze-v18.py'),str(w),'B'],'overlap-analysis.log');run(['python3',str(w/'audit-complete.py'),'--partial'],'audit.outer.log');assert len(json.loads((w/'audit-partial.json').read_text())['arms'])==4
 for path in traces:
  stats=json.loads(Path(path+'.v15-analysis.json').read_text());assert stats['nvtx_matmul_range_count']>0 and stats['attributed_matmul_kernel_count']>0,path
  server=(Path(path).parent/'server.log').read_text();assert 'cannot be preloaded'not in server
 run(['python3',str(w/'audit-holders.py'),str(w)],'holder-audit.log')
 s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
