from pathlib import Path
import json,hashlib,zipfile,time,shutil
w=Path('/mnt/efs/nlp/psyche/riley-overlap-v18b4-inspected-20261021');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
assert read(w/'supplement-state.json')['phase']=='complete';audit=read(w/'audit-partial.json');assert len(audit['arms'])==4 and read(w/'final-holder-audit.json')['passed']
assert all(x['peak_whole_device_MiB']<=22528 and x['resources_recovered']for x in audit['arms'])
assert all(x['actual_CPU_GPU_overlap']for x in read(w/'actual-candidate-dispatch.json'))
shutil.copy2(w.parent/'inspected-b4.py',w/'inspected-b4.py')
heavy={};files=[];skip={'tmp','cache','vllm-cache','__pycache__','torch_compile_cache','torchinductor_cache'}
for p in w.rglob('*'):
 if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
 with p.open('rb')as f:magic=f.read(4)
 if p.suffix in ['.sqlite','.nsys-rep']or magic==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
 if p.suffix in ['.json','.jsonl','.log','.py','.txt','.stdout','.stderr','.sh']:files.append(p)
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2));files.append(w/'heavy-evidence-index.json');manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)}
z=w/'evidence-archive.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as f:
 for p in sorted(files):f.write(p,str(p.relative_to(w)))
 f.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
receipt=dict(time_ns=time.time_ns(),archive=str(z),sha256=sha(z),bytes=z.stat().st_size,entries=len(files)+1,heavy_files=len(heavy));(w/'evidence-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
