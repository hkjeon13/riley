from pathlib import Path
import shutil,json,time,hashlib
p=Path('/mnt/efs/nlp/psyche');w=p/'riley-overlap-v18b4-inspected-20261021';base=p/'riley-overlap-v18b4-20261021'
assert json.loads((w/'supplement-state.json').read_text())['phase']=='failed'
root=w/'runs/profile-c16';assert not(root/'result.json').exists()and not list(root.rglob('requests.json'))and not list(root.rglob('correctness.json'))
root.rename(w/'failed-premeasurement-profile-c16')
for n in ['supplement-state.json','profile-c16.state.json','profile-c16.log','profile-c16.outer.log']:(w/n).rename(w/(n+'.attempt1'))
shutil.copy2(base/'holder.py',w/'holder.py');sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
(w/'trusted-helper-correction.json').write_text(json.dumps(dict(time_ns=time.time_ns(),reason='Supplemental profile GPU process-monitor import holder.py was absent; failed before correctness/warm/measured requests. Copy exact previously used trusted helper, no admission policy changes.',holder_sha256=sha(w/'holder.py'),origin=str(base/'holder.py'),completed_profile_arms_repeated=0,normal_arms_repeated=0,failed_startup_preserved='failed-premeasurement-profile-c16'),indent=2))
s=(p/'inspected-b4.py').read_text();start=s.index(' for c in [16,32]:');tail=s[start:]
prefix="from pathlib import Path\nimport json,time,subprocess,shutil,traceback,os,hashlib\np=Path('/mnt/efs/nlp/psyche');w=p/'riley-overlap-v18b4-inspected-20261021';base=p/'riley-overlap-v18b4-20261021';s=dict(phase='resuming-profile',started_ns=time.time_ns());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()\ndef save():(w/'supplement-state.json').write_text(json.dumps(s,indent=2))\ndef run(args,name):\n with(w/name).open('x')as log:q=subprocess.run(args,stdout=log,stderr=log,env=dict(os.environ,RILEY_HOST_STEP_TRACE='1'))\n assert q.returncode==0,(name,q.returncode)\ntry:\n save()\n"
(w/'resume-profiles-final.py').write_text(prefix+tail);exec(compile(prefix+tail,'resume-profiles-final','exec'))
