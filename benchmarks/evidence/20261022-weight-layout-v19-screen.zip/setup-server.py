from pathlib import Path
import json,hashlib,shutil,subprocess,time
p=Path('/mnt/efs/nlp/psyche');old=p/'riley-overlap-v18b4-20261021';base=p/'riley-prefill-host-v15c-20261021';root=p/'riley-projection-layout-v19-20261022';w=p/'riley-weight-layout-v19a-20261022';w.mkdir(exist_ok=False)
shutil.copytree(base/'source',w/'source')
subprocess.run(['tar','-xzf',str(root/'candidate-r3.tar.gz'),'-C',str(w/'source')],check=True)
for n in ['tmp','cache']:(w/n).mkdir()
for q in old.iterdir():
 if q.is_file()and q.suffix in ['.py','.sh','.rs']:
  (w/q.name).write_text(q.read_text().replace('riley-overlap-v18b4-20261021',w.name).replace('riley-overlap-v18b4','riley-weight-layout-v19a').replace("'--index','7'","'--index','6'").replace('GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0','GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7'))
s=(base/'build.sh').read_text().replace(base.name,w.name).replace('riley-prefill-host-v15c','riley-weight-layout-v19a');(w/'build.sh').write_text(s)
f=w/'queue-build-extra.py';f.write_text(f.read_text().replace('==(526,4,40)','==(520,4,40)'))
for n in ['observe-finite.py','holder.py']:shutil.copy2(old/n,w/n)
m=json.loads((base/'source-manifest.json').read_text());h={f:hashlib.sha256((w/'source'/f).read_bytes()).hexdigest()for f in m};assert len(h)==937;changed=[f for f in m if m[f]!=h[f]];assert len(changed)==8,changed
(w/'pre-build-source.json').write_text(json.dumps(dict(source_sha256=h,changed=changed,base_commit='57502e7a0fafd165966071e88b3e8a56cdea0e3d',time_ns=time.time_ns()),indent=2))
with(w/'build.outer.log').open('x')as f:q=subprocess.Popen(['bash',str(w/'build.sh')],stdout=f,stderr=f,start_new_session=True)
print(w,q.pid)
