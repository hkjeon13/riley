from pathlib import Path
import json,hashlib,struct,time
w=Path(__file__).resolve().parent;d=w/'weights';d.mkdir(exist_ok=True);p=Path('/mnt/efs/nlp/psyche/riley-261013/models/Qwen3-4B');m=json.loads((p/'riley-checkpoint.json').read_text());index=json.loads((p/'model.safetensors.index.json').read_text())['weight_map'];out={'started_ns':time.time_ns(),'source_revision':m['source_revision'],'shards':[],'weights':[]}
for shard in sorted(set(index[f'model.layers.{l}.mlp.{s}_proj.weight']for l in [0,17,35]for s in ['gate','up','down'])):
 f=p/shard;h=hashlib.sha256();
 with f.open('rb')as inp:
  while b:=inp.read(8*1024*1024):h.update(b)
 expected=next(x for x in m['files']if x['path']==shard);assert f.stat().st_size==expected['bytes']and h.hexdigest()==expected['sha256'];out['shards'].append(expected)
 with f.open('rb')as inp:
  size=struct.unpack('<Q',inp.read(8))[0];header=json.loads(inp.read(size))
  for l in [0,17,35]:
   for s in ['gate','up','down']:
    name=f'model.layers.{l}.mlp.{s}_proj.weight'
    if index[name]!=shard:continue
    item=header[name];assert item['dtype']=='BF16';a,b=item['data_offsets'];inp.seek(8+size+a);data=inp.read(b-a);assert len(data)==b-a;dest=d/f'layer{l}-{s}.bf16';dest.write_bytes(data);out['weights'].append(dict(name=name,shape=item['shape'],offset=8+size+a,bytes=b-a,sha256=hashlib.sha256(data).hexdigest(),file=dest.name))
out['finished_ns']=time.time_ns();(w/'weight-extraction.json').write_text(json.dumps(out,indent=2))
