#include "probe-kernels.cuh"


#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"CUDA line%d %s\n",__LINE__,cudaGetErrorString(e));return 2;}}while(0)
__global__ void fill(U*p,size_t n,int st){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n){uint32_t z=uint32_t(i)*1664525u+1013904223u+st*1237;float v=float(int(z%2047)-1023)/32768.f;if(st%6==1)v*=8;if(st%6==2)v*=.0078125f;if(st%6==3)v=i%7?0:v;if(st%6==4)v=i%2?-v:v;if(st%6==5)v*=32;p[i]=__float2bfloat16_rn(v);}}
__global__ void cmp(const U*a,const U*b,size_t n,unsigned*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n&&__bfloat16_as_ushort(a[i])!=__bfloat16_as_ushort(b[i]))atomicAdd(p,1u);}

#include <cublasLt.h>
#define BL(x) do{auto e=(x);if(e!=CUBLAS_STATUS_SUCCESS){fprintf(stderr,"BL line%d status%d\n",__LINE__,int(e));throw std::runtime_error("cublas");}}while(0)
struct CurrentLt {
 cublasLtHandle_t h{};cublasLtMatmulDesc_t op{};cublasLtMatrixLayout_t w{},a[33]{},c[33]{};cublasLtMatmulAlgo_t algo{};void*ws{};
 CurrentLt(int n,int k,bool down){
  if(cublasLtGetVersion()!=120405)throw std::runtime_error("wrong Lt version");
  BL(cublasLtCreate(&h));BL(cublasLtMatmulDescCreate(&op,CUBLAS_COMPUTE_32F,CUDA_R_32F));cublasOperation_t trans=CUBLAS_OP_T;BL(cublasLtMatmulDescSetAttribute(op,CUBLASLT_MATMUL_DESC_TRANSA,&trans,sizeof(trans)));BL(cublasLtMatrixLayoutCreate(&w,CUDA_R_16BF,k,n,k));
  BL(cublasLtMatmulAlgoInit(h,CUBLAS_COMPUTE_32F,CUDA_R_32F,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,31,&algo));
  const cublasLtMatmulAlgoConfigAttributes_t attrs[]={CUBLASLT_ALGO_CONFIG_TILE_ID,CUBLASLT_ALGO_CONFIG_STAGES_ID,CUBLASLT_ALGO_CONFIG_SPLITK_NUM,CUBLASLT_ALGO_CONFIG_REDUCTION_SCHEME,CUBLASLT_ALGO_CONFIG_CTA_SWIZZLING,CUBLASLT_ALGO_CONFIG_CUSTOM_OPTION};
  const uint32_t vals[]={15,down?18u:17u,down?2u:0u,down?4u:0u,down?1u:0u,0};
  for(int i=0;i<6;i++){BL(cublasLtMatmulAlgoConfigSetAttribute(&algo,attrs[i],&vals[i],sizeof(vals[i])));uint32_t got=0;size_t sz=0;BL(cublasLtMatmulAlgoConfigGetAttribute(&algo,attrs[i],&got,sizeof(got),&sz));if(got!=vals[i]||sz!=sizeof(got))throw std::runtime_error("algo metadata");}
  for(int r=2;r<=32;r++){BL(cublasLtMatrixLayoutCreate(&a[r],CUDA_R_16BF,k,r,k));BL(cublasLtMatrixLayoutCreate(&c[r],CUDA_R_16BF,n,r,n));cublasLtMatmulHeuristicResult_t check{};BL(cublasLtMatmulAlgoCheck(h,op,w,a[r],c[r],c[r],&algo,&check));BL(check.state);if(check.workspaceSize>4u*1024u*1024u)throw std::runtime_error("workspace bound");}
  if(cudaMalloc(&ws,4u*1024u*1024u)!=cudaSuccess)throw std::runtime_error("workspace alloc");
 }
 void run(const U*weight,const U*x,U*y,int r,cudaStream_t stream){float alpha=1,beta=0;BL(cublasLtMatmul(h,op,&alpha,weight,w,x,a[r],&beta,y,c[r],y,c[r],&algo,ws,4u*1024u*1024u,stream));}
 ~CurrentLt(){cudaFree(ws);for(int r=2;r<=32;r++){cublasLtMatrixLayoutDestroy(a[r]);cublasLtMatrixLayoutDestroy(c[r]);}cublasLtMatrixLayoutDestroy(w);cublasLtMatmulDescDestroy(op);cublasLtDestroy(h);}
};
__global__ void current_silu(const U*raw,U*y,int rows){int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<rows*9728){int r=i/9728,j=i%9728;float g=__bfloat162float(raw[r*19456+j]),u=__bfloat162float(raw[r*19456+9728+j]);float activated=__bfloat162float(__float2bfloat16_rn(g/(1.0f+expf(-g))));y[i]=__float2bfloat16_rn(activated*u);}}

__global__ void transpose_weight(const U*w,U*p,int n,int k){__shared__ U t[32][33];int a=blockIdx.x*32+threadIdx.x,b=blockIdx.y*32+threadIdx.y;for(int j=0;j<32;j+=8)if(a<k&&b+j<n)t[threadIdx.y+j][threadIdx.x]=w[size_t(b+j)*k+a];__syncthreads();a=blockIdx.y*32+threadIdx.x;b=blockIdx.x*32+threadIdx.y;for(int j=0;j<32;j+=8)if(a<n&&b+j<k)p[size_t(b+j)*n+a]=t[threadIdx.x][threadIdx.y+j];}
int main(){cudaStream_t stream;CU(cudaStreamCreate(&stream));auto alloc=[](size_t n){void*p;if(cudaMalloc(&p,n))throw std::runtime_error("allocation");return p;};U*w=(U*)alloc(19456ul*2560*2),*pw=(U*)alloc(19456ul*2560*2),*x=(U*)alloc(32ul*9728*2),*gold=(U*)alloc(32ul*9728*2),*y=(U*)alloc(32ul*9728*2),*raw=(U*)alloc(32ul*19456*2);unsigned*bad=(unsigned*)alloc(4);void*ws=alloc(4u*1024u*1024u);CurrentLt current_down(2560,9728,true),current_gate(19456,2560,false);
 cublasLtHandle_t lt;BL(cublasLtCreate(&lt));
 for(int op=0;op<2;op++)for(int rows:{2,8,16,32}){
  int n=op?2560:19456,k=op?9728:2560;size_t count=size_t(rows)*(op?2560:9728);
  cublasLtMatmulDesc_t desc;BL(cublasLtMatmulDescCreate(&desc,CUBLAS_COMPUTE_32F,CUDA_R_32F));cublasLtMatrixLayout_t A,B,C;BL(cublasLtMatrixLayoutCreate(&A,CUDA_R_16BF,n,k,n));BL(cublasLtMatrixLayoutCreate(&B,CUDA_R_16BF,k,rows,k));BL(cublasLtMatrixLayoutCreate(&C,CUDA_R_16BF,n,rows,n));cublasLtMatmulPreference_t pref;BL(cublasLtMatmulPreferenceCreate(&pref));size_t maxws=4u*1024u*1024u;BL(cublasLtMatmulPreferenceSetAttribute(pref,CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES,&maxws,sizeof(maxws)));cublasLtMatmulHeuristicResult_t hs[64];int got=0;auto stat=cublasLtMatmulAlgoGetHeuristic(lt,desc,A,B,C,C,pref,64,hs,&got);
  printf("{\"kind\":\"heuristics\",\"op\":%d,\"rows\":%d,\"status\":%d,\"returned\":%d}\n",op,rows,int(stat),got);fflush(stdout);
  if(stat==CUBLAS_STATUS_SUCCESS)for(int index=0;index<got;index++)for(int config=0;config<2;config++){
   auto algo=hs[index].algo;if(op){uint32_t split=2,red=4;BL(cublasLtMatmulAlgoConfigSetAttribute(&algo,CUBLASLT_ALGO_CONFIG_SPLITK_NUM,&split,sizeof(split)));BL(cublasLtMatmulAlgoConfigSetAttribute(&algo,CUBLASLT_ALGO_CONFIG_REDUCTION_SCHEME,&red,sizeof(red)));}uint32_t swizzle=config;auto set=cublasLtMatmulAlgoConfigSetAttribute(&algo,CUBLASLT_ALGO_CONFIG_CTA_SWIZZLING,&swizzle,sizeof(swizzle));cublasLtMatmulHeuristicResult_t check{};auto status=set==CUBLAS_STATUS_SUCCESS?cublasLtMatmulAlgoCheck(lt,desc,A,B,C,C,&algo,&check):set;
   printf("{\"kind\":\"candidate\",\"op\":%d,\"rows\":%d,\"index\":%d,\"swizzle\":%d,\"check\":%d,\"state\":%d,\"workspace\":%zu",op,rows,index,config,int(status),int(check.state),check.workspaceSize);
   if(status!=CUBLAS_STATUS_SUCCESS||check.state!=CUBLAS_STATUS_SUCCESS||check.workspaceSize>maxws){puts("}");continue;}
   auto old=[&](){if(op)current_down.run(w,x,gold,rows,stream);else if(rows<=16)sm80_fused_gateup<4,16,16,2><<<304,128,0,stream>>>(w,w+9728ul*2560,x,gold,rows);else{current_gate.run(w,x,raw,rows,stream);current_silu<<<(count+255)/256,256,0,stream>>>(raw,gold,rows);}};
   auto run=[&](){float alpha=1,beta=0;auto st=cublasLtMatmul(lt,desc,&alpha,pw,A,x,B,&beta,op?y:raw,C,op?y:raw,C,&algo,ws,maxws,stream);if(st==CUBLAS_STATUS_SUCCESS&&!op)current_silu<<<(count+255)/256,256,0,stream>>>(raw,y,rows);return st;};
   unsigned errors[6]{};bool valid=true;
   for(int state=0;state<6;state++){fill<<<(size_t(n)*k+255)/256,256,0,stream>>>(w,size_t(n)*k,state);fill<<<(32ul*9728+255)/256,256,0,stream>>>(x,32ul*9728,state+2);transpose_weight<<<dim3((k+31)/32,(n+31)/32),dim3(32,8),0,stream>>>(w,pw,n,k);old();auto st=run();CU(cudaGetLastError());CU(cudaStreamSynchronize(stream));if(st!=CUBLAS_STATUS_SUCCESS){valid=false;break;}CU(cudaMemsetAsync(bad,0,4,stream));cmp<<<(count+255)/256,256,0,stream>>>(gold,y,count,bad);CU(cudaMemcpyAsync(&errors[state],bad,4,cudaMemcpyDeviceToHost,stream));CU(cudaStreamSynchronize(stream));}
   printf(",\"valid\":%s,\"mismatches\":[%u,%u,%u,%u,%u,%u]",valid?"true":"false",errors[0],errors[1],errors[2],errors[3],errors[4],errors[5]);
   if(valid&&std::all_of(errors,errors+6,[](unsigned x){return x==0;})){
    printf(",\"pairs\":[");for(int rep=0;rep<5;rep++){float us[2];for(int turn=0;turn<2;turn++){int which=(turn+rep)%2;cudaGraph_t graph;cudaGraphExec_t exe;CU(cudaStreamBeginCapture(stream,cudaStreamCaptureModeThreadLocal));for(int i=0;i<32;i++){if(which)run();else old();}CU(cudaStreamEndCapture(stream,&graph));CU(cudaGraphInstantiate(&exe,graph,0));for(int i=0;i<3;i++)CU(cudaGraphLaunch(exe,stream));cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaEventRecord(a,stream));for(int i=0;i<8;i++)CU(cudaGraphLaunch(exe,stream));CU(cudaEventRecord(b,stream));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));us[which]=ms*1000/256;CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));CU(cudaGraphExecDestroy(exe));CU(cudaGraphDestroy(graph));}printf("%s[%.4f,%.4f]",rep?",":"",us[0],us[1]);}printf("]");
   }puts("}");fflush(stdout);
  }
  cublasLtMatmulPreferenceDestroy(pref);cublasLtMatrixLayoutDestroy(A);cublasLtMatrixLayoutDestroy(B);cublasLtMatrixLayoutDestroy(C);cublasLtMatmulDescDestroy(desc);
 }
 return 0;
}
