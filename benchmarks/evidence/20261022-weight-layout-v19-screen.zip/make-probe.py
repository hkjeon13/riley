from pathlib import Path
import shutil
w=Path(__file__).parent;old=Path('artifacts/projection-overlap-v17-20261021');s=(old/'probe-current.cu').read_text();h=(old/'probe-kernels.cuh').read_text();shutil.copy2(old/'probe-kernels.cuh',w/'probe-kernels.cuh');shutil.copy2(old/'mma-backend.cuh',w/'mma-backend.cuh')
# Exact original WMMA chains/epilogue; change only weight address mapping.
a=h.index('template<int W,int R,int P,int S>__device__ __forceinline__ void gateup_stage');g=h[a:];g=g[:g.index('\n',g.index('\n#endif\n}',g.index('__global__ void sm80_fused_gateup'))+len('\n#endif\n}'))] if '\n' in g[g.index('\n#endif\n}',g.index('__global__ void sm80_fused_gateup'))+len('\n#endif\n}'):]else g
# Header ends with this kernel in the original probe; take exact balanced section.
start=h.index('template<int W,int R,int P,int S>__device__ __forceinline__ void gateup_stage');end=h.index('\n#endif\n}',h.index('__global__ void sm80_fused_gateup',start))+len('\n#endif\n}');g=h[start:end]
g=g.replace('gateup_stage','packed_gate_stage').replace('sm80_fused_gateup','packed_gate')
needle='((row<N/2?wg:wu)+(col+row%(N/2))*2560+it*64+k)';assert g.count(needle)==1;g=g.replace(needle,'(wg+size_t(col/32)*40*64*64+size_t(it)*64*64+row*64+k)')
start=h.index('template<int W,int R,int P,int S>__device__ __forceinline__ void sm80_v9_down_stage');end=h.index('\n__global__ void sm80_v9_down_reduce',start);d=h[start:end].replace('sm80_v9_down_stage','packed_down_stage').replace('sm80_v9_down','packed_down')
needle='w+(col+row)*9728+kbase+k';assert d.count(needle)==1;d=d.replace(needle,'w+size_t((col+row)/64)*4*76*64*32+size_t(part*76+it)*64*32+((col+row)%64)*32+k')
pack=r'''
__global__ void pack_gate_tiles(const U*wg,const U*wu,U*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<19456ul*2560){int k=i%64,row=i/64%64,it=i/(64*64)%40,tile=i/(64*64*40);p[i]=(row<32?wg:wu)[size_t(tile*32+row%32)*2560+it*64+k];}}
__global__ void pack_down_tiles(const U*w,U*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<2560ul*9728){int k=i%32,row=i/32%64,it=i/(32*64)%76,part=i/(32*64*76)%4,tile=i/(32*64*76*4);p[i]=w[size_t(tile*64+row)*9728+(part/2)*4864+(part%2)*32+it*64+k];}}
'''
(w/'packed-kernels.cuh').write_text(g+'\n'+d+'\n'+pack)
s=s.replace('#include "mma-backend.cuh"','#include "mma-backend.cuh"\n#include "packed-kernels.cuh"')
s=s.replace('U*raw=(U*)alloc(32ul*19456*2);','U*pg=(U*)alloc(19456ul*2560*2),*pd=(U*)alloc(2560ul*9728*2);\n U*raw=(U*)alloc(32ul*19456*2);')
s=s.replace('for(int rows:{2,3,4,5,6,7,8,9,12,16,17,24,32})','for(int rows=2;rows<=32;rows++)')
s=s.replace('  auto run=[&]', '  pack_gate_tiles<<<(19456ul*2560+255)/256,256,0,stream>>>(wg,wu,pg);pack_down_tiles<<<(2560ul*9728+255)/256,256,0,stream>>>(wd,pd);CU(cudaStreamSynchronize(stream));\n  auto run=[&]')
a=s.index('    else{if(rows<=8)v17_gateup');b=s.index('\n   else{if(v==0)',a)
s=s[:a]+'''    else{if(rows<=16)packed_gate<4,16,16,2><<<304,128,0,stream>>>(pg,pg,x,y,rows);else packed_gate<4,32,8,2><<<304,128,0,stream>>>(pg,pg,x,y,rows);}}
'''+s[b:]
a=s.index('    else{if(rows<=8)v17_down');b=s.index('\n\n  };',a)
s=s[:a]+'''    else{if(v==1){if(rows<=16)packed_down<4,16,8,4><<<dim3(40,1,4),128,0,stream>>>(pd,x,parts,rows);else packed_down<4,32,16,4><<<dim3(40,1,4),128,0,stream>>>(pd,x,parts,rows);}else{if(rows<=16)packed_down<8,16,8,4><<<dim3(20,1,4),256,0,stream>>>(pd,x,parts,rows);else packed_down<8,32,8,4><<<dim3(20,1,4),256,0,stream>>>(pd,x,parts,rows);}sm80_v9_down_reduce<<<(rows*2560+255)/256,256,0,stream>>>(parts,y,rows*2560);}}
''' +s[b:]
s=s.replace('for(int v=1;v<=1;v++)','for(int v=1;v<=(op==0?1:2);v++)')
# Five independently timed pairs, alternating timing order, graph32 replays.
a=s.index('    if(st==0 && count==0)');b=s.index('\n    puts(',a)
s=s[:a]+r'''    if(st==0 && count==0){printf(",\"pairs\":[");for(int rep=0;rep<5;rep++){float us[2];for(int turn=0;turn<2;turn++){int z=(turn+rep)%2;cudaGraph_t graph;cudaGraphExec_t exe;CU(cudaStreamBeginCapture(stream,cudaStreamCaptureModeThreadLocal));for(int i=0;i<32;i++)run(op,z?v:0);CU(cudaStreamEndCapture(stream,&graph));CU(cudaGraphInstantiate(&exe,graph,0));for(int i=0;i<3;i++)CU(cudaGraphLaunch(exe,stream));cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaEventRecord(a,stream));for(int i=0;i<8;i++)CU(cudaGraphLaunch(exe,stream));CU(cudaEventRecord(b,stream));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));us[z]=ms*1000/256;CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));CU(cudaGraphExecDestroy(exe));CU(cudaGraphDestroy(graph));}printf("%s[%.4f,%.4f]",rep?",":"",us[0],us[1]);}printf("]");}''' +s[b:]
(w/'probe.cu').write_text(s)
