template<int W,int R,int P,int S>__device__ __forceinline__ void packed_gate_stage(__nv_bfloat16*dst,const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,int rows,int col,int first,int it){
 constexpr int N=W*16,L=64+P;for(int i=threadIdx.x;i<(N+R)*8;i+=W*32){int row=i/8,k=i%8*8;bool weight=row<N,valid=it<40&&(weight||first+row-N<rows);const __nv_bfloat16*src=wg;if(valid)src=weight?(wg+size_t(col/32)*40*64*64+size_t(it)*64*64+row*64+k):(x+(first+row-N)*2560+it*64+k);sm80_down_copy16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void packed_gate(const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,__nv_bfloat16*y,int rows){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=64+P,Stage=(N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];auto results=reinterpret_cast<float (*)[RB][256]>(shared);int col=blockIdx.x*(N/2),first=blockIdx.y*R,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB][2];
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::fill_fragment(c[rb][0],0.f);wmma::fill_fragment(c[rb][1],0.f);}
 #pragma unroll
 for(int st=0;st<S;st++)packed_gate_stage<W,R,P,S>(shared+st*Stage,wg,wu,x,rows,col,first,st);
 for(int it=0;it<40;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+it%S*Stage;
 #pragma unroll
 for(int j=0;j<4;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb][j/2],a,b,c[rb][j/2]);}}
 __syncthreads();packed_gate_stage<W,R,P,S>(t,wg,wu,x,rows,col,first,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){for(int i=0;i<c[rb][0].num_elements;i++)c[rb][0].x[i]=__fadd_rn(c[rb][0].x[i],c[rb][1].x[i]);wmma::store_matrix_sync(results[warp][rb],c[rb][0],16,wmma::mem_col_major);}
 __syncthreads();if(warp<W/2){
 #pragma unroll
 for(int rb=0;rb<RB;rb++)for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows){float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp][rb][i],0.f)));float u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp+W/2][rb][i],0.f)));float activated=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[row*9728+col+warp*16+i%16]=__float2bfloat16_rn(__fmul_rn(activated,u));}}}
#endif
}
template<int W,int R,int P,int S>__device__ __forceinline__ void packed_down_stage(__nv_bfloat16*dst,const __nv_bfloat16*w,const __nv_bfloat16*x,int rows,int col,int first,int part,int it){
 constexpr int N=W*16,L=32+P;int kbase=(part/2)*4864+(part%2)*32+it*64;
 for(int i=threadIdx.x;i<(N+R)*4;i+=W*32){int row=i/4,k=(i%4)*8;bool a=row<N;int xr=row-N;bool valid=it<76&&(a||first+xr<rows);const __nv_bfloat16*src=valid?(a?w+size_t((col+row)/64)*4*76*64*32+size_t(part*76+it)*64*32+((col+row)%64)*32+k:x+(first+xr)*9728+kbase+k):w;sm80_down_copy16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void packed_down(const __nv_bfloat16*w,const __nv_bfloat16*x,float*parts,int rows){
 #if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=32+P,Stage=(N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];int col=blockIdx.x*N,first=blockIdx.y*R,part=blockIdx.z,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB];
 #pragma unroll
 for(int rb=0;rb<RB;rb++)wmma::fill_fragment(c[rb],0.f);
 #pragma unroll
 for(int st=0;st<S;st++)packed_down_stage<W,R,P,S>(shared+st*Stage,w,x,rows,col,first,part,st);
 for(int it=0;it<76;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+(it%S)*Stage;
 #pragma unroll
 for(int j=0;j<2;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb],a,b,c[rb]);}}
 __syncthreads();packed_down_stage<W,R,P,S>(t,w,x,rows,col,first,part,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){float*out=reinterpret_cast<float*>(shared)+(warp*RB+rb)*256;wmma::store_matrix_sync(out,c[rb],16,wmma::mem_col_major);__syncwarp();for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows)parts[(part*rows+row)*2560+col+warp*16+i%16]=out[i];}}
#endif
}

__global__ void pack_gate_tiles(const U*wg,const U*wu,U*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<19456ul*2560){int k=i%64,row=i/64%64,it=i/(64*64)%40,tile=i/(64*64*40);p[i]=(row<32?wg:wu)[size_t(tile*32+row%32)*2560+it*64+k];}}
__global__ void pack_down_tiles(const U*w,U*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<2560ul*9728){int k=i%32,row=i/32%64,it=i/(32*64)%76,part=i/(32*64*76)%4,tile=i/(32*64*76*4);p[i]=w[size_t(tile*64+row)*9728+(part/2)*4864+(part%2)*32+it*64+k];}}

template<int W,int R,int P,int S>__device__ __forceinline__ void kmajor_gate_stage(__nv_bfloat16*dst,const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,int rows,int col,int first,int it){
 constexpr int N=W*16,L=64+P;for(int i=threadIdx.x;i<(N+R)*8;i+=W*32){int row=i/8,k=i%8*8;bool weight=row<N,valid=it<40&&(weight||first+row-N<rows);const __nv_bfloat16*src=wg;if(valid)src=weight?(wg+size_t(it)*304*64*64+size_t(col/32)*64*64+row*64+k):(x+(first+row-N)*2560+it*64+k);sm80_down_copy16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void kmajor_gate(const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,__nv_bfloat16*y,int rows){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=64+P,Stage=(N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];auto results=reinterpret_cast<float (*)[RB][256]>(shared);int col=blockIdx.x*(N/2),first=blockIdx.y*R,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB][2];
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::fill_fragment(c[rb][0],0.f);wmma::fill_fragment(c[rb][1],0.f);}
 #pragma unroll
 for(int st=0;st<S;st++)kmajor_gate_stage<W,R,P,S>(shared+st*Stage,wg,wu,x,rows,col,first,st);
 for(int it=0;it<40;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+it%S*Stage;
 #pragma unroll
 for(int j=0;j<4;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb][j/2],a,b,c[rb][j/2]);}}
 __syncthreads();kmajor_gate_stage<W,R,P,S>(t,wg,wu,x,rows,col,first,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){for(int i=0;i<c[rb][0].num_elements;i++)c[rb][0].x[i]=__fadd_rn(c[rb][0].x[i],c[rb][1].x[i]);wmma::store_matrix_sync(results[warp][rb],c[rb][0],16,wmma::mem_col_major);}
 __syncthreads();if(warp<W/2){
 #pragma unroll
 for(int rb=0;rb<RB;rb++)for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows){float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp][rb][i],0.f)));float u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp+W/2][rb][i],0.f)));float activated=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[row*9728+col+warp*16+i%16]=__float2bfloat16_rn(__fmul_rn(activated,u));}}}
#endif
}
template<int W,int R,int P,int S>__device__ __forceinline__ void kmajor_down_stage(__nv_bfloat16*dst,const __nv_bfloat16*w,const __nv_bfloat16*x,int rows,int col,int first,int part,int it){
 constexpr int N=W*16,L=32+P;int kbase=(part/2)*4864+(part%2)*32+it*64;
 for(int i=threadIdx.x;i<(N+R)*4;i+=W*32){int row=i/4,k=(i%4)*8;bool a=row<N;int xr=row-N;bool valid=it<76&&(a||first+xr<rows);const __nv_bfloat16*src=valid?(a?w+size_t(part*76+it)*40*64*32+size_t((col+row)/64)*64*32+((col+row)%64)*32+k:x+(first+xr)*9728+kbase+k):w;sm80_down_copy16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void kmajor_down(const __nv_bfloat16*w,const __nv_bfloat16*x,float*parts,int rows){
 #if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=32+P,Stage=(N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];int col=blockIdx.x*N,first=blockIdx.y*R,part=blockIdx.z,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB];
 #pragma unroll
 for(int rb=0;rb<RB;rb++)wmma::fill_fragment(c[rb],0.f);
 #pragma unroll
 for(int st=0;st<S;st++)kmajor_down_stage<W,R,P,S>(shared+st*Stage,w,x,rows,col,first,part,st);
 for(int it=0;it<76;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+(it%S)*Stage;
 #pragma unroll
 for(int j=0;j<2;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb],a,b,c[rb]);}}
 __syncthreads();kmajor_down_stage<W,R,P,S>(t,w,x,rows,col,first,part,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){float*out=reinterpret_cast<float*>(shared)+(warp*RB+rb)*256;wmma::store_matrix_sync(out,c[rb],16,wmma::mem_col_major);__syncwarp();for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows)parts[(part*rows+row)*2560+col+warp*16+i%16]=out[i];}}
#endif
}

__global__ void pack_gate_kmajor(const U*wg,const U*wu,U*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<19456ul*2560){int k=i%64,row=i/64%64,tile=i/(64*64)%304,it=i/(64*64*304);p[i]=(row<32?wg:wu)[size_t(tile*32+row%32)*2560+it*64+k];}}
__global__ void pack_down_kmajor(const U*w,U*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<2560ul*9728){int k=i%32,row=i/32%64,tile=i/(32*64)%40,it=i/(32*64*40)%76,part=i/(32*64*40*76);p[i]=w[size_t(tile*64+row)*9728+(part/2)*4864+(part%2)*32+it*64+k];}}
