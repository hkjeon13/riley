from pathlib import Path
import json,time,os,subprocess,hashlib,traceback,statistics,shutil
w=Path('/mnt/efs/nlp/psyche/riley-projection-layout-v19-20261022');old=w.parent/'riley-overlap-v18b4-20261021';r=w.parent/'riley-w0-a100-gpu67-20261019';w=Path(__file__).resolve().parent;s=dict(phase='compiling',started_ns=time.time_ns());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(w/'screen-state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 for n in ['tmp','cache']:(w/n).mkdir(exist_ok=True)
 for n in ['observe-finite.py','holder.py']:shutil.copy2(old/n,w/n)
 assert sha(w/'observe-finite.py')=='c0aad9d71eab4071eefb1f94d809c17ced2652d571e662e2af16bab765097947'
 env=dict(os.environ,TMPDIR=str(w/'tmp'),CUDA_VISIBLE_DEVICES='',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64')
 cmd=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-O3','-std=c++17','-arch=sm_80',str(w/'probe.cu'),'-lcublasLt','-o',str(w/'probe')];(w/'build.argv.json').write_text(json.dumps(cmd))
 with(w/'build.log').open('x')as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=f)
 assert q.returncode==0
 s.update(phase='screening',binary_sha256=sha(w/'probe'));save();env['RILEY_DIVERGENCE_NATIVE_OUTPUT']=str(w/'native-output')
 cmd=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'observed-screen'),'--timeout','900','--',str(w/'probe'),str(w.parent/'weights')];(w/'run.argv.json').write_text(json.dumps(cmd))
 with(w/'run.log').open('x')as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=f)
 assert q.returncode==0
 rows=[json.loads(l)for l in(w/'observed-screen.stdout').read_text().splitlines()];assert len(rows)==3*31*6*6
 timings=[]
 for x in rows:
  if 'pairs'in x:
   a=statistics.median(v[0]for v in x['pairs']);b=statistics.median(v[1]for v in x['pairs']);timings.append(dict(rows=x['rows'],op=x['op'],variant=x['variant'],old_us=a,new_us=b,change_percent=100*(b/a-1)))
 samples=[json.loads(l)for l in(w/'observed-screen.samples.jsonl').read_text().splitlines()];peak=max(x['device_memory_mib']for x in samples);assert peak<=22528
 (w/'screen-summary.json').write_text(json.dumps(dict(cases=len(rows),mismatches=[x for x in rows if x['mismatch']],timings=timings,whole_device_peak_MiB=peak,scope='Synthetic finite six-state component screen, R2..32. Exact current native fused GateUp<=16/current merged Lt+BF16 SiLU>=17/current Lt Down control. Tile-packed weights cold-only, no input packing, original WMMA accumulations and BF16 epilogues; not full-model qualification or HTTP speed.'),indent=2));s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
