// SM80 m16n8k16 register fragments; preserve native K16 instruction order.
__device__ __forceinline__ void v17_mma(float*c,const U*a,const U*b,int stride){
 int lane=threadIdx.x%32,g=lane/4,t=lane%4;
 const uint32_t a0=*reinterpret_cast<const uint32_t*>(a+g*stride+t*2);
 const uint32_t a1=*reinterpret_cast<const uint32_t*>(a+(g+8)*stride+t*2);
 const uint32_t a2=*reinterpret_cast<const uint32_t*>(a+g*stride+t*2+8);
 const uint32_t a3=*reinterpret_cast<const uint32_t*>(a+(g+8)*stride+t*2+8);
 const uint32_t b0=*reinterpret_cast<const uint32_t*>(b+g*stride+t*2);
 const uint32_t b1=*reinterpret_cast<const uint32_t*>(b+g*stride+t*2+8);
 asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" : "+f"(c[0]),"+f"(c[1]),"+f"(c[2]),"+f"(c[3]):"r"(a0),"r"(a1),"r"(a2),"r"(a3),"r"(b0),"r"(b1));
}
template<int W,int R,int P,int S>__global__ void v17_gateup(const U*wg,const U*wu,const U*x,U*y,int rows){
 constexpr int N=W*16,L=64+P,Stage=(N+R)*L,RB=R/8;
 __shared__ __align__(32)U shared[Stage*S];float c[RB][2][4]={};int warp=threadIdx.x/32,lane=threadIdx.x%32,col=blockIdx.x*(N/2),first=blockIdx.y*R;
 #pragma unroll
 for(int s=0;s<S;s++)gateup_stage<W,R,P,S>(shared+s*Stage,wg,wu,x,rows,col,first,s);
 for(int it=0;it<40;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+(it%S)*Stage;
 #pragma unroll
 for(int j=0;j<4;j++){
 #pragma unroll
 for(int rb=0;rb<RB;rb++)v17_mma(c[rb][j/2],t+warp*16*L+j*16,t+(N+rb*8)*L+j*16,L);}
 __syncthreads();gateup_stage<W,R,P,S>(t,wg,wu,x,rows,col,first,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();float*out=reinterpret_cast<float*>(shared);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){
 #pragma unroll
 for(int i=0;i<4;i++){int n=lane/4+(i/2)*8,r=lane%4*2+i%2;out[(warp*RB+rb)*128+r*16+n]=__fadd_rn(c[rb][0][i],c[rb][1][i]);}}
 __syncthreads();if(warp<W/2){
 #pragma unroll
 for(int rb=0;rb<RB;rb++)for(int i=lane;i<128;i+=32){int row=first+rb*8+i/16;if(row<rows){float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,out[(warp*RB+rb)*128+i],0.f)));float u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,out[((warp+W/2)*RB+rb)*128+i],0.f)));float act=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[row*9728+col+warp*16+i%16]=__float2bfloat16_rn(__fmul_rn(act,u));}}}
}
template<int W,int R,int P,int S>__global__ void v17_down(const U*w,const U*x,float*parts,int rows){
 constexpr int N=W*16,L=32+P,Stage=(N+R)*L,RB=R/8;__shared__ __align__(32)U shared[Stage*S];float c[RB][4]={};int col=blockIdx.x*N,first=blockIdx.y*R,part=blockIdx.z,warp=threadIdx.x/32,lane=threadIdx.x%32;
 #pragma unroll
 for(int s=0;s<S;s++)sm80_v9_down_stage<W,R,P,S>(shared+s*Stage,w,x,rows,col,first,part,s);
 for(int it=0;it<76;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+(it%S)*Stage;
 #pragma unroll
 for(int j=0;j<2;j++){
 #pragma unroll
 for(int rb=0;rb<RB;rb++)v17_mma(c[rb],t+warp*16*L+j*16,t+(N+rb*8)*L+j*16,L);}
 __syncthreads();sm80_v9_down_stage<W,R,P,S>(t,w,x,rows,col,first,part,it+S);}
 asm volatile("cp.async.wait_group 0;");
 #pragma unroll
 for(int rb=0;rb<RB;rb++){
 #pragma unroll
 for(int i=0;i<4;i++){int row=first+rb*8+lane%4*2+i%2,n=col+warp*16+lane/4+(i/2)*8;if(row<rows)parts[(part*rows+row)*2560+n]=c[rb][i];}}
}
