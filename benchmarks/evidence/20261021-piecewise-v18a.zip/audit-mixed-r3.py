from pathlib import Path
import json,hashlib,re,time
w=Path('/mnt/efs/nlp/psyche/riley-piecewise-v18a-20261021');old=w.parent/'riley-qkv-gateup-v214-20261019';hf=old/'qwen3-4b-fresh-A100-HF-v222';native=old/'v226-qwen3-4b-before-C1-eager';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();fixture=json.loads((hf/'fixture.json').read_text());case=next(c for c in fixture['models'][0]['cases']if c['id']=='natural-128');proof=[]
for name,folder,count in [('teacher-mixed-r3','teacher-mixed-output-r3',1024),('teacher-mixed-no-output-r3','teacher-mixed-no-output-r3',992)]:
 receipt=w/('observed-'+name+'.json');a=json.loads(receipt.read_text());assert a['status']=='complete' and a['returncode']==0,a
 d=w/folder;meta=json.loads((d/'result.json').read_text());rows=[r for m in meta['models']for c in m['cases']for r in c['rows']];assert len(rows)==count and len(list(d.glob('*.bf16')))==count
 for r in rows:
  step=next(x for x in case['steps']if x['step']==r['step']);ref=hf/Path(step['file']).name;nat=native/('qwen3-4b-natural-128-s%d.native.bf16'%r['step']);p=d/r['file'];assert p.read_bytes()==ref.read_bytes()==nat.read_bytes(),p
  assert sha(ref)==fixture['files'][step['file']]['sha256'];assert sha(p)==r['sha256']==r['HF_sha256']==r['native_sha256']
 out=(w/('observed-'+name+'.stdout')).read_text();err=(w/('observed-'+name+'.stderr')).read_text();assert 'RILEY_SPLIT_PREFLIGHT invalid_prefill_rejected=true shape_unchanged=true owner_reusable=true output_not_published=true'in out
 assert len(re.findall('RILEY_MIXED_TEACHER tick=',out))==63
 pre,post=err.split('RILEY_OWNED_BODY_WARMUP rows=1..32 greedy=false complete=true',1);assert 'capture=true'not in post
 stats=re.findall(r'RILEY_OWNED_SM80_MLP captures=(\d+) hits=(\d+) eager_fallbacks=(\d+) stream_resets=(\d+)',post);assert len(stats)==1 and int(stats[0][0])==1152 and int(stats[0][1])>0 and tuple(map(int,stats[0][2:]))==(0,0),stats
 samples=[json.loads(x)for x in(w/('observed-'+name+'.samples.jsonl')).read_text().splitlines()];peak=max(x['device_memory_mib']for x in samples);assert 0<peak<=22528
 proof.append(dict(name=name,rows=count,mixed_steps=31,logical_ticks=63,invalid_prefill_preflight_passed=True,no_hot_capture=True,all_literal_equal_to_original_native_and_HF=True,receipt_sha256=sha(receipt),whole_device_peak_MiB=peak,raw_file_sha256={r['file']:r['sha256']for r in rows}))
x=dict(time_ns=time.time_ns(),runs=proof,total_rows=sum(r['rows']for r in proof),scope='staggered32 natural128 requests, input/output permutation, full vocabulary, mixed no-output-prefill variant; original exact byte gate unchanged')
(w/'mixed-byte-r3-audit.json').write_text(json.dumps(x,indent=2));print([(r['name'],r['rows'])for r in proof])
