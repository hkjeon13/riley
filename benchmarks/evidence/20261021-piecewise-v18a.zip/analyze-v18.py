from pathlib import Path
import sqlite3,json,hashlib,sys,collections
w=Path(sys.argv[1]);mode=sys.argv[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def merged(xs):
 out=[]
 for a,b in sorted(xs):
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(out[-1][1],b)
 return out
def total(xs):return sum(b-a for a,b in merged(xs))
def intersect(a,b):
 a=merged(a);b=merged(b);i=j=0;ns=0
 while i<len(a)and j<len(b):
  ns+=max(0,min(a[i][1],b[j][1])-max(a[i][0],b[j][0]))
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return ns
proof=[]
for c in [16,32]:
 path=w/f'runs/profile-c{c}/c{c}-r0-owned-after/trace.sqlite';d=sqlite3.connect(path);d.row_factory=sqlite3.Row;strings=dict(d.execute('select id,value from StringIds'));rows=list(d.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL order by start'));assert rows
 graphs=collections.defaultdict(list)
 for row in rows:
  if row['graphId']:graphs[row['graphId']].append(row)
 result=dict(concurrency=c,trace=str(path),trace_sha256=sha(path),scope='Separate 64-request Nsight window; not normal throughput, not hardware utilization/bandwidth counters',kernel_sum_ms=sum(r['end']-r['start']for r in rows)/1e6)
 if mode=='A':
  pieces=[]
  for gid,rs in graphs.items():
   markers=[r for r in rs if 'piecewise_prefill_rows'in strings[r['demangledName']]]
   if not markers:continue
   nodes={r['graphNodeId']:strings[r['demangledName']]for r in rs};marker_nodes={r['graphNodeId']for r in markers};pvalues={4*r['gridX']//5 for r in markers}
   assert len(marker_nodes)==2 and len(pvalues)==1 and all(r['blockX']==256 for r in markers),(gid,pvalues)
   p=next(iter(pvalues));assert 64<=p<=130 or 161<=p<=576
   pieces.append(dict(graph=gid,prefill_tokens=p,multi_prefill=p>=161,copy_nodes=2,marker_executions=len(markers),complete_piece_launches=len(markers)//2,kernel_sum_ms=sum(r['end']-r['start']for r in rs)/1e6,node_names=nodes))
  assert pieces and any(x['multi_prefill']for x in pieces),('no actual multi-prefill MLP piece replay',path)
  result.update(actual_prefill_MLP_pieces=pieces,actual_multi_prefill_graph_replay=True,piece_kernel_sum_ms=sum(x['kernel_sum_ms']for x in pieces),detected_piece_fraction_of_kernel_sum=sum(x['kernel_sum_ms']for x in pieces)/result['kernel_sum_ms'],actual_piece_launches=sum(x['complete_piece_launches']for x in pieces),scope_detail='P inferred exactly from copy grid ceil(P*320/256); covers MLP pieces, not full mixed-body attention Graph. Variable R qualified by independent capacity576 full-vocabulary teachers; capture count alone is not execution proof.')
 else:
  tables={x[0]for x in d.execute("select name from sqlite_master where type='table'")};assert 'NVTX_EVENTS'in tables
  ranges=collections.defaultdict(list)
  for row in d.execute('select * from NVTX_EVENTS'):
   x=dict(row);label=x.get('text')or strings.get(x.get('textId'),'')
   if label in ['RILEY_CPU_RESULT_OVERLAP','RILEY_CPU_PLAN_OVERLAP']and x.get('end')is not None:ranges[label].append((x['start'],x['end']))
  gpu=[(x['start'],x['end'])for x in rows];data={}
  for label in ['RILEY_CPU_RESULT_OVERLAP','RILEY_CPU_PLAN_OVERLAP']:
   xs=ranges[label];assert xs,(label,path);ns=total(xs);both=intersect(xs,gpu);assert both>0,(label,'CPU range never overlapped a GPU kernel')
   data[label]=dict(ranges=len(xs),cpu_range_union_ms=ns/1e6,GPU_kernel_overlap_ms=both/1e6,overlap_fraction_of_CPU_range=both/ns)
  result.update(actual_CPU_GPU_overlap=True,nvtx=data,scope_detail='Real CPU generation acceptance, authoritative commit, bounded publication and next authoritative planning; intersected with actual GPU kernel intervals. Does not imply all CPU time is hidden or all speculative outputs are reused.')
 d.close();proof.append(result)
(w/'actual-candidate-dispatch.json').write_text(json.dumps(proof,indent=2));print(json.dumps(proof,indent=2))
