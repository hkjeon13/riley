from pathlib import Path
import argparse,bisect,collections,json,re,sqlite3
p=argparse.ArgumentParser();p.add_argument('traces',nargs='+');a=p.parse_args()
def union_ns(intervals):
 total=0;last=None
 for start,end in sorted(intervals):
  if last is None:last=[start,end]
  elif start<=last[1]:last[1]=max(last[1],end)
  else:total+=last[1]-last[0];last=[start,end]
 return total+(last[1]-last[0]if last else 0)
def analyze(path):
 db=sqlite3.connect(path);db.row_factory=sqlite3.Row;tables={x[0]for x in db.execute("select name from sqlite_master where type='table'")};strings=dict(db.execute('select id,value from StringIds'));kernels=list(db.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL'));assert kernels,'No GPU kernels in trace'
 ranges=collections.defaultdict(list)
 for table in ['NVTX_EVENTS','NvtxEvents']:
  if table not in tables:continue
  for row in db.execute('select * from '+table):
   d=dict(row);label=d.get('text')or strings.get(d.get('textId'),'')
   if label.startswith('W0/')and d.get('end')is not None:ranges[d['globalTid']].append((d['start'],d['end'],label))
 for key in ranges:ranges[key].sort()
 starts={key:[v[0]for v in rows]for key,rows in ranges.items()};correlations={};api=collections.defaultdict(lambda:dict(count=0,ms=0.0))
 for row in [row for table in ['CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER'] if table in tables for row in db.execute('select * from '+table)]:
  name=strings.get(row['nameId'],'?');api[name]['count']+=1;api[name]['ms']+=(row['end']-row['start'])/1e6
  tid=row['globalTid'];labels=ranges.get(tid,[]);i=bisect.bisect_right(starts.get(tid,[]),row['start'])-1
  if i>=0 and row['end']<=labels[i][1]:correlations[row['correlationId']]=labels[i][2]
 categories=collections.defaultdict(lambda:dict(count=0,ms=0.0));detail=collections.defaultdict(lambda:dict(count=0,ms=0.0));geometry=collections.defaultdict(lambda:dict(count=0,ms=0.0))
 graph_map={}
 gp=path.parent/'graph-attribution-v15.json'
 if gp.exists():
  for g in json.loads(gp.read_text())['node_audit']:
   for n in g.get('mapped',[]):graph_map[(g['graph'],n['node'])]=n['stage']
 for row in kernels:
  name=strings.get(row['demangledName'],'?');label=correlations.get(row['correlationId']);category=None
  if label:
   geometry[label]['count']+=1;geometry[label]['ms']+=(row['end']-row['start'])/1e6
   if '/StridedBatchedEx/'in label or '/BatchedEx/'in label:category='attention-QK-PV'
   else:
    m,rows,k,batch=map(int,re.search(r'/N(\d+)/M(\d+)/K(\d+)/B(\d+)',label).groups())
    if (m,k)==(4096,2560):category='linear-Q'
    elif (m,k)==(1024,2560):category='linear-KV'
    elif (m,k)==(2560,4096):category='linear-O'
    elif (m,k) in [(9728,2560),(19456,2560)]:category='linear-GateUp'
    elif (m,k)==(2560,9728):category='linear-Down'
    elif (m,k)==(151936,2560):category='linear-LMhead'
    elif (m,k)==(4096,4096):category='linear-Q-or-O-Mistral'
    elif (m,k)==(1024,4096):category='linear-KV-Mistral'
    elif (m,k)==(14336,4096):category='linear-GateUp-Mistral'
    elif (m,k)==(4096,14336):category='linear-Down-Mistral'
    elif (m,k)==(32768,4096):category='linear-LMhead-Mistral'
    else:category='other-cublas'
  else:
   lowered=name.lower()
   category=next((c for token,c in [('piecewise_prefill_rows','prefill-row-copy'),('sm80_batched_lm_head','linear-LMhead'),('sm80_fused_gateup','linear-GateUp'),('owned_sm80_tiled_kv','linear-KV'),('sm80_batched_qk','attention-QK-PV'),('sm80_batched_pv','attention-QK-PV'),('sm80_batched_softmax','softmax'),('sm80_v9_down','linear-Down'),('sm80_v8_down','linear-Down'),('sm80_v8_gate','linear-GateUp'),('sm80_down_native_sliced','linear-Down'),('sm80_down_reduce','linear-Down'),('owned_sm80_native_kv_rows','linear-KV'),('sm80_chunk_paged_qk','attention-QK-PV'),('sm80_chunk_paged_wmma_qk','attention-QK-PV'),('sm80_chunk_paged_pv','attention-QK-PV'),('sm80_chunk_paged_wmma_pv','attention-QK-PV'),('rms_norm','norm'),('softmax','softmax'),('kv_gather','KV-gather'),('rope','RoPE'),('silu','SiLU'),('gated_multiply','gate-multiply'),('residual','residual'),('argmax','greedy'),('pack_separate','QKV-pack')]if token in lowered),'other-unattributed')
  if category=='other-unattributed':category=graph_map.get((row['graphId'],row['graphNodeId']),category)
  duration=(row['end']-row['start'])/1e6;categories[category]['count']+=1;categories[category]['ms']+=duration;detail[name]['count']+=1;detail[name]['ms']+=duration
 copies=[]
 if 'CUPTI_ACTIVITY_KIND_MEMCPY'in tables:copies=list(db.execute('select * from CUPTI_ACTIVITY_KIND_MEMCPY'))
 copy_directions={}
 if copies:
  labels={row[0]:row[2]for row in db.execute('select * from ENUM_CUDA_MEMCPY_OPER')} if 'ENUM_CUDA_MEMCPY_OPER'in tables else {}
  for kind,count,nbytes,ms in db.execute('select copyKind,count(*),sum(bytes),sum(end-start)/1e6 from CUPTI_ACTIVITY_KIND_MEMCPY group by copyKind'):
   copy_directions[labels.get(kind,str(kind))]=dict(count=count,bytes=nbytes,ms=ms)
 lo=min(row['start']for row in kernels);hi=max(row['end']for row in kernels);busy=union_ns([(row['start'],row['end'])for row in kernels]);total=sum(row['end']-row['start']for row in kernels)
 result=dict(trace=str(path),scope='Profiler diagnostic, not HTTP throughput measurement; kernel-duration sums overlap CPU API waits',kernel_count=len(kernels),kernel_sum_ms=total/1e6,kernel_union_ms=busy/1e6,gpu_kernel_span_ms=(hi-lo)/1e6,kernel_busy_fraction=busy/(hi-lo),nvtx_matmul_range_count=sum(map(len,ranges.values())),attributed_matmul_kernel_count=sum(v['count']for v in geometry.values()),categories=dict(sorted(categories.items(),key=lambda x:-x[1]['ms'])),cuda_api=dict(sorted(api.items(),key=lambda x:-x[1]['ms'])[:20]),copy_directions=copy_directions,copy_count=len(copies),copy_bytes=sum(row['bytes']for row in copies),copy_sum_ms=sum(row['end']-row['start']for row in copies)/1e6,top_kernels=dict(sorted(detail.items(),key=lambda x:-x[1]['ms'])[:15]),matmul_geometries=dict(sorted(geometry.items(),key=lambda x:-x[1]['ms'])))
 Path(str(path)+'.v15-analysis.json').write_text(json.dumps(result,indent=2));return {k:result[k]for k in ['trace','kernel_count','kernel_sum_ms','gpu_kernel_span_ms','kernel_busy_fraction','nvtx_matmul_range_count','categories']}
for path in a.traces:print(json.dumps(analyze(Path(path)),indent=2))
