from pathlib import Path
import subprocess
w=Path(__file__).parent
for n in ['run-canonical576.py','run-multi576.py']:
 p=subprocess.run(['python3',str(w/n)]);assert p.returncode==0,(n,p.returncode)
