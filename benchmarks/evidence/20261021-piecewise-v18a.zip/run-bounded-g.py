from pathlib import Path
import json,os,subprocess,hashlib,time,re,traceback
w=Path('/mnt/efs/nlp/psyche/riley-piecewise-v18a-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';old=w.parent/'riley-qkv-gateup-v214-20261019';s=dict(phase='building',started_ns=time.time_ns());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(w/'bounded576-state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 while True:
  p=w/'build-extra-state.json';a=json.loads(p.read_text())if p.exists()else{};assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 assert json.loads((w.parent/'riley-mlp-batch-v16d-20261021/routes-state.json').read_text())['phase']=='complete'
 while True:
  p=w.parent/'riley-projection-v17a-20261021/accuracy-r3-state.json';a=json.loads(p.read_text())if p.exists()else{};assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 source=(w/'teacher-body.rs').read_text();assert source.count('LlamaBatchMetadataConfig::new(copies, 512*copies.min(8),')==1;assert source.count('copy_order.chunks(copies.min(8))')==1
 source=source.replace('LlamaBatchMetadataConfig::new(copies, 512*copies.min(8),','LlamaBatchMetadataConfig::new(copies, 576,').replace('copy_order.chunks(copies.min(8))','copy_order.chunks(4)');(w/'teacher-bounded576.rs').write_text(source)
 builder=(w/'build-teacher-body.py').read_text().replace('teacher-body','teacher-bounded576');(w/'build-teacher-bounded576.py').write_text(builder)
 with(w/'bounded576-build.outer.log').open('x')as out:q=subprocess.run(['python3',str(w/'build-teacher-bounded576.py')],stdout=out,stderr=out)
 assert q.returncode==0
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'teacher-bounded576-output'),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES='32',RILEY_TEACHER_SHRINK='',RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH='segments-v1',RILEY_OWNED_BATCH='native-prefill-sm80-v5');env.pop('CUBLAS_WORKSPACE_CONFIG',None)
 cmd=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'observed-bounded576'),'--',str(w/'teacher-bounded576'),'--ignored','--exact','owned_batch_teacher_forced_logits_are_finite_and_reported','--nocapture','--test-threads=1'];(w/'bounded576.argv.json').write_text(json.dumps(cmd,indent=2));s['phase']='numerical';save()
 with(w/'bounded576.launch.log').open('x')as out:q=subprocess.run(cmd,env=env,stdout=out,stderr=out)
 assert q.returncode==0
 root=w/'teacher-bounded576-output';files=list(root.glob('*.bf16'));assert len(files)==2048;before=old/'v226-qwen3-4b-before-C1-eager';hashes={}
 for p in files:
  ref=re.sub(r'-r\d+(?=-s\d+\.)','',p.name);assert p.read_bytes()==(before/ref).read_bytes(),p.name;hashes[p.name]=sha(p)
 hf=old/'qwen3-4b-fresh-A100-HF-v222';fixture=json.loads((hf/'fixture.json').read_text());case=next(c for c in fixture['models'][0]['cases']if c['id']=='natural-128')
 for step in case['steps']:
  reference=hf/step['file'];assert sha(reference)==fixture['files'][step['file']]['sha256']
  for count in range(1,33):assert(root/f'qwen3-4b-natural-128-r{count}-s{step["step"]}.native.bf16').read_bytes()==reference.read_bytes()
 meta=json.loads((root/'result.json').read_text());rows=[v for m in meta['models']for c in m['cases']for v in c['rows']];assert len(rows)==1024 and all(v['max_abs']==v['mean_abs']==0 for v in rows)
 (w/'bounded576-byte-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),files=2048,HF_full_vocabulary_rows=1024,all_equal_to_original_native_and_HF=True,scope='Same original natural128 teacher, R1..32, capacity576 and prefill chunks4; covers model paths256/384/512 plus cold bounded raw-buffer resize. Adds2048 files to original4480 gate; no new reference or tolerance.',teacher_binary_sha256=sha(w/'teacher-bounded576'),raw_file_sha256=hashes),indent=2));s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as err:s.update(phase='failed',error=repr(err),finished_ns=time.time_ns(),traceback=traceback.format_exc());save();raise
