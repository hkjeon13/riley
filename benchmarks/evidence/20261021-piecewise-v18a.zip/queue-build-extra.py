from pathlib import Path
import subprocess,time,json,re,traceback
w=Path('/mnt/efs/nlp/psyche/riley-piecewise-v18a-20261021');state=dict(phase='waiting-build',started_ns=time.time_ns())
def save():(w/'build-extra-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while not(w/'native-kv-build-and-cpu.exit').exists():time.sleep(3)
 assert (w/'riley-piecewise-v18a').is_file()
 log=(w/'native-kv-regression.log').read_text();rows=[tuple(map(int,m))for m in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',log)];assert tuple(sum(r[i]for r in rows)for i in range(3))==(522,4,40),rows
 for name,args in [('recheck-c02.py',['--allow-test-tmp']),('build-teacher-final.py',[]),('build-teacher-body.py',[]),('build-teacher-mixed.py',[])]:
  state.update(phase='building-teachers',current=name);save()
  with(w/(name+'.outer.log')).open('x')as f:p=subprocess.run(['python3',str(w/name)]+args,stdout=f,stderr=f)
  assert p.returncode==0,(name,p.returncode)
 state.update(phase='building-gpu-tests',current='build-gpu-c.sh');save()
 with(w/'build-gpu.outer.log').open('x')as f:p=subprocess.run(['bash',str(w/'build-gpu-c.sh')],stdout=f,stderr=f)
 assert p.returncode==0
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
