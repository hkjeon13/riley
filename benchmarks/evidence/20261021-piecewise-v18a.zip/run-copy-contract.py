from pathlib import Path
import json,subprocess,os,hashlib,time,traceback
w=Path(__file__).parent;r=w.parent/'riley-w0-a100-gpu67-20261019';s=dict(phase='building',started_ns=time.time_ns());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():
 p=w/'copy-contract-state.json';t=p.with_suffix('.json.pending');t.write_text(json.dumps(s,indent=2));t.replace(p)
try:
 save();a=json.loads((w/'teacher-final-build.argv.json').read_text())['argv'];libs=[Path(a[i+1].removeprefix('native='))/'libriley_cuda_native.a'for i,v in enumerate(a[:-1])if v=='-L'];libs=[p for p in libs if p.exists()];assert len(libs)==1,libs
 argv=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-std=c++17','-O2','-arch=sm_80','-DRILEY_CUDA_ENABLE_CUBLAS_GEMM_PROBE=1','-I'+str(w/'source/kernels/include'),str(w/'piecewise-row-copy-contract.cpp'),str(libs[0]),'-L/usr/local/cuda-12.4/lib64','-L/usr/local/cuda-12.4/lib64/stubs','-lcublas','-lcublasLt','-lcudart','-lcuda','-ldl','-lpthread','-o',str(w/'piecewise-row-copy-contract')]
 (w/'copy-contract-build.argv.json').write_text(json.dumps(dict(argv=argv,library_sha256=sha(libs[0]),source_sha256=sha(w/'piecewise-row-copy-contract.cpp')),indent=2))
 with(w/'copy-contract-build.log').open('x')as f:q=subprocess.run(argv,env=dict(os.environ,CUDA_VISIBLE_DEVICES='',TMPDIR=str(w/'tmp')),stdout=f,stderr=f)
 assert q.returncode==0
 s['phase']='waiting-GPU6';save();deadline=time.monotonic()+1800
 while True:
  p=w.parent/'riley-overlap-v18b3-20261021/canonical-state.json'
  try:a=json.loads(p.read_text())
  except(FileNotFoundError,json.JSONDecodeError):a={}
  assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  assert time.monotonic()<deadline;time.sleep(2)
 s['phase']='GPU-contract';save();binary=w/'piecewise-row-copy-contract';s['binary_sha256']=sha(binary);save()
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'copy-contract-output'))
 argv=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','40-47','python3',str(w/'observe-finite.py'),'--out',str(w/'observed-copy-contract'),'--',str(binary)];(w/'copy-contract.argv.json').write_text(json.dumps(argv,indent=2))
 with(w/'copy-contract.launch.log').open('x')as f:q=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert q.returncode==0
 result=json.loads((w/'observed-copy-contract.stdout').read_text());assert result==dict(passed=True,same_graph_R_replays=33,rejected_invalid_or_busy_calls=75,hostile_device_offset_no_write=True,final_allocation_zero=True),result
 (w/'copy-contract-audit.json').write_text(json.dumps(dict(**result,time_ns=time.time_ns(),binary_sha256=sha(binary),original_observer_unchanged=sha(w/'observe-finite.py')=='c0aad9d71eab4071eefb1f94d809c17ced2652d571e662e2af16bab765097947'),indent=2));s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
