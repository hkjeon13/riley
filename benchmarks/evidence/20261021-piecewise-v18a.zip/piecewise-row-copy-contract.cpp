#include "riley_cuda.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cstdint>
static RileyCudaErrorInfo e{};
static unsigned rejects=0;
static void ok(RileyCudaStatus s){if(s){std::fprintf(stderr,"native failure %d: %s\n",s,e.message);std::exit(2);}}
static void reject(RileyCudaStatus s){if(!s){std::fprintf(stderr,"invalid call unexpectedly accepted\n");std::exit(3);}++rejects;}
static RileyCudaBufferSpan span(RileyCudaDeviceBuffer* b,uint64_t bytes,RileyCudaDType dtype=RILEY_CUDA_DTYPE_BF16){RileyCudaBufferSpan x{};x.struct_size=sizeof(x);x.dtype=dtype;x.buffer=b;x.byte_len=bytes;return x;}
int main(){
 e.struct_size=sizeof(e);constexpr unsigned cap=128,width=16,P=64;constexpr uint64_t bytes=cap*width*2;
 RileyCudaContext*c=nullptr;RileyCudaStream*s=nullptr;RileyCudaPinnedHostBuffer*h=nullptr;
 RileyCudaDeviceBuffer *input=nullptr,*scratch=nullptr,*output=nullptr,*prefix=nullptr;RileyCudaStepGraph*g=nullptr;
 ok(riley_cuda_context_create(0,&c,&e));ok(riley_cuda_stream_create(c,&s,&e));
 for(auto b:{&input,&scratch,&output})ok(riley_cuda_device_buffer_create(c,bytes,b,&e));
 ok(riley_cuda_device_buffer_create(c,4,&prefix,&e));ok(riley_cuda_pinned_host_buffer_create(c,bytes*3+4,&h,&e));
 std::vector<uint16_t> data(cap*width),zeros(cap*width),got(cap*width);for(unsigned i=0;i<data.size();++i)data[i]=uint16_t(i*17+3);
 ok(riley_cuda_pinned_host_buffer_write(h,0,reinterpret_cast<const uint8_t*>(data.data()),bytes,&e));
 ok(riley_cuda_pinned_host_buffer_write(h,bytes,reinterpret_cast<const uint8_t*>(zeros.data()),bytes,&e));
 RileyCudaRowGatherParams a{};a.struct_size=sizeof(a);a.input=span(input,bytes);a.output=span(scratch,bytes);a.row_indices=span(prefix,4,RILEY_CUDA_DTYPE_U32);a.input_row_count=cap;a.output_row_count=P;a.column_count=width;
 RileyCudaRowGatherParams b=a;b.input=span(scratch,bytes);b.output=span(output,bytes);
 reject(riley_cuda_piecewise_rows_execute(&a,0,s,&e));
 ok(riley_cuda_stream_command_batch_begin(s,&e));
 reject(riley_cuda_piecewise_rows_execute(&a,4,s,&e));
 auto bad=a;bad.output=a.input;reject(riley_cuda_piecewise_rows_execute(&bad,0,s,&e));
 bad=a;bad.output.byte_offset=2;reject(riley_cuda_piecewise_rows_execute(&bad,0,s,&e));
 bad=a;bad.output.byte_len=bytes-2;reject(riley_cuda_piecewise_rows_execute(&bad,0,s,&e));
 bad=a;bad.output_row_count=cap+1;reject(riley_cuda_piecewise_rows_execute(&bad,0,s,&e));
 bad=a;bad.column_count=15;reject(riley_cuda_piecewise_rows_execute(&bad,0,s,&e));
 bad=a;bad.input.dtype=RILEY_CUDA_DTYPE_F32;reject(riley_cuda_piecewise_rows_execute(&bad,0,s,&e));
 bad=a;bad.reserved[0]=1;reject(riley_cuda_piecewise_rows_execute(&bad,0,s,&e));
 ok(riley_cuda_command_batch_copy_h2d_async(input,0,h,0,bytes,s,&e));
 ok(riley_cuda_stream_command_batch_end(s,&e));
 for(uint32_t r=0;r<=32;++r){
  ok(riley_cuda_pinned_host_buffer_write(h,bytes*3,reinterpret_cast<const uint8_t*>(&r),4,&e));
  ok(riley_cuda_stream_command_batch_begin(s,&e));
  ok(riley_cuda_command_batch_copy_h2d_async(prefix,0,h,bytes*3,4,s,&e));
  ok(riley_cuda_command_batch_copy_h2d_async(output,0,h,bytes,bytes,s,&e));
  ok(riley_cuda_piecewise_rows_execute(&a,2,s,&e));ok(riley_cuda_piecewise_rows_execute(&b,3,s,&e));
  if(!g){ok(riley_cuda_stream_command_batch_step_capture_begin(s,&e));ok(riley_cuda_piecewise_rows_execute(&a,0,s,&e));ok(riley_cuda_piecewise_rows_execute(&b,1,s,&e));ok(riley_cuda_stream_command_batch_step_capture_end(s,&g,&e));}
  ok(riley_cuda_stream_command_batch_step_graph_launch(s,g,&e));
  reject(riley_cuda_device_buffer_close(&prefix,&e));if(!prefix)return 4;
  reject(riley_cuda_device_buffer_close(&input,&e));if(!input)return 5;
  ok(riley_cuda_command_batch_copy_d2h_async(h,bytes*2,output,0,bytes,s,&e));
  ok(riley_cuda_stream_command_batch_end(s,&e));
  ok(riley_cuda_pinned_host_buffer_read(h,bytes*2,reinterpret_cast<uint8_t*>(got.data()),bytes,&e));
  for(unsigned i=0;i<got.size();++i){uint16_t want=i>=r*width && i<(r+P)*width?data[i]:0;if(got[i]!=want){std::fprintf(stderr,"R%u element%u mismatched\n",r,i);return 6;}}
 }
 // A hostile device offset must cause no out-of-range access or write.
 uint32_t invalid=cap+1;ok(riley_cuda_pinned_host_buffer_write(h,bytes*3,reinterpret_cast<const uint8_t*>(&invalid),4,&e));
 ok(riley_cuda_stream_command_batch_begin(s,&e));ok(riley_cuda_command_batch_copy_h2d_async(prefix,0,h,bytes*3,4,s,&e));ok(riley_cuda_command_batch_copy_h2d_async(output,0,h,bytes,bytes,s,&e));ok(riley_cuda_piecewise_rows_execute(&a,2,s,&e));ok(riley_cuda_piecewise_rows_execute(&b,3,s,&e));ok(riley_cuda_stream_command_batch_step_graph_launch(s,g,&e));ok(riley_cuda_command_batch_copy_d2h_async(h,bytes*2,output,0,bytes,s,&e));ok(riley_cuda_stream_command_batch_end(s,&e));ok(riley_cuda_pinned_host_buffer_read(h,bytes*2,reinterpret_cast<uint8_t*>(got.data()),bytes,&e));if(got!=zeros)return 7;
 ok(riley_cuda_step_graph_destroy(g,&e));for(auto buffer:{&input,&scratch,&output,&prefix})ok(riley_cuda_device_buffer_close(buffer,&e));ok(riley_cuda_pinned_host_buffer_close(&h,&e));ok(riley_cuda_stream_close(&s,&e));RileyCudaAllocationStats stats{};stats.struct_size=sizeof(stats);ok(riley_cuda_context_allocation_stats(c,&stats,&e));if(stats.device_live_bytes||stats.device_live_allocations||stats.pinned_host_live_bytes||stats.pinned_host_live_allocations)return 8;ok(riley_cuda_context_close(&c,&e));
 std::printf("{\"passed\":true,\"same_graph_R_replays\":33,\"rejected_invalid_or_busy_calls\":%u,\"hostile_device_offset_no_write\":true,\"final_allocation_zero\":true}\n",rejects);
}
