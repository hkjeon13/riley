"""Serve the inspected distribution and the same held-GPU vLLM reference."""
import asyncio
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from uuid import uuid4

import run_profile
from profile_workload import load_cell, save
from check_distribution_gpu import (
    RILEY,
    SHUTDOWN,
    check_config,
    digest,
    docker,
    find_interrupted_container,
    gpu_pids,
    holder_pids,
    inspect_container,
    log_command,
    require,
    wait_for_gpu_release,
    wait_ready,
)

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parent.parent
MODEL = ROOT / "models/Qwen2.5-Coder-14B-Instruct"
CELLS = json.loads((STAGE / "schedules.json").read_bytes())["schedules"][os.environ["W3_GPU_INDEX"]]
OUT = STAGE / f"gpu{os.environ['W3_GPU_INDEX']}"
GPU = os.environ["CUDA_VISIBLE_DEVICES"]
IMAGE = "sha256:1729f15a677422d552b9a3fd2352dfeb08dd4cccd3558680a016058d27191098"
CPU = ROOT / "evidence/w5-shard-package-20261124.nhBcrYgP/cpu-evidence/report.json"
LEASE = Path(os.environ["RILEY_GPU_HOLDER_LEASE_DIR"]) / f"{OUT.name}.status.json"


def interrupt(_signal, _frame):
    raise KeyboardInterrupt


def check_lease(holders):
    status = json.loads(LEASE.read_bytes())
    require(holder_pids(GPU) == holders == {status["pid"]}
            and status["gpu"] == GPU
            and status["phase"] == "active" and status["allocation_bytes"] == 64 * 2**20
            and time.time_ns() - status["updated_ns"] < 10**10, "GPU lease was lost")


def riley():
    out = OUT / os.environ["W3_PREFILL_ORDER"]
    out.mkdir()
    cpu = json.loads(CPU.read_bytes())
    binary = digest(STAGE / "riley-diagnostic")
    require(cpu["status"] == "passed" and cpu["image_id"] == IMAGE
            and cpu["source_revision"] == "0511b9280f62c3ee87c7a1344444423d8b4623c4", "package receipt changed")
    check_config(json.loads(docker("image", "inspect", IMAGE)), IMAGE,
                 cpu["source_revision"], cpu["source_archive_sha256"])
    holders = holder_pids(GPU)
    check_lease(holders)
    require(gpu_pids(GPU) == holders, "GPU has a foreign process")
    server = [
        "serve", "--model", "/models", "--model-id", "m", "--max-active-sequences", "32",
        "--max-weight-bytes", "68719476736", "--inference-profile", "native-bf16-varlen-v1",
        "--max-sequence-tokens", "8192", "--max-output-tokens", "256", "--kv-blocks", "2576",
        "--batch-token-budget", "1024", "--prefill-chunk-tokens", "1024",
        "--batch-shape-buckets", run_profile.BUCKETS, "--prefill-burst-steady-budget", "256",
        "--prefill-burst-max-decode-rows", "32", "--prefill-burst-min-prompt-tokens", "512",
    ]
    name = f"riley-w3-coder14-{uuid4().hex}"
    user = f"{os.getuid()}:{os.getgid()}"
    command = [
        "create", "--pull=never", "--cpuset-cpus", os.environ["W3_SERVER_CPUS"], "--name", name, "--label", f"io.riley.gpu-check={name}",
        "--user", user, "--gpus", f"device={GPU}", "--env", "NVIDIA_DRIVER_CAPABILITIES=compute,utility",
        "--env", f"RILEY_SHUTDOWN_METRICS_PATH={SHUTDOWN}",
        "--env", "RILEY_W3_RAG_STEPS=1",
        "--env", "RILEY_W3_RESERVE_AGED_DECODE=1",
        "--env", f"RILEY_W3_PREFILL_FIFO={int(os.environ['W3_PREFILL_ORDER'] == 'combined')}",
        "--mount", f"type=bind,source={STAGE / 'riley-diagnostic'},target={RILEY},readonly", "--publish", "127.0.0.1::8080",
        "--mount", f"type=bind,source={MODEL},target=/models,readonly", IMAGE, *server,
    ]
    save(out / "plan.json", {"server": server, "docker": command, "cells": CELLS,
                              "server_cpu_affinity": sorted(os.sched_getaffinity(0))})
    container = None
    try:
        container = docker(*command).strip()
        runtime = inspect_container(container)
        require(runtime["Image"] == IMAGE and runtime["Config"]["User"] == user, "container did not use reviewed image")
        docker("start", container)
        runtime = inspect_container(container)
        (binding,) = runtime["NetworkSettings"]["Ports"]["8080/tcp"]
        port = int(binding["HostPort"])
        require(binding["HostIp"] == "127.0.0.1", "not a loopback test binding")
        save(out / "ready.json", wait_ready(container, port))
        device, = docker("exec", container, "nvidia-smi", "--query-gpu=uuid,name,driver_version", "--format=csv,noheader").splitlines()
        require(device.split(",")[0] == GPU, "unexpected container GPU")
        pid = runtime["State"]["Pid"]
        observed, _ = docker("exec", container, "/bin/sh", "-ec",
                             f'test "$(readlink /proc/1/exe)" = {RILEY}; sha256sum /proc/1/exe').split()
        require(observed == binary and pid > 0 and gpu_pids(GPU) == holders | {pid}, "binary or GPU context changed")

        require(os.sched_getaffinity(pid) == os.sched_getaffinity(0), "Riley server CPU affinity differs")
        client = [sys.executable, "-B", str(STAGE / "client.py"), str(out / "plan.json"), f"127.0.0.1:{port}"]
        deadline = time.monotonic() + 1000
        with (out / "client.log").open("xb") as log:
            job = subprocess.Popen(client, stdout=log, stderr=subprocess.STDOUT)
            try:
                while job.poll() is None:
                    check_lease(holders)
                    require(gpu_pids(GPU) == holders | {pid}, "GPU process changed during measurement")
                    require(time.monotonic() < deadline, "Riley client timed out")
                    time.sleep(1)
                require(job.returncode == 0, "Riley client failed")
            finally:
                if job.poll() is None:
                    job.terminate()
                    try:
                        job.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        job.kill()
                        job.wait(timeout=5)
        results = {}
        for label, spec in CELLS.items():
            path = out / f"{label}.json"
            require(len(json.loads(path.read_bytes())["measured"]) == spec["requests"], f"missing requests in {label}")
            results[label] = digest(path)
        job = [sys.executable, "-B", str(STAGE / "holdout.py"), str(out / "token-id-holdout.json"), f"127.0.0.1:{port}"]
        subprocess.run(job, check=True, timeout=160)
        check_lease(holders)
        require(gpu_pids(GPU) == holders | {pid}, "GPU process changed during holdout")
        docker("stop", "--time", "20", container)
        state = inspect_container(container)["State"]
        require(not state["Running"] and state["ExitCode"] == 0, "Riley exit was not graceful")
        docker("cp", f"{container}:{SHUTDOWN}", str(out / "shutdown.json"))
        shutdown = json.loads((out / "shutdown.json").read_bytes())
        require(all(shutdown[key] == 0 for key in ("active_requests", "waiting_requests", "kv_allocated_blocks"))
                and shutdown["allocation"] and all(value == 0 for value in shutdown["allocation"].values()),
                "Riley retained allocation or KV state")
        wait_for_gpu_release(GPU, holders, pid)
        save(out / "receipt.json", {"status": "passed", "gpu": GPU, "device": device,
                                   "holder_pid": next(iter(holders)), "image_id": IMAGE, "riley_binary_sha256": observed,
                                   "source_revision": cpu["source_revision"], "cpu_report_sha256": digest(CPU),
                                   "checkpoint_sha256": digest(MODEL / "riley-checkpoint.json"),
                                   "common_kv_blocks": 2576, "kv_cache_bytes": 8103395328, "shutdown_exit": state["ExitCode"],
                                   "holdout_sha256": digest(out / "token-id-holdout.json"), "results": results})
    finally:
        container = container or find_interrupted_container(name)
        if container is not None:
            try:
                log_command(out, "server.log", ["docker", "logs", container], 25, check=False)
            finally:
                docker("rm", "--force", "--volumes", container)


def vllm():
    run_profile.RUN = OUT
    run_profile.ROOT = ROOT
    run_profile.VLLM = ROOT / "tools/vllm-venv/bin/vllm"
    run_profile.cells = lambda *_: CELLS
    run_profile.run("coder14", "vllm")
    receipt = json.loads((OUT / "coder14-vllm/receipt.json").read_bytes())
    require(receipt["kv_capacity_matches"], "vLLM cache budget did not match")


if __name__ == "__main__":
    signal.signal(signal.SIGINT, interrupt)
    signal.signal(signal.SIGTERM, interrupt)
    {"riley": riley, "vllm": vllm}[sys.argv[1]]()
