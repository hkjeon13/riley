from pathlib import Path
import json,hashlib,time
p=Path(__file__).resolve().parent;r=p.parent/'riley-batched-v11-20261020/research';rows=[]
def digest(f):
 h=hashlib.sha256()
 with f.open('rb')as stream:
  while True:
   b=stream.read(4*1024*1024)
   if not b:break
   h.update(b)
 return h.hexdigest()
for f in sorted(r.iterdir()):
 if not f.is_file()or f.is_symlink():continue
 with f.open('rb')as s:elf=s.read(4)==b'\x7fELF'
 if elf or f.suffix in ['.bf16','.sqlite','.nsys-rep']:
  rows.append(dict(path=str(f),bytes=f.stat().st_size,sha256=digest(f)))
(p/'research-heavy-index.json').write_text(json.dumps(dict(time_ns=time.time_ns(),scope='Preserved component inputs/binaries/traces from accepted and rejected research; acceptance is given by individual receipts',files=rows),indent=2));print('indexed research heavy files',len(rows))
