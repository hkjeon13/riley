// Research only: classify native same-SM80 M1 vs batched GEMM equality.
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <mma.h>
#include <cublas_v2.h>
#include <cublasLt.h>
#include <algorithm>
#include <openssl/sha.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <stdexcept>
#include <filesystem>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <unistd.h>
using U=uint16_t;
#define CU(x) do{if((x)!=cudaSuccess)throw std::runtime_error("CUDA API failed");}while(0)
#define BL(x) do{if((x)!=CUBLAS_STATUS_SUCCESS)throw std::runtime_error("cuBLAS API failed");}while(0)
std::string sha(const std::vector<U>&x){unsigned char d[32];SHA256((const unsigned char*)x.data(),x.size()*2,d);static const char*h="0123456789abcdef";std::string s;for(auto c:d){s+=h[c>>4];s+=h[c&15];}return s;}
std::vector<U>read(const std::string&p,size_t bytes,const std::string&digest){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f||uint64_t(f.tellg())!=bytes||bytes%2||bytes>(1ull<<30))throw std::runtime_error("input size");std::vector<U>x(bytes/2);f.seekg(0);f.read((char*)x.data(),bytes);if(!f||sha(x)!=digest)throw std::runtime_error("input SHA256");return x;}
float cv(U x){uint32_t b=uint32_t(x)<<16;float f;memcpy(&f,&b,4);return f;}
U bf(float f){uint32_t b;memcpy(&b,&f,4);return U((b+0x7fff+((b>>16)&1))>>16);}
void save(const std::string&p,const std::vector<U>&x){if(std::filesystem::exists(p))throw std::runtime_error("raw exists");std::ofstream f(p,std::ios::binary);f.write((const char*)x.data(),x.size()*2);if(!f)throw std::runtime_error("raw save");}


__device__ __forceinline__ void sm80_down_copy16(void*dst,const void*src,bool valid){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
unsigned sm=static_cast<unsigned>(__cvta_generic_to_shared(dst));asm volatile("cp.async.cg.shared.global [%0], [%1], 16, %2;"::"r"(sm),"l"(src),"r"(valid?16:0));
#endif
}
template<int W,int R,int P,int S>__device__ __forceinline__ void output_v11_stage(__nv_bfloat16*dst,const __nv_bfloat16*w,const __nv_bfloat16*x,int rows,int col,int first,int part,int it){
 constexpr int N=W*16,L=32+P;int kbase=(part/2)*2048+(part%2)*32+it*64;
 for(int i=threadIdx.x;i<(N+R)*4;i+=W*32){int row=i/4,k=(i%4)*8;bool a=row<N;int xr=row-N;bool valid=it<32&&(a||first+xr<rows);const __nv_bfloat16*src=valid?(a?w+(col+row)*4096+kbase+k:x+(first+xr)*4096+kbase+k):w;sm80_down_copy16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void output_v11(const __nv_bfloat16*w,const __nv_bfloat16*x,float*parts,int rows){
 #if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=32+P,Stage=(N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];int col=blockIdx.x*N,first=blockIdx.y*R,part=blockIdx.z,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB];
 #pragma unroll
 for(int rb=0;rb<RB;rb++)wmma::fill_fragment(c[rb],0.f);
 #pragma unroll
 for(int st=0;st<S;st++)output_v11_stage<W,R,P,S>(shared+st*Stage,w,x,rows,col,first,part,st);
 for(int it=0;it<32;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+(it%S)*Stage;
 #pragma unroll
 for(int j=0;j<2;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb],a,b,c[rb]);}}
 __syncthreads();output_v11_stage<W,R,P,S>(t,w,x,rows,col,first,part,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){float*out=reinterpret_cast<float*>(shared)+(warp*RB+rb)*256;wmma::store_matrix_sync(out,c[rb],16,wmma::mem_col_major);__syncwarp();for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows)parts[(part*rows+row)*2560+col+warp*16+i%16]=out[i];}}
#endif
}
__global__ void sm80_v9_down_reduce(const float*p,__nv_bfloat16*y,int n){int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n){float a=__fadd_rn(p[i],p[n+i]),b=__fadd_rn(p[2*n+i],p[3*n+i]);y[i]=__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(a,b),0.f));}}

template<int W,int R,int P,int S>void trial(cublasHandle_t h,cublasLtHandle_t lt,cublasLtMatmulDesc_t op,cublasLtMatrixLayout_t weights,const cublasLtMatmulAlgo_t&algo,cudaStream_t s,U*w,U*x,U*y,float*parts,void*workspace,const std::vector<std::vector<U>>&xs,const std::vector<std::vector<U>>&gold){
 cublasLtMatrixLayout_t ins[33]{},outs[33]{};for(int r=2;r<=32;r++){BL(cublasLtMatrixLayoutCreate(&ins[r],CUDA_R_16BF,4096,r,4096));BL(cublasLtMatrixLayoutCreate(&outs[r],CUDA_R_16BF,2560,r,2560));cublasLtMatmulHeuristicResult_t check{};BL(cublasLtMatmulAlgoCheck(lt,op,weights,ins[r],outs[r],outs[r],&algo,&check));BL(check.state);if(check.workspaceSize>4u*1024u*1024u)throw std::runtime_error("workspace");}
 auto candidate=[&](int rows){float alpha=1,beta=0;if(rows==1)BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,2560,1,4096,&alpha,w,CUDA_R_16BF,4096,x,CUDA_R_16BF,4096,&beta,y,CUDA_R_16BF,2560,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));else BL(cublasLtMatmul(lt,op,&alpha,w,weights,x,ins[rows],&beta,y,outs[rows],y,outs[rows],&algo,workspace,4u*1024u*1024u,s));};
 auto baseline=[&](int rows){float alpha=1,beta=0;for(int first=0;first<rows;first+=8){int n=std::min(8,rows-first);if(n==1)BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,2560,1,4096,&alpha,w,CUDA_R_16BF,4096,x+first*4096,CUDA_R_16BF,4096,&beta,y+first*2560,CUDA_R_16BF,2560,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));else BL(cublasLtMatmul(lt,op,&alpha,w,weights,x+first*4096,ins[n],&beta,y+first*2560,outs[n],y+first*2560,outs[n],&algo,workspace,4u*1024u*1024u,s));}};
 for(int state=0;state<6;state++){CU(cudaMemcpyAsync(x,xs[state].data(),xs[state].size()*2,cudaMemcpyHostToDevice,s));for(int rows=1;rows<=32;rows++){candidate(rows);CU(cudaStreamSynchronize(s));std::vector<U>a(rows*2560);CU(cudaMemcpy(a.data(),y,a.size()*2,cudaMemcpyDeviceToHost));size_t bad=0;for(size_t i=0;i<a.size();i++)bad+=a[i]!=gold[state][i];if(bad){printf("{\"W\":%d,\"R\":%d,\"state\":%d,\"rows\":%d,\"changed\":%zu}\n",W,R,state,rows,bad);fflush(stdout);return;}}}
 printf("{\"W\":%d,\"R\":%d,\"comparisons\":192,\"changed\":0}\n",W,R);fflush(stdout);CU(cudaMemcpyAsync(x,xs[0].data(),xs[0].size()*2,cudaMemcpyHostToDevice,s));
 auto time=[&](auto fn){for(int j=0;j<8;j++)fn();CU(cudaStreamSynchronize(s));cudaGraph_t g;cudaGraphExec_t e;CU(cudaStreamBeginCapture(s,cudaStreamCaptureModeThreadLocal));for(int j=0;j<64;j++)fn();CU(cudaStreamEndCapture(s,&g));CU(cudaGraphInstantiate(&e,g,nullptr,nullptr,0));cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaGraphLaunch(e,s));CU(cudaEventRecord(a,s));for(int j=0;j<8;j++)CU(cudaGraphLaunch(e,s));CU(cudaEventRecord(b,s));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));CU(cudaGraphExecDestroy(e));CU(cudaGraphDestroy(g));return ms*1000/(64*8);};
 for(int rep=0;rep<3;rep++)for(int rows:{8,12,16,24,32}){float a,b;if(rep%2){b=time([&]{candidate(rows);});a=time([&]{baseline(rows);});}else{a=time([&]{baseline(rows);});b=time([&]{candidate(rows);});}printf("{\"W\":%d,\"R\":%d,\"rows\":%d,\"repeat\":%d,\"baseline_us\":%f,\"candidate_us\":%f}\n",W,R,rows,rep,a,b);fflush(stdout);}
}
int main(int argc,char**argv){try{if(argc!=4)return 1;cudaDeviceProp prop;CU(cudaGetDeviceProperties(&prop,0));if(prop.major!=8||prop.minor!=0||prop.multiProcessorCount!=108)throw std::runtime_error("SM80");std::ifstream f(argv[1]);std::string line,z;getline(f,line);std::stringstream ss(line);std::vector<std::string>a;while(getline(ss,z,'\t'))a.push_back(z);auto seed=read(a[3],128ul*2560*2,a[4]),hw=read(argv[2],2560ul*4096*2,argv[3]);U*w,*x,*y,*dy;float*parts;void*workspace;CU(cudaMalloc(&w,hw.size()*2));CU(cudaMalloc(&x,32ul*4096*2));CU(cudaMalloc(&y,32ul*2560*2));CU(cudaMalloc(&dy,32ul*2560*2));CU(cudaMalloc(&parts,4ul*32*2560*4));CU(cudaMalloc(&workspace,4u*1024u*1024u));CU(cudaMemcpy(w,hw.data(),hw.size()*2,cudaMemcpyHostToDevice));cudaStream_t s;CU(cudaStreamCreateWithFlags(&s,cudaStreamNonBlocking));cublasHandle_t h;BL(cublasCreate(&h));BL(cublasSetStream(h,s));int ver;BL(cublasGetVersion(h,&ver));if(ver!=120405)throw std::runtime_error("cuBLAS");BL(cublasSetMathMode(h,CUBLAS_DEFAULT_MATH));BL(cublasSetAtomicsMode(h,CUBLAS_ATOMICS_NOT_ALLOWED));std::vector<std::vector<U>>xs(6),gold(6);float alpha=1,beta=0;
 for(int st=0;st<6;st++){auto&v=xs[st];v.resize(32ul*4096);for(size_t i=0;i<v.size();i++)v[i]=st==0?seed[i%seed.size()]:st==1?0:st==2?bf(cv(seed[(i*13+37)%seed.size()])*(i%3==0?-.5f:1.5f)):st==3?bf((int(i%17)-8)*.125f):st==4?bf((i%2?-1:1)*.0009765625f):bf(cv(seed[(i*7+19)%seed.size()])*4.f);CU(cudaMemcpyAsync(x,v.data(),v.size()*2,cudaMemcpyHostToDevice,s));for(int r=0;r<32;r++)BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,2560,1,4096,&alpha,w,CUDA_R_16BF,4096,x+r*4096,CUDA_R_16BF,4096,&beta,dy+r*2560,CUDA_R_16BF,2560,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));CU(cudaStreamSynchronize(s));gold[st].resize(32ul*2560);CU(cudaMemcpy(gold[st].data(),dy,gold[st].size()*2,cudaMemcpyDeviceToHost));}
 cublasLtHandle_t lt;cublasLtMatmulDesc_t op;cublasLtMatrixLayout_t weights;cublasLtMatmulAlgo_t algo;BL(cublasLtCreate(&lt));BL(cublasLtMatmulDescCreate(&op,CUBLAS_COMPUTE_32F,CUDA_R_32F));cublasOperation_t trans=CUBLAS_OP_T;BL(cublasLtMatmulDescSetAttribute(op,CUBLASLT_MATMUL_DESC_TRANSA,&trans,sizeof(trans)));BL(cublasLtMatrixLayoutCreate(&weights,CUDA_R_16BF,4096,2560,4096));BL(cublasLtMatmulAlgoInit(lt,CUBLAS_COMPUTE_32F,CUDA_R_32F,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,21,&algo));const cublasLtMatmulAlgoConfigAttributes_t attrs[]={CUBLASLT_ALGO_CONFIG_TILE_ID,CUBLASLT_ALGO_CONFIG_STAGES_ID,CUBLASLT_ALGO_CONFIG_SPLITK_NUM,CUBLASLT_ALGO_CONFIG_REDUCTION_SCHEME,CUBLASLT_ALGO_CONFIG_CTA_SWIZZLING,CUBLASLT_ALGO_CONFIG_CUSTOM_OPTION};const uint32_t vals[]={15,18,2,2,0,0};for(int i=0;i<6;i++)BL(cublasLtMatmulAlgoConfigSetAttribute(&algo,attrs[i],&vals[i],4));
 trial<1,32,0,1>(h,lt,op,weights,algo,s,w,x,y,parts,workspace,xs,gold);return 0;}catch(const std::exception&e){fprintf(stderr,"%s\n",e.what());return 1;}}
