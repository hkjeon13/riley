// Research only: classify native same-SM80 M1 vs batched GEMM equality.
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <mma.h>
#include <cublas_v2.h>
#include <cublasLt.h>
#include <algorithm>
#include <openssl/sha.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <stdexcept>
#include <filesystem>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <unistd.h>
using U=uint16_t;
#define CU(x) do{if((x)!=cudaSuccess)throw std::runtime_error("CUDA API failed");}while(0)
#define BL(x) do{if((x)!=CUBLAS_STATUS_SUCCESS)throw std::runtime_error("cuBLAS API failed");}while(0)
std::string sha(const std::vector<U>&x){unsigned char d[32];SHA256((const unsigned char*)x.data(),x.size()*2,d);static const char*h="0123456789abcdef";std::string s;for(auto c:d){s+=h[c>>4];s+=h[c&15];}return s;}
std::vector<U>read(const std::string&p,size_t bytes,const std::string&digest){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f||uint64_t(f.tellg())!=bytes||bytes%2||bytes>(1ull<<30))throw std::runtime_error("input size");std::vector<U>x(bytes/2);f.seekg(0);f.read((char*)x.data(),bytes);if(!f||sha(x)!=digest)throw std::runtime_error("input SHA256");return x;}
float cv(U x){uint32_t b=uint32_t(x)<<16;float f;memcpy(&f,&b,4);return f;}
U bf(float f){uint32_t b;memcpy(&b,&f,4);return U((b+0x7fff+((b>>16)&1))>>16);}
void save(const std::string&p,const std::vector<U>&x){if(std::filesystem::exists(p))throw std::runtime_error("raw exists");std::ofstream f(p,std::ios::binary);f.write((const char*)x.data(),x.size()*2);if(!f)throw std::runtime_error("raw save");}


#include "hf_softmax_diagnostic.cuh"
struct HfDecodeChunk { int count,total,tokens[32],starts[32]; };

template <typename input_t, typename output_t, typename acc_t, int log2_elements, bool is_log_softmax, bool is_masked, int WARP_SIZE_PARAM, bool scaled_bf16_d128 = false, bool scaled_bf16_d64 = false, bool strided_rows = false>
__device__ __forceinline__ void hf_wide_chunk_softmax_body(output_t *dst, const input_t *src, int batch_size, int stride, int element_count, int virtual_x, int virtual_y, int virtual_warps, const bool *mask = nullptr, const int head_chunk_size = -1, bool is_transformer_mask = false, int first_batch_override = -1)
{
    // WARP_SIZE and WARP_BATCH must match the return values batches_per_warp and warp_size of method warp_softmax_forward_kernel.
    constexpr int next_power_of_two = 1 << log2_elements;
    constexpr int WARP_SIZE = (next_power_of_two < WARP_SIZE_PARAM) ? next_power_of_two : WARP_SIZE_PARAM;
    constexpr int WARP_ITERATIONS = next_power_of_two / WARP_SIZE;
    constexpr int WARP_BATCH = (next_power_of_two <= 128) ? 2 : 1;

    int first_batch = first_batch_override >= 0 ? first_batch_override : (virtual_warps * blockIdx.x + virtual_y) * WARP_BATCH;

    // batch_size might not be a multiple of WARP_BATCH. Check how
    // many batches have to computed within this WARP.
    int local_batches = batch_size - first_batch;
    if (local_batches > WARP_BATCH)
        local_batches = WARP_BATCH;

    // there might be multiple batches per warp. compute the index within the batch
    int local_idx = virtual_x;
    int idx_offset = first_batch * stride + local_idx;

    src += idx_offset;
    dst += idx_offset;

    if (is_transformer_mask) {
        mask += ((first_batch * stride) / head_chunk_size) * stride + local_idx;
    } else {
        mask += idx_offset;
    }
    // The nested loops over WARP_BATCH and then WARP_ITERATIONS can be simplified to one loop,
    // but I think doing so would obfuscate the logic of the algorithm, thus I chose to keep
    // the nested loops.
    // This should have no impact on performance because the loops are unrolled anyway.

    // load data from global memory
    acc_t elements[WARP_BATCH][WARP_ITERATIONS];
    for (int i = 0;  i < WARP_BATCH;  ++i) {
        int batch_element_count = (i >= local_batches) ? 0 : element_count;
        for (int it = 0;  it < WARP_ITERATIONS;  ++it) {
            int element_index = local_idx + it * WARP_SIZE;
            if (element_index < batch_element_count) {
                elements[i][it] = src[i*(strided_rows?stride:element_count)+it*WARP_SIZE];
                if constexpr (scaled_bf16_d64) {
                    elements[i][it] = __bfloat162float(__float2bfloat16_rn(__fmul_rn(elements[i][it],0.125f)));
                }
                if constexpr (scaled_bf16_d128) {
                    elements[i][it] = hf_decode_scaled_bf16_d128(elements[i][it]);
                }
            } else {
                elements[i][it] = -CUDART_INF_F;
            }
        }
    }

    // compute max_value
    acc_t max_value[WARP_BATCH];
    #pragma unroll
    for (int i = 0;  i < WARP_BATCH;  ++i) {
        int batch_element_count = (i >= local_batches) ? 0 : element_count;
        bool is_meaningful_max = false;
        max_value[i] = elements[i][0];
        #pragma unroll
        for (int it = 0;  it < WARP_ITERATIONS;  ++it) {
            if (is_masked) {
                int idx = it*WARP_SIZE;
                if ((idx + local_idx) < batch_element_count) {
                    if (!is_transformer_mask) {
                        idx += i*(strided_rows?stride:element_count);
                    }
                    if (!mask[idx]) {
                        max_value[i] = (is_meaningful_max && max_value[i] > elements[i][it]) ? max_value[i] : elements[i][it];
                        is_meaningful_max = true;
                    }
                }
            } else {
                max_value[i] = max_value[i] > elements[i][it] ? max_value[i] : elements[i][it];
            }
        }
        if (is_masked) {
            if (!is_meaningful_max) {
                max_value[i] = -CUDART_INF_F;
            }
        }
    }
    warp_reduce<acc_t, WARP_BATCH, WARP_SIZE, Max>(max_value);

    acc_t sum[WARP_BATCH] { 0.0f };
    #pragma unroll
    for (int i = 0;  i < WARP_BATCH;  ++i) {
        int batch_element_count = (i >= local_batches) ? 0 : element_count;
        #pragma unroll
        for (int it = 0;  it < WARP_ITERATIONS;  ++it) {
            if (!is_masked) {
                if (is_log_softmax) {
                    sum[i] += std::exp(elements[i][it] - max_value[i]);
                } else {
                    elements[i][it] = std::exp(elements[i][it] - max_value[i]);
                    sum[i] += elements[i][it];
                }
            } else {
                int idx = it*WARP_SIZE;
                bool valid = (idx + local_idx) < batch_element_count;
                if (!is_transformer_mask) {
                    idx += i*(strided_rows?stride:element_count);
                }
                if (valid) {
                    if (!mask[idx]) {
                        if (is_log_softmax) {
                            sum[i] += std::exp(elements[i][it] - max_value[i]);
                        } else {
                            elements[i][it] = std::exp(elements[i][it] - max_value[i]);
                            sum[i] += elements[i][it];
                        }
                    } else {
                        if (!is_log_softmax) {
                            // Masked values are treated as -infinity, and std::exp(-infinity) is 0.
                            elements[i][it] = 0;
                        }
                    }
                } else {
                    if (!is_log_softmax) {
                        elements[i][it] = 0.;
                    }
                }
            }
        }
    }
    warp_reduce<acc_t, WARP_BATCH, WARP_SIZE, Add>(sum);

    // store result
    #pragma unroll
    for (int i = 0;  i < WARP_BATCH;  ++i) {
        if (i >= local_batches)
            break;
        if (is_log_softmax) sum[i] = std::log(sum[i]);
        #pragma unroll
        for (int it = 0;  it < WARP_ITERATIONS;  ++it) {
            int element_index = local_idx + it * WARP_SIZE;
            if (element_index < element_count) {
                if (is_log_softmax) {
                    dst[i*(strided_rows?stride:element_count)+it*WARP_SIZE] = elements[i][it] - max_value[i] - sum[i];
                } else if (sum[i] == 0) {
                    dst[i*(strided_rows?stride:element_count)+it*WARP_SIZE] = CUDART_NAN_F;
                } else {
                    dst[i*(strided_rows?stride:element_count)+it*WARP_SIZE] = elements[i][it] / sum[i];
                }
            } else {
                break;
            }
        }
    }
}
__global__ void hf_wide_chunk_softmax(__nv_bfloat16* probability,const HfDecodeChunk info){
 const int r=blockIdx.y,t=info.tokens[r];int log=0;while((1<<log)<t)log++;
 const int width=log<5?(1<<log):32,warps=128/width,wb=log<=7?2:1;
 if(blockIdx.x>=(32+warps*wb-1)/(warps*wb))return;
 const int tid=threadIdx.x+blockDim.x*threadIdx.y;
 auto*p=probability+uint64_t(info.starts[r])*32;
 #define HF_WIDE_SOFTMAX_CASE(L) case L:hf_wide_chunk_softmax_body<__nv_bfloat16,__nv_bfloat16,float,L,false,false,32,true>(p,p,32,t,t,tid%width,tid/width,warps);break;
 switch(log){HF_WIDE_SOFTMAX_CASE(0) HF_WIDE_SOFTMAX_CASE(1) HF_WIDE_SOFTMAX_CASE(2) HF_WIDE_SOFTMAX_CASE(3) HF_WIDE_SOFTMAX_CASE(4) HF_WIDE_SOFTMAX_CASE(5) HF_WIDE_SOFTMAX_CASE(6) HF_WIDE_SOFTMAX_CASE(7) HF_WIDE_SOFTMAX_CASE(8) HF_WIDE_SOFTMAX_CASE(9)}
 #undef HF_WIDE_SOFTMAX_CASE
}
__host__ __device__ static int sm80_paged_qk_family(uint64_t t){
 if(t<24 || t>216)return -1;
 if(t>=130 && t%2==0)return 2;
 if((t>=49 && t%2==1)||t%8==0)return 1;
 return 0;
}
struct HfSm80Group {int count=0,maximum=0,rows[32]{};};
__device__ __forceinline__ uint64_t sm80_paged_id(const uint32_t*ids,const uint32_t*slots,const uint32_t*offsets,int r,int page,uint64_t physical,uint64_t sequences,uint64_t id_count){
 uint64_t slot=slots[r];if(slot>=sequences)return physical;uint64_t start=offsets[slot],end=offsets[slot+1];if(start>end||end>id_count||uint64_t(page)>=end-start)return physical;uint64_t id=ids[start+page];return id<physical?id:physical;
}
// Pinned SM80 native reduction families. All scores and probabilities retain
// their original BF16 stores; queries and KV pages keep their existing layout.
template<bool Serial16> __global__ void sm80_chunk_paged_qk(const __nv_bfloat16*q,const __nv_bfloat16*k,const uint32_t*ids,__nv_bfloat16*score,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const HfDecodeChunk info,const HfSm80Group group){
 int r=group.rows[blockIdx.z],t=info.tokens[r];q+=r*32*128;score+=uint64_t(info.starts[r])*32;
 constexpr int L=Serial16?16:8;int lane=threadIdx.x,token=blockIdx.x*8+threadIdx.y,head=blockIdx.y;float sum=0.f;
 if(token<t){uint64_t id=sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count);
 #pragma unroll
 for(int j=0;j<128/L;j++){int d=Serial16?lane+j*16:lane*16+j;float a=id<physical?__bfloat162float(k[((id*8+head/4)*16+token%16)*128+d]):CUDART_NAN_F;float b=__bfloat162float(q[head*128+d]);sum=__fmaf_rn(a,b,sum);}}
 __shared__ float p[8][L];p[threadIdx.y][lane]=sum;__syncthreads();
 if(lane==0&&token<t){float v=p[threadIdx.y][0];if(Serial16){
 #pragma unroll
 for(int j=1;j<L;j++)v=__fadd_rn(v,p[threadIdx.y][j]);
 }else{float*pv=p[threadIdx.y];float a=__fadd_rn(pv[0],pv[4]),b=__fadd_rn(pv[1],pv[5]),c=__fadd_rn(pv[2],pv[6]),d=__fadd_rn(pv[3],pv[7]);v=__fadd_rn(__fadd_rn(a,c),__fadd_rn(b,d));}score[head*t+token]=__float2bfloat16_rn(__fmaf_rn(1.f,v,0.f));}
}
__global__ void sm80_chunk_paged_wmma_qk(const __nv_bfloat16*q,const __nv_bfloat16*k,const uint32_t*ids,__nv_bfloat16*score,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const HfDecodeChunk info,const HfSm80Group group){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800

 int r=group.rows[blockIdx.z],t=info.tokens[r];q+=r*32*128;score+=uint64_t(info.starts[r])*32;if(blockIdx.x*16>=t)return;
 using namespace nvcuda;int lane=threadIdx.x,head=blockIdx.y,first=blockIdx.x*16;
 __shared__ __align__(32) __nv_bfloat16 stage[4096];
 for(int i=lane;i<256;i+=32){int token=first+i/16,depth=i%16;uint64_t id=token<t?sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count):physical;uint4 v=make_uint4(0,0,0,0);if(token<t){if(id<physical)v=reinterpret_cast<const uint4*>(k)[((id*8+head/4)*16+token%16)*16+depth];else v=make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);}reinterpret_cast<uint4*>(stage)[i]=v;
  reinterpret_cast<uint4*>(stage+2048)[i]=i<16?reinterpret_cast<const uint4*>(q)[head*16+i]:make_uint4(0,0,0,0);
 }__syncwarp();
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>acc;wmma::fill_fragment(acc,0.f);
 #pragma unroll
 for(int j=0;j<128;j+=16){wmma::load_matrix_sync(a,stage+j,128);wmma::load_matrix_sync(b,stage+2048+j,128);wmma::mma_sync(acc,a,b,acc);}
 __shared__ __align__(32) float result[256];wmma::store_matrix_sync(result,acc,16,wmma::mem_col_major);__syncwarp();if(lane<16&&first+lane<t)score[head*t+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,result[lane],0.f));

#endif
}
__global__ void sm80_chunk_paged_pv(const __nv_bfloat16*values,const uint32_t*ids,const __nv_bfloat16*prob,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const HfDecodeChunk info,const HfSm80Group group){
 int r=group.rows[blockIdx.z],t=info.tokens[r];prob+=uint64_t(info.starts[r])*32;out+=r*32*128;
 int tid=threadIdx.x,head=blockIdx.y,depth=blockIdx.x*32+tid%32,lane=tid/32;float sum=0.f;
 for(int page=0;page<(t+15)/16;page++){uint64_t id=sm80_paged_id(ids,slots,offsets,r,page,physical,sequences,id_count),base=((id*8+head/4)*16)*128+depth;
 #pragma unroll
 for(int j=lane;j<16;j+=2){int token=page*16+j;if(token<t){float a=id<physical?__bfloat162float(values[base+j*128]):CUDART_NAN_F;float b=__bfloat162float(prob[head*t+token]);sum=__fmaf_rn(a,b,sum);}}}
 __shared__ float p[64];p[tid]=sum;__syncthreads();if(tid<32)out[head*128+depth]=__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(p[tid],p[tid+32]),0.f));
}
__global__ void sm80_chunk_paged_wmma_pv(const __nv_bfloat16*values,const uint32_t*ids,const __nv_bfloat16*prob,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const HfDecodeChunk info,const HfSm80Group group){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800

 int r=group.rows[blockIdx.z],t=info.tokens[r];prob+=uint64_t(info.starts[r])*32;out+=r*32*128;
 using namespace nvcuda;int head=blockIdx.y,kh=head/4,lane=threadIdx.x,first=blockIdx.x*16;
 __shared__ __align__(32) __nv_bfloat16 stage[512];
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::col_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>acc;wmma::fill_fragment(acc,0.f);
 for(int base=0;base<t;base+=16){uint64_t id=sm80_paged_id(ids,slots,offsets,r,base/16,physical,sequences,id_count);
  for(int i=lane;i<32;i+=32){int token=base+i/2,depth=first/8+i%2;uint4 v=make_uint4(0,0,0,0);if(token<t){if(id<physical)v=reinterpret_cast<const uint4*>(values)[((id*8+kh)*16+token%16)*16+depth];else v=make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);}reinterpret_cast<uint4*>(stage)[i]=v;}
  for(int i=lane;i<256;i+=32){int token=base+i%16;stage[256+i]=token<t?prob[head*t+token]:__float2bfloat16_rn(0.f);}__syncwarp();
  wmma::load_matrix_sync(a,stage,16);wmma::load_matrix_sync(b,stage+256,16);wmma::mma_sync(acc,a,b,acc);__syncwarp();
 }__shared__ __align__(32) float result[256];wmma::store_matrix_sync(result,acc,16,wmma::mem_col_major);__syncwarp();if(lane<16)out[head*128+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,result[lane],0.f));

#endif
}
// Graph-stable paged attention: fixed request stride and device-selected
// native reduction families; no context length is captured by value.
template<bool Serial16> __global__ void sm80_dynamic_paged_qk(const __nv_bfloat16*q,const __nv_bfloat16*k,const uint32_t*ids,__nv_bfloat16*score,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
 int r=blockIdx.z,t=positions[r]+1;if(t<24||t>216||sm80_paged_qk_family(t)!=(Serial16?1:0))return;q+=r*32*128;score+=uint64_t(r)*512*32;
 constexpr int L=Serial16?16:8;int lane=threadIdx.x,token=blockIdx.x*8+threadIdx.y,head=blockIdx.y;float sum=0.f;
 if(token<t){uint64_t id=sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count);
 #pragma unroll
 for(int j=0;j<128/L;j++){int d=Serial16?lane+j*16:lane*16+j;float a=id<physical?__bfloat162float(k[((id*8+head/4)*16+token%16)*128+d]):CUDART_NAN_F;float b=__bfloat162float(q[head*128+d]);sum=__fmaf_rn(a,b,sum);}}
 __shared__ float p[8][L];p[threadIdx.y][lane]=sum;__syncthreads();
 if(lane==0&&token<t){float v=p[threadIdx.y][0];if(Serial16){
 #pragma unroll
 for(int j=1;j<L;j++)v=__fadd_rn(v,p[threadIdx.y][j]);
 }else{float*pv=p[threadIdx.y];float a=__fadd_rn(pv[0],pv[4]),b=__fadd_rn(pv[1],pv[5]),c=__fadd_rn(pv[2],pv[6]),d=__fadd_rn(pv[3],pv[7]);v=__fadd_rn(__fadd_rn(a,c),__fadd_rn(b,d));}score[head*t+token]=__float2bfloat16_rn(__fmaf_rn(1.f,v,0.f));}
}
__global__ void sm80_dynamic_paged_wmma_qk(const __nv_bfloat16*q,const __nv_bfloat16*k,const uint32_t*ids,__nv_bfloat16*score,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800

 int r=blockIdx.z,t=positions[r]+1;if(t<24||t>216||sm80_paged_qk_family(t)!=2)return;q+=r*32*128;score+=uint64_t(r)*512*32;if(blockIdx.x*16>=t)return;
 using namespace nvcuda;int lane=threadIdx.x,head=blockIdx.y,first=blockIdx.x*16;
 __shared__ __align__(32) __nv_bfloat16 stage[4096];
 for(int i=lane;i<256;i+=32){int token=first+i/16,depth=i%16;uint64_t id=token<t?sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count):physical;uint4 v=make_uint4(0,0,0,0);if(token<t){if(id<physical)v=reinterpret_cast<const uint4*>(k)[((id*8+head/4)*16+token%16)*16+depth];else v=make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);}reinterpret_cast<uint4*>(stage)[i]=v;
  reinterpret_cast<uint4*>(stage+2048)[i]=i<16?reinterpret_cast<const uint4*>(q)[head*16+i]:make_uint4(0,0,0,0);
 }__syncwarp();
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>acc;wmma::fill_fragment(acc,0.f);
 #pragma unroll
 for(int j=0;j<128;j+=16){wmma::load_matrix_sync(a,stage+j,128);wmma::load_matrix_sync(b,stage+2048+j,128);wmma::mma_sync(acc,a,b,acc);}
 __shared__ __align__(32) float result[256];wmma::store_matrix_sync(result,acc,16,wmma::mem_col_major);__syncwarp();if(lane<16&&first+lane<t)score[head*t+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,result[lane],0.f));

#endif
}
__global__ void sm80_dynamic_paged_pv(const __nv_bfloat16*values,const uint32_t*ids,const __nv_bfloat16*prob,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
 int r=blockIdx.z,t=positions[r]+1;if(t<24||t>216||t%8==0)return;prob+=uint64_t(r)*512*32;out+=r*32*128;
 int tid=threadIdx.x,head=blockIdx.y,depth=blockIdx.x*32+tid%32,lane=tid/32;float sum=0.f;
 for(int page=0;page<(t+15)/16;page++){uint64_t id=sm80_paged_id(ids,slots,offsets,r,page,physical,sequences,id_count),base=((id*8+head/4)*16)*128+depth;
 #pragma unroll
 for(int j=lane;j<16;j+=2){int token=page*16+j;if(token<t){float a=id<physical?__bfloat162float(values[base+j*128]):CUDART_NAN_F;float b=__bfloat162float(prob[head*t+token]);sum=__fmaf_rn(a,b,sum);}}}
 __shared__ float p[64];p[tid]=sum;__syncthreads();if(tid<32)out[head*128+depth]=__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(p[tid],p[tid+32]),0.f));
}
__global__ void sm80_dynamic_paged_wmma_pv(const __nv_bfloat16*values,const uint32_t*ids,const __nv_bfloat16*prob,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800

 int r=blockIdx.z,t=positions[r]+1;if(t<24||t>216||t%8!=0)return;prob+=uint64_t(r)*512*32;out+=r*32*128;
 using namespace nvcuda;int head=blockIdx.y,kh=head/4,lane=threadIdx.x,first=blockIdx.x*16;
 __shared__ __align__(32) __nv_bfloat16 stage[512];
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::col_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>acc;wmma::fill_fragment(acc,0.f);
 for(int base=0;base<t;base+=16){uint64_t id=sm80_paged_id(ids,slots,offsets,r,base/16,physical,sequences,id_count);
  for(int i=lane;i<32;i+=32){int token=base+i/2,depth=first/8+i%2;uint4 v=make_uint4(0,0,0,0);if(token<t){if(id<physical)v=reinterpret_cast<const uint4*>(values)[((id*8+kh)*16+token%16)*16+depth];else v=make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);}reinterpret_cast<uint4*>(stage)[i]=v;}
  for(int i=lane;i<256;i+=32){int token=base+i%16;stage[256+i]=token<t?prob[head*t+token]:__float2bfloat16_rn(0.f);}__syncwarp();
  wmma::load_matrix_sync(a,stage,16);wmma::load_matrix_sync(b,stage+256,16);wmma::mma_sync(acc,a,b,acc);__syncwarp();
 }__shared__ __align__(32) float result[256];wmma::store_matrix_sync(result,acc,16,wmma::mem_col_major);__syncwarp();if(lane<16)out[head*128+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,result[lane],0.f));

#endif
}
__global__ void sm80_dynamic_softmax(__nv_bfloat16* probability,const uint32_t*positions){
 const int r=blockIdx.y,t=positions[r]+1;if(t<24||t>216)return;int log=0;while((1<<log)<t)log++;
 const int width=log<5?(1<<log):32,warps=128/width,wb=log<=7?2:1;
 if(blockIdx.x>=(32+warps*wb-1)/(warps*wb))return;
 const int tid=threadIdx.x+blockDim.x*threadIdx.y;
 auto*p=probability+uint64_t(r)*512*32;
 #define HF_WIDE_SOFTMAX_CASE(L) case L:hf_wide_chunk_softmax_body<__nv_bfloat16,__nv_bfloat16,float,L,false,false,32,true>(p,p,32,t,t,tid%width,tid/width,warps);break;
 switch(log){HF_WIDE_SOFTMAX_CASE(0) HF_WIDE_SOFTMAX_CASE(1) HF_WIDE_SOFTMAX_CASE(2) HF_WIDE_SOFTMAX_CASE(3) HF_WIDE_SOFTMAX_CASE(4) HF_WIDE_SOFTMAX_CASE(5) HF_WIDE_SOFTMAX_CASE(6) HF_WIDE_SOFTMAX_CASE(7) HF_WIDE_SOFTMAX_CASE(8) HF_WIDE_SOFTMAX_CASE(9)}
 #undef HF_WIDE_SOFTMAX_CASE
}
// One CTA owns one request and four query heads sharing one KV head. QK/probability remain materialized BF16 in
// shared memory; native reduction families and softmax tree are unchanged.
template<int Heads> __global__ void sm80_fused_paged_attention(const __nv_bfloat16*q,const __nv_bfloat16*k,const __nv_bfloat16*v,const uint32_t*ids,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 int r=blockIdx.x,head=blockIdx.y*Heads,t=positions[r]+1,kind=sm80_paged_qk_family(t);
 if(kind!=2)return;
 int tid=threadIdx.x,warp=tid/32,lane=tid%32;
 q+=r*32*128+head*128;out+=r*32*128+head*128;
 __shared__ __align__(32) __nv_bfloat16 stage[4][4096];
 __shared__ __align__(32) float result[4][256];
 __shared__ float partial[Heads][128];
 __shared__ __nv_bfloat16 score[Heads][256];
 using namespace nvcuda;
 if(kind==2){
  for(int first0=0;first0<t;first0+=64){
   int first=first0+warp*16;
   for(int i=lane;i<256;i+=32){int token=first+i/16,depth=i%16;uint64_t id=token<t?sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count):physical;uint4 a=make_uint4(0,0,0,0);if(token<t)a=id<physical?reinterpret_cast<const uint4*>(k)[((id*8+head/4)*16+token%16)*16+depth]:make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);reinterpret_cast<uint4*>(stage[warp])[i]=a;reinterpret_cast<uint4*>(stage[warp]+2048)[i]=i<Heads*16?reinterpret_cast<const uint4*>(q)[i]:make_uint4(0,0,0,0);}
   __syncwarp();wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c;wmma::fill_fragment(c,0.f);
   #pragma unroll
   for(int j=0;j<128;j+=16){wmma::load_matrix_sync(a,stage[warp]+j,128);wmma::load_matrix_sync(b,stage[warp]+2048+j,128);wmma::mma_sync(c,a,b,c);}
   wmma::store_matrix_sync(result[warp],c,16,wmma::mem_col_major);__syncwarp();if(lane<16&&first+lane<t)for(int h=0;h<Heads;h++)score[h][first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,result[warp][h*16+lane],0.f));
  }
 }else{
  int L=kind==1?16:8,qlane=tid%L;
  for(int first=0;first<t;first+=128/L){int token=first+tid/L;float sum[4]={};
   if(token<t){uint64_t id=sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count);for(int j=0;j<128/L;j++){int d=kind==1?qlane+j*16:qlane*16+j;float a=id<physical?__bfloat162float(k[((id*8+head/4)*16+token%16)*128+d]):CUDART_NAN_F;for(int h=0;h<Heads;h++)sum[h]=__fmaf_rn(a,__bfloat162float(q[h*128+d]),sum[h]);}}
   for(int h=0;h<Heads;h++)partial[h][tid]=sum[h];__syncthreads();
   if(qlane==0&&token<t)for(int h=0;h<Heads;h++){float*p=partial[h]+tid;float val=p[0];if(kind==1){for(int j=1;j<16;j++)val=__fadd_rn(val,p[j]);}else{float a=__fadd_rn(p[0],p[4]),b=__fadd_rn(p[1],p[5]),c=__fadd_rn(p[2],p[6]),d=__fadd_rn(p[3],p[7]);val=__fadd_rn(__fadd_rn(a,c),__fadd_rn(b,d));}score[h][token]=__float2bfloat16_rn(__fmaf_rn(1.f,val,0.f));}
   __syncthreads();
  }
 }
 __syncthreads();
 if(warp<Heads){int log=0;while((1<<log)<t)log++;
#define FUSED_SM(L) case L:hf_wide_chunk_softmax_body<__nv_bfloat16,__nv_bfloat16,float,L,false,false,32,true>(score[warp],score[warp],1,t,t,lane,0,1,nullptr,-1,false,0);break;
  switch(log){FUSED_SM(5) FUSED_SM(6) FUSED_SM(7) FUSED_SM(8)}
#undef FUSED_SM
 }
 __syncthreads();
 if(t%8==0){
  for(int first=warp*16;first<128;first+=64){
   wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::col_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c;wmma::fill_fragment(c,0.f);
   for(int base=0;base<t;base+=16){uint64_t id=sm80_paged_id(ids,slots,offsets,r,base/16,physical,sequences,id_count);int token=base+lane/2,depth=first/8+lane%2;uint4 z=make_uint4(0,0,0,0);if(token<t)z=id<physical?reinterpret_cast<const uint4*>(v)[((id*8+head/4)*16+token%16)*16+depth]:make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);reinterpret_cast<uint4*>(stage[warp])[lane]=z;for(int i=lane;i<256;i+=32)stage[warp][256+i]=i/16<Heads&&base+i%16<t?score[i/16][base+i%16]:__float2bfloat16_rn(0.f);__syncwarp();wmma::load_matrix_sync(a,stage[warp],16);wmma::load_matrix_sync(b,stage[warp]+256,16);wmma::mma_sync(c,a,b,c);__syncwarp();}
   wmma::store_matrix_sync(result[warp],c,16,wmma::mem_col_major);__syncwarp();if(lane<16)for(int h=0;h<Heads;h++)out[h*128+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,result[warp][h*16+lane],0.f));
  }
 }else{
  float a[4]={},b[4]={};for(int page=0;page<(t+15)/16;page++){uint64_t id=sm80_paged_id(ids,slots,offsets,r,page,physical,sequences,id_count),base=((id*8+head/4)*16)*128+tid;
   #pragma unroll
   for(int j=0;j<16;j+=2){float va=page*16+j<t?(id<physical?__bfloat162float(v[base+j*128]):CUDART_NAN_F):0.f,vb=page*16+j+1<t?(id<physical?__bfloat162float(v[base+(j+1)*128]):CUDART_NAN_F):0.f;for(int h=0;h<Heads;h++){if(page*16+j<t)a[h]=__fmaf_rn(va,__bfloat162float(score[h][page*16+j]),a[h]);if(page*16+j+1<t)b[h]=__fmaf_rn(vb,__bfloat162float(score[h][page*16+j+1]),b[h]);}}}
  for(int h=0;h<Heads;h++)out[h*128+tid]=__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(a[h],b[h]),0.f));
 }
#endif
}

template<int Heads,bool Serial16>__device__ __forceinline__ void sm80_scalar_qk_shared(const __nv_bfloat16*q,const __nv_bfloat16*k,const uint32_t*ids,const uint32_t*slots,const uint32_t*offsets,int r,int head,int t,uint64_t physical,uint64_t sequences,uint64_t id_count,__nv_bfloat16*score,float*partial){
 constexpr int L=Serial16?16:8;int tid=threadIdx.x,lane=tid%L;
 for(int first=0;first<t;first+=256/L){int token=first+tid/L;uint64_t id=token<t?sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count):physical;float sum[Heads]={};
 #pragma unroll
 for(int j=0;j<128/L;j++){int d=Serial16?lane+j*16:lane*16+j;float a=id<physical?__bfloat162float(k[((id*8+head/4)*16+token%16)*128+d]):CUDART_NAN_F;
 #pragma unroll
 for(int h=0;h<Heads;h++)sum[h]=__fmaf_rn(a,__bfloat162float(q[h*128+d]),sum[h]);}
 #pragma unroll
 for(int h=0;h<Heads;h++){
  float val=sum[h];if constexpr(Serial16){partial[h*256+tid]=val;__syncwarp();if(lane==0){
   #pragma unroll
   for(int j=1;j<16;j++)val=__fadd_rn(val,partial[h*256+tid+j]);}
   __syncwarp();
  }else{
   #pragma unroll
   for(int d=4;d;d/=2){float a=__shfl_down_sync(0xffffffffu,val,d,8);if(lane<d)val=__fadd_rn(val,a);}
  }
  if(lane==0&&token<t)score[h*256+token]=__float2bfloat16_rn(__fmaf_rn(1.f,val,0.f));
 }
 }
}
// Native scalar QK families use warp-local reductions, with identical trees.
// Eight warps cover independent tokens/depths without a barrier per token tile.
template<int Heads>__global__ void sm80_scalar_fused_attention(const __nv_bfloat16*q,const __nv_bfloat16*k,const __nv_bfloat16*v,const uint32_t*ids,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 int r=blockIdx.x,head=blockIdx.y*Heads,t=positions[r]+1,kind=sm80_paged_qk_family(t);if(kind<0||kind==2)return;
 int tid=threadIdx.x,warp=tid/32,lane=tid%32,L=kind==1?16:8,qlane=tid%L;
 q+=r*32*128+head*128;out+=r*32*128+head*128;
 __shared__ __nv_bfloat16 score[Heads][256];
 __shared__ __align__(32) __nv_bfloat16 stage[8][512];
 __shared__ __align__(32) float result[8][256];
 if(kind==1)sm80_scalar_qk_shared<Heads,true>(q,k,ids,slots,offsets,r,head,t,physical,sequences,id_count,&score[0][0],&result[0][0]);
 else sm80_scalar_qk_shared<Heads,false>(q,k,ids,slots,offsets,r,head,t,physical,sequences,id_count,&score[0][0],&result[0][0]);
 __syncthreads();if(warp<Heads){int log=0;while((1<<log)<t)log++;
#define SCALAR_SM(L) case L:hf_wide_chunk_softmax_body<__nv_bfloat16,__nv_bfloat16,float,L,false,false,32,true>(score[warp],score[warp],1,t,t,lane,0,1,nullptr,-1,false,0);break;
  switch(log){SCALAR_SM(5) SCALAR_SM(6) SCALAR_SM(7) SCALAR_SM(8)}
#undef SCALAR_SM
 }
 __syncthreads();
 if(t%8==0){using namespace nvcuda;int first=warp*16;
  wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::col_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c;wmma::fill_fragment(c,0.f);
  for(int base=0;base<t;base+=16){uint64_t id=sm80_paged_id(ids,slots,offsets,r,base/16,physical,sequences,id_count);int token=base+lane/2,depth=first/8+lane%2;uint4 z=make_uint4(0,0,0,0);if(token<t)z=id<physical?reinterpret_cast<const uint4*>(v)[((id*8+head/4)*16+token%16)*16+depth]:make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);reinterpret_cast<uint4*>(stage[warp])[lane]=z;
   for(int i=lane;i<256;i+=32)stage[warp][256+i]=i/16<Heads&&base+i%16<t?score[i/16][base+i%16]:__float2bfloat16_rn(0.f);__syncwarp();wmma::load_matrix_sync(a,stage[warp],16);wmma::load_matrix_sync(b,stage[warp]+256,16);wmma::mma_sync(c,a,b,c);__syncwarp();}
  wmma::store_matrix_sync(result[warp],c,16,wmma::mem_col_major);__syncwarp();if(lane<16)for(int h=0;h<Heads;h++)out[h*128+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,result[warp][h*16+lane],0.f));
 }else{
  int depth=tid%128,chain=tid/128;float a[Heads]={};
  for(int page=0;page<(t+15)/16;page++){uint64_t id=sm80_paged_id(ids,slots,offsets,r,page,physical,sequences,id_count),base=((id*8+head/4)*16)*128+depth;
   #pragma unroll
   for(int j=chain;j<16;j+=2){int token=page*16+j;if(token<t){float vv=id<physical?__bfloat162float(v[base+j*128]):CUDART_NAN_F;
    #pragma unroll
    for(int h=0;h<Heads;h++)a[h]=__fmaf_rn(vv,__bfloat162float(score[h][token]),a[h]);}}}
  #pragma unroll
  for(int h=0;h<Heads;h++)result[h][tid]=a[h];__syncthreads();if(tid<128){
   #pragma unroll
   for(int h=0;h<Heads;h++)out[h*128+tid]=__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(result[h][tid],result[h][tid+128]),0.f));}
 }
#endif
}
int main(){try{cudaDeviceProp prop;CU(cudaGetDeviceProperties(&prop,0));if(prop.major!=8||prop.minor!=0||prop.multiProcessorCount!=108)throw std::runtime_error("SM80 required");cudaStream_t s;CU(cudaStreamCreateWithFlags(&s,cudaStreamNonBlocking));constexpr int RMAX=32,PH=512;U *q,*k,*v,*out,*gold,*prob;uint32_t*ids,*slots,*offsets,*positions;CU(cudaMalloc(&q,RMAX*32*128*2));CU(cudaMalloc(&k,PH*8*16*128*2));CU(cudaMalloc(&v,PH*8*16*128*2));CU(cudaMalloc(&out,RMAX*32*128*2));CU(cudaMalloc(&gold,RMAX*32*128*2));CU(cudaMalloc(&prob,RMAX*512*32*2));CU(cudaMalloc(&ids,PH*4));CU(cudaMalloc(&slots,RMAX*4));CU(cudaMalloc(&offsets,(RMAX+1)*4));CU(cudaMalloc(&positions,RMAX*4));std::vector<uint32_t>hi(PH),hs(RMAX),ho(RMAX+1),hp(RMAX);for(int i=0;i<PH;i++)hi[i]=(i*73+19)%PH;for(int r=0;r<RMAX;r++){hs[r]=r;ho[r]=r*16;}ho[RMAX]=PH;CU(cudaMemcpy(ids,hi.data(),PH*4,cudaMemcpyHostToDevice));CU(cudaMemcpy(slots,hs.data(),RMAX*4,cudaMemcpyHostToDevice));CU(cudaMemcpy(offsets,ho.data(),(RMAX+1)*4,cudaMemcpyHostToDevice));
 HfDecodeChunk info{};HfSm80Group qg[3]{},pg[2]{};
 auto prepare=[&](int rows,int t,bool mixed){info={};info.count=rows;for(auto&g:qg)g={};for(auto&g:pg)g={};for(int r=0;r<rows;r++){int len=mixed?24+(t-24+r*7)%193:t;info.starts[r]=info.total;info.tokens[r]=len;info.total+=len;hp[r]=len-1;auto&g=qg[sm80_paged_qk_family(len)];g.rows[g.count++]=r;g.maximum=std::max(g.maximum,len);auto&p=pg[len%8==0];p.rows[p.count++]=r;p.maximum=std::max(p.maximum,len);}CU(cudaMemcpyAsync(positions,hp.data(),rows*4,cudaMemcpyHostToDevice,s));};
 auto baseline=[&](int rows){
#define QARGS (const __nv_bfloat16*)q,(const __nv_bfloat16*)k,ids,(__nv_bfloat16*)prob,PH,RMAX,PH,slots,offsets,info
 if(qg[0].count)sm80_chunk_paged_qk<false><<<dim3((qg[0].maximum+7)/8,32,qg[0].count),dim3(8,8),0,s>>>(QARGS,qg[0]);
 if(qg[1].count)sm80_chunk_paged_qk<true><<<dim3((qg[1].maximum+7)/8,32,qg[1].count),dim3(16,8),0,s>>>(QARGS,qg[1]);
 if(qg[2].count)sm80_chunk_paged_wmma_qk<<<dim3((qg[2].maximum+15)/16,32,qg[2].count),32,0,s>>>(QARGS,qg[2]);
#undef QARGS
 hf_wide_chunk_softmax<<<dim3(8,rows),128,0,s>>>((__nv_bfloat16*)prob,info);
#define PARGS (const __nv_bfloat16*)v,ids,(const __nv_bfloat16*)prob,(__nv_bfloat16*)gold,PH,RMAX,PH,slots,offsets,info
 if(pg[0].count)sm80_chunk_paged_pv<<<dim3(4,32,pg[0].count),64,0,s>>>(PARGS,pg[0]);
 if(pg[1].count)sm80_chunk_paged_wmma_pv<<<dim3(8,32,pg[1].count),32,0,s>>>(PARGS,pg[1]);
#undef PARGS
 CU(cudaGetLastError());};
 auto candidate=[&](int rows){sm80_scalar_fused_attention<2><<<dim3(rows,16),256,0,s>>>((const __nv_bfloat16*)q,(const __nv_bfloat16*)k,(const __nv_bfloat16*)v,ids,(__nv_bfloat16*)out,PH,RMAX,PH,slots,offsets,positions);sm80_fused_paged_attention<2><<<dim3(rows,16),128,0,s>>>((const __nv_bfloat16*)q,(const __nv_bfloat16*)k,(const __nv_bfloat16*)v,ids,(__nv_bfloat16*)out,PH,RMAX,PH,slots,offsets,positions);CU(cudaGetLastError());};
 int comparisons=0;uint64_t values=0;
 for(int state=0;state<6;state++){for(auto pair:{std::pair<U*,size_t>(q,RMAX*32*128),std::pair<U*,size_t>(k,PH*8*16*128),std::pair<U*,size_t>(v,PH*8*16*128)}){std::vector<U>a(pair.second);uint32_t seed=12345+state*777;for(size_t i=0;i<a.size();i++){seed=seed*1664525+1013904223;float x=(int(seed>>16)-32768)/32768.f;float z=state==0?x:state==1?0.f:state==2?x*8.f:state==3?(int(i%17)-8)*.125f:state==4?(i%2?-1:1)*.0009765625f:x*.25f;a[i]=bf(z);}CU(cudaMemcpyAsync(pair.first,a.data(),a.size()*2,cudaMemcpyHostToDevice,s));}
 for(int rows:{1,2,16,32})for(int t=24;t<=216;t++)for(bool mixed:{false,true}){prepare(rows,t,mixed);baseline(rows);candidate(rows);CU(cudaStreamSynchronize(s));std::vector<U>a(rows*32*128),b(a.size());CU(cudaMemcpy(a.data(),gold,a.size()*2,cudaMemcpyDeviceToHost));CU(cudaMemcpy(b.data(),out,b.size()*2,cudaMemcpyDeviceToHost));size_t bad=0,first=0;for(size_t i=0;i<a.size();i++)if(a[i]!=b[i]){if(!bad)first=i;bad++;}comparisons++;values+=a.size();if(bad){printf("{\"state\":%d,\"rows\":%d,\"t\":%d,\"mixed\":%d,\"changed\":%zu,\"first\":%zu,\"before\":%u,\"after\":%u}\n",state,rows,t,int(mixed),bad,first,a[first],b[first]);return 2;}}
 printf("{\"state\":%d,\"comparisons\":%d,\"values\":%llu,\"changed\":0}\n",state,comparisons,(unsigned long long)values);fflush(stdout);}
 auto time=[&](auto fn){for(int j=0;j<8;j++)fn();CU(cudaStreamSynchronize(s));cudaGraph_t g;cudaGraphExec_t e;CU(cudaStreamBeginCapture(s,cudaStreamCaptureModeThreadLocal));for(int j=0;j<64;j++)fn();CU(cudaStreamEndCapture(s,&g));CU(cudaGraphInstantiate(&e,g,nullptr,nullptr,0));cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaGraphLaunch(e,s));CU(cudaEventRecord(a,s));for(int j=0;j<16;j++)CU(cudaGraphLaunch(e,s));CU(cudaEventRecord(b,s));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));CU(cudaGraphExecDestroy(e));CU(cudaGraphDestroy(g));return ms*1000/(64*16);};
 for(int rep=0;rep<3;rep++)for(int rows:{16,32})for(int t:{125,126,129,130,131,136,144,159,160,192,216}){prepare(rows,t,true);float a,b;if(rep%2){b=time([&]{candidate(rows);});a=time([&]{baseline(rows);});}else{a=time([&]{baseline(rows);});b=time([&]{candidate(rows);});}printf("{\"repeat\":%d,\"rows\":%d,\"t\":%d,\"baseline_us\":%f,\"candidate_us\":%f}\n",rep,rows,t,a,b);fflush(stdout);}return 0;}catch(const std::exception&e){fprintf(stderr,"%s\n",e.what());return 1;}}
