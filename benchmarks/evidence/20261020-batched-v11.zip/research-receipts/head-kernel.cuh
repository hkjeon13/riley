template<int W,int R,int P,int S>__device__ __forceinline__ void head_stage(__nv_bfloat16*dst,const __nv_bfloat16*w,const __nv_bfloat16*x,int rows,int col,int first,int split,int it){
 constexpr int N=W*16,L=64+P;int kbase=it*64;
 for(int i=threadIdx.x;i<(N+R)*8;i+=W*32){int row=i/8,k=(i%8)*8;bool a=row<N;int xr=row-N;bool valid=it<40&&(a||first+xr<rows);const __nv_bfloat16*src=valid?(a?w+(col+row)*2560+kbase+k:x+(first+xr)*2560+kbase+k):w;sm80_down_copy16(dst+row*L+k,src,valid);}
 asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void head_v11(const __nv_bfloat16*w,const __nv_bfloat16*x,__nv_bfloat16*parts,int rows){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800

 using namespace nvcuda;constexpr int N=W*16,L=64+P,Stage=(N+R)*L,RB=R/16;
 __shared__ __align__(32)__nv_bfloat16 shared[Stage*S];int col=blockIdx.x*N,first=blockIdx.y*R,split=blockIdx.z,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;
 wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;
 wmma::fragment<wmma::accumulator,16,16,16,float>c[RB][2];
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::fill_fragment(c[rb][0],0.f);wmma::fill_fragment(c[rb][1],0.f);}
 #pragma unroll
 for(int st=0;st<S;st++)head_stage<W,R,P,S>(shared+st*Stage,w,x,rows,col,first,split,st);
 for(int it=0;it<40;it++){
  asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+(it%S)*Stage;
  #pragma unroll
  for(int j=0;j<4;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
   #pragma unroll
   for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb][j/2],a,b,c[rb][j/2]);}}
  __syncthreads();head_stage<W,R,P,S>(t,w,x,rows,col,first,split,it+S);
 }
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){
  for(int i=0;i<c[rb][0].num_elements;i++)c[rb][0].x[i]=__fadd_rn(c[rb][0].x[i],c[rb][1].x[i]);
  float*out=reinterpret_cast<float*>(shared)+(warp*RB+rb)*256;wmma::store_matrix_sync(out,c[rb][0],16,wmma::mem_col_major);__syncwarp();
  for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows)parts[row*151936+col+warp*16+i%16]=__float2bfloat16_rn(__fmaf_rn(1.f,out[i],0.f));}
 }

#endif
}


