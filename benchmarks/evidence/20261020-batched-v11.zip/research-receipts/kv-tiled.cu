// Research only: classify native same-SM80 M1 vs batched GEMM equality.
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <mma.h>
#include <cublas_v2.h>
#include <cublasLt.h>
#include <algorithm>
#include <openssl/sha.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <stdexcept>
#include <filesystem>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <unistd.h>
using U=uint16_t;
#define CU(x) do{if((x)!=cudaSuccess)throw std::runtime_error("CUDA API failed");}while(0)
#define BL(x) do{if((x)!=CUBLAS_STATUS_SUCCESS)throw std::runtime_error("cuBLAS API failed");}while(0)
std::string sha(const std::vector<U>&x){unsigned char d[32];SHA256((const unsigned char*)x.data(),x.size()*2,d);static const char*h="0123456789abcdef";std::string s;for(auto c:d){s+=h[c>>4];s+=h[c&15];}return s;}
std::vector<U>read(const std::string&p,size_t bytes,const std::string&digest){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f||uint64_t(f.tellg())!=bytes||bytes%2||bytes>(1ull<<30))throw std::runtime_error("input size");std::vector<U>x(bytes/2);f.seekg(0);f.read((char*)x.data(),bytes);if(!f||sha(x)!=digest)throw std::runtime_error("input SHA256");return x;}
float cv(U x){uint32_t b=uint32_t(x)<<16;float f;memcpy(&f,&b,4);return f;}
U bf(float f){uint32_t b;memcpy(&b,&f,4);return U((b+0x7fff+((b>>16)&1))>>16);}
void save(const std::string&p,const std::vector<U>&x){if(std::filesystem::exists(p))throw std::runtime_error("raw exists");std::ofstream f(p,std::ios::binary);f.write((const char*)x.data(),x.size()*2);if(!f)throw std::runtime_error("raw save");}


template<int R>__global__ void kv_rows(const U*__restrict__ w,const U*__restrict__ x,U*y,int rows){
 int lane=threadIdx.x,col=blockIdx.x*4+threadIdx.y,first=blockIdx.y*R;float a[R]={};
 #pragma unroll 16
 for(int j=0;j<80;j++){int d=lane+j*32;float ww=__bfloat162float(__ushort_as_bfloat16(w[col*2560+d]));
 #pragma unroll
 for(int r=0;r<R;r++)if(first+r<rows)a[r]=__fmaf_rn(ww,__bfloat162float(__ushort_as_bfloat16(x[(first+r)*2560+d])),a[r]);}
 #pragma unroll
 for(int d=16;d;d/=2){
 #pragma unroll
 for(int r=0;r<R;r++){float v=__shfl_down_sync(0xffffffff,a[r],d);if(lane<d)a[r]=__fadd_rn(a[r],v);}}
 if(lane==0){
 #pragma unroll
 for(int r=0;r<R;r++)if(first+r<rows)y[(first+r)*1024+col]=__bfloat16_as_ushort(__float2bfloat16_rn(__fmaf_rn(1.f,a[r],0.f)));}
}
__device__ __forceinline__ void kv_copy16(void*dst,const void*src,bool valid){unsigned sm=static_cast<unsigned>(__cvta_generic_to_shared(dst));asm volatile("cp.async.cg.shared.global [%0], [%1], 16, %2;"::"r"(sm),"l"(src),"r"(valid?16:0));}
template<int C,int R>__device__ __forceinline__ void kv_stage(U*dst,const U*w,const U*x,int rows,int first,int col,int it){for(int i=threadIdx.x+32*threadIdx.y;i<(C+R)*32;i+=C*32){int r=i/32,k=i%32*8;bool valid=it<10&&(r<C||first+r-C<rows);const U*src=valid?(r<C?w+(col+r)*2560+it*256+k:x+(first+r-C)*2560+it*256+k):w;kv_copy16(dst+r*256+k,src,valid);}asm volatile("cp.async.commit_group;");}
template<int C,int R>__global__ void kv_tiled(const U*w,const U*x,U*y,int rows){
 constexpr int Stage=(C+R)*256;__shared__ __align__(32)U sh[Stage*2];int lane=threadIdx.x,col=blockIdx.x*C+threadIdx.y,first=blockIdx.y*R;float a[R]={};kv_stage<C,R>(sh,w,x,rows,first,blockIdx.x*C,0);kv_stage<C,R>(sh+Stage,w,x,rows,first,blockIdx.x*C,1);
 for(int it=0;it<10;it++){asm volatile("cp.async.wait_group 1;");__syncthreads();auto*t=sh+it%2*Stage;
 #pragma unroll
 for(int j=0;j<8;j++){int d=lane+j*32;float ww=__bfloat162float(__ushort_as_bfloat16(t[threadIdx.y*256+d]));
 #pragma unroll
 for(int r=0;r<R;r++)if(first+r<rows)a[r]=__fmaf_rn(ww,__bfloat162float(__ushort_as_bfloat16(t[(C+r)*256+d])),a[r]);}
 __syncthreads();kv_stage<C,R>(t,w,x,rows,first,blockIdx.x*C,it+2);}
 asm volatile("cp.async.wait_group 0;");
 #pragma unroll
 for(int d=16;d;d/=2){
 #pragma unroll
 for(int r=0;r<R;r++){float b=__shfl_down_sync(0xffffffff,a[r],d);if(lane<d)a[r]=__fadd_rn(a[r],b);}}
 if(lane==0){
 #pragma unroll
 for(int r=0;r<R;r++)if(first+r<rows)y[(first+r)*1024+col]=__bfloat16_as_ushort(__float2bfloat16_rn(__fmaf_rn(1.f,a[r],0.f)));}
}
template<int C,int R>void trial(cudaStream_t s,U*w,U*x,U*y,const std::vector<std::vector<U>>&xs,const std::vector<std::vector<U>>&gold){
 auto launch=[&](int rows,int tile){if(tile==1)kv_tiled<C,R><<<dim3(1024/C,(rows+R-1)/R),dim3(32,C),0,s>>>(w,x,y,rows);else kv_rows<8><<<dim3(256,(rows+7)/8),dim3(32,4),0,s>>>(w,x,y,rows);CU(cudaGetLastError());};
 for(int st=0;st<6;st++){CU(cudaMemcpyAsync(x,xs[st].data(),xs[st].size()*2,cudaMemcpyHostToDevice,s));for(int rows=1;rows<=32;rows++){launch(rows,1);CU(cudaStreamSynchronize(s));std::vector<U>b(rows*1024);CU(cudaMemcpy(b.data(),y,b.size()*2,cudaMemcpyDeviceToHost));size_t bad=0;for(size_t i=0;i<b.size();i++)bad+=b[i]!=gold[st][i];if(bad)throw std::runtime_error("KV equality failed");}}
 printf("{\"C\":%d,\"R\":%d,\"exact_comparisons\":192,\"changed\":0}\n",C,R);fflush(stdout);
 CU(cudaMemcpyAsync(x,xs[0].data(),xs[0].size()*2,cudaMemcpyHostToDevice,s));
 auto time=[&](int rows,int tile){for(int j=0;j<8;j++)launch(rows,tile);CU(cudaStreamSynchronize(s));cudaGraph_t g;cudaGraphExec_t e;CU(cudaStreamBeginCapture(s,cudaStreamCaptureModeThreadLocal));for(int j=0;j<128;j++)launch(rows,tile);CU(cudaStreamEndCapture(s,&g));CU(cudaGraphInstantiate(&e,g,nullptr,nullptr,0));cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaGraphLaunch(e,s));CU(cudaEventRecord(a,s));for(int j=0;j<16;j++)CU(cudaGraphLaunch(e,s));CU(cudaEventRecord(b,s));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));CU(cudaGraphExecDestroy(e));CU(cudaGraphDestroy(g));return ms*1000/(128*16);};
 for(int rep=0;rep<3;rep++)for(int rows:{8,12,16,24,32}){float a,b;if(rep%2){b=time(rows,1);a=time(rows,8);}else{a=time(rows,8);b=time(rows,1);}printf("{\"C\":%d,\"R\":%d,\"rows\":%d,\"repeat\":%d,\"baseline_us\":%f,\"candidate_us\":%f}\n",C,R,rows,rep,a,b);fflush(stdout);}
}
int main(int argc,char**argv){try{if(argc!=4)return 1;cudaDeviceProp prop;CU(cudaGetDeviceProperties(&prop,0));if(prop.major!=8||prop.minor!=0||prop.multiProcessorCount!=108)throw std::runtime_error("SM80 required");std::ifstream f(argv[1]);std::string line;getline(f,line);std::stringstream ss(line);std::vector<std::string>a;std::string z;while(getline(ss,z,'\t'))a.push_back(z);auto seed=read(a[3],128ul*2560*2,a[4]),hw=read(argv[2],1024ul*2560*2,argv[3]);U*w,*x,*y,*dy;CU(cudaMalloc(&w,hw.size()*2));CU(cudaMalloc(&x,32ul*2560*2));CU(cudaMalloc(&y,32ul*1024*2));CU(cudaMalloc(&dy,32ul*1024*2));CU(cudaMemcpy(w,hw.data(),hw.size()*2,cudaMemcpyHostToDevice));cudaStream_t s;CU(cudaStreamCreateWithFlags(&s,cudaStreamNonBlocking));cublasHandle_t h;BL(cublasCreate(&h));BL(cublasSetStream(h,s));int ver;BL(cublasGetVersion(h,&ver));if(ver!=120405)throw std::runtime_error("cuBLAS version");BL(cublasSetMathMode(h,CUBLAS_DEFAULT_MATH));BL(cublasSetAtomicsMode(h,CUBLAS_ATOMICS_NOT_ALLOWED));std::vector<std::vector<U>>xs(6),gold(6);float alpha=1,beta=0;
 for(int st=0;st<6;st++){auto&v=xs[st];v.resize(32ul*2560);for(size_t i=0;i<v.size();i++)v[i]=st==0?seed[i]:st==1?0:st==2?bf(cv(seed[(i*13+37)%v.size()])*(i%3==0?-.5f:1.5f)):st==3?bf((int(i%17)-8)*.125f):st==4?bf((i%2?-1:1)*.0009765625f):bf(cv(seed[(i*7+19)%v.size()])*4.f);CU(cudaMemcpyAsync(x,v.data(),v.size()*2,cudaMemcpyHostToDevice,s));for(int r=0;r<32;r++)BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,1024,1,2560,&alpha,w,CUDA_R_16BF,2560,x+r*2560,CUDA_R_16BF,2560,&beta,dy+r*1024,CUDA_R_16BF,1024,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));CU(cudaStreamSynchronize(s));gold[st].resize(32ul*1024);CU(cudaMemcpy(gold[st].data(),dy,gold[st].size()*2,cudaMemcpyDeviceToHost));}
 trial<8,4>(s,w,x,y,xs,gold);trial<8,8>(s,w,x,y,xs,gold);trial<16,4>(s,w,x,y,xs,gold);trial<4,8>(s,w,x,y,xs,gold);CU(cudaStreamSynchronize(s));return 0;}catch(const std::exception&e){fprintf(stderr,"%s\n",e.what());return 1;}}
