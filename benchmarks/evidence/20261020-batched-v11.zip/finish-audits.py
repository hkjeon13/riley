from pathlib import Path
import json,time,subprocess,hashlib,re,statistics
p=Path(__file__).resolve().parent
while not(p/'all-analysis-complete.json').exists():
 s=json.loads((p/'pipeline.state.json').read_text());assert s['status']!='failed',s;time.sleep(3)
rows=[];ready={}
for c in [16,32]:
 ready[str(c)]={}
 for mode in ['owned-before','owned-after','vllm']:
  files=sorted((p/f'runs/final-c{c}').glob(f'*-{mode}/startup-readiness.json'));assert len(files)==5;ready[str(c)][mode]=statistics.median(json.loads(f.read_text())['elapsed_ms']/1000 for f in files)
 for rep in range(5):
  f=p/f'runs/final-c{c}/c{c}-r{rep}-owned-after';s=(f/'server.log').read_text();before,after=s.split('riley listening on',1);keys=sorted(set(map(int,re.findall(r'RILEY_OWNED_BODY_KEY active_rows=(\d+)',before))));assert keys==list(range(2,c+1));assert before.count('RILEY_OWNED_SEGMENT capture=true')==c-1 and after.count('RILEY_OWNED_SEGMENT capture=true')==0;assert f'RILEY_OWNED_BODY_WARMUP rows=1..{c} greedy=true complete=true'in before;rows.append(dict(concurrency=c,repeat=rep,pre_listen_keys=keys,pre_listen_captures=c-1,post_listen_captures=0,readiness=json.loads((f/'startup-readiness.json').read_text())))
(p/'startup-graph-capture-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),arms=rows,readiness_medians_seconds=ready,scope='All10 normal candidate servers; no post-listen capture'),indent=2))
manifest=json.loads((p/'source-manifest.json').read_text());assert all(hashlib.sha256((p/'source'/n).read_bytes()).hexdigest()==h for n,h in manifest.items());binding=json.loads((p/'source-binary-binding.json').read_text());assert hashlib.sha256((p/'riley-batched-v11e').read_bytes()).hexdigest()==binding['binary_sha256'];(p/'end-source-binary-proof.json').write_text(json.dumps(dict(time_ns=time.time_ns(),source_files=len(manifest),all_hashes_equal=True,binary_sha256=binding['binary_sha256']),indent=2))
subprocess.run(['/home/nlp/riley-261013/vllm0271-venv/bin/python',str(p/'stock-runtime-proof.py')],check=True)
a=json.loads((p/'stock-installed-source-proof.json').read_text());v=p.parent/'riley-comprehensive-v10-20261020/stock-installed-source-proof.json';b=json.loads(v.read_text());assert a['vllm']==b['vllm']and a['torch']==b['torch']and{x['path']:x['sha256']for x in a['sources']}=={x['path']:x['sha256']for x in b['sources']};(p/'stock-source-unchanged-proof.json').write_text(json.dumps(dict(time_ns=time.time_ns(),identical=True,baseline=str(v),files=len(a['sources'])),indent=2))
r=subprocess.run(['nvidia-smi','--id=6,7','--query-gpu=index,name,uuid,driver_version','--format=csv,noheader'],capture_output=True,text=True,check=True);(p/'qualification-tools-live.json').write_text(json.dumps(dict(time_ns=time.time_ns(),build_time_rustc=(p/'qualification-rustc.txt').read_text(),build_time_nvcc=(p/'qualification-nvcc.txt').read_text(),live_gpu_query=r.stdout),indent=2))
subprocess.run(['/usr/bin/taskset','-c','48-51','python3',str(p/'index-research-heavy.py')],check=True)
subprocess.run(['python3',str(p/'verify-final-holds.py')],check=True)
(p/'finalize-ready.json').write_text(json.dumps(dict(time_ns=time.time_ns(),status='complete'),indent=2));print('final audits complete; original holders idle20GiB')
