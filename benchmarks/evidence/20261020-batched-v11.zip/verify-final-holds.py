from pathlib import Path
import json,subprocess,time,hashlib,os
p=Path(__file__).resolve().parent;r=p.parent/'riley-w0-a100-gpu67-20261019';samples=[]
for turn in range(3):
 rows=[]
 for index,pid,ticks in [(6,2027914,'6083215119'),(7,2027915,'6083215121')]:
  s=json.loads(subprocess.check_output(['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index',str(index),'status']))
  assert s['pid']==pid and s['start_ticks']==ticks and s['phase']=='idle' and s['allocation_bytes']==21474836480 and not s['other_processes'],s
  output=subprocess.check_output(['nvidia-smi','-i',str(index),'--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader,nounits'],text=True)
  assert [int(x.split(',')[0])for x in output.splitlines()]==[pid],output
  assert Path(f'/proc/{pid}/stat').read_text().split()[21]==ticks
  rows.append(dict(status=s,processes=output))
 samples.append(dict(time_ns=time.time_ns(),gpus=rows));time.sleep(1)
x=dict(scope='Three fresh idle20GiB samples; original holder PID/start ticks/UUID, no other GPU processes. No holder stop/restart/release.',samples=samples)
(p/'terminal-hold-proof.json').write_text(json.dumps(x,indent=2));print([(r['status']['physical_index'],r['status']['pid'],r['status']['allocation_bytes'])for r in rows])
