from pathlib import Path
import json,sqlite3,re,time
p=Path(__file__).resolve().parent;proof=[]
for c in [16,32]:
 f=p/f'runs/profile-c{c}/c{c}-r0-owned-after/trace.sqlite';d=sqlite3.connect(f);strings=dict(d.execute('select id,value from StringIds'));kernels=[dict(name=strings[row[0]],count=row[1],ms=row[2])for row in d.execute('select demangledName,count(*),sum(end-start)/1e6 from CUPTI_ACTIVITY_KIND_KERNEL group by demangledName')]
 names=['sm80_batched_qk_dispatch','sm80_batched_pv_dispatch','sm80_batched_softmax','sm80_fused_gateup','owned_sm80_tiled_kv','sm80_batched_lm_head','sm80_v9_down']
 selected={n:dict(count=sum(v['count']for v in kernels if n in v['name']),ms=sum(v['ms']for v in kernels if n in v['name']))for n in names}
 for n in names[:5]:assert selected[n]['count']>0,(c,n,selected)
 assert selected['sm80_v9_down']['count']==0,(c,selected)
 if c==32:assert selected['sm80_batched_lm_head']['count']>0,(c,selected)
 analysis=json.loads(Path(str(f)+'.analysis.json').read_text());full={}
 for label,k,oldcap in [('O',4096,8),('Down',9728,4)]:
  matches={name:v for name,v in analysis['matmul_geometries'].items()if re.search(r'W0/LtMatmul/N2560/M(\d+)/K'+str(k)+r'/B1$',name)and oldcap<int(re.search(r'/M(\d+)/',name).group(1))<=32}
  if c==32:assert matches,(c,label,'no actual full-row Lt calls')
  full[label]=matches
 graph=[dict(name=strings[r[0]],count=r[1],CPU_ms=r[2])for r in d.execute('select nameId,count(*),sum(end-start)/1e6 from CUPTI_ACTIVITY_KIND_RUNTIME group by nameId')if'GraphLaunch'in strings[r[0]]];assert sum(v['count']for v in graph)>0
 proof.append(dict(concurrency=c,trace=str(f),actual_kernel_selection=selected,actual_large_row_Lt_calls=full,graph_launches=graph,kernel_count=analysis['kernel_count'],kernel_sum_ms=analysis['kernel_sum_ms']))
(p/'selected-paths-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),passed=True,scope='Actual integrated GPU kernels and NVTX matmul geometries, not source/compile-only evidence',runs=proof),indent=2));print([(v['concurrency'],v['actual_kernel_selection'])for v in proof])
