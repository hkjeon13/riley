from pathlib import Path
import json,hashlib,time,argparse
p=argparse.ArgumentParser();p.add_argument('--names',nargs='+',required=True);p.add_argument('--report',required=True);a=p.parse_args();n=Path(__file__).resolve().parent;old=n.parent/'riley-qkv-gateup-v214-20261019';before=old/'v226-qwen3-4b-before-C1-eager';froot=old/'qwen3-4b-fresh-A100-HF-v222';fixture=json.loads((froot/'fixture.json').read_text());proof=[]
for name in [v for x in a.names for v in x.split(",")]:
 folder=n/name;receipt=json.loads((n/('observed-'+name+'.json')).read_text());reconciled=n/('observed-'+name+'.reconciled.json');receipt=json.loads(reconciled.read_text()) if reconciled.exists() else receipt;assert receipt['status']=='complete'and receipt['returncode']==0;meta=json.loads((folder/'result.json').read_text());rows=[r for m in meta['models']for c in m['cases']for r in c['rows']];assert len(rows)==104;assert all(r['max_abs']==0 and r['mean_abs']==0 for r in rows)
 files={};expected_files={p.name for p in before.glob('*.bf16')};assert {p.name for p in folder.glob('*.bf16')}==expected_files
 for p in sorted(folder.glob('*.bf16')):
  data=p.read_bytes();assert data==(before/p.name).read_bytes(),(name,p.name);files[p.name]=hashlib.sha256(data).hexdigest()
 for case in fixture['models'][0]['cases']:
  for st in case['steps']:
   p=froot/st['file'];data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==fixture['files'][st['file']]['sha256'];actual=folder/f"qwen3-4b-{case['id']}-s{st['step']}.native.bf16";assert actual.read_bytes()==data,(name,actual)
 logs=(n/('observed-'+name+'.stderr')).read_text();stdout=(n/('observed-'+name+'.stdout')).read_text();captures=logs.count('RILEY_OWNED_SEGMENT capture=true');replays=logs.count('RILEY_OWNED_SEGMENT replay=true')
 if meta['all_counts']:assert captures==replays==2304 and'RILEY_TEACHER_ALL_COUNTS verified=1..32 changed_contexts=true'in stdout
 proof.append(dict(name=name,HF_full_vocabulary_rows=104,files_compared=len(files),all_bytes_equal_to_before_and_HF=True,raw_file_sha256=files,graph_captures=captures,graph_first_replays=replays,all_actual_rows_1_to_32=meta['all_counts'],all_allocations_closed=True))
(n/a.report).write_text(json.dumps(dict(time_ns=time.time_ns(),baseline=str(before),runs=proof,scope='Whole-model exact BF16 files,104HFrows, changed order/context and actual graph rows; no tolerance.'),indent=2));print([(v['name'],v['files_compared'],v['graph_captures'])for v in proof])
