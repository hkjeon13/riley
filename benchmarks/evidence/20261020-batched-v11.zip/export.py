from pathlib import Path
import os,json,hashlib,zipfile,time
p=Path(__file__).parent
assert json.loads((p/'all-analysis-complete.json').read_text())['status']=='complete'
assert (p/'terminal-hold-proof.json').exists() and (p/'final-report.md').exists()
q=p/'compact-evidence';q.mkdir()
allowed={'.json','.jsonl','.txt','.log','.py','.sh','.cu','.cuh','.rs','.tsv','.md','.patch','.exit','.stdout','.stderr','.sha256'}
blocked={'source','target','cache','tmp','vllm-cache','ipc6','ipc7','merge-only','target-copy-collision-unqualified','compact-evidence','__pycache__'}
files=[];heavy=[]
for root,dirs,names in os.walk(p):
 dirs[:]=[d for d in dirs if d not in blocked]
 for name in names:
  f=Path(root)/name;rel=f.relative_to(p)
  if f.is_symlink():continue
  if f.suffix in ['.bf16','.sqlite','.nsys-rep'] or (f.suffix in ['', '.so'] and f.open('rb').read(4)==bytes.fromhex('7f454c46')):
   heavy.append(dict(path=str(f),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()));continue
  if f.suffix in allowed:
   data=f.read_bytes();dest=q/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);files.append(dict(path=str(rel),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
(q/'raw-heavy-index.json').write_text(json.dumps(heavy,indent=2));f=q/'raw-heavy-index.json';files.append(dict(path=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),bytes=f.stat().st_size))
(q/'CHECKSUMS.json').write_text(json.dumps(files,indent=2))
z=p/'compact-evidence.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=6)as archive:
 for f in sorted(q.rglob('*')):
  if f.is_file():archive.write(f,str(f.relative_to(q)))
with zipfile.ZipFile(z)as archive:
 names=archive.namelist();assert len(names)==len(set(names));assert all(not Path(n).is_absolute()and'..'not in Path(n).parts for n in names)
 for row in files:assert hashlib.sha256(archive.read(row['path'])).hexdigest()==row['sha256']
receipt=dict(time_ns=time.time_ns(),zip=str(z),bytes=z.stat().st_size,sha256=hashlib.sha256(z.read_bytes()).hexdigest(),hashed_files=len(files),zip_entries=len(names),heavy_files=len(heavy));(p/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
