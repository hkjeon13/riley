# Qwen batched projection/attention and decode body Graph v11 evidence

Qualified candidate: E, Qwen3-4B BF16 on A100 SM80, GPU6/7 only.
EFS root: `/mnt/efs/nlp/psyche/riley-batched-v11e-20261020`.

- `final-report.md`: implementation, five fresh C16/C32 comparisons and limits.
- `source-binary-binding.json`, `source-manifest.json`, `candidate/`: exact 935-file source and seven-file layer over immutable v10.
- `final-statistics.json`, `primary-matrix-audit.json`, `runs/final-c16/`, `runs/final-c32/`: all 30 normal arms; no discarded initial cohort/repeats.
- `independent-audit.json`, `measurement-isolation-audit.json`: raw SSE/quantile/throughput/binary/resource audit; profiling excluded from normal metrics.
- `final-teacher-audit.json`: 2464 original native/HF BF16 files byte-equal; complete scope and per-file hashes.
- `cpu-regression-audit.json`, `c02-removal-proof.json`: 523 CPU passes; only four approved private `/tmp` fixture exceptions, all removed.
- `selected-paths-audit.json`, `profile-summary.json`, `stock-profile-selection-audit.json`: actual GPU paths and separate diagnostics; anonymous captured native/stock GEMM remains unattributed where labels are absent.
- `startup-graph-capture-audit.json`: all serving keys captured before listen, zero post-listen capture in all ten candidate servers; startup readiness measured separately.
- `terminal-hold-proof.json`: three fresh idle20GiB samples; original holder contexts alive, no other GPU processes.
- `raw-heavy-index.json`: BF16, binaries and Nsight traces retained on EFS with SHA256; `research-heavy-index.json` indexes accepted/rejected component research at its original EFS root.
- `intermediate-d-not-selected/`: preserved intermediate D diagnostics, never combined with final E data. Initial unqualified copy/build failures remain separate from the fresh-target qualified build.

`CHECKSUMS.json` hashes every compact included file except itself. The sibling
ZIP receipt records the ZIP hash separately. Raw heavy files, model weights,
source/target trees and caches remain on EFS; unqualified copied build targets
are excluded. No commit/push was performed. GPU holders remain running.
