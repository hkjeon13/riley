from pathlib import Path
import json,subprocess,time,os,hashlib,traceback,concurrent.futures,re
p=Path(__file__).resolve().parent;state=dict(status='running',phase='waiting-fresh-build',pid=os.getpid(),completed=[])
def save():
 q=p/'pipeline.state.next';q.write_text(json.dumps(state,indent=2));q.replace(p/'pipeline.state.json')
def phase(v):state['phase']=v;save()
def run(argv,log):
 with(p/log).open('x')as f:subprocess.run(argv,stdout=f,stderr=f,check=True)
def wait_json(file):
 while True:
  try:v=json.loads(file.read_text())
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(2);continue
  if v.get('status')in['failed','complete']:
   assert v['status']=='complete'and v.get('returncode',0)==0,v
   return v
  time.sleep(2)
def job(n):run(['python3',str(p/'run-job.py'),n],n+'.outer.log')
save()
try:
 while not(p/'native-kv-build-and-cpu.exit').exists():time.sleep(3)
 assert(p/'native-kv-build-and-cpu.exit').read_text().strip()=='101'
 log=(p/'native-kv-regression.log').read_text();assert sum(map(int,re.findall(r'test result:.*? (\d+) passed;',log)))==519
 assert sum(map(int,re.findall(r'test result:.*? (\d+) failed;',log)))==4
 phase('cpu-private-fixture-recheck')
 run(['python3',str(p/'recheck-c02.py'),'--allow-test-tmp'],'c02-rerun.log')
 tmp=json.loads((p/'c02-fixture-recheck-v2/complete.json').read_text())['temporary_root'];assert not Path(tmp).exists();(p/'c02-removal-proof.json').write_text(json.dumps(dict(removed=True,path=tmp)))
 v=p.parent/'riley-comprehensive-v10-20261020';baseline=json.loads((v/'source-manifest.json').read_text());manifest={f:hashlib.sha256((p/'source'/f).read_bytes()).hexdigest()for f in baseline};(p/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
 binding=dict(binary_sha256=hashlib.sha256((p/'riley-batched-v11e').read_bytes()).hexdigest(),source_manifest_sha256=hashlib.sha256((p/'source-manifest.json').read_bytes()).hexdigest(),files=len(manifest),changed=[n for n in manifest if manifest[n]!=baseline[n]])
 assert len(binding['changed'])==7;(p/'source-binary-binding.json').write_text(json.dumps(binding,indent=2));state['completed'].append('cpu523-and-source-binding');save()
 assert(p.parent/'riley-batched-v11d-20261020/all-analysis-complete.json').exists()
 phase('regular-teachers');run(['python3',str(p/'build-teacher-final.py')],'teacher-build.log');wait_json(p/'final-teacher-state.json')
 phase('all-row-body-teacher');run(['python3',str(p/'prepare-body-teacher.py')],'prepare-body-teacher.log');wait_json(p/'observed-teacher-body-allR.json')
 phase('literal-native-HF-audit');run(['python3',str(p/'audit-teachers-e.py')],'teacher-literal-audit.log');state['completed'].append('all2464-BF16-files-literal-native-HF');save()
 phase('profile-selection-before-normal')
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(job,['profile-c16','profile-c32']))
 job('profile-stock')
 traces=sorted((p/'runs').glob('profile-*/c*/trace.sqlite'));assert len(traces)==5
 run(['python3',str(p/'analyze-profiles.py'),*map(str,traces)],'profile-analysis.log')
 run(['python3',str(p/'audit-selected-paths.py')],'selected-paths-audit.log')
 run(['python3',str(p/'audit-final.py'),'--partial'],'profile-independent-audit.log');state['completed'].append('actual-all-selected-GPU-paths');save()
 phase('fresh-normal-five-repeats')
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(job,['final-c16','final-c32']))
 phase('complete-independent-SSE-and-resource-audit');run(['python3',str(p/'audit-complete.py')],'complete-independent-audit.log');x=json.loads((p/'independent-audit.json').read_text());matrix=[]
 for c in [16,32]:
  rows=[dict(z['record'],campaign=z['run'])for z in x['arms']if z['run']==f'final-c{c}'];assert len(rows)==15 and {(z['repeat'],z['mode'])for z in rows}=={(r,m)for r in range(5)for m in ['owned-before','owned-after','vllm']};matrix.append(dict(concurrency=c,records=rows))
 (p/'primary-matrix-audit.json').write_text(json.dumps(matrix,indent=2));(p/'normal-primary-coverage.json').write_text(json.dumps(dict(complete=True,normal_arms=30,profile_arms=5),indent=2));run(['python3',str(p/'analyze-final.py')],'final-statistics.log')
 state.update(status='complete',phase='complete',finished_ns=time.time_ns());save();(p/'all-analysis-complete.json').write_text(json.dumps(state,indent=2))
except BaseException as e:state.update(status='failed',error=repr(e),traceback=traceback.format_exc(),finished_ns=time.time_ns());save();raise
