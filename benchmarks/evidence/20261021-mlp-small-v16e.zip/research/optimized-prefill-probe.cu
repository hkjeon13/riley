#include "probe-kernels.cuh"
#include "mixed-small.cuh"
#include <cublas_v2.h>
#include <cublasLt.h>
#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"cuda line%d %s\n",__LINE__,cudaGetErrorString(e));return 2;}}while(0)
#define BL(x) do{if((x)!=CUBLAS_STATUS_SUCCESS)return 3;}while(0)
__global__ void fill(U*p,size_t n,int st){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n){uint32_t z=uint32_t(i)*1664525u+1013904223u+st*1237;float v=float(int(z%4093)-2046)/32768.f;if(st%6==1)v*=8;if(st%6==2)v*=.0078125f;if(st%6==3)v=i%7?0:v;if(st%6==4)v=i%2?-v:v;if(st%6==5)v*=32;p[i]=__float2bfloat16_rn(v);}}
__global__ void epilogue(const U*g,const U*u,U*y,int n){int i=blockIdx.x*256+threadIdx.x;if(i<n){float a=__bfloat162float(g[i]),b=__bfloat162float(u[i]);float z=__bfloat162float(__float2bfloat16_rn(a/(1.f+expf(-a))));y[i]=__float2bfloat16_rn(__fmul_rn(z,b));}}
__global__ void decode_merged_ref(const U*raw,U*y,int count){int i=blockIdx.x*256+threadIdx.x;if(i<count){int row=i/9728,col=i%9728;float g=__bfloat162float(raw[row*19456+col]),u=__bfloat162float(raw[row*19456+9728+col]);float z=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[i]=__float2bfloat16_rn(__fmul_rn(z,u));}}
__global__ void cmp(const U*a,const U*b,size_t n,unsigned*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n&&__bfloat16_as_ushort(a[i])!=__bfloat16_as_ushort(b[i]))atomicAdd(p,1u);}
int main(){cudaStream_t stream;CU(cudaStreamCreate(&stream));cublasHandle_t h;BL(cublasCreate(&h));BL(cublasSetStream(h,stream));BL(cublasSetMathMode(h,CUBLAS_DEFAULT_MATH));BL(cublasSetAtomicsMode(h,CUBLAS_ATOMICS_NOT_ALLOWED));auto alloc=[](size_t n){void*p;cudaMalloc(&p,n);return p;};U*w=(U*)alloc(19456ul*2560*2),*x=(U*)alloc(176ul*2560*2),*g=(U*)alloc(352ul*9728*2),*u=(U*)alloc(176ul*9728*2),*gold=(U*)alloc(176ul*9728*2),*y=(U*)alloc(176ul*9728*2);unsigned*bad=(unsigned*)alloc(4);float alpha=1,beta=0;
 cublasLtHandle_t lt;BL(cublasLtCreate(&lt));cublasLtMatmulDesc_t desc;BL(cublasLtMatmulDescCreate(&desc,CUBLAS_COMPUTE_32F,CUDA_R_32F));cublasOperation_t trans=CUBLAS_OP_T;BL(cublasLtMatmulDescSetAttribute(desc,CUBLASLT_MATMUL_DESC_TRANSA,&trans,sizeof(trans)));cublasLtMatrixLayout_t Al;BL(cublasLtMatrixLayoutCreate(&Al,CUDA_R_16BF,2560,19456,2560));void*ws=alloc(16ul<<20);cublasLtMatmulAlgo_t algo;BL(cublasLtMatmulAlgoInit(lt,CUBLAS_COMPUTE_32F,CUDA_R_32F,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,31,&algo));uint32_t vals[]={15,17,0,0,0,0};int index=0;for(auto attr:{CUBLASLT_ALGO_CONFIG_TILE_ID,CUBLASLT_ALGO_CONFIG_STAGES_ID,CUBLASLT_ALGO_CONFIG_SPLITK_NUM,CUBLASLT_ALGO_CONFIG_REDUCTION_SCHEME,CUBLASLT_ALGO_CONFIG_CTA_SWIZZLING,CUBLASLT_ALGO_CONFIG_CUSTOM_OPTION})BL(cublasLtMatmulAlgoConfigSetAttribute(&algo,attr,&vals[index++],4));

 cublasLtMatmulAlgo_t prefill_algo;BL(cublasLtMatmulAlgoInit(lt,CUBLAS_COMPUTE_32F,CUDA_R_32F,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,21,&prefill_algo));uint32_t pvals[]={20,11,0,0,0,0};int pi=0;for(auto attr:{CUBLASLT_ALGO_CONFIG_TILE_ID,CUBLASLT_ALGO_CONFIG_STAGES_ID,CUBLASLT_ALGO_CONFIG_SPLITK_NUM,CUBLASLT_ALGO_CONFIG_REDUCTION_SCHEME,CUBLASLT_ALGO_CONFIG_CTA_SWIZZLING,CUBLASLT_ALGO_CONFIG_CUSTOM_OPTION})BL(cublasLtMatmulAlgoConfigSetAttribute(&prefill_algo,attr,&pvals[pi++],4));
 CU(cudaFuncSetAttribute(v16_mixed_small<4,160,2,32>,cudaFuncAttributeMaxDynamicSharedMemorySize,35840));
 CU(cudaFuncSetAttribute(v16_mixed_small<4,176,2,32>,cudaFuncAttributeMaxDynamicSharedMemorySize,38400));
 int checks=0;
 for(int prefill:{64,115,128,129,130})for(int decode:{2,4,8,12,16,24,30,32}){int rows=prefill+decode;if(rows>176)continue;
  bool use_lt=decode==1||decode>16;cublasLtMatrixLayout_t DB=nullptr,DC=nullptr;if(use_lt){BL(cublasLtMatrixLayoutCreate(&DB,CUDA_R_16BF,2560,decode,2560));BL(cublasLtMatrixLayoutCreate(&DC,CUDA_R_16BF,19456,decode,19456));cublasLtMatmulHeuristicResult_t check{};BL(cublasLtMatmulAlgoCheck(lt,desc,Al,DB,DC,DC,&algo,&check));BL(check.state);if(check.workspaceSize>(16ul<<20))return 8;}

  cublasLtMatrixLayout_t PB=nullptr,PC=nullptr;if(prefill>=65){BL(cublasLtMatrixLayoutCreate(&PB,CUDA_R_16BF,2560,prefill,2560));BL(cublasLtMatrixLayoutCreate(&PC,CUDA_R_16BF,19456,prefill,19456));cublasLtMatmulHeuristicResult_t check{};BL(cublasLtMatmulAlgoCheck(lt,desc,Al,PB,PC,PC,&prefill_algo,&check));BL(check.state);if(check.workspaceSize>(16ul<<20))return 9;}
  for(int state=0;state<6;state++){
   fill<<<(19456ul*2560+255)/256,256,0,stream>>>(w,19456ul*2560,state);fill<<<(176ul*2560+255)/256,256,0,stream>>>(x,176ul*2560,state+2);
   auto original=[&](){
    if(use_lt){BL(cublasLtMatmul(lt,desc,&alpha,w,Al,x,DB,&beta,g,DC,g,DC,&algo,ws,16ul<<20,stream));decode_merged_ref<<<(decode*9728+255)/256,256,0,stream>>>(g,gold,decode*9728);}else if(decode){sm80_fused_gateup<4,16,16,2><<<304,128,0,stream>>>(w,w+9728ul*2560,x,gold,decode);}
    BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,9728,prefill,2560,&alpha,w,CUDA_R_16BF,2560,x+decode*2560,CUDA_R_16BF,2560,&beta,g+decode*9728,CUDA_R_16BF,9728,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));
    BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,9728,prefill,2560,&alpha,w+9728ul*2560,CUDA_R_16BF,2560,x+decode*2560,CUDA_R_16BF,2560,&beta,u+decode*9728,CUDA_R_16BF,9728,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));
    epilogue<<<(prefill*9728+255)/256,256,0,stream>>>(g+decode*9728,u+decode*9728,gold+decode*9728,prefill*9728);return 0;
   };
   auto optimized=[&](){if(prefill<65)return original();if(use_lt){BL(cublasLtMatmul(lt,desc,&alpha,w,Al,x,DB,&beta,g,DC,g,DC,&algo,ws,16ul<<20,stream));decode_merged_ref<<<(decode*9728+255)/256,256,0,stream>>>(g,gold,decode*9728);}else if(decode){sm80_fused_gateup<4,16,16,2><<<304,128,0,stream>>>(w,w+9728ul*2560,x,gold,decode);}BL(cublasLtMatmul(lt,desc,&alpha,w,Al,x+decode*2560,PB,&beta,g,PC,g,PC,&prefill_algo,ws,16ul<<20,stream));decode_merged_ref<<<(prefill*9728+255)/256,256,0,stream>>>(g,gold+decode*9728,prefill*9728);return 0;};
   auto candidate=[&](){if((decode+15)/16*16+prefill<=160)v16_mixed_small<4,160,2,32><<<304,128,35840,stream>>>(w,w+9728ul*2560,x,y,rows,decode);else v16_mixed_small<4,176,2,32><<<304,128,38400,stream>>>(w,w+9728ul*2560,x,y,rows,decode);};
   if(original())return 3;candidate();CU(cudaMemsetAsync(bad,0,4,stream));cmp<<<(rows*9728+255)/256,256,0,stream>>>(gold,y,rows*9728,bad);if(optimized())return 3;cmp<<<(rows*9728+255)/256,256,0,stream>>>(gold,y,rows*9728,bad);unsigned count;CU(cudaMemcpyAsync(&count,bad,4,cudaMemcpyDeviceToHost,stream));CU(cudaStreamSynchronize(stream));printf("{\"prefill\":%d,\"decode\":%d,\"state\":%d,\"mismatch\":%u",prefill,decode,state,count);if(count){puts("}");return 4;}checks++;
   if(state==0){float times[3];for(int z=0;z<3;z++){for(int i=0;i<4;i++)if(z==2)candidate();else if(z==1)optimized();else original();cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaEventRecord(a,stream));for(int i=0;i<64;i++)if(z==2)candidate();else if(z==1)optimized();else original();CU(cudaEventRecord(b,stream));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));times[z]=ms*1000/64;CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));}printf(",\"original_us\":%.3f,\"current_candidate_us\":%.3f,\"fused_us\":%.3f",times[0],times[1],times[2]);}puts("}");fflush(stdout);
  }
  if(prefill>=65){BL(cublasLtMatrixLayoutDestroy(PB));BL(cublasLtMatrixLayoutDestroy(PC));}
  if(use_lt){BL(cublasLtMatrixLayoutDestroy(DB));BL(cublasLtMatrixLayoutDestroy(DC));}
 }
 BL(cublasLtMatrixLayoutDestroy(Al));BL(cublasLtMatmulDescDestroy(desc));BL(cublasLtDestroy(lt));printf("COMPLETE checks=%d\n",checks);return 0;
}
