template<int W,int R,int S,int K>__device__ __forceinline__ void mixed_wide_stage(U*dst,const U*wg,const U*wu,const U*x,int rows,int decode,int col,int it){
 constexpr int N=W*16,L=K+8;int padded=(decode+15)/16*16;
 for(int i=threadIdx.x;i<(N+R)*(K/8);i+=W*32){int r=i/(K/8),k=i%(K/8)*8,source=r-N;if(r>=N)source=source<padded?(source<decode?source:-1):source-padded+decode;bool valid=it<2560/K&&(r<N||(source>=0&&source<rows));const U*src=wg;if(valid)src=r<N?((r<N/2?wg:wu)+(col+r%(N/2))*2560+it*K+k):x+source*2560+it*K+k;sm80_down_copy16(dst+r*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int S,int K>__global__ void v16_mixed_small(const U*wg,const U*wu,const U*x,U*y,int rows,int decode){
 using namespace nvcuda;constexpr int N=W*16,L=K+8,Stage=(N+R)*L,RB=R/16;extern __shared__ __align__(32)U sh[];
 int warp=threadIdx.x/32,lane=threadIdx.x%32,col=blockIdx.x*(N/2),padded=(decode+15)/16*16;
 wmma::fragment<wmma::matrix_a,16,16,16,U,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,U,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB],extra[2];
 #pragma unroll
 for(int rb=0;rb<RB;rb++)wmma::fill_fragment(c[rb],0.f);
 wmma::fill_fragment(extra[0],0.f);wmma::fill_fragment(extra[1],0.f);
 #pragma unroll
 for(int i=0;i<S;i++)mixed_wide_stage<W,R,S,K>(sh+i*Stage,wg,wu,x,rows,decode,col,i);
 for(int it=0;it<2560/K;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=sh+(it%S)*Stage;
  #pragma unroll
  for(int j=0;j<K/16;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
   #pragma unroll
   for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);
    if(rb<2&&rb*16<padded&&((it*(K/16)+j)/2)%2==1){if(rb==0)wmma::mma_sync(extra[0],a,b,extra[0]);else if(rb==1)wmma::mma_sync(extra[1],a,b,extra[1]);}else wmma::mma_sync(c[rb],a,b,c[rb]);
   }}
  __syncthreads();mixed_wide_stage<W,R,S,K>(t,wg,wu,x,rows,decode,col,it+S);
 }asm volatile("cp.async.wait_group 0;");__syncthreads();
 float*temp=reinterpret_cast<float*>(sh)+warp*256;U*saved=sh+W*512;
 #pragma unroll
 for(int rb=0;rb<RB;rb++){
  if(rb<2&&rb*16<padded){for(int i=0;i<c[rb].num_elements;i++)if(rb==0)c[rb].x[i]=__fadd_rn(c[rb].x[i],extra[0].x[i]);else if(rb==1)c[rb].x[i]=__fadd_rn(c[rb].x[i],extra[1].x[i]);}
  wmma::store_matrix_sync(temp,c[rb],16,wmma::mem_col_major);__syncwarp();for(int i=lane;i<256;i+=32)saved[(warp*RB+rb)*256+i]=__float2bfloat16_rn(__fmaf_rn(1.f,temp[i],0.f));__syncwarp();
 }
 __syncthreads();if(warp<W/2){
  #pragma unroll
  for(int rb=0;rb<RB;rb++)for(int i=lane;i<256;i+=32){int r=rb*16+i/16,source=r<padded?(r<decode?r:-1):r-padded+decode;if(source>=0&&source<rows){float g=__bfloat162float(saved[(warp*RB+rb)*256+i]),u=__bfloat162float(saved[((warp+W/2)*RB+rb)*256+i]);float activated=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[source*9728+col+warp*16+i%16]=__float2bfloat16_rn(__fmul_rn(activated,u));}}
 }
}
