from pathlib import Path
import argparse,json,hashlib,time,zipfile,collections
p=argparse.ArgumentParser();p.add_argument('kind',choices=['d','e']);a=p.parse_args();d=a.kind=='d';w=Path('/mnt/efs/nlp/psyche')/('riley-mlp-batch-v16d-20261021'if d else'riley-mlp-small-v16e-20261021');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();state=json.loads((w/('component-r6-state.json'if d else'mixed-small-state.json')).read_text());assert state['phase']in ['complete','failed'];n=w/('observed-batch-merged-r3'if d else'research/observed-mixed-small');receipt=json.loads(n.with_suffix('.json').read_text());samples=[json.loads(l)for l in n.with_suffix('.samples.jsonl').read_text().splitlines()];assert samples and max(s['device_memory_mib']for s in samples)<=22528
rows=[json.loads(l)for l in n.with_suffix('.stdout').read_text().splitlines()if l.startswith('{')];expected=2676 if d else 240;passed=state['phase']=='complete'and len(rows)==expected and all(x.get('mismatch')==0 for x in rows)
if state['phase']=='complete':assert passed
scope='Actual layer0 Gate/Up weights,6finite input transforms; both two pinned Lt21 and original native balanced65..130 groups checked against merged Lt21. Timings compare two Lt calls vs one only; M131..160 research correctness, current coalesced server baseline supportedM>=161.'if d else'Generated finite weights/activations, qualified decode Lt31/native-fused families + classic prefill reference vs small double-buffered fused mixed Gate/Up. Not whole-model, allR, or HTTP throughput qualification.'
timings=[x for x in rows if 'original_us'in x];audit=dict(time_ns=time.time_ns(),state=state,observed_returncode=receipt['returncode'],scope=scope,expected=expected,observed_rows=len(rows),all_expected_cases_passed=passed,nonzero_rows=[x for x in rows if x.get('mismatch',0)>0],timing_scope='One CUDA-event screen per listed shape; not repeated medians or server throughput',timings=[dict(**x,percent_change=(x['candidate_us']/x['original_us']-1)*100)for x in timings],receipt_sha256=sha(n.with_suffix('.json')),whole_device_peak_MiB=max(s['device_memory_mib']for s in samples),runtime_adopted=False)
if not d:audit['selected_tile_case_counts']=dict(collections.Counter(str(160 if ((x['decode']+15)//16*16+x['prefill'])<=160 else 176)for x in rows))
if not d:
 extra=json.loads((w/'optimized-prefill-state.json').read_text());assert extra['phase']=='complete'
 nn=w/'research/observed-optimized-prefill';rr=json.loads(nn.with_suffix('.json').read_text());assert rr['returncode']==0 and rr['status']=='complete'
 more=[json.loads(l)for l in nn.with_suffix('.stdout').read_text().splitlines()if l.startswith('{')];assert len(more)==240 and all(z['mismatch']==0 for z in more)
 ss=[json.loads(l)for l in nn.with_suffix('.samples.jsonl').read_text().splitlines()];assert max(z['device_memory_mib']for z in ss)<=22528
 audit['current_candidate_comparison']=dict(cases=240,all_bytes_equal_to_both_original_and_C=True,receipt_sha256=sha(nn.with_suffix('.json')),whole_device_peak_MiB=max(z['device_memory_mib']for z in ss),scope='Same Gate/Up+SiLU portion only; no Down, prefix Graph cost or whole-model/HTTP claim. CurrentC uses separate decode family then merged prefill Lt21 whenP>=65.',timings=[dict(**z,percent_change_vs_C=(z['fused_us']/z['current_candidate_us']-1)*100)for z in more if 'original_us'in z])
(w/'component-audit.json').write_text(json.dumps(audit,indent=2));skip={'tmp','cache','__pycache__'};heavy={};files=[]
allowed={'.json','.jsonl','.py','.cu','.cuh','.log','.stdout','.stderr','.txt','.sh'}
for p in w.rglob('*'):
 if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
 with p.open('rb')as f:magic=f.read(4)
 if magic==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
 if p.suffix in allowed and p.name not in ['evidence-archive-receipt.json','heavy-evidence-index.json']:files.append(p)
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2));files.append(w/'heavy-evidence-index.json');manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)};z=w/'evidence-archive.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as f:
 for p in sorted(files):f.write(p,str(p.relative_to(w)))
 f.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
r=dict(archive=str(z),bytes=z.stat().st_size,entries=len(files)+1,sha256=sha(z));(w/'evidence-archive-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
