from pathlib import Path
import subprocess,os,json,shutil,time
w=Path('/mnt/efs/nlp/psyche/riley-mlp-small-v16e-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';c=w.parent/'riley-prefill-host-v15c-20261021';w.mkdir(exist_ok=True)
for n in ['tmp','cache','research']:(w/n).mkdir(exist_ok=True)
for n in ['holder.py','observe-finite.py']:shutil.copy2(c/n,w/n)
state=dict(phase='waiting-large-batch-screen',started_ns=time.time_ns());p=w/'mixed-small-state.json'
def save():p.write_text(json.dumps(state,indent=2))
save()
try:
 while True:
  gate=w.parent/'riley-mlp-batch-v16d-20261021/component-r4-state.json'
  a=json.loads(gate.read_text())if gate.exists()else{}
  if a.get('phase')in ['complete','failed']:break
  time.sleep(3)
 state['phase']='compiling';save()
 env=dict(os.environ,TMPDIR=str(w/'tmp'),CUDA_VISIBLE_DEVICES='',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64')
 argv=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-O3','--ptxas-options=-v','-std=c++17','-arch=sm_80',str(w/'research/mixed-small-probe.cu'),'-lcublas','-o',str(w/'research/mixed-small')]
 with(w/'research/mixed-small-build.log').open('x')as f:ret=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert ret.returncode==0,'compile failed'
 state['phase']='component-qualification';save()
 argv=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'research/observed-mixed-small'),'--timeout','900','--',str(w/'research/mixed-small')]
 env.update(RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'research/mixed-small-output'))
 (w/'research/mixed-small-argv.json').write_text(json.dumps(argv,indent=2))
 with(w/'research/mixed-small-run.log').open('x')as f:ret=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert ret.returncode==0,'component failed'
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e));save();raise
