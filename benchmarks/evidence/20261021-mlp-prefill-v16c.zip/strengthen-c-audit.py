from pathlib import Path
w=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021');p=w/'audit-continuation.py';s=p.read_text();mark="assert len(result)==34";i=s.index(mark)
s=s[:i]+"""for required in ['continue-c16-r0-stock','continue-c16-r1to4','continue-c16-r4','final-c32','profile-c16','profile-c32']:
 assert json.loads((p/(required+'.state.json')).read_text())['status']=='complete',required
normal_rows=[v['record']for v in result if v['run']not in ['profile-c16','profile-c32']]
assert {(v['concurrency'],v['repeat'],v['mode'])for v in normal_rows}=={(c,r,m)for c in [16,32]for r in range(5)for m in ['owned-before','owned-after','vllm']}
"""+s[i:];compile(s,str(p),'exec');p.write_text(s)
p=w/'finish-c-r6.py';s=p.read_text();mark="m=json.loads((w/'source-manifest.json')";i=s.index(mark);s=s[:i]+"""for name in ['continue-c16-r0-stock','continue-c16-r1to4','continue-c16-r4','final-c32']:
 state=json.loads((w/(name+'.state.json')).read_text());assert state['status']=='complete' and state['argv']==json.loads((w/(name+'.argv.json')).read_text())
"""+s[i:];compile(s,str(p),'exec');p.write_text(s)
print('continuation coverage, completion states and executed-plan binding added')
