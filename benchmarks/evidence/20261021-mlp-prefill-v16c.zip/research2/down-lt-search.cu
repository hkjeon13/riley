#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cublas_v2.h>
#include <cublasLt.h>
#include <vector>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <string>
using U=__nv_bfloat16;
#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"CUDA line%d %s\n",__LINE__,cudaGetErrorString(e));return 2;}}while(0)
#define BL(x) do{auto e=(x);if(e!=CUBLAS_STATUS_SUCCESS){fprintf(stderr,"BLAS line%d %d\n",__LINE__,int(e));return 3;}}while(0)
std::vector<U> read(const char*p){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error("input");size_t n=f.tellg();std::vector<U>b(n/2);f.seekg(0);f.read((char*)b.data(),n);if(!f)throw std::runtime_error("read");return b;}
float cv(U u){uint16_t v;memcpy(&v,&u,2);uint32_t z=uint32_t(v)<<16;float f;memcpy(&f,&z,4);return f;}
U bf(float f){uint32_t z;memcpy(&z,&f,4);uint16_t b=(z+0x7fff+((z>>16)&1))>>16;U x;memcpy(&x,&b,2);return x;}
__global__ void pack(const U*g,const U*u,U*out,int m){int i=blockIdx.x*256+threadIdx.x;if(i<m*19456){int row=i/19456,j=i%19456;out[i]=j<9728?g[row*9728+j]:u[row*9728+j-9728];}}
__global__ void cmp(const U*a,const U*b,int n,unsigned*p){int i=blockIdx.x*256+threadIdx.x;if(i<n&&__bfloat16_as_ushort(a[i])!=__bfloat16_as_ushort(b[i]))atomicAdd(p,1u);}

int main(int argc,char**argv){if(argc!=3)return 1;auto seed=read(argv[1]),weights=read(argv[2]);const int n=2560,k=9728,maximum=130;cudaStream_t s;CU(cudaStreamCreate(&s));cublasHandle_t h;BL(cublasCreate(&h));BL(cublasSetStream(h,s));BL(cublasSetMathMode(h,CUBLAS_DEFAULT_MATH));BL(cublasSetAtomicsMode(h,CUBLAS_ATOMICS_NOT_ALLOWED));cublasLtHandle_t lt;BL(cublasLtCreate(&lt));auto alloc=[](size_t n){void*p;cudaMalloc(&p,n);return p;};U*w=(U*)alloc(weights.size()*2),*y=(U*)alloc(maximum*n*2);unsigned*bad=(unsigned*)alloc(4);void*ws=alloc(16ul<<20);float alpha=1,beta=0;CU(cudaMemcpy(w,weights.data(),weights.size()*2,cudaMemcpyHostToDevice));U*x[6],*gold[6];
 for(int state=0;state<6;state++){std::vector<U>xx(size_t(maximum)*k);for(size_t i=0;i<xx.size();i++){float f=cv(seed[state==5?(i*13+37)%seed.size():i%seed.size()]);if(state==1)f*=8;if(state==2)f*=.0078125f;if(state==3&&i%7)f=0;if(state==4&&i%2)f=-f;if(state==5)f*=1.5f;xx[i]=bf(f);}x[state]=(U*)alloc(xx.size()*2);gold[state]=(U*)alloc(maximum*n*2);CU(cudaMemcpy(x[state],xx.data(),xx.size()*2,cudaMemcpyHostToDevice));}
 cublasLtMatmulDesc_t desc;BL(cublasLtMatmulDescCreate(&desc,CUBLAS_COMPUTE_32F,CUDA_R_32F));cublasOperation_t trans=CUBLAS_OP_T;BL(cublasLtMatmulDescSetAttribute(desc,CUBLASLT_MATMUL_DESC_TRANSA,&trans,sizeof(trans)));cublasLtMatrixLayout_t A,B[131]{},C[131]{};BL(cublasLtMatrixLayoutCreate(&A,CUDA_R_16BF,k,n,k));for(int m=65;m<=130;m++){BL(cublasLtMatrixLayoutCreate(&B[m],CUDA_R_16BF,k,m,k));BL(cublasLtMatrixLayoutCreate(&C[m],CUDA_R_16BF,n,m,n));}
 auto native=[&](int m,int st){return cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,n,m,k,&alpha,w,CUDA_R_16BF,k,x[st],CUDA_R_16BF,k,&beta,gold[st],CUDA_R_16BF,n,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP);};for(int st=0;st<6;st++)BL(native(128,st));
 auto equal=[&](const cublasLtMatmulAlgo_t&a,int m,int st){if(cublasLtMatmul(lt,desc,&alpha,w,A,x[st],B[m],&beta,y,C[m],y,C[m],&a,ws,16ul<<20,s)!=CUBLAS_STATUS_SUCCESS)return false;cudaMemsetAsync(bad,0,4,s);cmp<<<(m*n+255)/256,256,0,s>>>(gold[st],y,m*n,bad);unsigned count;cudaMemcpyAsync(&count,bad,4,cudaMemcpyDeviceToHost,s);if(cudaStreamSynchronize(s)!=cudaSuccess)throw std::runtime_error("sync");return count==0;};
 auto elapsed=[&](auto fn){for(int i=0;i<3;i++)fn();cudaEvent_t a,b;cudaEventCreate(&a);cudaEventCreate(&b);cudaEventRecord(a,s);for(int i=0;i<32;i++)fn();cudaEventRecord(b,s);cudaEventSynchronize(b);float ms;cudaEventElapsedTime(&ms,a,b);cudaEventDestroy(a);cudaEventDestroy(b);return ms*1000/32;};
 cublasLtMatmulAlgo_t base;BL(cublasLtMatmulAlgoInit(lt,CUBLAS_COMPUTE_32F,CUDA_R_32F,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,6,&base));
 auto cap=[&](cublasLtMatmulAlgoCapAttributes_t attr,uint32_t fallback){size_t bytes=0;auto e=cublasLtMatmulAlgoCapGetAttribute(&base,attr,nullptr,0,&bytes);if(e||!bytes)return std::vector<uint32_t>{fallback};std::vector<uint32_t>v(bytes/4);if(cublasLtMatmulAlgoCapGetAttribute(&base,attr,v.data(),bytes,&bytes)!=0)return std::vector<uint32_t>{fallback};return v;};auto tiles=cap(CUBLASLT_ALGO_CAP_TILE_IDS,24),stages=cap(CUBLASLT_ALGO_CAP_STAGES_IDS,15);
 struct Candidate{cublasLtMatmulAlgo_t algo;uint32_t tile,stage,swizzle;float us;};std::vector<Candidate>passed;
 for(uint32_t tile:tiles)for(uint32_t stage:stages)for(uint32_t swizzle:{0u,1u}){auto algo=base;uint32_t vals[]={tile,stage,5,4,swizzle,0};int j=0;bool valid=true;for(auto attr:{CUBLASLT_ALGO_CONFIG_TILE_ID,CUBLASLT_ALGO_CONFIG_STAGES_ID,CUBLASLT_ALGO_CONFIG_SPLITK_NUM,CUBLASLT_ALGO_CONFIG_REDUCTION_SCHEME,CUBLASLT_ALGO_CONFIG_CTA_SWIZZLING,CUBLASLT_ALGO_CONFIG_CUSTOM_OPTION})if(cublasLtMatmulAlgoConfigSetAttribute(&algo,attr,&vals[j++],4)!=0)valid=false;if(!valid)continue;cublasLtMatmulHeuristicResult_t ch{};if(cublasLtMatmulAlgoCheck(lt,desc,A,B[128],C[128],C[128],&algo,&ch)||ch.state||ch.workspaceSize>(16ul<<20))continue;for(int st=0;st<6;st++)if(!equal(algo,128,st)){valid=false;break;}if(!valid)continue;float us=elapsed([&](){cublasLtMatmul(lt,desc,&alpha,w,A,x[0],B[128],&beta,y,C[128],y,C[128],&algo,ws,16ul<<20,s);});passed.push_back({algo,tile,stage,swizzle,us});printf("{\"phase\":\"search\",\"config\":[6,%u,%u,5,4,%u,0],\"M128_us\":%.6f,\"all_six_exact\":true}\n",tile,stage,swizzle,us);fflush(stdout);}
 std::sort(passed.begin(),passed.end(),[](const Candidate&a,const Candidate&b){return a.us<b.us;});if(passed.size()>3)passed.resize(3);
 for(int m=65;m<=130;m++){for(int st=0;st<6;st++)BL(native(m,st));for(auto&a:passed){bool valid=true;cublasLtMatmulHeuristicResult_t ch{};if(cublasLtMatmulAlgoCheck(lt,desc,A,B[m],C[m],C[m],&a.algo,&ch)||ch.state||ch.workspaceSize>(16ul<<20))valid=false;for(int st=0;st<6&&valid;st++)valid=equal(a.algo,m,st);printf("{\"phase\":\"verify\",\"M\":%d,\"config\":[6,%u,%u,5,4,%u,0],\"all_six_exact\":%s",m,a.tile,a.stage,a.swizzle,valid?"true":"false");if(valid&&(m==65||m==115||m==128||m==129||m==130)){float before=elapsed([&](){native(m,0);});float after=elapsed([&](){cublasLtMatmul(lt,desc,&alpha,w,A,x[0],B[m],&beta,y,C[m],y,C[m],&a.algo,ws,16ul<<20,s);});printf(",\"before_us\":%.6f,\"after_us\":%.6f",before,after);}puts("}");fflush(stdout);}}
 printf("COMPLETE shortlisted=%zu\n",passed.size());CU(cudaStreamSynchronize(s));return 0;
}
