from pathlib import Path
import json,ast,hashlib,statistics,time,sys
p=Path(__file__).resolve().parent;r=p.parent/'riley-w0-a100-gpu67-20261019'
oracle={x['id']:x['value']for x in json.loads((r/'runs/qwen7-bootstrap/native-reference.json').read_text())['rows']}
partial='--partial'in sys.argv
partial=True
names=[x.name for x in sorted((p/'runs').iterdir()) if (x/'result.json').exists() and (partial or (x/'complete.json').exists())]
result=[]
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def quantile(v,q):
 v=sorted(v);i=(len(v)-1)*q;l=int(i);return v[l]+(v[min(l+1,len(v)-1)]-v[l])*(i-l)
for name in names:
 campaign=p;root=p/'runs'/name;f=root/'result.json'
 if not f.exists():
  assert partial or name in ['expanded-profile'],name;continue
 data=json.loads(f.read_text());plan=data['plan'];gpu=6 if plan['gpu'].endswith('55ee1e6a7')else 7;holder=2027914 if gpu==6 else 2027915
 runner='measure-route-proof.py' if name.startswith('route-proof-c32') else 'measure-profile.py' if plan['profile'] else 'measure-matched.py'
 assert plan['runner_sha256']==sha(campaign/runner)
 for rec in data['records']:
  arm=root/('c%d-r%d-%s'%(rec['concurrency'],rec['repeat'],rec['mode']))
  if not(arm/'gpu-samples.json').exists():
   assert partial,('unfinished arm',arm);continue
  is_vllm=rec['mode']=='vllm';argv=json.loads((arm/'argv.json').read_text())
  budget_flag='--max-num-batched-tokens'if is_vllm else'--batch-token-budget'
  expected_budget=1024 if name.startswith('policy-') and rec['mode']=='owned-after' else 576
  assert int(argv[argv.index(budget_flag)+1])==expected_budget,('unexpected budget',arm,argv)
  assert plan['persistent_holder']['pid']==str(holder)
  assert plan['persistent_holder']['start_ticks']==('6083215119'if gpu==6 else'6083215121')
  if is_vllm:
   assert '--no-enable-prefix-caching'in argv and '--enforce-eager'not in argv
   assert int(argv[argv.index('--num-gpu-blocks-override')+1])==rec['concurrency']*64
  else:
   assert int(argv[argv.index('--kv-blocks')+1])==rec['concurrency']*64

  if not is_vllm:assert sha(argv[0])==(plan['baseline_server_sha256']if rec['mode']=='owned-before'else plan['candidate_sha256'])
  if not is_vllm:
   server=(arm/'server.log').read_text();assert ('completion=IterationBatch, M='+str(int(argv[argv.index('--batch-token-budget')+1]) if '--batch-token-budget'in argv else 512)+', T=1024')in server and 'RILEY_NUMERICS profile=owned-hf-eager-bf16-v1'in server
   policy=argv[argv.index('--owned-decode-batch')+1];assert 'mode='+policy in server
   if '--owned-decode-graph'not in argv:assert 'graph=false'in server
   config_code,config_raw=ast.literal_eval((arm/'config-before.txt').read_text());assert config_code==503 and json.loads(config_raw)['error']['code']=='config_unavailable'
  else:config_code=None
  measured=json.loads((arm/'w0/requests.json').read_text());correct=json.loads((arm/'correctness.json').read_text());groups=measured+correct;recovered=None
  if(arm/'recovery.json').exists():
   x=json.loads((arm/'recovery.json').read_text());assert x['before']['allocation']==x['after']['allocation'];assert x['after']['kv_allocated_blocks']==0;groups+=x['retries'];recovered=True
  if(arm/'bucket-warm.json').exists():
   for wave in json.loads((arm/'bucket-warm.json').read_text()):groups+=wave['requests']
  for row in groups:
   if not is_vllm:assert row['value']==oracle[row['id']]and row['hf_token_equal'],(arm,row['id'])
   else:
    assert row['value']['usage']['prompt_tokens']==oracle[row['id']]['usage']['prompt_tokens'],(arm,row['id'],'prompt token count')
    assert row['hf_token_equal']==(row['value']['token_ids']==oracle[row['id']]['token_ids'])
    assert row['hf_text_equal']==(row['value']['text']==oracle[row['id']]['text'])
   ids=[];text='';finish=None;usage=None;prompt=None;done=False;done_count=0
   for line in row['raw_sse'].splitlines():
    if not line.startswith('data: '):continue
    data=line[6:]
    if data.strip()=='[DONE]':done=True;done_count+=1;continue
    assert not done,('SSE data after DONE',arm)
    event=json.loads(data);assert'error'not in event;usage=event.get('usage')or usage
    for c in event.get('choices',[]):ids+=c.get('token_ids')or[];text+=c.get('text')or'';finish=c.get('finish_reason')or finish;prompt=c.get('prompt_token_ids')or prompt
   assert done_count==1 and done and dict(token_ids=ids,text=text,finish_reason=finish,usage=usage,prompt_ids=prompt)==row['value']
  code,raw=ast.literal_eval((arm/'w0/metrics-after.txt').read_text());assert code==200
  if not is_vllm:
   m=json.loads(raw);assert m['active_requests']==m['waiting_requests']==m['kv_allocated_blocks']==0
  else:
   gauges={}
   for line in raw.splitlines():
    if line.startswith(('vllm:num_requests_running','vllm:num_requests_waiting','vllm:kv_cache_usage_perc')):gauges[line.split('{')[0]]=float(line.split()[-1])
   assert len(gauges)>=2 and all(v==0 for v in gauges.values()),gauges
  assert len(measured)==rec['requests'];speed=sum(len(v['value']['token_ids'])for v in measured)/(max(v['end']for v in measured)-min(v['start']for v in measured));assert abs(speed-rec['output_tok_s'])<1e-7
  for metric in ['ttft_ms','tpot_ms','e2e_ms']:
   for suffix,q in [('p50',.5),('p95',.95),('p99',.99)]:assert abs(quantile([v[metric]for v in measured if v[metric]is not None],q)-rec[metric+'_'+suffix])<1e-7
  peak=0;device_peak=0;foreign=set()
  for s in json.loads((arm/'gpu-samples.json').read_text()):
   if 'gpu'in s:device_peak=max(device_peak,float(s['gpu'].split(',')[0]))
   own=0
   for line in s.get('processes','').splitlines():
    pid,mem=line.split(',');pid=int(pid);mem=float(mem)
    if pid==holder or str(pid)in s['verified_owned_start_ticks']:own+=mem
    else:foreign.add(pid)
   peak=max(peak,own)
  assert peak<=22528 and 0<device_peak<=22528;assert not foreign,(arm,foreign)
  result.append(dict(token_budget_from_actual_argv=int(argv[argv.index(budget_flag)+1]),run=name,arm=arm.name,gpu=gpu,record=rec,full_SSE_values_verified=len(groups),HF_token_matches=sum(v['hf_token_equal']for v in groups),HF_text_matches=sum(v['hf_text_equal']for v in groups),resources_recovered=True,owned_config_endpoint_status=config_code,resolved_startup_and_binary_verified=(not is_vllm),disconnect_recovery=recovered,peak_owned_and_holder_MiB=peak,peak_whole_device_MiB=device_peak,foreign_gpu_pids=sorted(foreign),actual_binary_sha256=None if is_vllm else sha(argv[0])))

if not partial:
 for required in ['final-c16','final-c32','profile-c16','profile-c32']:
  assert required in names,('missing final campaign',required)
  assert json.load(open(p/(required+'.state.json')))['status']=='complete'
cells=[]
keys=['output_tok_s']+[m+'_'+s for m in ['ttft_ms','tpot_ms','e2e_ms'] for s in ['p50','p95','p99']]
for name in names:
 for conc in sorted({v['record']['concurrency'] for v in result if v['run']==name}):
  arms=[v['record']for v in result if v['run']==name and v['record']['concurrency']==conc]
  modes={m:{k:statistics.median(v[k]for v in arms if v['mode']==m)for k in keys}for m in sorted({v['mode']for v in arms})}
  pairs=[]
  for rep in sorted({v['repeat']for v in arms}):
   by={v['mode']:v for v in arms if v['repeat']==rep}
   if 'owned-before'in by and 'owned-after'in by:pairs.append(dict(repeat=rep,ratios={k:by['owned-after'][k]/by['owned-before'][k]for k in keys}))
  cells.append(dict(run=name,concurrency=conc,modes=modes,pairs=pairs))
for required in ['continue-c16-r0-stock','continue-c16-r1to4','continue-c16-r4','final-c32','profile-c16','profile-c32']:
 assert json.loads((p/(required+'.state.json')).read_text())['status']=='complete',required
normal_rows=[v['record']for v in result if v['run']not in ['profile-c16','profile-c32']]
assert {(v['concurrency'],v['repeat'],v['mode'])for v in normal_rows}=={(c,r,m)for c in [16,32]for r in range(5)for m in ['owned-before','owned-after','vllm']}
assert len(result)==34 and len({(v['record']['concurrency'],v['record']['repeat'],v['record']['mode'])for v in result if v['run']not in ['profile-c16','profile-c32']})==30
x=dict(partial=partial,time_ns=time.time_ns(),arms=result,cells=cells,total_full_SSE_values_verified=sum(v['full_SSE_values_verified']for v in result),scope='Completed arms only; full original native value/SSE oracle, quantiles, binary/runner identity, same GPU and zero resource gauges. Failed experiments remain on EFS.')
(p/'independent-audit.json').write_text(json.dumps(x,indent=2));print([(v['run'],v['concurrency'],len(v['pairs']))for v in cells]);print('full SSE values',x['total_full_SSE_values_verified'])
