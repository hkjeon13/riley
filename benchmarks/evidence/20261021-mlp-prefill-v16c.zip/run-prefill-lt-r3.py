from pathlib import Path
import json,os,subprocess,time,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021');b=w.parent/'riley-mlp-decode-v16b-20261021';r=w.parent/'riley-w0-a100-gpu67-20261019';state=dict(phase='waiting-B-accuracy',started_ns=time.time_ns())
def save():(w/'prefill-lt-r3-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  a=json.loads((b/'accuracy-r3-state.json').read_text());assert a['phase']!='failed',a
  if a['phase']=='complete':break
  time.sleep(2)
 state['phase']='component-qualification';save();p=w/'research2';seed=w.parent/'riley-qkv-gateup-v214-20261019/v215-inputs/qwen4b-x.bf16'
 env=dict(os.environ,TMPDIR=str(w/'tmp'),LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',RILEY_DIVERGENCE_NATIVE_OUTPUT=str(p/'prefill-lt-r3-output'))
 argv=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(p/'observed-prefill-lt-r3'),'--timeout','900','--',str(p/'prefill-lt'),str(seed),str(p/'merged-gate-up.bf16'),str(p/'down.bf16')];(p/'argv-r3.json').write_text(json.dumps(argv,indent=2))
 with(p/'run-r3.log').open('x')as f:ret=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert ret.returncode==0
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
