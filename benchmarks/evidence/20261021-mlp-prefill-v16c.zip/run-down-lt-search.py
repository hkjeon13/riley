from pathlib import Path
import json,subprocess,os,time,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';state=dict(phase='compiling',started_ns=time.time_ns())
def save():(w/'down-lt-search-state.json').write_text(json.dumps(state,indent=2))
try:
 save();assert json.loads((w/'prefill-lt-r3-state.json').read_text())['phase']=='complete';env=dict(os.environ,TMPDIR=str(w/'tmp'),CUDA_VISIBLE_DEVICES='',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64');argv=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-O3','-std=c++17','-arch=sm_80',str(w/'research2/down-lt-search.cu'),'-lcublas','-lcublasLt','-o',str(w/'research2/down-lt-search')]
 with(w/'research2/down-lt-build.log').open('x')as f:p=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert p.returncode==0
 state['phase']='searching-and-verifying';save();env.update(RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'research2/down-lt-output'))
 argv=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'research2/observed-down-lt-search'),'--timeout','900','--',str(w/'research2/down-lt-search'),str(w.parent/'riley-qkv-gateup-v214-20261019/v215-inputs/qwen4b-x.bf16'),str(w/'research2/down.bf16')];(w/'research2/down-lt-argv.json').write_text(json.dumps(argv,indent=2))
 with(w/'research2/down-lt-run.log').open('x')as f:p=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert p.returncode==0
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
