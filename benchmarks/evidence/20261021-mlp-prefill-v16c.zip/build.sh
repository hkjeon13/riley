#!/bin/bash
set -euo pipefail
umask 077
RUN=/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021
export RUSTUP_HOME=/home/nlp/riley-261013/rustup CARGO_HOME=/home/nlp/riley-261013/cargo RUSTUP_TOOLCHAIN=1.85.0
export PATH="$CARGO_HOME/bin:/usr/local/cuda-12.4/bin:/usr/local/bin:/usr/bin:/bin"
export CMAKE=/usr/local/bin/cmake CARGO_BUILD_JOBS=2 CMAKE_BUILD_PARALLEL_LEVEL=2
export CUDA_HOME=/usr/local/cuda-12.4 CUDAToolkit_ROOT=/usr/local/cuda-12.4 CUDACXX=/usr/local/cuda-12.4/bin/nvcc RILEY_CUDA_ARCHITECTURES=80 CUDA_VISIBLE_DEVICES=
export LD_LIBRARY_PATH=/usr/local/cuda-12.4/lib64 CARGO_TARGET_DIR="$RUN/target" TMPDIR="$RUN/tmp" XDG_CACHE_HOME="$RUN/cache"
unset RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
trap 'rc=$?; printf "%s\n" "$rc" > "$RUN/native-kv-build-and-cpu.exit"' EXIT
cd "$RUN/source"
rustc -Vv > "$RUN/qualification-rustc.txt"
/usr/local/cuda-12.4/bin/nvcc --version > "$RUN/qualification-nvcc.txt"
/usr/bin/taskset -c 48-51 cargo build --locked --offline --release -p riley-server --features server,owned-hf-eager > "$RUN/native-kv-server-build.log" 2>&1
cp "$CARGO_TARGET_DIR/release/riley" "$RUN/riley-mlp-prefill-v16c"
sha256sum "$RUN/riley-mlp-prefill-v16c" > "$RUN/qualification-binary.sha256"
 /usr/bin/taskset -c 48-51 cargo test --locked --offline --release -p riley-cuda -p riley-runtime -p riley-scheduler -p riley-server --features riley-server/server,riley-server/owned-hf-eager --lib --bins --message-format=json > "$RUN/native-kv-regression.log" 2>&1
