from pathlib import Path
import shutil,json
w=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021');b=w.parent/'riley-mlp-decode-v16b-20261021'
for n in ['build-gpu-c.sh','recheck-c02.py','build-teacher-final.py','teacher-probe-final.rs','teacher-body.rs','teacher-mixed.rs','build-teacher-body.py','build-teacher-mixed.py','measure-matched.py','measure-profile.py','analyze-profiles.py','audit-complete.py','analyze-final.py','run-job.py','stock-runtime-proof.py','holder.py','observe-finite.py','audit-tail-b.py','pointer-inspection.cpp','analyze-profile-v15.py','attribute-graphs.py','audit-teachers-r3.py','audit-mixed-r3.py','queue-normal-analysis-r4.py']:
 s=(b/n).read_text().replace(str(b),str(w)).replace('riley-mlp-decode-v16b','riley-mlp-prefill-v16c');(w/n).write_text(s)
for n in ['pointer-inspection.so','call-inspection-nvtx.so']:shutil.copy2(b/n,w/n)
for c in [16,32]:
 a=json.loads((b/f'final-c{c}.argv.json').read_text());a=[x.replace(str(b),str(w)).replace('riley-mlp-decode-v16b','riley-mlp-prefill-v16c')for x in a];(w/f'final-c{c}.argv.json').write_text(json.dumps(a,indent=2))
s=(b/'queue-build-extra-b.py').read_text().replace(str(b),str(w)).replace('riley-mlp-decode-v16b','riley-mlp-prefill-v16c');(w/'queue-build-extra.py').write_text(s)
s=(b/'queue-accuracy-r3.py').read_text().replace(str(b),str(w));mark=" while not (w/'build-extra-state.json').exists()";i=s.index(mark);s=s[:i]+''' while True:
  p=b/'diagnostics-state.json'
  if p.exists():
   a=json.loads(p.read_text());assert a['phase']!='failed',a
   if a['phase']=='complete':break
  time.sleep(2)
'''+s[i:];# b in inherited script originally named old v15B; set actual serialized prerequisite.
s=s.replace("b=w.parent/'riley-prefill-host-v15b-20261021'",f"b=Path({str(b)!r})");(w/'queue-accuracy.py').write_text(s)
