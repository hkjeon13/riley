from pathlib import Path
import json,subprocess,hashlib,time
w=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
l=json.loads((w/'source-lineage.json').read_text());assert all(sha(Path(p))==h for p,h in l['normal_inputs_sha256'].items());assert len(json.loads((w/'runs/final-c16/result.json').read_text())['records'])==2
(w/'ipc7').mkdir(mode=0o700,exist_ok=True);(w/'ipc6').mkdir(mode=0o700,exist_ok=True)
for name,rep,reps,modes in [('continue-c16-r0-stock',0,1,'vllm'),('continue-c16-r1to4',1,4,'owned-before,owned-after,vllm')]:
 a=json.loads((w/'final-c16.argv.json').read_text());a[a.index('--out')+1]=str(w/'runs'/name)
 for key,value in [('--repeat-start',str(rep)),('--repeats',str(reps)),('--modes',modes)]:a[a.index(key)+1]=value
 (w/(name+'.argv.json')).write_text(json.dumps(a,indent=2))
(w/'normal-continuation-proof.json').write_text(json.dumps(dict(time_ns=time.time_ns(),reason='Missing EFS ipc7 directory prevented first stock startup; original two completed r0 Riley arms preserved, no runner/source/binary/original-plan change',original_inputs_still_equal=True,new_plans={n:sha(w/(n+'.argv.json'))for n in ['continue-c16-r0-stock','continue-c16-r1to4']},completed_normal_arms_excluded=0),indent=2))
# Retry orchestrators use new state names; failed originals remain verbatim.
s=(w/'queue-normal-c.py').read_text();a=s.index(" with(w/'freeze-c.log')");b=s.index(" for name in ['final-c16','final-c32']:",a);s=s[:a]+s[b:];s=s.replace("['final-c16','final-c32']","['continue-c16-r0-stock','continue-c16-r1to4','final-c32']").replace("'campaign-r4-state.json'","'campaign-r5-state.json'")
(w/'queue-normal-r5.py').write_text(s)
s=(w/'queue-normal-analysis-r4.py').read_text().replace('campaign-r4-state','campaign-r5-state').replace('normal-analysis-r4-state','normal-analysis-r5-state').replace("['final-c16','final-c32']","['final-c16','continue-c16-r0-stock','continue-c16-r1to4','final-c32']")
(w/'queue-analysis-r5.py').write_text(s)
s=(w/'queue-c-diagnostics-r2.py').read_text().replace('campaign-r4-state','campaign-r5-state').replace('diagnostics-state','diagnostics-r5-state').replace("str(w/'audit-complete.py')","str(w/'audit-continuation.py')")
(w/'queue-diagnostics-r5.py').write_text(s)
s=(w/'audit-complete.py').read_text().replace("names=[x.name", "partial=True\nnames=[x.name").replace("(p/('audit-partial.json' if partial else 'independent-audit.json'))","(p/'independent-audit.json')")
s=s.replace("x=dict(partial=partial", "assert len(result)==34 and len({(v['record']['concurrency'],v['record']['repeat'],v['record']['mode'])for v in result if v['run']not in ['profile-c16','profile-c32']})==30\nx=dict(partial=partial")
(w/'audit-continuation.py').write_text(s)
for n in ['queue-normal-r5.py','queue-analysis-r5.py','queue-diagnostics-r5.py']:
 with(w/(n+'.outer.log')).open('x')as f:q=subprocess.Popen(['python3',str(w/n)],stdout=f,stderr=f,start_new_session=True)
 print(n,q.pid)
