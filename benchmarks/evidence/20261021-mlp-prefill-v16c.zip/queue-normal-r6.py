from pathlib import Path
import json,time,subprocess,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021');s=dict(phase='waiting-C32',started_ns=time.time_ns())
def save():(w/'campaign-r6-state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 while True:
  a=json.loads((w/'campaign-r5-state.json').read_text());assert a['phase']!='failed',a
  if a['phase']=='complete':break
  time.sleep(3)
 s['phase']='fill-C16-r4';save()
 with(w/'continue-c16-r4.orchestrator.log').open('x')as f:r=subprocess.run(['python3',str(w/'run-job.py'),'continue-c16-r4'],stdout=f,stderr=f)
 assert r.returncode==0
 s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
