from pathlib import Path
import json,struct,hashlib,shutil,subprocess,os,time,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021');c=w.parent/'riley-prefill-host-v15c-20261021';r=w.parent/'riley-w0-a100-gpu67-20261019';model=w.parent/'riley-261013/models/Qwen3-4B';w.mkdir(exist_ok=True)
for n in ['tmp','cache','research2']:(w/n).mkdir(exist_ok=True)
for n in ['holder.py','observe-finite.py']:shutil.copy2(c/n,w/n)
state=dict(phase='extracting-checkpoint-tensors',started_ns=time.time_ns())
def save():(w/'prefill-lt-r2-state.json').write_text(json.dumps(state,indent=2))
try:
 save();parts={};proof=[]
 for p in model.glob('*.safetensors'):
  with p.open('rb')as f:
   size=struct.unpack('<Q',f.read(8))[0];head=json.loads(f.read(size));base=8+size
   for tag in ['gate_proj','up_proj','down_proj']:
    key=f'model.layers.0.mlp.{tag}.weight'
    if key not in head:continue
    a=head[key];assert a['dtype']=='BF16';start,end=a['data_offsets'];f.seek(base+start);raw=f.read(end-start);assert len(raw)==end-start;parts[tag]=raw;proof.append(dict(file=str(p),tensor=key,metadata=a,raw_sha256=hashlib.sha256(raw).hexdigest()))
 assert set(parts)=={'gate_proj','up_proj','down_proj'}
 (w/'research2/merged-gate-up.bf16').write_bytes(parts['gate_proj']+parts['up_proj']);(w/'research2/down.bf16').write_bytes(parts['down_proj']);seed=w.parent/'riley-qkv-gateup-v214-20261019/v215-inputs/qwen4b-x.bf16';assert hashlib.sha256(seed.read_bytes()).hexdigest()=='a40efc709560fc220c7b4dd491d54add7d82052817aa8bff5a44325fa496c07c'
 (w/'research2/input-proof.json').write_text(json.dumps(dict(checkpoint_tensors=proof,seed_path=str(seed),seed_sha256=hashlib.sha256(seed.read_bytes()).hexdigest(),scope='Actual layer0 weights; six finite transforms of existing hidden-input seed. Repeated hidden seed for Down K9728 is a component input, not an actual gated activation.'),indent=2))
 env=dict(os.environ,TMPDIR=str(w/'tmp'),CUDA_VISIBLE_DEVICES='',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64');argv=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-O3','-std=c++17','-arch=sm_80',str(w/'research2/prefill-lt.cu'),'-lcublas','-lcublasLt','-o',str(w/'research2/prefill-lt')]
 state['phase']='compiling';save()
 with(w/'research2/build.log').open('x')as f:p=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert p.returncode==0
 state['phase']='component-qualification';save();env.update(RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'research2/prefill-lt-output'))
 argv=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'research2/observed-prefill-lt'),'--timeout','900','--',str(w/'research2/prefill-lt'),str(seed),str(w/'research2/merged-gate-up.bf16'),str(w/'research2/down.bf16')];(w/'research2/argv.json').write_text(json.dumps(argv,indent=2))
 with(w/'research2/run.log').open('x')as f:p=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert p.returncode==0
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
