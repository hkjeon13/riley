from pathlib import Path
import json,subprocess,time,hashlib,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();state=dict(phase='tail-continuation-audit',started_ns=time.time_ns())
def save():(w/'normal-analysis-r7-state.json').write_text(json.dumps(state,indent=2))
try:
 save();assert json.loads((w/'campaign-r6-state.json').read_text())['phase']=='complete'
 matrix=json.loads((w/'primary-matrix-audit.json').read_text());assert len(matrix)==2 and all(len(c['records'])==15 for c in matrix)
 s=(w/'audit-tail-b.py').read_text().replace(" root=w/f'runs/final-c{c}';data=json.loads((root/'result.json').read_text())['records']"," data=next(x['records']for x in json.loads((w/'primary-matrix-audit.json').read_text())if x['concurrency']==c)")
 s=s.replace("   p=root/f'c{c}-r{rep}-{mode}';", "   rec=next(r for r in data if r['repeat']==rep and r['mode']==mode);root=w/'runs'/rec['campaign'];p=root/f'c{c}-r{rep}-{mode}';")
 (w/'audit-tail-continuation.py').write_text(s)
 with(w/'tail-continuation.log').open('x')as f:r=subprocess.run(['python3',str(w/'audit-tail-continuation.py')],stdout=f,stderr=f)
 assert r.returncode==0
 m=json.loads((w/'source-manifest.json').read_text());assert len(m)==937 and all(sha(w/'source'/f)==h for f,h in m.items());l=json.loads((w/'source-lineage.json').read_text());assert sha(Path(l['binary']))==l['binary_sha256'];assert all(sha(Path(f))==h for f,h in l['normal_inputs_sha256'].items())
 old=json.loads((w/'normal-continuation-proof.json').read_text());extra=json.loads((w/'normal-continuation-r6-proof.json').read_text());assert extra['prior_proof_sha256']==sha(w/'normal-continuation-proof.json');plans={**old['new_plans'],**extra['new_plan']};assert all(sha(w/(n+'.argv.json'))==h for n,h in plans.items())
 (w/'normal-input-stability.json').write_text(json.dumps(dict(source937_all_equal=True,binary_sha256=l['binary_sha256'],normal_runner_sha256=sha(w/'measure-matched.py'),normal_arm_count=30,continuation_plans_sha256=plans,all_original_normal_inputs_still_equal=True,normal_completed_arms_excluded=0,scope='All original completed r0 records retained; five distinct before/after/stock repetitions eachC, tail request paths resolved from audited campaign labels'),indent=2))
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
