from pathlib import Path
import json,time,hashlib,os,signal,subprocess
w=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((w/'campaign-r5-state.json').read_text())['phase']=='measuring'
a=json.loads((w/'final-c16.argv.json').read_text());name='continue-c16-r4';a[a.index('--out')+1]=str(w/'runs'/name);a[a.index('--repeat-start')+1]='4';a[a.index('--repeats')+1]='5';(w/(name+'.argv.json')).write_text(json.dumps(a,indent=2))
(w/'normal-continuation-r6-proof.json').write_text(json.dumps(dict(time_ns=time.time_ns(),prior_proof_sha256=sha(w/'normal-continuation-proof.json'),reason='Runner range(repeat_start,repeats) uses exclusive end; r1to4 completed r1..3. Preserve all completed records and fill r4 after C32.',new_plan={name:sha(w/(name+'.argv.json'))},completed_normal_arms_excluded=0),indent=2))
s='''from pathlib import Path
import json,time,subprocess,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-prefill-v16c-20261021');s=dict(phase='waiting-C32',started_ns=time.time_ns())
def save():(w/'campaign-r6-state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 while True:
  a=json.loads((w/'campaign-r5-state.json').read_text());assert a['phase']!='failed',a
  if a['phase']=='complete':break
  time.sleep(3)
 s['phase']='fill-C16-r4';save()
 with(w/'continue-c16-r4.orchestrator.log').open('x')as f:r=subprocess.run(['python3',str(w/'run-job.py'),'continue-c16-r4'],stdout=f,stderr=f)
 assert r.returncode==0
 s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
''';(w/'queue-normal-r6.py').write_text(s)
for pid,old,state,new in [(319755,'queue-analysis-r5.py','normal-analysis-r5-state.json','queue-analysis-r6.py'),(319756,'queue-diagnostics-r5.py','diagnostics-r5-state.json','queue-diagnostics-r6.py')]:
 p=Path(f'/proc/{pid}');current=json.loads((w/state).read_text());assert current['phase']=='waiting-normal';assert p.stat().st_uid==os.getuid();assert p.joinpath('cmdline').read_bytes().split(b'\0')[:2]==[b'python3',str(w/old).encode()]
 (w/(old+'.preflight.json')).write_text(json.dumps(dict(state=current,pid=pid,start_ticks=p.joinpath('stat').read_text().rsplit(')',1)[1].split()[19],reason='Wait for missing C16 r4 instead of auditing/profiling incomplete matrix; no GPU job from this waiting queue'),indent=2));os.kill(pid,signal.SIGTERM)
 s=(w/old).read_text().replace('campaign-r5-state','campaign-r6-state').replace("'continue-c16-r1to4','final-c32'","'continue-c16-r1to4','continue-c16-r4','final-c32'")
 (w/new).write_text(s)
for name in ['queue-normal-r6.py','queue-analysis-r6.py','queue-diagnostics-r6.py']:
 with(w/(name+'.outer.log')).open('x')as f:r=subprocess.Popen(['python3',str(w/name)],stdout=f,stderr=f,start_new_session=True)
 print(name,r.pid)
