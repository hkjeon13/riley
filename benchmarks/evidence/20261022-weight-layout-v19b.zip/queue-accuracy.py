from pathlib import Path
import os,json,time,subprocess,traceback,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19b-20261022');b=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';old=w.parent/'riley-qkv-gateup-v214-20261019';state=dict(phase='waiting-build',completed=[],started_ns=time.time_ns())
def save():(w/'accuracy-r3-state.json').write_text(json.dumps(state,indent=2))
def script(name,args=[]):
 with(w/(name+'.outer.log')).open('x')as f:p=subprocess.run(['python3',str(w/name)]+args,stdout=f,stderr=f)
 assert p.returncode==0,(name,p.returncode)
try:
 save()
 while True:
  p=b/'diagnostics-state.json'
  if p.exists():
   a=json.loads(p.read_text());assert a['phase']!='failed',a
   if a['phase']=='complete':break
  time.sleep(2)
 while True:
  p=w/'bounded576-state.json';a=json.loads(p.read_text())if p.exists()else{};assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 while not (w/'build-extra-state.json').exists() or json.loads((w/'build-extra-state.json').read_text())['phase'] not in ['complete','failed']:time.sleep(2)
 assert json.loads((w/'build-extra-state.json').read_text())['phase']=='complete'
 for name,binary,copies,graph,shrink,no_output in [('final-teacher-C1-eager','teacher-probe-final','1','off','',False),('final-teacher-allR-Graph','teacher-probe-final','32','segments-v1','all-v1',False),('teacher-body-allR','teacher-body','32','segments-v1','',False),('teacher-mixed','teacher-mixed','32','segments-v1','',False),('teacher-mixed-no-output','teacher-mixed','32','segments-v1','',True)]:
  tag=name+'-r3';folder=('teacher-mixed-output'if name=='teacher-mixed'else name)+'-r3';state.update(phase='numerical',current=tag);save()
  env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/folder),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES=copies,RILEY_TEACHER_SHRINK=shrink,RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH=graph,RILEY_OWNED_BATCH='native-prefill-sm80-v5')
  env.pop('CUBLAS_WORKSPACE_CONFIG',None)
  if no_output:env['RILEY_MIXED_NO_OUTPUT_PREFILL']='1'
  a=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/('observed-'+tag)),'--',str(w/binary),'--ignored','--exact','owned_batch_teacher_forced_logits_are_finite_and_reported','--nocapture','--test-threads=1'];(w/(tag+'.argv.json')).write_text(json.dumps(a,indent=2))
  with(w/(tag+'.launch.log')).open('x')as f:p=subprocess.run(a,env=env,stdout=f,stderr=f)
  assert p.returncode==0,(name,p.returncode);state['completed'].append(name);save()
 for name in ['audit-teachers-r3.py','audit-mixed-r3.py']:script(name)
 artifacts=[]
 for line in(w/'ledger-gpu-build.jsonl').read_text().splitlines():
  try:a=json.loads(line)
  except ValueError:continue
  if a.get('reason')=='compiler-artifact'and a.get('executable')and a['target']['name']in ['host_runtime_gpu','memory_gpu','owned_hf_command_batch_gpu','sm80_prefill_alignment_gpu']:artifacts.append(a)
 assert len(artifacts)==4,[a['target']['name']for a in artifacts]
 for item in artifacts:
  name=item['target']['name'];state.update(phase='gpu-contracts',current=name);save();cmd=[item['executable'],'--ignored','--nocapture','--test-threads=1']
  if name in ['host_runtime_gpu','memory_gpu']:cmd+=['command_batch']
  env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/('gpu-contract-'+name)))
  a=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/('observed-'+name)),'--']+cmd;(w/(name+'.argv.json')).write_text(json.dumps(a,indent=2))
  with(w/(name+'.launch.log')).open('x')as f:p=subprocess.run(a,env=env,stdout=f,stderr=f)
  assert p.returncode==0,(name,p.returncode);state['completed'].append(name);save()
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
