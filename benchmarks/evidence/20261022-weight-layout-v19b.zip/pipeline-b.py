from pathlib import Path
import json,subprocess,time,hashlib,shutil,traceback
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19b-20261022');a=w.parent/'riley-weight-layout-v19a-20261022';s=dict(phase='waiting-build',started_ns=time.time_ns())
def save():(w/'pipeline-state.json').write_text(json.dumps(s,indent=2))
def run(name,args=[]):
 s.update(phase=name);save()
 with(w/(name+'.pipeline.log')).open('x')as f:q=subprocess.run(['python3',str(w/name)]+args,stdout=f,stderr=f)
 assert q.returncode==0,(name,q.returncode)
try:
 save()
 while True:
  f=w/'build-extra-state.json';v=json.loads(f.read_text())if f.exists()else{};assert v.get('phase')!='failed',v
  if v.get('phase')=='complete':break
  time.sleep(3)
 for name in ['run-bounded-g.py','queue-accuracy.py','run-canonical.py','validate-c16-b.py']:run(name)
 # Validate every accepted finite sample before any normal arm.
 receipts=[]
 for f in w.glob('observed-*.samples.jsonl'):
  rows=[json.loads(l)for l in f.read_text().splitlines()];assert rows;peak=max(x['device_memory_mib']for x in rows);assert peak<=22528,(f,peak)
  for x in rows:assert all(p['pid']==2027915 or str(p['pid'])in x['verified_owned_start_ticks']for p in x['processes']),(f,x)
  receipts.append(dict(name=f.name,samples=len(rows),whole_device_peak_MiB=peak,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
 assert len(receipts)==15,len(receipts);(w/'qualification-resource-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),GPU=7,cap_MiB=22528,runs=receipts),indent=2))
 old=w.parent/'riley-weight-layout-v19a-functional-gpu7-20261022';d=w.parent/'riley-weight-layout-v19b-functional-20261022';d.mkdir()
 for n in ['run-pilot.py','run-job.py','measure-matched.py','audit-complete.py','holder.py']:(d/n).write_text((old/n).read_text().replace(old.name,d.name).replace(a.name,w.name).replace('riley-weight-layout-v19a','riley-weight-layout-v19b'))
 for c in [16,32]:
  argv=json.loads((old/f'pilot-c{c}.argv.json').read_text());argv=[x.replace(old.name,d.name).replace(a.name,w.name).replace('riley-weight-layout-v19a','riley-weight-layout-v19b')for x in argv];(d/f'pilot-c{c}.argv.json').write_text(json.dumps(argv,indent=2))
 s['phase']='functional-pilot';save()
 with(d/'outer.log').open('x')as f:q=subprocess.run(['python3',str(d/'run-pilot.py')],stdout=f,stderr=f)
 assert q.returncode==0
 (w/'normal-ready.json').write_text(json.dumps(dict(time_ns=time.time_ns(),all_compilation_and_finite_qualification_quiet=True,exact_binary_functional_pilot=True,physical_GPU=7,original_BF16_files=7552,additional_C16_files=2544),indent=2))
 s['phase']='packed-graph-contract';save()
 with(w/'packed-contract-v3.outer.log').open('x')as f:q=subprocess.run(['python3',str(w/'run-packed-contract-v3.py')],stdout=f,stderr=f)
 assert q.returncode==0
 s.update(phase='qualified-and-functional',finished_ns=time.time_ns());save()
 with(w/'experiment.queue.log').open('x')as f:q=subprocess.run(['python3',str(w/'queue-experiment-v19.py'),str(w),'B'],stdout=f,stderr=f)
 assert q.returncode==0
 s.update(phase='measured-and-audited',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
