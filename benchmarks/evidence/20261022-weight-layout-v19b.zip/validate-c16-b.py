from pathlib import Path
import json,hashlib,subprocess,time,os,traceback
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19b-20261022');r=w.parent/'riley-w0-a100-gpu67-20261019';old=w.parent/'riley-qkv-gateup-v214-20261019';a=w.parent/'riley-weight-layout-v19a-20261022';s=dict(phase='building',started_ns=time.time_ns(),completed=[]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(w/'c16-accuracy-state.json').write_text(json.dumps(s,indent=2))
def build(name,source,template,base_name):
 (w/(name+'.rs')).write_text(source);text=(w/template).read_text().replace(base_name,name);p=w/('build-'+name+'.py');p.write_text(text)
 with(w/(name+'-build.outer.log')).open('x')as f:q=subprocess.run(['python3',str(p)],stdout=f,stderr=f)
 assert q.returncode==0,(name,q.returncode)
try:
 save()
 t=(w/'teacher-bounded576.rs').read_text();assert t.count('(1..=32).map')==1;t=t.replace('(1..=32).map','(1..=16).map').replace('let mut remaining_live = 32usize','let mut remaining_live = 16usize').replace('R1..32 natural128','R1..16 natural128');build('teacher-c16-body576',t,'build-teacher-body.py','teacher-body')
 for src,name in [('teacher-mixed.rs','teacher-c16-mixed576'),('teacher-canonical.rs','teacher-c16-canonical576')]:
  t=(w/src).read_text();assert t.count('LlamaBatchMetadataConfig::new(copies, 512*copies.min(8),')==1 and t.count('assert_eq!(copies,32)')==1 and t.count('assert_eq!(mixed,31)')==1 and t.count('if no_output_prefill{992}else{1024}')==1
  t=t.replace('LlamaBatchMetadataConfig::new(copies, 512*copies.min(8),','LlamaBatchMetadataConfig::new(copies, 576,').replace('assert_eq!(copies,32)','assert_eq!(copies,16)').replace('assert_eq!(mixed,31)','assert_eq!(mixed,15)').replace('if no_output_prefill{992}else{1024}','if no_output_prefill{496}else{512}');build(name,t,'build-teacher-mixed.py','teacher-mixed')
 rows=[]
 for tag,exe,expected,no_output,source in [('c16-body576','teacher-c16-body576',1024,False,'teacher-bounded576-output'),('c16-mixed576','teacher-c16-mixed576',512,False,'teacher-mixed-output-r3'),('c16-no-output576','teacher-c16-mixed576',496,True,'teacher-mixed-no-output-r3'),('c16-canonical576','teacher-c16-canonical576',512,False,'teacher-canonical-output')]:
  s.update(phase='numerical',current=tag);save();output=w/(tag+'-output');env=dict(os.environ,LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(output),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES='16',RILEY_TEACHER_SHRINK='',RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH='segments-v1',RILEY_OWNED_BATCH='native-prefill-sm80-v5');env.pop('CUBLAS_WORKSPACE_CONFIG',None);env.pop('RILEY_MIXED_NO_OUTPUT_PREFILL',None)
  if no_output:env['RILEY_MIXED_NO_OUTPUT_PREFILL']='1'
  cmd=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/('observed-'+tag)),'--',str(w/exe),'--ignored','--exact','owned_batch_teacher_forced_logits_are_finite_and_reported','--nocapture','--test-threads=1'];(w/(tag+'.argv.json')).write_text(json.dumps(cmd,indent=2))
  with(w/(tag+'.launch.log')).open('x')as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=f)
  assert q.returncode==0,(tag,q.returncode);files=list(output.glob('*.bf16'));assert len(files)==expected,(tag,len(files));hashes={}
  for p in files:assert p.read_bytes()==(a/source/p.name).read_bytes(),p.name;hashes[p.name]=sha(p)
  meta=json.loads((output/'result.json').read_text());data=[x for m in meta['models']for c in m['cases']for x in c['rows']]
  if tag=='c16-body576':assert len(data)==512 and all(x['max_abs']==x['mean_abs']==0 for x in data)
  else:assert len(data)==expected and all(x['bytes_equal']and x['sha256']==x['HF_sha256']==x['native_sha256']for x in data)
  log=(w/('observed-'+tag+'.stdout')).read_text()+(w/('observed-'+tag+'.stderr')).read_text();assert 'RILEY_V19_PACKED_GATE_UP layers=32 bytes=3187671040'in log
  rows.append(dict(tag=tag,files=expected,source_scope='Additional capacity16/budget576 corpus; original capacity32 suite is separately required and unchanged. Same original natural128 tokens, native/HF reference bytes, 32steps, reversed/canonical/no-output output slots; only capacity and appropriate case-count assertions differ.',all_original_native_HF_bytes_equal=True,raw_file_sha256=hashes,binary_sha256=sha(w/exe)));s['completed'].append(tag);save()
 assert sum(x['files']for x in rows)==2544
 (w/'c16-byte-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),runs=rows,files=2544,reference_and_tolerance_unchanged=True),indent=2));s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
