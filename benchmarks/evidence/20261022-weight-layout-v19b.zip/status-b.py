from pathlib import Path
import json
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19b-20261022')
for n in ['pipeline-state.json','experiment-state.json']:
 p=w/n
 if p.exists(): print(n,p.read_text())
for c in [16,32]:
 p=w/f'runs/final-c{c}/result.json'
 if p.exists():
  a=json.loads(p.read_text());print('C',c,'keys',list(a));print('completed',[(x.get('repeat'),x.get('mode'),round(x.get('output_tok_s',0),2)) for x in a.get('results',[])])
