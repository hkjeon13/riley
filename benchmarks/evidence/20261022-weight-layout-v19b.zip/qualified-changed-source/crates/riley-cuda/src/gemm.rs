use std::cell::Cell;
use std::fmt;
use std::marker::PhantomData;
use std::ptr;
use std::sync::Arc;

use crate::error::{CudaError, CudaResult};
use crate::memory::CudaDeviceBuffer;
use crate::primitives::{CudaBufferSpan, CudaBufferSpanMut, CudaDType};
use crate::runtime::{
    ContextInner, CudaContext, CudaExecutionStream, CudaStream, ensure_same_context,
    execution_stream_mut,
};

use crate::error::{CudaErrorDomain, CudaErrorKind, CudaErrorStage};
#[cfg(feature = "cuda")]
use crate::ffi;

const BF16_BYTES: u64 = 2;
const GEMM_OFFSET_ALIGNMENT: u64 = 256;
const MAX_CUBLASLT_DIMENSION: u64 = 2_147_483_647;
/// Version of the fixed-contiguous-37-balanced reduction contract.
pub const FIXED37_REDUCTION_VERSION: u32 = 1;
/// Elements traversed by each ascending local reduction chunk.
pub const FIXED37_CHUNK_ELEMENTS: u32 = 37;
/// Maximum number of chunk partials accepted by the additive backend.
pub const FIXED37_MAX_CHUNK_COUNT: u32 = 4096;
/// Largest logical reduction axis accepted by the additive backend.
pub const FIXED37_MAX_REDUCTION_ELEMENTS: u64 =
    (FIXED37_CHUNK_ELEMENTS as u64) * (FIXED37_MAX_CHUNK_COUNT as u64);
#[cfg(feature = "cuda")]
const NATIVE_CUBLASLT_BACKEND_ID: u32 = 1;
#[cfg(feature = "cuda")]
const NATIVE_FIXED37_BACKEND_ID: u32 = 2;
#[cfg(feature = "cuda-cublas-gemm-probe")]
const NATIVE_CUBLAS_GEMM_PROBE_BACKEND_ID: u32 = 3;
#[cfg(feature = "cuda")]
const DETERMINISTIC_REQUIRED: u32 = 1;
#[cfg(feature = "cuda-cublas-gemm-probe")]
const CUBLAS_DEFAULT_MATH_MODE: i32 = 0;
#[cfg(feature = "cuda-cublas-gemm-probe")]
const CUBLAS_POINTER_MODE_HOST: i32 = 0;
#[cfg(feature = "cuda-cublas-gemm-probe")]
const CUBLAS_ATOMICS_NOT_ALLOWED: i32 = 0;
#[cfg(any(feature = "cuda", test))]
const REDUCTION_SCHEME_NONE: u32 = 0;
#[cfg(any(feature = "cuda", test))]
const REDUCTION_SCHEME_INPLACE: u32 = 1;
#[cfg(any(feature = "cuda", test))]
const REDUCTION_SCHEME_COMPUTE_TYPE: u32 = 2;
#[cfg(any(feature = "cuda", test))]
const REDUCTION_SCHEME_OUTPUT_TYPE: u32 = 4;

#[cfg(any(feature = "cuda", test))]
const fn is_deterministic_reduction_configuration(
    policy: CudaGemmReductionPolicy,
    split_k: u32,
    scheme: u32,
) -> bool {
    if split_k <= 1 {
        return scheme == REDUCTION_SCHEME_NONE;
    }
    match policy {
        CudaGemmReductionPolicy::StrictNoSplitV1 => false,
        CudaGemmReductionPolicy::AllowOutputTypeSplitKV1 => scheme == REDUCTION_SCHEME_OUTPUT_TYPE,
        CudaGemmReductionPolicy::AllowInPlaceAndOutputTypeSplitKV1 => {
            scheme == REDUCTION_SCHEME_INPLACE || scheme == REDUCTION_SCHEME_OUTPUT_TYPE
        }
        CudaGemmReductionPolicy::HfCompatibleBiasSplitKV1 => {
            scheme == REDUCTION_SCHEME_INPLACE || scheme == REDUCTION_SCHEME_COMPUTE_TYPE
                || scheme == REDUCTION_SCHEME_OUTPUT_TYPE
        }
    }
}

// A permissive prepare policy does not imply the selected algorithm split K.
#[cfg(any(feature = "cuda", test))]
const fn selected_graph_topology_supported(split_k: u32, scheme: u32) -> bool {
    split_k <= 1 && scheme == REDUCTION_SCHEME_NONE
}

#[cfg(test)]
mod selected_graph_topology_tests {
    #[test]
    fn selected_graph_rejects_split_or_reduction_topologies() {
        use super::selected_graph_topology_supported as supported;
        assert!(supported(0, 0));
        assert!(supported(1, 0));
        for (split, scheme) in [(2, 0), (2, 4), (2, 1), (1, 4), (1, 1), (0, u32::MAX)] {
            assert!(!supported(split, scheme));
        }
    }
}

/// Reviewed deterministic cuBLASLt reduction policy selected during prepare.
#[derive(Clone, Copy, Debug, Default, Eq, Hash, PartialEq)]
#[non_exhaustive]
pub enum CudaGemmReductionPolicy {
    /// Require split-K at most one with the `NONE` reduction scheme.
    #[default]
    StrictNoSplitV1,
    /// Also permit split-K greater than one with `OUTPUT_TYPE` reduction.
    AllowOutputTypeSplitKV1,
    /// Also permit reviewed `INPLACE` and `OUTPUT_TYPE` split-K reductions.
    ///
    /// cuBLASLt's `INPLACE` scheme uses output-type storage plus workspace
    /// counters to guarantee sequentiality. `OUTPUT_TYPE` stores output-type
    /// partials in workspace and reduces them in a separate deterministic
    /// step. This policy preserves either scheme when returned by the reviewed
    /// first heuristic instead of rewriting it to no-split.
    AllowInPlaceAndOutputTypeSplitKV1,
    /// Preserve checked HF bias-epilogue heuristics, including FP32
    /// `COMPUTE_TYPE` partial reduction. Only bias preparation admits it.
    /// Existing strict and output-type policies keep their original bounds.
    HfCompatibleBiasSplitKV1,
}

impl CudaGemmReductionPolicy {
    /// Stable diagnostic identifier.
    #[must_use]
    pub const fn id(self) -> &'static str {
        match self {
            Self::StrictNoSplitV1 => "strict-no-split-v1",
            Self::AllowOutputTypeSplitKV1 => "allow-output-type-split-k-v1",
            Self::AllowInPlaceAndOutputTypeSplitKV1 => "allow-in-place-and-output-type-split-k-v1",
            Self::HfCompatibleBiasSplitKV1 => "hf-compatible-bias-split-k-v1",
        }
    }

    #[cfg(feature = "cuda")]
    const fn abi_flags(self) -> u32 {
        match self {
            Self::StrictNoSplitV1 => 0,
            Self::AllowOutputTypeSplitKV1 => 1,
            Self::AllowInPlaceAndOutputTypeSplitKV1 => 3,
            Self::HfCompatibleBiasSplitKV1 => 7,
        }
    }
}

/// Exact dense GEMM contract accepted by the CUDA adapter.
///
/// The logical operation is row-major `Y[M, N] = X[M, K] * W[N, K]^T`.
/// Inputs, weights, and output are BF16, accumulation is F32, and deterministic
/// algorithm selection is mandatory. [`CudaPreparedGemm`] fixes the epilogue to
/// none. [`CudaPreparedBiasEpilogueGemm`] uses the same matrix contract with a
/// separate BF16 row-bias input and a cuBLASLt bias epilogue. The only selectable
/// detail is the reviewed reduction policy; strict no-split is the fail-closed
/// default.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub struct CudaGemmConfig {
    m: u64,
    n: u64,
    k: u64,
    max_workspace_bytes: u64,
    reduction_policy: CudaGemmReductionPolicy,
    bit_equivalent_selection: bool,
    input_bytes: u64,
    weight_bytes: u64,
    output_bytes: u64,
}

impl CudaGemmConfig {
    /// Creates a checked deterministic BF16/F32 GEMM configuration.
    ///
    /// `max_workspace_bytes` is a preparation-time cap. The exact selected
    /// workspace requirement is reported by [`CudaGemmAlgorithmMetadata`].
    ///
    /// # Errors
    ///
    /// Returns invalid-argument for a zero dimension and out-of-range if a
    /// required matrix byte length or the native workspace size overflows.
    pub fn new(m: u64, n: u64, k: u64, max_workspace_bytes: u64) -> CudaResult<Self> {
        const OPERATION: &str = "CudaGemmConfig::new";
        if m == 0 || n == 0 || k == 0 {
            return Err(CudaError::invalid_argument(
                OPERATION,
                "M, N, and K must all be non-zero",
            ));
        }
        if m > MAX_CUBLASLT_DIMENSION || n > MAX_CUBLASLT_DIMENSION || k > MAX_CUBLASLT_DIMENSION {
            return Err(CudaError::out_of_range(
                OPERATION,
                "M, N, and K must each fit the cuBLASLt signed 32-bit dimension range",
            ));
        }

        let max_native_workspace = u64::try_from(usize::MAX).unwrap_or(u64::MAX);
        if max_workspace_bytes > max_native_workspace {
            return Err(CudaError::out_of_range(
                OPERATION,
                "workspace cap exceeds the native size_t range",
            ));
        }

        let input_bytes = checked_bf16_matrix_bytes(m, k, "input")?;
        let weight_bytes = checked_bf16_matrix_bytes(n, k, "weight")?;
        let output_bytes = checked_bf16_matrix_bytes(m, n, "output")?;
        Ok(Self {
            m,
            n,
            k,
            max_workspace_bytes,
            reduction_policy: CudaGemmReductionPolicy::StrictNoSplitV1,
            bit_equivalent_selection: false,
            input_bytes,
            weight_bytes,
            output_bytes,
        })
    }

    /// Logical output row count.
    #[must_use]
    pub const fn m(self) -> u64 {
        self.m
    }

    /// Logical output column count.
    #[must_use]
    pub const fn n(self) -> u64 {
        self.n
    }

    /// Reduction dimension.
    #[must_use]
    pub const fn k(self) -> u64 {
        self.k
    }

    /// Maximum temporary bytes allowed during deterministic algorithm choice.
    #[must_use]
    pub const fn max_workspace_bytes(self) -> u64 {
        self.max_workspace_bytes
    }

    /// Returns a copy resolved to the reviewed deterministic reduction policy.
    #[must_use]
    pub const fn with_reduction_policy(mut self, policy: CudaGemmReductionPolicy) -> Self {
        self.reduction_policy = policy;
        self
    }

    /// Deterministic reduction policy used during native algorithm selection.
    #[must_use]
    pub const fn reduction_policy(self) -> CudaGemmReductionPolicy {
        self.reduction_policy
    }

    /// Lets an anchored plan replace the anchor algorithm with a listed
    /// configuration that reproduces the anchor's output bits for this exact
    /// shape. The native layer verifies the equality on a probe input during
    /// preparation and keeps the anchor algorithm otherwise.
    #[must_use]
    pub const fn with_bit_equivalent_selection(mut self, enabled: bool) -> Self {
        self.bit_equivalent_selection = enabled;
        self
    }

    /// Whether anchored preparation may pick a verified bit-equivalent algorithm.
    #[must_use]
    pub const fn bit_equivalent_selection(self) -> bool {
        self.bit_equivalent_selection
    }

    /// Exact required bytes for row-major BF16 `X[M, K]`.
    #[must_use]
    pub const fn input_bytes(self) -> u64 {
        self.input_bytes
    }

    /// Exact required bytes for row-major BF16 `W[N, K]`.
    #[must_use]
    pub const fn weight_bytes(self) -> u64 {
        self.weight_bytes
    }

    /// Exact required bytes for row-major BF16 `Y[M, N]`.
    #[must_use]
    pub const fn output_bytes(self) -> u64 {
        self.output_bytes
    }

    /// Exact required bytes for one BF16 row-bias vector `B[N]`.
    ///
    /// `CudaGemmConfig::new` has already bounded `N` to the native signed
    /// 32-bit range, so this multiplication cannot overflow `u64`.
    #[must_use]
    pub const fn bias_bytes(self) -> u64 {
        self.n * BF16_BYTES
    }

    /// Input storage type fixed by this adapter.
    #[must_use]
    pub const fn input_dtype(self) -> CudaDType {
        CudaDType::BF16
    }

    /// Weight storage type fixed by this adapter.
    #[must_use]
    pub const fn weight_dtype(self) -> CudaDType {
        CudaDType::BF16
    }

    /// Accumulation type fixed by this adapter.
    #[must_use]
    pub const fn accumulator_dtype(self) -> CudaDType {
        CudaDType::F32
    }

    /// Output storage type fixed by this adapter.
    #[must_use]
    pub const fn output_dtype(self) -> CudaDType {
        CudaDType::BF16
    }

    /// Whether algorithm selection is required to be deterministic.
    #[must_use]
    pub const fn deterministic(self) -> bool {
        true
    }
}

fn checked_bf16_matrix_bytes(
    rows: u64,
    columns: u64,
    matrix_name: &'static str,
) -> CudaResult<u64> {
    rows.checked_mul(columns)
        .and_then(|elements| elements.checked_mul(BF16_BYTES))
        .ok_or_else(|| {
            CudaError::out_of_range(
                "CudaGemmConfig::new",
                format!("{matrix_name} BF16 matrix byte length overflows u64"),
            )
        })
}

/// Immutable provenance for the cuBLASLt algorithm selected at preparation.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub struct CudaGemmAlgorithmMetadata {
    backend_id: u32,
    algorithm_id: i32,
    tile_id: u32,
    stages_id: u32,
    split_k: u32,
    reduction_scheme: u32,
    cta_swizzling: u32,
    custom_option: u32,
    deterministic: bool,
    workspace_bytes: u64,
    numerical_implementation_flags: u64,
    compute_capability_major: u32,
    compute_capability_minor: u32,
    runtime_version: i32,
    cublaslt_version: i32,
    m: u64,
    n: u64,
    k: u64,
}

impl CudaGemmAlgorithmMetadata {
    /// Stable backend implementation identifier for cuBLASLt.
    pub const CUBLASLT_BACKEND_ID: u32 = 1;

    /// Native backend implementation identifier.
    #[must_use]
    pub const fn backend_id(self) -> u32 {
        self.backend_id
    }

    /// cuBLASLt algorithm configuration identifier.
    #[must_use]
    pub const fn algorithm_id(self) -> i32 {
        self.algorithm_id
    }

    /// cuBLASLt tile identifier.
    #[must_use]
    pub const fn tile_id(self) -> u32 {
        self.tile_id
    }

    /// cuBLASLt pipeline-stages identifier.
    #[must_use]
    pub const fn stages_id(self) -> u32 {
        self.stages_id
    }

    /// Selected split-K count.
    #[must_use]
    pub const fn split_k(self) -> u32 {
        self.split_k
    }

    /// cuBLASLt reduction-scheme identifier.
    #[must_use]
    pub const fn reduction_scheme(self) -> u32 {
        self.reduction_scheme
    }

    /// Selected CTA swizzling value.
    #[must_use]
    pub const fn cta_swizzling(self) -> u32 {
        self.cta_swizzling
    }

    /// Selected backend-specific custom option.
    #[must_use]
    pub const fn custom_option(self) -> u32 {
        self.custom_option
    }

    /// Whether the selected algorithm satisfies the deterministic contract.
    #[must_use]
    pub const fn deterministic(self) -> bool {
        self.deterministic
    }

    /// Exact U8 workspace bytes required by every execution of this plan.
    #[must_use]
    pub const fn workspace_bytes(self) -> u64 {
        self.workspace_bytes
    }

    /// cuBLASLt numerical implementation capability flags.
    #[must_use]
    pub const fn numerical_implementation_flags(self) -> u64 {
        self.numerical_implementation_flags
    }

    /// Compute capability used during algorithm selection.
    #[must_use]
    pub const fn compute_capability(self) -> (u32, u32) {
        (self.compute_capability_major, self.compute_capability_minor)
    }

    /// CUDA Runtime version used during algorithm selection.
    #[must_use]
    pub const fn runtime_version(self) -> i32 {
        self.runtime_version
    }

    /// cuBLASLt version used during algorithm selection.
    #[must_use]
    pub const fn cublaslt_version(self) -> i32 {
        self.cublaslt_version
    }

    /// Prepared `(M, N, K)` dimensions recorded by native code.
    #[must_use]
    pub const fn dimensions(self) -> (u64, u64, u64) {
        (self.m, self.n, self.k)
    }
}

/// Borrowed buffers for one synchronous prepared GEMM execution.
///
/// Every span length must exactly match the prepared shape. All byte offsets
/// must be 256-byte aligned, all provided buffers must be distinct and owned
/// by the plan's context, and workspace must be U8. `workspace` may be `None`
/// only when the selected workspace requirement is zero.
#[derive(Debug)]
pub struct GemmParams<'a> {
    /// Row-major BF16 `X[M, K]`.
    pub input: CudaBufferSpan<'a>,
    /// Row-major BF16 `W[N, K]` consumed logically transposed.
    pub weight: CudaBufferSpan<'a>,
    /// Row-major BF16 `Y[M, N]`.
    pub output: CudaBufferSpanMut<'a>,
    /// Exact selected U8 workspace, or none when zero bytes were selected.
    pub workspace: Option<CudaBufferSpanMut<'a>>,
}

/// Borrowed buffers for one synchronous cuBLASLt BF16 bias-epilogue GEMM.
///
/// This is an opt-in numerical contract for qualification only. cuBLASLt adds
/// `bias[N]` as part of its epilogue, which can round differently from the
/// strict standalone GEMM followed by [`crate::row_bias_add_in_place`]. Every
/// span length must exactly match the prepared shape. All byte offsets must be
/// 256-byte aligned, all provided buffers must be distinct and owned by the
/// plan's context, and workspace must be U8. `workspace` may be `None` only
/// when the selected workspace requirement is zero.
#[derive(Debug)]
pub struct BiasGemmParams<'a> {
    /// Row-major BF16 `X[M, K]`.
    pub input: CudaBufferSpan<'a>,
    /// Row-major BF16 `W[N, K]` consumed logically transposed.
    pub weight: CudaBufferSpan<'a>,
    /// BF16 row-bias `B[N]` broadcast into every output row by cuBLASLt.
    pub bias: CudaBufferSpan<'a>,
    /// Row-major BF16 `Y[M, N]`.
    pub output: CudaBufferSpanMut<'a>,
    /// Exact selected U8 workspace, or none when zero bytes were selected.
    pub workspace: Option<CudaBufferSpanMut<'a>>,
}

/// Owning immutable cuBLASLt execution plan.
///
/// A plan retains its CUDA context and can move between host threads, but is
/// deliberately `!Sync`. Execution requires `&mut self` and returns only after
/// the explicit stream has synchronized, so all borrowed buffers can be reused
/// immediately after `Ok(())`.
pub struct CudaPreparedGemm {
    #[cfg(feature = "cuda")]
    native: ffi::GemmPlanHandle,
    // Native must close before releasing the context lease.
    context: Arc<ContextInner>,
    config: CudaGemmConfig,
    algorithm: CudaGemmAlgorithmMetadata,
    poisoned: bool,
    _not_sync: PhantomData<Cell<()>>,
}

/// Owning opt-in cuBLASLt bias-epilogue execution plan.
///
/// The native plan is deliberately separate from [`CudaPreparedGemm`]. It
/// preserves the strict GEMM API and graph contracts while qualifying the
/// external fused-bias rounding contract. A plan retains its CUDA context and
/// can move between host threads, but is deliberately `!Sync`. Execution
/// requires `&mut self` and synchronizes the explicit stream before returning.
pub struct CudaPreparedBiasEpilogueGemm {
    #[cfg(feature = "cuda")]
    native: ffi::BiasGemmPlanHandle,
    // Native must close before releasing the context lease.
    context: Arc<ContextInner>,
    config: CudaGemmConfig,
    algorithm: CudaGemmAlgorithmMetadata,
    poisoned: bool,
    _not_sync: PhantomData<Cell<()>>,
}

impl fmt::Debug for CudaPreparedGemm {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("CudaPreparedGemm")
            .field("device_ordinal", &self.context.ordinal)
            .field("config", &self.config)
            .field("algorithm", &self.algorithm)
            .field("poisoned", &self.poisoned)
            .finish_non_exhaustive()
    }
}

impl fmt::Debug for CudaPreparedBiasEpilogueGemm {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("CudaPreparedBiasEpilogueGemm")
            .field("device_ordinal", &self.context.ordinal)
            .field("config", &self.config)
            .field("algorithm", &self.algorithm)
            .field("poisoned", &self.poisoned)
            .finish_non_exhaustive()
    }
}

#[cfg(feature = "cuda-cublas-gemm-probe")]
impl CudaContext {
    /// Prepares the isolated direct-cuBLAS BF16 arithmetic qualifier.
    ///
    /// The probe accepts only the strict no-split config surface, owns no
    /// caller workspace, rejects command batches/graphs natively, and is not
    /// wired into model dispatch. It is available solely in test builds that
    /// opt into `cuda-cublas-gemm-probe`.
    ///
    /// # Errors
    ///
    /// Returns not-supported for a non-strict reduction policy or any native
    /// device/library capability failure. A successful prepare is not a
    /// full-forward, serving, or performance qualification.
    pub fn prepare_cublas_gemm_probe(
        &self,
        config: CudaGemmConfig,
    ) -> CudaResult<CudaPreparedCublasGemmProbe> {
        self.prepare_classic_hf_gemm(config, false)
    }

    /// Prepares owned HF arithmetic with command-batch resource lifetimes.
    ///
    /// Outside a batch execution synchronizes as usual. Inside a batch the
    /// plan and all device buffers stay leased until batch completion; graph
    /// capture remains rejected. GEMM arithmetic and row grouping are unchanged.
    ///
    /// # Errors
    /// Returns the same strict configuration and device errors as the probe.
    pub fn prepare_owned_hf_gemm(
        &self,
        config: CudaGemmConfig,
    ) -> CudaResult<CudaPreparedCublasGemmProbe> {
        self.prepare_classic_hf_gemm(config, true)
    }

    fn prepare_classic_hf_gemm(
        &self,
        config: CudaGemmConfig,
        owned_command_batches: bool,
    ) -> CudaResult<CudaPreparedCublasGemmProbe> {
        const OPERATION: &str = "CudaContext::prepare_cublas_gemm_probe";
        if config.reduction_policy != CudaGemmReductionPolicy::StrictNoSplitV1 {
            return Err(fixed37_not_supported(
                OPERATION,
                "the direct-cuBLAS qualifier accepts only strict-no-split-v1 policy",
            ));
        }
        let native = ffi::CublasGemmProbePlanHandle::create(
            &self.inner.native,
            config.m,
            config.n,
            config.k,
            config.max_workspace_bytes,
            owned_command_batches,
        )?;
        let metadata = CublasGemmProbeMetadata::from_native(config, native.info()?)?;
        Ok(CudaPreparedCublasGemmProbe {
            native,
            context: Arc::clone(&self.inner),
            config,
            metadata,
            poisoned: false,
            owned_command_batches,
            _not_sync: PhantomData,
        })
    }
}

impl CudaContext {
    /// Prepares one deterministic cuBLASLt algorithm and all of its immutable
    /// descriptors for allocation-free repeated execution.
    ///
    /// # Errors
    ///
    /// Returns an actionable unavailable error when CUDA support is disabled,
    /// or a translated validation, capability, allocation, driver, runtime, or
    /// cuBLASLt preparation error.
    pub fn prepare_gemm(&self, config: CudaGemmConfig) -> CudaResult<CudaPreparedGemm> {
        #[cfg(feature = "cuda")]
        {
            let native = ffi::GemmPlanHandle::create(
                &self.inner.native,
                config.m,
                config.n,
                config.k,
                config.max_workspace_bytes,
                config.reduction_policy.abi_flags(),
                config.bit_equivalent_selection,
            )?;
            let algorithm = CudaGemmAlgorithmMetadata::from_native(config, native.info()?)?;
            Ok(CudaPreparedGemm {
                native,
                context: Arc::clone(&self.inner),
                config,
                algorithm,
                poisoned: false,
                _not_sync: PhantomData,
            })
        }
        #[cfg(not(feature = "cuda"))]
        {
            let _ = config;
            Err(CudaError::unavailable("CudaContext::prepare_gemm"))
        }
    }

    /// Prepares a separate deterministic cuBLASLt BF16 bias-epilogue plan.
    ///
    /// `preparation_bias` is verified during cold-path descriptor and
    /// algorithm qualification. Each [`CudaPreparedBiasEpilogueGemm::execute`]
    /// call supplies its own BF16 bias span; native code does not retain this
    /// preparation span after this method returns. The current qualification
    /// surface accepts only the strict no-split reduction policy and supplies
    /// no CUDA-graph integration.
    ///
    /// # Errors
    ///
    /// Returns invalid-argument for a foreign, misaligned, mistyped, or
    /// incorrectly sized bias span; not-supported for a non-strict reduction
    /// policy; or an actionable CUDA preparation error.
    pub fn prepare_bias_epilogue_gemm(
        &self,
        config: CudaGemmConfig,
        preparation_bias: CudaBufferSpan<'_>,
    ) -> CudaResult<CudaPreparedBiasEpilogueGemm> {
        const OPERATION: &str = "CudaContext::prepare_bias_epilogue_gemm";
        if config.reduction_policy != CudaGemmReductionPolicy::StrictNoSplitV1 {
            return Err(CudaError::new(
                CudaErrorKind::NotSupported,
                CudaErrorDomain::Rust,
                CudaErrorStage::Validation,
                0,
                OPERATION,
                "bias-epilogue qualification accepts only the strict-no-split-v1 reduction policy",
            ));
        }
        self.prepare_bias_epilogue_gemm_unchecked(config, preparation_bias, OPERATION, false)
    }

    /// Prepares the isolated HF-compatible cuBLASLt BIAS qualifier.
    ///
    /// The profile permits reviewed in-place split-K reduction because the
    /// pinned PyTorch `torch.addmm(vector_bias, X, W.T)` trace selects that
    /// topology. It is available only with `cuda-cublas-gemm-probe`, has no
    /// graph or serving-selector integration, and must pass its exact P2051
    /// quality receipt before any production admission is considered.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    pub fn prepare_hf_compatible_bias_epilogue_probe(
        &self,
        config: CudaGemmConfig,
        preparation_bias: CudaBufferSpan<'_>,
    ) -> CudaResult<CudaPreparedBiasEpilogueGemm> {
        const OPERATION: &str = "CudaContext::prepare_hf_compatible_bias_epilogue_probe";
        if !matches!(config.reduction_policy,
            CudaGemmReductionPolicy::AllowInPlaceAndOutputTypeSplitKV1 |
            CudaGemmReductionPolicy::HfCompatibleBiasSplitKV1) {
            return Err(CudaError::new(
                CudaErrorKind::NotSupported,
                CudaErrorDomain::Rust,
                CudaErrorStage::Validation,
                0,
                OPERATION,
                "the HF-compatible qualifier requires an explicit HF bias reduction policy",
            ));
        }
        self.prepare_bias_epilogue_gemm_unchecked(config, preparation_bias, OPERATION, false)
    }

    /// Prepares a bounded SM89 Q/K/V batch with each matrix kept at M=1.
    /// Returns NotSupported when the device or frozen algorithm is unqualified.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    pub fn prepare_hf_bias_singleton_batch(
        &self, config: CudaGemmConfig, preparation_bias: CudaBufferSpan<'_>,
    ) -> CudaResult<CudaPreparedBiasEpilogueGemm> {
        self.prepare_bias_epilogue_gemm_unchecked(config,preparation_bias,
            "CudaContext::prepare_hf_bias_singleton_batch",true)
    }

    fn prepare_bias_epilogue_gemm_unchecked(
        &self,
        config: CudaGemmConfig,
        preparation_bias: CudaBufferSpan<'_>,
        operation: &'static str,
        singleton_batch: bool,
    ) -> CudaResult<CudaPreparedBiasEpilogueGemm> {
        ensure_same_context(
            &self.inner,
            preparation_bias.buffer().context_owner(),
            operation,
        )?;
        validate_span(
            operation,
            preparation_bias.buffer(),
            preparation_bias.dtype(),
            preparation_bias.byte_offset(),
            preparation_bias.byte_len(),
            CudaDType::BF16,
            config.bias_bytes(),
            "preparation_bias",
        )?;

        #[cfg(feature = "cuda")]
        {
            let native = ffi::BiasGemmPlanHandle::create(
                &self.inner.native,
                config.m,
                config.n,
                config.k,
                config.max_workspace_bytes,
                config.reduction_policy.abi_flags(),
                preparation_bias.raw(),
                singleton_batch,
            )?;
            let algorithm = CudaGemmAlgorithmMetadata::from_native(config, native.info()?)?;
            Ok(CudaPreparedBiasEpilogueGemm {
                native,
                context: Arc::clone(&self.inner),
                config,
                algorithm,
                poisoned: false,
                _not_sync: PhantomData,
            })
        }
        #[cfg(not(feature = "cuda"))]
        {
            let _ = (config, preparation_bias);
            Err(CudaError::unavailable(operation))
        }
    }

    /// Prepares an exact-M child GEMM that preserves an existing plan's
    /// cuBLASLt reduction topology.
    ///
    /// This is intended for shape-bucketed execution where changing only M
    /// must not permit cuBLASLt to select a numerically different heuristic.
    /// The anchor must belong to this context and use the same GEMM contract
    /// other than M. Native validates the copied opaque algorithm against the
    /// child descriptors and fails closed without a heuristic fallback if that
    /// algorithm cannot execute for the requested shape.
    ///
    /// # Errors
    ///
    /// Returns invalid-state for a foreign or poisoned anchor; returns
    /// not-supported when the anchor algorithm is not valid for `config`.
    pub fn prepare_gemm_anchored(
        &self,
        config: CudaGemmConfig,
        anchor: &CudaPreparedGemm,
    ) -> CudaResult<CudaPreparedGemm> {
        const OPERATION: &str = "CudaContext::prepare_gemm_anchored";
        ensure_same_context(&self.inner, &anchor.context, OPERATION)?;
        if anchor.poisoned {
            return Err(CudaError::invalid_state(
                OPERATION,
                "the anchor GEMM plan was poisoned by a prior native execution failure",
            ));
        }
        #[cfg(feature = "cuda")]
        {
            let native = ffi::GemmPlanHandle::create_anchored(
                &self.inner.native,
                config.m,
                config.n,
                config.k,
                config.max_workspace_bytes,
                config.reduction_policy.abi_flags(),
                config.bit_equivalent_selection,
                &anchor.native,
            )?;
            let algorithm = CudaGemmAlgorithmMetadata::from_native(config, native.info()?)?;
            Ok(CudaPreparedGemm {
                native,
                context: Arc::clone(&self.inner),
                config,
                algorithm,
                poisoned: false,
                _not_sync: PhantomData,
            })
        }
        #[cfg(not(feature = "cuda"))]
        {
            let _ = config;
            Err(CudaError::unavailable(OPERATION))
        }
    }
}

impl CudaPreparedGemm {
    #[cfg(feature = "cuda")]
    pub(crate) fn graph_resource_handle(&self) -> CudaResult<&ffi::GemmPlanHandle> {
        if self.poisoned {
            return Err(CudaError::invalid_state(
                "reserve GEMM resource",
                "plan is poisoned",
            ));
        }
        Ok(&self.native)
    }

    /// Exact logical and storage contract used to prepare this plan.
    #[must_use]
    pub const fn config(&self) -> CudaGemmConfig {
        self.config
    }

    /// Immutable selected algorithm and environment provenance.
    #[must_use]
    pub const fn algorithm_metadata(&self) -> CudaGemmAlgorithmMetadata {
        self.algorithm
    }

    /// Device ordinal retained by this plan.
    #[must_use]
    pub fn device_ordinal(&self) -> u32 {
        self.context.ordinal
    }

    /// Whether a prior native execution failed and permanently disabled reuse
    /// of this safe plan wrapper.
    #[must_use]
    pub const fn is_poisoned(&self) -> bool {
        self.poisoned
    }

    /// Validates the exact by-value resource bundle admitted by C05-21's
    /// capture-only canonical cuBLASLt graph. This is deliberately separate
    /// from eager [`Self::execute`]: graph capture retains the plan and all
    /// four fixed allocations across replay and therefore admits neither
    /// spans, offsets, workspace omission, non-strict reduction, nor a
    /// poisoned plan.
    #[cfg(feature = "cuda")]
    pub(crate) fn validate_canonical_graph_capture(
        &self,
        stream: &CudaStream,
        input: &CudaDeviceBuffer,
        weight: &CudaDeviceBuffer,
        output: &CudaDeviceBuffer,
        workspace: &CudaDeviceBuffer,
        operation: &'static str,
    ) -> CudaResult<()> {
        if self.poisoned {
            return Err(CudaError::invalid_state(
                operation,
                "the canonical GEMM graph cannot retain a plan poisoned by a prior native execution failure",
            ));
        }
        if self.config.reduction_policy != CudaGemmReductionPolicy::StrictNoSplitV1 {
            return Err(CudaError::new(
                CudaErrorKind::NotSupported,
                CudaErrorDomain::Rust,
                CudaErrorStage::Validation,
                0,
                operation,
                "the canonical GEMM graph admits only the strict-no-split-v1 reduction policy",
            ));
        }
        if self.algorithm.backend_id != NATIVE_CUBLASLT_BACKEND_ID
            || !self.algorithm.deterministic
            || self.algorithm.dimensions() != (self.config.m, self.config.n, self.config.k)
        {
            return Err(CudaError::new(
                CudaErrorKind::Internal,
                CudaErrorDomain::Internal,
                CudaErrorStage::Validation,
                0,
                operation,
                "the prepared GEMM metadata does not describe one canonical deterministic cuBLASLt plan",
            ));
        }

        ensure_same_context(&self.context, &stream.context, operation)?;
        let buffers = [
            ("input", input, self.config.input_bytes),
            ("weight", weight, self.config.weight_bytes),
            ("output", output, self.config.output_bytes),
            ("workspace", workspace, self.algorithm.workspace_bytes),
        ];
        for (name, buffer, expected_byte_len) in buffers {
            ensure_same_context(&self.context, buffer.context_owner(), operation)?;
            buffer.ensure_idle_for_operation(operation)?;
            if buffer.byte_len() != expected_byte_len {
                return Err(CudaError::out_of_range(
                    operation,
                    format!(
                        "canonical GEMM {name} allocation must be exactly {expected_byte_len} bytes, got {}",
                        buffer.byte_len()
                    ),
                ));
            }
        }
        let buffer_handles = [
            ("input", input.native_handle()),
            ("weight", weight.native_handle()),
            ("output", output.native_handle()),
            ("workspace", workspace.native_handle()),
        ];
        for (index, (left_name, left)) in buffer_handles.iter().enumerate() {
            for (right_name, right) in buffer_handles.iter().skip(index + 1) {
                if left.same_allocation(right) {
                    return Err(CudaError::invalid_argument(
                        operation,
                        format!(
                            "canonical GEMM {left_name} and {right_name} must be distinct fixed device allocations"
                        ),
                    ));
                }
            }
        }
        Ok(())
    }

    /// Additive selected-plan contract; preserves policy and algorithm verbatim.
    #[cfg(feature = "cuda")]
    pub(crate) fn validate_selected_no_split_graph_capture(
        &self,
        stream: &CudaStream,
        input: &CudaDeviceBuffer,
        weight: &CudaDeviceBuffer,
        output: &CudaDeviceBuffer,
        workspace: Option<&CudaDeviceBuffer>,
        operation: &'static str,
    ) -> CudaResult<()> {
        if self.poisoned {
            return Err(CudaError::invalid_state(operation, "GEMM plan is poisoned"));
        }
        if !selected_graph_topology_supported(
            self.algorithm.split_k,
            self.algorithm.reduction_scheme,
        ) {
            return Err(CudaError::new(
                CudaErrorKind::NotSupported,
                CudaErrorDomain::Rust,
                CudaErrorStage::Validation,
                0,
                operation,
                "selected graph requires effective no-split topology",
            ));
        }
        if self.algorithm.backend_id != NATIVE_CUBLASLT_BACKEND_ID
            || !self.algorithm.deterministic
            || self.algorithm.dimensions() != (self.config.m, self.config.n, self.config.k)
        {
            return Err(CudaError::invalid_state(
                operation,
                "selected GEMM metadata mismatch",
            ));
        }
        ensure_same_context(&self.context, &stream.context, operation)?;
        let buffers = [
            (Some(input), self.config.input_bytes, false),
            (Some(weight), self.config.weight_bytes, false),
            (Some(output), self.config.output_bytes, false),
            (workspace, self.algorithm.workspace_bytes, true),
        ];
        for (index, (buffer, required, parent)) in buffers.iter().enumerate() {
            let Some(buffer) = buffer else {
                if *required != 0 {
                    return Err(CudaError::out_of_range(
                        operation,
                        "required workspace missing",
                    ));
                }
                continue;
            };
            ensure_same_context(&self.context, buffer.context_owner(), operation)?;
            buffer.ensure_idle_for_operation(operation)?;
            if if *parent {
                buffer.byte_len() < *required
            } else {
                buffer.byte_len() != *required
            } {
                return Err(CudaError::out_of_range(
                    operation,
                    "selected GEMM buffer size mismatch",
                ));
            }
            for (other, _, _) in &buffers[..index] {
                if other.is_some_and(|other| {
                    buffer
                        .native_handle()
                        .same_allocation(other.native_handle())
                }) {
                    return Err(CudaError::invalid_argument(
                        operation,
                        "selected GEMM allocations must be distinct",
                    ));
                }
            }
        }
        Ok(())
    }

    #[cfg(feature = "cuda")]
    pub(crate) fn begin_selected_no_split_graph_capture_native(
        &self,
        stream: &mut CudaStream,
        input: &CudaDeviceBuffer,
        weight: &CudaDeviceBuffer,
        output: &CudaDeviceBuffer,
        workspace: Option<&CudaDeviceBuffer>,
        mode: u32,
    ) -> CudaResult<ffi::GraphCaptureHandle> {
        stream
            .native
            .begin_graph_selected_no_split_gemm_bf16_capture(
                &self.native,
                input.native_handle(),
                weight.native_handle(),
                output.native_handle(),
                workspace.map(CudaDeviceBuffer::native_handle),
                mode,
            )
    }

    /// Enters native C05-21 capture only after
    /// [`Self::validate_canonical_graph_capture`] has completed. Native repeats
    /// the immutable plan/allocation checks because raw callers can bypass the
    /// Rust boundary; no eager synchronization or plan mutation occurs here.
    #[cfg(feature = "cuda")]
    pub(crate) fn begin_canonical_graph_capture_native(
        &self,
        stream: &mut CudaStream,
        input: &CudaDeviceBuffer,
        weight: &CudaDeviceBuffer,
        output: &CudaDeviceBuffer,
        workspace: &CudaDeviceBuffer,
        mode: u32,
    ) -> CudaResult<ffi::GraphCaptureHandle> {
        stream.native.begin_graph_canonical_gemm_bf16_capture(
            &self.native,
            input.native_handle(),
            weight.native_handle(),
            output.native_handle(),
            workspace.native_handle(),
            mode,
        )
    }

    /// Enters native C05-22 capture after the graph layer proves that the
    /// fixed canonical RMSNorm output is the exact GEMM input allocation.
    /// The native boundary repeats every immutable allocation, shape, and
    /// strict-plan check because raw callers can bypass the Rust owner.
    #[cfg(feature = "cuda")]
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn begin_canonical_rms_norm_gemm_graph_capture_native(
        &self,
        stream: &mut CudaStream,
        rms_norm_input: &CudaDeviceBuffer,
        rms_norm_weight: &CudaDeviceBuffer,
        rms_norm_output: &CudaDeviceBuffer,
        gemm_weight: &CudaDeviceBuffer,
        gemm_output: &CudaDeviceBuffer,
        gemm_workspace: &CudaDeviceBuffer,
        row_count: u64,
        hidden_size: u64,
        epsilon: f32,
        mode: u32,
    ) -> CudaResult<ffi::GraphCaptureHandle> {
        stream
            .native
            .begin_graph_canonical_rms_norm_gemm_bf16_capture(
                &self.native,
                rms_norm_input.native_handle(),
                rms_norm_weight.native_handle(),
                rms_norm_output.native_handle(),
                gemm_weight.native_handle(),
                gemm_output.native_handle(),
                gemm_workspace.native_handle(),
                row_count,
                hidden_size,
                epsilon,
                mode,
            )
    }

    /// Executes the prepared GEMM and synchronizes the same explicit stream.
    ///
    /// The successful repeated path performs no host or device allocation.
    /// A native execution error poisons this wrapper conservatively; native
    /// active-use guards independently prevent buffer, stream, or plan reuse
    /// when completion or context restoration could not be confirmed.
    ///
    /// # Errors
    ///
    /// Returns before entering native code for dtype, exact-size, alignment,
    /// context, alias, workspace, busy-buffer, or poisoned-plan violations.
    /// Native launch, cuBLASLt, synchronization, and restoration failures are
    /// translated with their status domain and lifecycle stage.
    pub fn execute<S: CudaExecutionStream + ?Sized>(
        &mut self,
        params: &mut GemmParams<'_>,
        stream: &mut S,
    ) -> CudaResult<()> {
        const OPERATION: &str = "CudaPreparedGemm::execute";
        let stream = execution_stream_mut(stream);
        if self.poisoned {
            return Err(CudaError::invalid_state(
                OPERATION,
                "the GEMM plan was poisoned by a prior native execution failure",
            ));
        }
        self.validate_execution(params, stream)?;

        #[cfg(feature = "cuda")]
        {
            let workspace = match params.workspace.as_ref() {
                Some(workspace) => workspace.raw(),
                None => params.output.buffer().native_handle().span(
                    ffi::DTYPE_U8,
                    params.output.byte_offset(),
                    0,
                ),
            };
            let result = self.native.execute(
                params.input.raw(),
                params.weight.raw(),
                params.output.raw(),
                workspace,
                &mut stream.native,
            );
            if result.is_err() {
                self.poisoned = true;
            }
            result
        }
        #[cfg(not(feature = "cuda"))]
        {
            let _ = (params, stream);
            Err(CudaError::unavailable("CudaPreparedGemm::execute"))
        }
    }

    /// Explicitly closes the prepared plan.
    ///
    /// A poisoned wrapper refuses to report a successful explicit close. Its
    /// private native owner still performs best-effort fail-closed cleanup on
    /// drop; ambiguous native resources remain retained rather than becoming
    /// reachable through a stale handle.
    ///
    /// # Errors
    ///
    /// Returns invalid-state for a poisoned plan, unavailable without CUDA, or
    /// a translated native descriptor/context destruction error.
    pub fn close(self) -> CudaResult<()> {
        #[cfg(feature = "cuda")]
        {
            let mut this = self;
            if this.poisoned {
                return Err(CudaError::invalid_state(
                    "CudaPreparedGemm::close",
                    "a poisoned GEMM plan cannot be explicitly reused or reported as cleanly closed",
                ));
            }
            this.native.close()
        }
        #[cfg(not(feature = "cuda"))]
        {
            Err(CudaError::unavailable("CudaPreparedGemm::close"))
        }
    }

    fn validate_execution(&self, params: &GemmParams<'_>, stream: &CudaStream) -> CudaResult<()> {
        const OPERATION: &str = "CudaPreparedGemm::execute";
        ensure_same_context(&self.context, &stream.context, OPERATION)?;

        validate_span(
            OPERATION,
            params.input.buffer(),
            params.input.dtype(),
            params.input.byte_offset(),
            params.input.byte_len(),
            CudaDType::BF16,
            self.config.input_bytes,
            "input",
        )?;
        validate_span(
            OPERATION,
            params.weight.buffer(),
            params.weight.dtype(),
            params.weight.byte_offset(),
            params.weight.byte_len(),
            CudaDType::BF16,
            self.config.weight_bytes,
            "weight",
        )?;
        validate_span(
            OPERATION,
            params.output.buffer(),
            params.output.dtype(),
            params.output.byte_offset(),
            params.output.byte_len(),
            CudaDType::BF16,
            self.config.output_bytes,
            "output",
        )?;

        let workspace_bytes = self.algorithm.workspace_bytes;
        match params.workspace.as_ref() {
            Some(workspace) => validate_span(
                OPERATION,
                workspace.buffer(),
                workspace.dtype(),
                workspace.byte_offset(),
                workspace.byte_len(),
                CudaDType::U8,
                workspace_bytes,
                "workspace",
            )?,
            None if workspace_bytes == 0 => {}
            None => {
                return Err(CudaError::invalid_argument(
                    OPERATION,
                    format!(
                        "the selected algorithm requires an exact {workspace_bytes}-byte U8 workspace"
                    ),
                ));
            }
        }

        let required_buffers = [
            ("input", params.input.buffer()),
            ("weight", params.weight.buffer()),
            ("output", params.output.buffer()),
        ];
        for (_, buffer) in required_buffers {
            ensure_same_context(&self.context, buffer.context_owner(), OPERATION)?;
        }
        ensure_distinct_buffers(&required_buffers, OPERATION)?;

        if let Some(workspace) = params.workspace.as_ref() {
            let workspace_buffer = workspace.buffer();
            ensure_same_context(&self.context, workspace_buffer.context_owner(), OPERATION)?;
            for (name, buffer) in required_buffers {
                if ptr::eq(buffer, workspace_buffer) {
                    return Err(CudaError::invalid_argument(
                        OPERATION,
                        format!("workspace aliases the {name} device-buffer handle"),
                    ));
                }
            }
        }
        Ok(())
    }
}

impl CudaPreparedBiasEpilogueGemm {
    /// Exact logical and storage contract used to prepare this plan.
    #[must_use]
    pub const fn config(&self) -> CudaGemmConfig {
        self.config
    }

    /// Immutable selected algorithm and environment provenance.
    #[must_use]
    pub const fn algorithm_metadata(&self) -> CudaGemmAlgorithmMetadata {
        self.algorithm
    }

    /// Device ordinal retained by this plan.
    #[must_use]
    pub fn device_ordinal(&self) -> u32 {
        self.context.ordinal
    }

    /// Whether a prior native execution failed and permanently disabled reuse
    /// of this safe plan wrapper.
    #[must_use]
    pub const fn is_poisoned(&self) -> bool {
        self.poisoned
    }

    /// Executes the prepared cuBLASLt BF16 bias-epilogue GEMM and synchronizes
    /// the same explicit stream.
    ///
    /// This qualification-only plan has no CUDA-graph resource interface. A
    /// successful repeated path performs no host or device allocation. A
    /// native execution error poisons this wrapper conservatively.
    ///
    /// # Errors
    ///
    /// Returns before entering native code for dtype, exact-size, alignment,
    /// context, alias, workspace, busy-buffer, or poisoned-plan violations.
    /// Native launch, cuBLASLt, synchronization, and restoration failures are
    /// translated with their status domain and lifecycle stage.
    pub fn execute<S: CudaExecutionStream + ?Sized>(
        &mut self,
        params: &mut BiasGemmParams<'_>,
        stream: &mut S,
    ) -> CudaResult<()> {
        const OPERATION: &str = "CudaPreparedBiasEpilogueGemm::execute";
        let stream = execution_stream_mut(stream);
        if self.poisoned {
            return Err(CudaError::invalid_state(
                OPERATION,
                "the bias-epilogue GEMM plan was poisoned by a prior native execution failure",
            ));
        }
        self.validate_execution(params, stream)?;

        #[cfg(feature = "cuda")]
        {
            let workspace = match params.workspace.as_ref() {
                Some(workspace) => workspace.raw(),
                None => params.output.buffer().native_handle().span(
                    ffi::DTYPE_U8,
                    params.output.byte_offset(),
                    0,
                ),
            };
            let result = self.native.execute(
                params.input.raw(),
                params.weight.raw(),
                params.bias.raw(),
                params.output.raw(),
                workspace,
                &mut stream.native,
            );
            if result.is_err() {
                self.poisoned = true;
            }
            result
        }
        #[cfg(not(feature = "cuda"))]
        {
            let _ = (params, stream);
            Err(CudaError::unavailable(OPERATION))
        }
    }

    /// Explicitly closes the qualification-only prepared plan.
    ///
    /// A poisoned wrapper refuses to report a successful explicit close. The
    /// fused-bias plan is deliberately not graph-capture capable, so callers
    /// must close it outside an active graph capture.
    pub fn close(self) -> CudaResult<()> {
        #[cfg(feature = "cuda")]
        {
            let mut this = self;
            if this.poisoned {
                return Err(CudaError::invalid_state(
                    "CudaPreparedBiasEpilogueGemm::close",
                    "a poisoned bias-epilogue GEMM plan cannot be explicitly reused or reported as cleanly closed",
                ));
            }
            if crate::graph::has_active_graph_capture() {
                return Err(CudaError::invalid_state(
                    "CudaPreparedBiasEpilogueGemm::close",
                    "bias-epilogue GEMM plans must close outside an active CUDA graph capture",
                ));
            }
            this.native.close()
        }
        #[cfg(not(feature = "cuda"))]
        {
            Err(CudaError::unavailable(
                "CudaPreparedBiasEpilogueGemm::close",
            ))
        }
    }

    fn validate_execution(
        &self,
        params: &BiasGemmParams<'_>,
        stream: &CudaStream,
    ) -> CudaResult<()> {
        const OPERATION: &str = "CudaPreparedBiasEpilogueGemm::execute";
        ensure_same_context(&self.context, &stream.context, OPERATION)?;

        validate_span(
            OPERATION,
            params.input.buffer(),
            params.input.dtype(),
            params.input.byte_offset(),
            params.input.byte_len(),
            CudaDType::BF16,
            self.config.input_bytes,
            "input",
        )?;
        validate_span(
            OPERATION,
            params.weight.buffer(),
            params.weight.dtype(),
            params.weight.byte_offset(),
            params.weight.byte_len(),
            CudaDType::BF16,
            self.config.weight_bytes,
            "weight",
        )?;
        validate_span(
            OPERATION,
            params.bias.buffer(),
            params.bias.dtype(),
            params.bias.byte_offset(),
            params.bias.byte_len(),
            CudaDType::BF16,
            self.config.bias_bytes(),
            "bias",
        )?;
        validate_span(
            OPERATION,
            params.output.buffer(),
            params.output.dtype(),
            params.output.byte_offset(),
            params.output.byte_len(),
            CudaDType::BF16,
            self.config.output_bytes,
            "output",
        )?;

        let workspace_bytes = self.algorithm.workspace_bytes;
        match params.workspace.as_ref() {
            Some(workspace) => validate_span(
                OPERATION,
                workspace.buffer(),
                workspace.dtype(),
                workspace.byte_offset(),
                workspace.byte_len(),
                CudaDType::U8,
                workspace_bytes,
                "workspace",
            )?,
            None if workspace_bytes == 0 => {}
            None => {
                return Err(CudaError::invalid_argument(
                    OPERATION,
                    format!(
                        "the selected algorithm requires an exact {workspace_bytes}-byte U8 workspace"
                    ),
                ));
            }
        }

        let required_buffers = [
            ("input", params.input.buffer()),
            ("weight", params.weight.buffer()),
            ("bias", params.bias.buffer()),
            ("output", params.output.buffer()),
        ];
        for (_, buffer) in required_buffers {
            ensure_same_context(&self.context, buffer.context_owner(), OPERATION)?;
        }
        ensure_distinct_buffers(&required_buffers, OPERATION)?;

        if let Some(workspace) = params.workspace.as_ref() {
            let workspace_buffer = workspace.buffer();
            ensure_same_context(&self.context, workspace_buffer.context_owner(), OPERATION)?;
            for (name, buffer) in required_buffers {
                if ptr::eq(buffer, workspace_buffer) {
                    return Err(CudaError::invalid_argument(
                        OPERATION,
                        format!("workspace aliases the {name} device-buffer handle"),
                    ));
                }
            }
        }
        Ok(())
    }
}

impl Drop for CudaPreparedBiasEpilogueGemm {
    fn drop(&mut self) {
        #[cfg(feature = "cuda")]
        {
            // This plan deliberately has no graph-resource API. Retaining the
            // context still makes a dropped owner fail closed if a caller
            // attempts teardown while an unrelated capture is active.
            let _ = crate::graph::retain_context_for_active_graph_capture(&self.context);
        }
    }
}

impl Drop for CudaPreparedGemm {
    fn drop(&mut self) {
        #[cfg(feature = "cuda")]
        {
            // cuBLASLt descriptor teardown enters CUDA. Retain the safe
            // context until a live graph capture either drains the native
            // deferred close or intentionally remains fail-closed.
            let _ = crate::graph::retain_context_for_active_graph_capture(&self.context);
        }
    }
}

/// Immutable provenance for the custom fixed37 GEMM implementation.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub struct CudaFixed37GemmMetadata {
    backend_id: u32,
    reduction_version: u32,
    chunk_elements: u32,
    accumulator_dtype: CudaDType,
    output_dtype: CudaDType,
    threads_per_block: u32,
    deterministic: bool,
    dynamic_shared_memory_bytes: u64,
    workspace_bytes: u64,
    m: u64,
    n: u64,
    k: u64,
}

impl CudaFixed37GemmMetadata {
    /// Stable native backend identifier for this custom implementation.
    pub const BACKEND_ID: u32 = 2;

    /// Native backend identifier.
    #[must_use]
    pub const fn backend_id(self) -> u32 {
        self.backend_id
    }

    /// Fixed reduction contract version.
    #[must_use]
    pub const fn reduction_version(self) -> u32 {
        self.reduction_version
    }

    /// Logical elements in every full local chunk.
    #[must_use]
    pub const fn chunk_elements(self) -> u32 {
        self.chunk_elements
    }

    /// Accumulation dtype, always F32.
    #[must_use]
    pub const fn accumulator_dtype(self) -> CudaDType {
        self.accumulator_dtype
    }

    /// Output dtype, always BF16.
    #[must_use]
    pub const fn output_dtype(self) -> CudaDType {
        self.output_dtype
    }

    /// CUDA threads in each custom kernel block.
    #[must_use]
    pub const fn threads_per_block(self) -> u32 {
        self.threads_per_block
    }

    /// Whether execution has a fixed deterministic reduction order.
    #[must_use]
    pub const fn deterministic(self) -> bool {
        self.deterministic
    }

    /// Exact per-block dynamic shared-memory scratch.
    #[must_use]
    pub const fn dynamic_shared_memory_bytes(self) -> u64 {
        self.dynamic_shared_memory_bytes
    }

    /// Caller workspace bytes, always zero for the custom backend.
    #[must_use]
    pub const fn workspace_bytes(self) -> u64 {
        self.workspace_bytes
    }

    /// Prepared `(M, N, K)` dimensions.
    #[must_use]
    pub const fn dimensions(self) -> (u64, u64, u64) {
        (self.m, self.n, self.k)
    }
}

/// Borrowed buffers for one synchronous custom fixed37 GEMM execution.
///
/// Span sizes exactly match the prepared BF16 matrices, offsets are 256-byte
/// aligned, and the three allocations must be distinct. The implementation
/// never accepts a workspace and never falls back to canonical GEMM.
#[derive(Debug)]
pub struct Fixed37GemmParams<'a> {
    /// Row-major BF16 `X[M, K]`.
    pub input: CudaBufferSpan<'a>,
    /// Row-major BF16 `W[N, K]` consumed logically transposed.
    pub weight: CudaBufferSpan<'a>,
    /// Row-major BF16 `Y[M, N]`.
    pub output: CudaBufferSpanMut<'a>,
}

/// Immutable provenance for the isolated direct-cuBLAS BF16 qualifier.
///
/// This metadata reports the exact handle modes observed at native prepare
/// time. It is diagnostic-only: repeat exactness is a GPU test gate rather
/// than a general cuBLAS determinism claim.
#[cfg(feature = "cuda-cublas-gemm-probe")]
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub struct CublasGemmProbeMetadata {
    backend_id: u32,
    requested_math_mode: i32,
    actual_math_mode: i32,
    requested_pointer_mode: i32,
    actual_pointer_mode: i32,
    requested_atomics_mode: i32,
    actual_atomics_mode: i32,
    runtime_version: i32,
    cublas_version: i32,
    compute_capability_major: u32,
    compute_capability_minor: u32,
    m: u64,
    n: u64,
    k: u64,
}

#[cfg(feature = "cuda-cublas-gemm-probe")]
impl CublasGemmProbeMetadata {
    /// Stable native backend identifier for the direct-cuBLAS diagnostic.
    pub const BACKEND_ID: u32 = 3;

    /// Native backend identifier.
    #[must_use]
    pub const fn backend_id(self) -> u32 {
        self.backend_id
    }

    /// Requested and observed cuBLAS math-mode enum values.
    #[must_use]
    pub const fn math_modes(self) -> (i32, i32) {
        (self.requested_math_mode, self.actual_math_mode)
    }

    /// Requested and observed cuBLAS scalar-pointer-mode enum values.
    #[must_use]
    pub const fn pointer_modes(self) -> (i32, i32) {
        (self.requested_pointer_mode, self.actual_pointer_mode)
    }

    /// Requested and observed cuBLAS atomics-mode enum values.
    #[must_use]
    pub const fn atomics_modes(self) -> (i32, i32) {
        (self.requested_atomics_mode, self.actual_atomics_mode)
    }

    /// CUDA Runtime version observed at plan preparation.
    #[must_use]
    pub const fn runtime_version(self) -> i32 {
        self.runtime_version
    }

    /// cuBLAS library version observed at plan preparation.
    #[must_use]
    pub const fn cublas_version(self) -> i32 {
        self.cublas_version
    }

    /// Compute capability observed at plan preparation.
    #[must_use]
    pub const fn compute_capability(self) -> (u32, u32) {
        (self.compute_capability_major, self.compute_capability_minor)
    }

    /// Prepared logical `(M, N, K)` dimensions.
    #[must_use]
    pub const fn dimensions(self) -> (u64, u64, u64) {
        (self.m, self.n, self.k)
    }
}

/// Borrowed buffers for one synchronous direct-cuBLAS diagnostic execution.
///
/// This deliberately has no caller workspace, graph, or canonical fallback.
/// It exists only with the `cuda-cublas-gemm-probe` test feature.
#[cfg(feature = "cuda-cublas-gemm-probe")]
#[derive(Debug)]
pub struct CublasGemmProbeParams<'a> {
    /// Row-major BF16 `X[M, K]`.
    pub input: CudaBufferSpan<'a>,
    /// Row-major BF16 `W[N, K]` consumed logically transposed.
    pub weight: CudaBufferSpan<'a>,
    /// Row-major BF16 `Y[M, N]`.
    pub output: CudaBufferSpanMut<'a>,
}

/// Owning direct-cuBLAS raw-projection qualifier.
///
/// Direct `cublasGemmEx` default-math owner. The diagnostic constructor
/// requires per-operation completion; the owned eager constructor additionally
/// supports resource leases managed by command-batch completion.
#[cfg(feature = "cuda-cublas-gemm-probe")]
pub struct CudaPreparedCublasGemmProbe {
    native: ffi::CublasGemmProbePlanHandle,
    context: Arc<ContextInner>,
    config: CudaGemmConfig,
    metadata: CublasGemmProbeMetadata,
    poisoned: bool,
    owned_command_batches: bool,
    _not_sync: PhantomData<Cell<()>>,
}

#[cfg(feature = "cuda-cublas-gemm-probe")]
impl fmt::Debug for CudaPreparedCublasGemmProbe {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("CudaPreparedCublasGemmProbe")
            .field("device_ordinal", &self.context.ordinal)
            .field("config", &self.config)
            .field("metadata", &self.metadata)
            .field("owned_command_batches", &self.owned_command_batches)
            .field("poisoned", &self.poisoned)
            .finish_non_exhaustive()
    }
}

/// Owning custom fixed-contiguous-37-balanced-v1 GEMM plan.
///
/// This is deliberately a sibling of [`CudaPreparedGemm`], not a runtime
/// selector. It owns its additive native plan and performs no cuBLASLt query,
/// workspace allocation, or canonical fallback.
pub struct CudaPreparedFixed37Gemm {
    #[cfg(feature = "cuda")]
    native: ffi::Fixed37GemmPlanHandle,
    context: Arc<ContextInner>,
    config: CudaGemmConfig,
    metadata: CudaFixed37GemmMetadata,
    poisoned: bool,
    _not_sync: PhantomData<Cell<()>>,
}

impl fmt::Debug for CudaPreparedFixed37Gemm {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("CudaPreparedFixed37Gemm")
            .field("device_ordinal", &self.context.ordinal)
            .field("config", &self.config)
            .field("metadata", &self.metadata)
            .field("poisoned", &self.poisoned)
            .finish_non_exhaustive()
    }
}

impl CudaContext {
    /// Prepares the additive fixed37 GEMM implementation.
    ///
    /// # Errors
    ///
    /// Returns not-supported when `K` needs more than 4096 fixed chunks,
    /// unavailable without CUDA, or a translated native creation/contract
    /// error. No CUDA kernel or model is run during preparation.
    pub fn prepare_fixed37_gemm(
        &self,
        config: CudaGemmConfig,
    ) -> CudaResult<CudaPreparedFixed37Gemm> {
        #[cfg(feature = "cuda")]
        {
            if config.reduction_policy != CudaGemmReductionPolicy::StrictNoSplitV1 {
                return Err(fixed37_not_supported(
                    "CudaContext::prepare_fixed37_gemm",
                    "fixed37 has its own exact reduction contract and rejects cuBLASLt split-K policy flags",
                ));
            }
            if config.k > FIXED37_MAX_REDUCTION_ELEMENTS {
                return Err(fixed37_not_supported(
                    "CudaContext::prepare_fixed37_gemm",
                    format!(
                        "K={} requires more than {} fixed {}-element chunks",
                        config.k, FIXED37_MAX_CHUNK_COUNT, FIXED37_CHUNK_ELEMENTS
                    ),
                ));
            }
            let native = ffi::Fixed37GemmPlanHandle::create(
                &self.inner.native,
                config.m,
                config.n,
                config.k,
                config.max_workspace_bytes,
            )?;
            let metadata = CudaFixed37GemmMetadata::from_native(config, native.info()?)?;
            Ok(CudaPreparedFixed37Gemm {
                native,
                context: Arc::clone(&self.inner),
                config,
                metadata,
                poisoned: false,
                _not_sync: PhantomData,
            })
        }
        #[cfg(not(feature = "cuda"))]
        {
            let _ = config;
            Err(CudaError::unavailable("CudaContext::prepare_fixed37_gemm"))
        }
    }
}

impl CudaPreparedFixed37Gemm {
    /// Exact logical and storage contract used to prepare this plan.
    #[must_use]
    pub const fn config(&self) -> CudaGemmConfig {
        self.config
    }

    /// Immutable fixed-reduction implementation metadata.
    #[must_use]
    pub const fn metadata(&self) -> CudaFixed37GemmMetadata {
        self.metadata
    }

    /// Device ordinal retained by this plan.
    #[must_use]
    pub fn device_ordinal(&self) -> u32 {
        self.context.ordinal
    }

    /// Whether a prior native execution error disabled safe reuse.
    #[must_use]
    pub const fn is_poisoned(&self) -> bool {
        self.poisoned
    }

    /// Executes the custom GEMM and synchronizes the explicit stream.
    ///
    /// # Errors
    ///
    /// Returns before native execution for dtype, size, alignment, context,
    /// alias, busy-buffer, or poisoned-plan violations. Any native execution
    /// failure poisons this safe wrapper conservatively.
    pub fn execute<S: CudaExecutionStream + ?Sized>(
        &mut self,
        params: &mut Fixed37GemmParams<'_>,
        stream: &mut S,
    ) -> CudaResult<()> {
        const OPERATION: &str = "CudaPreparedFixed37Gemm::execute";
        let stream = execution_stream_mut(stream);
        if self.poisoned {
            return Err(CudaError::invalid_state(
                OPERATION,
                "the fixed37 GEMM plan was poisoned by a prior native execution failure",
            ));
        }
        self.validate_execution(params, stream)?;
        #[cfg(feature = "cuda")]
        {
            let result = self.native.execute(
                params.input.raw(),
                params.weight.raw(),
                params.output.raw(),
                &mut stream.native,
            );
            if result.is_err() {
                self.poisoned = true;
            }
            result
        }
        #[cfg(not(feature = "cuda"))]
        {
            let _ = (params, stream);
            Err(CudaError::unavailable(OPERATION))
        }
    }

    /// Explicitly closes the custom native plan.
    ///
    /// # Errors
    ///
    /// A poisoned plan cannot be reported as cleanly closed. Drop retains the
    /// existing fail-closed best-effort native cleanup behavior.
    pub fn close(self) -> CudaResult<()> {
        #[cfg(feature = "cuda")]
        {
            let mut this = self;
            if this.poisoned {
                return Err(CudaError::invalid_state(
                    "CudaPreparedFixed37Gemm::close",
                    "a poisoned fixed37 GEMM plan cannot be reported as cleanly closed",
                ));
            }
            this.native.close()
        }
        #[cfg(not(feature = "cuda"))]
        {
            Err(CudaError::unavailable("CudaPreparedFixed37Gemm::close"))
        }
    }

    fn validate_execution(
        &self,
        params: &Fixed37GemmParams<'_>,
        stream: &CudaStream,
    ) -> CudaResult<()> {
        const OPERATION: &str = "CudaPreparedFixed37Gemm::execute";
        ensure_same_context(&self.context, &stream.context, OPERATION)?;
        validate_span(
            OPERATION,
            params.input.buffer(),
            params.input.dtype(),
            params.input.byte_offset(),
            params.input.byte_len(),
            CudaDType::BF16,
            self.config.input_bytes,
            "input",
        )?;
        validate_span(
            OPERATION,
            params.weight.buffer(),
            params.weight.dtype(),
            params.weight.byte_offset(),
            params.weight.byte_len(),
            CudaDType::BF16,
            self.config.weight_bytes,
            "weight",
        )?;
        validate_span(
            OPERATION,
            params.output.buffer(),
            params.output.dtype(),
            params.output.byte_offset(),
            params.output.byte_len(),
            CudaDType::BF16,
            self.config.output_bytes,
            "output",
        )?;
        let buffers = [
            ("input", params.input.buffer()),
            ("weight", params.weight.buffer()),
            ("output", params.output.buffer()),
        ];
        for (_, buffer) in buffers {
            ensure_same_context(&self.context, buffer.context_owner(), OPERATION)?;
        }
        ensure_distinct_buffers(&buffers, OPERATION)
    }
}

#[cfg(feature = "cuda-cublas-gemm-probe")]
impl CudaPreparedCublasGemmProbe {
    pub(crate) fn register_mlp_uses(&self,down:&Self,buffers:[ffi::RawBufferSpan;8],packed:Option<ffi::RawBufferSpan>,stream:&mut CudaStream)->CudaResult<()> {
        if self.poisoned || down.poisoned {return Err(CudaError::invalid_state("owned MLP graph","poisoned GEMM plan"));}
        if let Some(packed)=packed {let b=[buffers[0],buffers[1],buffers[2],buffers[3],buffers[4],buffers[5],buffers[6],buffers[7],packed];self.native.register_mlp_packed_uses(&down.native,&b,&mut stream.native)}else{self.native.register_mlp_uses(&down.native,&buffers,&mut stream.native)}
    }

    /// Private request-row execution; no plan or buffer is allocated while dispatching.
    pub fn execute_row_groups<S:CudaExecutionStream+?Sized>(&mut self,params:&mut CublasGemmProbeParams<'_>,slots:&[u32],output_rows:Option<usize>,grouped_decode:u8,stream:&mut S)->CudaResult<()> {
        const OP:&str="CudaPreparedCublasGemmProbe::execute_row_groups";
        if self.poisoned {return Err(CudaError::invalid_state(OP,"poisoned owner"));}
        let stream=execution_stream_mut(stream);self.validate_execution(params,stream)?;
        let total=output_rows.unwrap_or(slots.len());
        if total as u64>self.config.m {return Err(CudaError::invalid_argument(OP,"active request rows exceed cold plan"));}
        if grouped_decode>10 { return Err(CudaError::invalid_argument(OP,"unknown decode batch mode")); }
        if grouped_decode==1 && total>1 {
            if output_rows.is_none() && slots.windows(2).any(|w| w[0]==w[1]) {
                return Err(CudaError::invalid_argument(OP,"grouped decode requires one row per request"));
            }
            let input=params.input.subspan(0,total as u64*self.config.k*2)?;
            let output=params.output.buffer().native_handle().span(ffi::DTYPE_BF16,params.output.byte_offset(),total as u64*self.config.n*2);
            let result=self.native.execute_rows(input.raw(),params.weight.raw(),output,total as u64,grouped_decode,&mut stream.native);
            if result.is_err(){self.poisoned=true;} return result;
        }
        let mut begin=0;
        while begin<total {
            let mut end=begin+1;
            if output_rows.is_none() {while end<total && slots[end]==slots[begin] {end+=1;}}
            let original_end=end;
            // Only mode10 merges adjacent prefill groups with an independently
            // qualified native arithmetic family. Other modes preserve extents.
            let prefill_bounds=if grouped_decode==10 && output_rows.is_none(){
                match (self.config.n,self.config.k) {
                    (9728, 2560) | (2560, 9728) => Some((64_usize,130_usize,161_usize,576_usize)),
                    // Packed linear tokens: keep each original native-M128
                    // arithmetic family and its independently qualified bounds.
                    (4096, 2560) => Some((65,130,257,576)),
                    (1024, 2560) => Some((94,128,161,512)),
                    (2560, 4096) => Some((65,128,161,576)),
                    _ => None,
                }
            }else{None};
            if let Some((original_min,original_max,merged_min,merged_max))=prefill_bounds {
                if (original_min..=original_max).contains(&(end-begin)) {
                    let mut scan_end=end;
                    while scan_end<total {
                        let mut next_end=scan_end+1;while next_end<total && slots[next_end]==slots[scan_end]{next_end+=1;}
                        if !(original_min..=original_max).contains(&(next_end-scan_end)) || next_end-begin>merged_max {break;}
                        scan_end=next_end;
                        if scan_end-begin>=merged_min {end=scan_end;}
                    }
                }
            }
            // Mode11 is a private native call selector, not a public decode mode.
            // Never replace a standalone large prefill with the M128 recipe.
            let packed_projection=matches!((self.config.n,self.config.k),(4096,2560)|(1024,2560)|(2560,4096));
            let fixed_prefill=end>original_end && (packed_projection || self.config.k==9728 || (257..=512).contains(&(end-begin)));
            let mut mode=if fixed_prefill {11}else{0};
            if grouped_decode>=2 && end==begin+1 {
                mode=grouped_decode;
                while end<total && end-begin<32 {
                    if output_rows.is_none() && end+1<total && slots[end]==slots[end+1] {break;}
                    end+=1;
                }
            }
            let m=(end-begin) as u64;
            let input=params.input.subspan(begin as u64*self.config.k*2,m*self.config.k*2)?;
            let offset=params.output.byte_offset()+begin as u64*self.config.n*2;
            let output=params.output.buffer().native_handle().span(ffi::DTYPE_BF16,offset,m*self.config.n*2);
            let result=self.native.execute_rows(input.raw(),params.weight.raw(),output,m,mode,&mut stream.native);
            if result.is_err(){self.poisoned=true;return result;}
            begin=end;
        }
        Ok(())
    }

    pub fn execute_row_groups_cached<S:CudaExecutionStream+?Sized>(&mut self,params:&mut CublasGemmProbeParams<'_>,groups:crate::batch::ValidatedRequestRowGroups<'_>,output_rows:Option<usize>,grouped_decode:u8,stream:&mut S)->CudaResult<()> {
        self.execute_row_groups_cached_from(params,groups,output_rows,grouped_decode,0,stream)
    }

    /// Runs a suffix starting at a proven request boundary. The full parent
    /// spans are validated before offsets are applied, as for the zero prefix.
    pub fn execute_row_groups_cached_from<S:CudaExecutionStream+?Sized>(&mut self,params:&mut CublasGemmProbeParams<'_>,groups:crate::batch::ValidatedRequestRowGroups<'_>,output_rows:Option<usize>,grouped_decode:u8,first_row:usize,stream:&mut S)->CudaResult<()> {
        const OP:&str="CudaPreparedCublasGemmProbe::execute_row_groups";
        let slots=groups.row_sequence_slots();
        if self.poisoned {return Err(CudaError::invalid_state(OP,"poisoned owner"));}
        let stream=execution_stream_mut(stream);self.validate_execution(params,stream)?;
        let total=output_rows.unwrap_or(slots.len());
        if total as u64>self.config.m {return Err(CudaError::invalid_argument(OP,"active request rows exceed cold plan"));}
        if grouped_decode>10 { return Err(CudaError::invalid_argument(OP,"unknown decode batch mode")); }
        if grouped_decode==1 && total>1 && first_row==0 {
            if output_rows.is_none() && slots.windows(2).any(|w| w[0]==w[1]) {
                return Err(CudaError::invalid_argument(OP,"grouped decode requires one row per request"));
            }
            let input=params.input.subspan(0,total as u64*self.config.k*2)?;
            let output=params.output.buffer().native_handle().span(ffi::DTYPE_BF16,params.output.byte_offset(),total as u64*self.config.n*2);
            let result=self.native.execute_rows(input.raw(),params.weight.raw(),output,total as u64,grouped_decode,&mut stream.native);
            if result.is_err(){self.poisoned=true;} return result;
        }
        if first_row>total || (first_row<total && first_row>0 && slots[first_row-1]==slots[first_row]) {
            return Err(CudaError::invalid_argument(OP,"suffix must start on a request boundary"));
        }
        let mut begin=first_row;
        while begin<total {
            let mut end=begin+1;
            if output_rows.is_none() {end=groups.group_end(begin)?;}
            let original_end=end;
            // Only mode10 merges adjacent prefill groups with an independently
            // qualified native arithmetic family. Other modes preserve extents.
            let prefill_bounds=if grouped_decode==10 && output_rows.is_none(){
                match (self.config.n,self.config.k) {
                    (9728, 2560) | (2560, 9728) => Some((64_usize,130_usize,161_usize,576_usize)),
                    // Packed linear tokens: keep each original native-M128
                    // arithmetic family and its independently qualified bounds.
                    (4096, 2560) => Some((65,130,257,576)),
                    (1024, 2560) => Some((94,128,161,512)),
                    (2560, 4096) => Some((65,128,161,576)),
                    _ => None,
                }
            }else{None};
            if let Some((original_min,original_max,merged_min,merged_max))=prefill_bounds {
                if (original_min..=original_max).contains(&(end-begin)) {
                    let mut scan_end=end;
                    while scan_end<total {
                        let next_end=groups.group_end(scan_end)?;
                        if !(original_min..=original_max).contains(&(next_end-scan_end)) || next_end-begin>merged_max {break;}
                        scan_end=next_end;
                        if scan_end-begin>=merged_min {end=scan_end;}
                    }
                }
            }
            // Mode11 is a private native call selector, not a public decode mode.
            // Never replace a standalone large prefill with the M128 recipe.
            let packed_projection=matches!((self.config.n,self.config.k),(4096,2560)|(1024,2560)|(2560,4096));
            let fixed_prefill=end>original_end && (packed_projection || self.config.k==9728 || (257..=512).contains(&(end-begin)));
            let mut mode=if fixed_prefill {11}else{0};
            if grouped_decode>=2 && end==begin+1 {
                mode=grouped_decode;
                while end<total && end-begin<32 {
                    if output_rows.is_none() && end+1<total && slots[end]==slots[end+1] {break;}
                    end+=1;
                }
            }
            let m=(end-begin) as u64;
            let input=params.input.subspan(begin as u64*self.config.k*2,m*self.config.k*2)?;
            let offset=params.output.byte_offset()+begin as u64*self.config.n*2;
            let output=params.output.buffer().native_handle().span(ffi::DTYPE_BF16,offset,m*self.config.n*2);
            let result=self.native.execute_rows(input.raw(),params.weight.raw(),output,m,mode,&mut stream.native);
            if result.is_err(){self.poisoned=true;return result;}
            begin=end;
        }
        Ok(())
    }

    /// Private native-M1-equivalent merged Gate/Up. Only independently
    /// qualified R1 and R17..32 use the pinned SM80/cuBLASLt recipe.
    pub fn execute_sm80_merged_gate_up<S:CudaExecutionStream+?Sized>(
        &mut self,input:CudaBufferSpan<'_>,weight:CudaBufferSpan<'_>,
        output:CudaBufferSpanMut<'_>,rows:u64,stream:&mut S,
    )->CudaResult<()> {
        const OP:&str="native exact SM80 merged Gate/Up";
        if self.poisoned || self.config.n!=19456 || self.config.k!=2560 || rows>self.config.m
            || !(rows==1 || (17..=32).contains(&rows)) {
            return Err(CudaError::invalid_argument(OP,"qualified cold merged plan and R1/R17..32 required"));
        }
        let stream=execution_stream_mut(stream);
        ensure_same_context(&self.context,&stream.context,OP)?;
        for b in [input.buffer(),weight.buffer(),output.buffer()] {ensure_same_context(&self.context,b.context_owner(),OP)?;}
        let result=self.native.execute_rows(input.raw(),weight.raw(),output.raw(),rows,12,&mut stream.native);
        if result.is_err(){self.poisoned=true;}result
    }

    /// Bounded attention bridge with caller-owned cold scratch and plan-selected completion.
    #[allow(clippy::too_many_arguments)]
    pub fn execute_hf_attention<S: CudaExecutionStream + ?Sized>(
        &mut self, query: CudaBufferSpan<'_>, key: CudaBufferSpan<'_>,
        value: CudaBufferSpan<'_>, ids: CudaBufferSpan<'_>,
        output: CudaBufferSpanMut<'_>, scratch: &mut [CudaDeviceBuffer; 8],
        rows: u64, tokens: u64, physical: u64, qh:u64,kvh:u64,head_size:u64,stream: &mut S,
    ) -> CudaResult<()> {
        const OPERATION: &str = "CudaPreparedCublasGemmProbe::execute_hf_attention";
        if self.poisoned || !hf_attention_geometry_valid(self.config,rows,tokens,physical,qh,kvh,head_size) {
            return Err(CudaError::invalid_argument(OPERATION,"bounded cold D64/D128 attention geometry or poisoned owner"));
        }
        let stream = execution_stream_mut(stream);
        ensure_same_context(&self.context, &stream.context, OPERATION)?;
        for b in [query.buffer(), key.buffer(), value.buffer(), ids.buffer(), output.buffer()] {
            ensure_same_context(&self.context,b.context_owner(),OPERATION)?;
        }
        let sizes = [rows*qh*head_size*2,physical*kvh*16*head_size*2,physical*kvh*16*head_size*2,tokens.div_ceil(16)*4,rows*qh*head_size*2];
        for (span,(dtype,size)) in [query,key,value,ids].iter().zip([(CudaDType::BF16,sizes[0]),(CudaDType::BF16,sizes[1]),(CudaDType::BF16,sizes[2]),(CudaDType::U32,sizes[3])]) {
            if span.dtype()!=dtype || span.byte_len()!=size {return Err(CudaError::invalid_argument(OPERATION,"input span geometry or dtype mismatch"));}
        }
        if output.dtype()!=CudaDType::BF16 || output.byte_len()!=sizes[4] {return Err(CudaError::invalid_argument(OPERATION,"output span geometry mismatch"));}
        let q=rows*qh*head_size*2;let kv=tokens*qh*head_size*2;let s=qh*rows*tokens;let tiled=qh*rows.min(128)*tokens;
        // Completed BF16 score rows become probabilities in-place; GEMM geometry is unchanged.
        let lens=[q,kv,kv,s*2,tiled*4,tiled*4,q,16777216];
        let roles=[5,6,7,8,9,10,12,13];
        let mut spans=[query.raw();14];spans[1]=key.raw();spans[2]=value.raw();spans[3]=ids.raw();spans[4]=output.raw();
        for (i,b) in scratch.iter_mut().enumerate() {
            ensure_same_context(&self.context,b.context_owner(),OPERATION)?;
            let dtype=if i==4||i==5 {CudaDType::F32} else if i==7 {CudaDType::U8} else {CudaDType::BF16};
            spans[roles[i]]=CudaBufferSpan::new(b,dtype,0,lens[i])?.raw();
        }
        spans[11]=spans[8]; // Exact internal alias, retained exclusively by this scratch owner.
        let result=self.native.attention(&spans,rows,tokens,physical,qh,kvh,head_size,&mut stream.native);
        if result.is_err(){self.poisoned=true;}
        result
    }

    /// Exact Smol gate/up projection plus SiLU multiply, preserving BF16
    /// stores after both projections, after SiLU, and after multiplication.
    pub fn try_execute_hf_smol_fused_gate_up<S:CudaExecutionStream+?Sized>(&mut self,gate:CudaBufferSpan<'_>,up:CudaBufferSpan<'_>,input:CudaBufferSpan<'_>,output:CudaBufferSpanMut<'_>,rows:u64,stream:&mut S)->CudaResult<bool> {
        const OP:&str="CudaPreparedCublasGemmProbe::try_execute_hf_smol_fused_gate_up";
        if self.poisoned{return Err(CudaError::invalid_argument(OP,"prepared plan is poisoned"));}
        if !self.native.smol_fused_gate_up_supported(rows){return Ok(false);}
        if [gate,up,input].iter().any(|v|v.byte_offset()%16!=0){return Ok(false);}
        let stream=execution_stream_mut(stream);ensure_same_context(&self.context,&stream.context,OP)?;
        let spans=[gate.raw(),up.raw(),input.raw(),output.raw()];
        let result=self.native.smol_fused_gate_up(&spans,rows,&mut stream.native);
        if result.is_err(){self.poisoned=true;}result.map(|_|true)
    }

    /// Native SM80 batched Gate/Up with shared input and BF16 SiLU boundaries.
    pub fn try_execute_hf_sm80_fused_gate_up<S:CudaExecutionStream+?Sized>(&mut self,gate:CudaBufferSpan<'_>,up:CudaBufferSpan<'_>,input:CudaBufferSpan<'_>,output:CudaBufferSpanMut<'_>,rows:u64,stream:&mut S)->CudaResult<bool> {
        const OP:&str="CudaPreparedCublasGemmProbe::try_execute_hf_sm80_fused_gate_up";
        if self.poisoned{return Err(CudaError::invalid_argument(OP,"prepared plan is poisoned"));}
        if !self.native.sm80_fused_gate_up_supported(rows){return Ok(false);}
        if [gate,up,input].iter().any(|v|v.byte_offset()%32!=0){return Ok(false);}
        let stream=execution_stream_mut(stream);ensure_same_context(&self.context,&stream.context,OP)?;
        let spans=[gate.raw(),up.raw(),input.raw(),output.raw()];
        let result=self.native.sm80_fused_gate_up(&spans,rows,&mut stream.native);
        if result.is_err(){self.poisoned=true;}result.map(|_|true)
    }
    pub fn try_execute_hf_sm80_fused_gate_up_packed<S:CudaExecutionStream+?Sized>(&mut self,packed:CudaBufferSpan<'_>,gate:CudaBufferSpan<'_>,up:CudaBufferSpan<'_>,input:CudaBufferSpan<'_>,output:CudaBufferSpanMut<'_>,rows:u64,stream:&mut S)->CudaResult<bool> {
        const OP:&str="CudaPreparedCublasGemmProbe::try_execute_hf_sm80_fused_gate_up";
        if self.poisoned{return Err(CudaError::invalid_argument(OP,"prepared plan is poisoned"));}
        if !(2..=16).contains(&rows) || !self.native.sm80_fused_gate_up_supported(rows){return Ok(false);}
        if [gate,up,input].iter().any(|v|v.byte_offset()%32!=0){return Ok(false);}
        let stream=execution_stream_mut(stream);ensure_same_context(&self.context,&stream.context,OP)?;
        let spans=[gate.raw(),up.raw(),input.raw(),output.raw(),packed.raw()];
        let result=self.native.sm80_fused_gate_up_packed(&spans,rows,&mut stream.native);
        if result.is_err(){self.poisoned=true;}result.map(|_|true)
    }

    /// Fuses independent decode groups even when prefill shares this iteration.
    /// Non-singleton groups retain the existing mode10 prefill merge/recipe.
    #[allow(clippy::too_many_arguments)]
    pub fn try_execute_hf_sm80_fused_gate_up_groups<S:CudaExecutionStream+?Sized>(
        &mut self,gate:CudaBufferSpan<'_>,up:CudaBufferSpan<'_>,input:CudaBufferSpan<'_>,
        gate_raw:&mut CudaDeviceBuffer,up_raw:&mut CudaDeviceBuffer,product:&mut CudaDeviceBuffer,
        groups:crate::batch::ValidatedRequestRowGroups<'_>,stream:&mut S,
    )->CudaResult<bool>{
        self.try_execute_hf_sm80_fused_gate_up_groups_from(gate,up,input,gate_raw,up_raw,product,groups,0,stream)
    }
    #[allow(clippy::too_many_arguments)]
    pub fn try_execute_hf_sm80_fused_gate_up_groups_from<S:CudaExecutionStream+?Sized>(
        &mut self,gate:CudaBufferSpan<'_>,up:CudaBufferSpan<'_>,input:CudaBufferSpan<'_>,
        gate_raw:&mut CudaDeviceBuffer,up_raw:&mut CudaDeviceBuffer,product:&mut CudaDeviceBuffer,
        groups:crate::batch::ValidatedRequestRowGroups<'_>,first_row:usize,stream:&mut S,
    )->CudaResult<bool>{
        self.try_execute_hf_sm80_fused_gate_up_groups_packed_from(None,gate,up,input,gate_raw,up_raw,product,groups,first_row,stream)
    }
    #[allow(clippy::too_many_arguments)]
    pub fn try_execute_hf_sm80_fused_gate_up_groups_packed_from<S:CudaExecutionStream+?Sized>(
        &mut self,packed:Option<CudaBufferSpan<'_>>,gate:CudaBufferSpan<'_>,up:CudaBufferSpan<'_>,input:CudaBufferSpan<'_>,
        gate_raw:&mut CudaDeviceBuffer,up_raw:&mut CudaDeviceBuffer,product:&mut CudaDeviceBuffer,
        groups:crate::batch::ValidatedRequestRowGroups<'_>,first_row:usize,stream:&mut S,
    )->CudaResult<bool>{
        const OP:&str="CudaPreparedCublasGemmProbe::try_execute_hf_sm80_fused_gate_up_groups";
        if self.poisoned{return Err(CudaError::invalid_state(OP,"poisoned owner"));}
        if !self.native.sm80_fused_gate_up_supported(2){return Ok(false);}
        if [gate,up,input].iter().any(|v|v.byte_offset()%32!=0){return Ok(false);}
        let slots=groups.row_sequence_slots();let total=slots.len();
        if total as u64>self.config.m{return Err(CudaError::invalid_argument(OP,"active rows exceed plan"));}
        let range=|begin:usize|->CudaResult<(usize,u8,bool)>{
            let mut end=groups.group_end(begin)?;let original_end=end;
            if (64..=130).contains(&(end-begin)){
                let mut scan=end;
                while scan<total{let next=groups.group_end(scan)?;if !(64..=130).contains(&(next-scan))||next-begin>576{break;}scan=next;if scan-begin>=161{end=scan;}}
            }
            let mut mode=if end>original_end&&(257..=512).contains(&(end-begin)){11}else{0};
            if end==begin+1{mode=10;while end<total&&end-begin<32{if end+1<total&&slots[end]==slots[end+1]{break;}end+=1;}}
            Ok((end,mode,mode==10&&end-begin>=2))
        };
        // Unsupported/all-prefill batches submit nothing through this route.
        if first_row>total || (first_row<total && first_row>0 && slots[first_row-1]==slots[first_row]) {return Err(CudaError::invalid_argument(OP,"fused suffix boundary"));}
        let mut scan=first_row;let mut useful=false;while scan<total{let(end,_,fused)=range(scan)?;useful|=fused;scan=end;}
        if !useful{return Ok(false);}
        let stream=execution_stream_mut(stream);
        {let p=CublasGemmProbeParams{input,weight:gate,output:CudaBufferSpanMut::new(gate_raw,CudaDType::BF16,0,self.config.output_bytes())?};self.validate_execution(&p,stream)?;}
        {let p=CublasGemmProbeParams{input,weight:up,output:CudaBufferSpanMut::new(up_raw,CudaDType::BF16,0,self.config.output_bytes())?};self.validate_execution(&p,stream)?;}
        ensure_same_context(&self.context,product.context_owner(),OP)?;
        if product.byte_len()<self.config.output_bytes(){return Err(CudaError::invalid_argument(OP,"product capacity below plan"));}
        let result=(||->CudaResult<()>{let mut begin=first_row;while begin<total{
            let(end,mode,fused)=range(begin)?;let rows=(end-begin)as u64;let in_span=input.subspan(begin as u64*2560*2,rows*2560*2)?;let offset=begin as u64*9728*2;let bytes=rows*9728*2;
            if fused{
                let out=CudaBufferSpanMut::new(product,CudaDType::BF16,offset,bytes)?;
                if let Some(packed)=packed.filter(|_|rows<=16){self.native.sm80_fused_gate_up_packed(&[gate.raw(),up.raw(),in_span.raw(),out.raw(),packed.raw()],rows,&mut stream.native)?;}else{self.native.sm80_fused_gate_up(&[gate.raw(),up.raw(),in_span.raw(),out.raw()],rows,&mut stream.native)?;}
            }else{
                for(weight,out)in[(gate,&mut *gate_raw),(up,&mut *up_raw)]{
                    let out=CudaBufferSpanMut::new(out,CudaDType::BF16,offset,bytes)?;
                    self.native.execute_rows(in_span.raw(),weight.raw(),out.raw(),rows,mode,&mut stream.native)?;
                }
                let mut p=crate::GatedMultiplyParams{activated_gate:CudaBufferSpan::new(gate_raw,CudaDType::BF16,offset,bytes)?,up:CudaBufferSpan::new(up_raw,CudaDType::BF16,offset,bytes)?,output:CudaBufferSpanMut::new(product,CudaDType::BF16,offset,bytes)?,element_count:rows*9728};
                crate::silu_gated_multiply(&mut p,stream)?;
            }
            begin=end;
        }Ok(())})();
        if result.is_err(){self.poisoned=true;}result.map(|_|true)
    }

    /// Executes three disjoint Smol projections with their original FP32 FMA
    /// chains. Unsupported environments/alignment submit nothing and return false.
    #[allow(clippy::too_many_arguments)]
    pub fn try_execute_hf_smol_fused_qkv<S:CudaExecutionStream+?Sized>(&mut self,query_weight:CudaBufferSpan<'_>,key_weight:CudaBufferSpan<'_>,value_weight:CudaBufferSpan<'_>,input:CudaBufferSpan<'_>,query:CudaBufferSpanMut<'_>,key:CudaBufferSpanMut<'_>,value:CudaBufferSpanMut<'_>,rows:u64,stream:&mut S)->CudaResult<bool> {
        const OP:&str="CudaPreparedCublasGemmProbe::try_execute_hf_smol_fused_qkv";
        if self.poisoned {return Err(CudaError::invalid_argument(OP,"prepared plan is poisoned"));}
        if !self.native.smol_fused_qkv_supported(rows){return Ok(false);}
        if [query_weight,key_weight,value_weight,input].iter().any(|v|v.byte_offset()%16!=0){return Ok(false);}
        let stream=execution_stream_mut(stream);ensure_same_context(&self.context,&stream.context,OP)?;
        let spans=[query_weight.raw(),key_weight.raw(),value_weight.raw(),input.raw(),query.raw(),key.raw(),value.raw()];
        let result=self.native.smol_fused_qkv(&spans,rows,&mut stream.native);
        if result.is_err(){self.poisoned=true;}result.map(|_|true)
    }

    /// Cold qualification for exact decode chunks; unknown environments fall back.
    #[must_use]
    pub fn supports_exact_smol_attention(&self,tokens:u64)->bool { !self.poisoned && self.native.smol_exact_supported(tokens) }
    /// Exact H9/KV3/D64 attention for selected independent singleton rows.
    #[allow(clippy::too_many_arguments)]
    pub fn execute_hf_attention_smol_exact<S:CudaExecutionStream+?Sized>(&mut self,query:CudaBufferSpan<'_>,key:CudaBufferSpan<'_>,value:CudaBufferSpan<'_>,output:CudaBufferSpanMut<'_>,scratch:&mut[CudaDeviceBuffer;3],batch:crate::PackedBatchV1<'_>,selected:&[u32],stream:&mut S)->CudaResult<()> {
        const OP:&str="CudaPreparedCublasGemmProbe::execute_hf_attention_smol_exact";
        let host=batch.host();let positions=host.row_positions();let slots=host.row_sequence_slots();let active=positions.len() as u64;
        if selected.is_empty()||selected.len()>32||active==0||active>self.config.m||self.config.k!=64||selected.windows(2).any(|x|x[0]>=x[1]) {return Err(CudaError::invalid_argument(OP,"sorted R1..32 rows within prepared H9KV3D64 bounds required"));}
        let mut rows=[0u32;32];let mut tokens=[0u64;32];
        for (i,&row) in selected.iter().enumerate(){let r=row as usize;if r>=positions.len() || (r>0&&slots[r-1]==slots[r]) || (r+1<slots.len()&&slots[r+1]==slots[r]) {return Err(CudaError::invalid_argument(OP,"selected rows must be independent singleton groups"));}let t=u64::from(positions[r])+1;if t>self.config.n||!self.supports_exact_smol_attention(t){return Err(CudaError::invalid_argument(OP,"unsupported exact attention recipe"));}rows[i]=row;tokens[i]=t;}
        let physical=host.physical_block_count();let q=active*576*2;let pool=physical*3*16*64*2;let ids=batch.device_block_ids();let slots=batch.device_row_sequence_slots();let offsets=batch.device_sequence_block_offsets();let positions=batch.device_row_positions();
        let stream=execution_stream_mut(stream);ensure_same_context(&self.context,&stream.context,OP)?;
        for (span,dtype,n) in [(query,CudaDType::BF16,q),(key,CudaDType::BF16,pool),(value,CudaDType::BF16,pool),(ids,CudaDType::U32,host.block_ids().len() as u64*4),(slots,CudaDType::U32,active*4),(offsets,CudaDType::U32,(host.sequence_count()+1)*4),(positions,CudaDType::U32,active*4)] {ensure_same_context(&self.context,span.buffer().context_owner(),OP)?;if span.dtype()!=dtype||span.byte_len()!=n{return Err(CudaError::invalid_argument(OP,"exact attention input geometry"));}}
        ensure_same_context(&self.context,output.buffer().context_owner(),OP)?;if output.dtype()!=CudaDType::BF16||output.byte_len()!=q{return Err(CudaError::invalid_argument(OP,"exact attention output geometry"));}
        let mut spans=[query.raw();11];spans[1]=key.raw();spans[2]=value.raw();spans[3]=ids.raw();spans[4]=output.raw();spans[8]=slots.raw();spans[9]=offsets.raw();spans[10]=positions.raw();
        for (i,b) in scratch.iter_mut().enumerate(){ensure_same_context(&self.context,b.context_owner(),OP)?;let n=selected.len() as u64*if i<2{3*1024*64*2}else{9*1024*2};spans[5+i]=CudaBufferSpan::new(b,CudaDType::BF16,0,n)?.raw();}
        let result=self.native.attention_smol_exact(&spans,&rows,&tokens,selected.len() as u64,active,physical,host.sequence_count(),host.block_ids().len() as u64,&mut stream.native);if result.is_err(){self.poisoned=true;}result
    }

    /// Cold SM80/CUDA12.4/108SM environment qualification; shape checks stay native.
    pub fn prepare_bounded_sm80_projections(&mut self)->CudaResult<()> {self.native.prepare_bounded_sm80_projections()}
    /// Cold opt-in attention staging; the native owner validates SM80 geometry.
    pub fn prepare_sm80_attention(&mut self)->CudaResult<()> {self.native.prepare_sm80_attention()}
    /// Opt-in paged chunk preparation; native SIMT/WMMA families stay pinned.
    pub fn prepare_sm80_prefill(&mut self)->CudaResult<()> {self.native.prepare_sm80_prefill()}
    pub fn prepare_sm80_paged_attention(&mut self)->CudaResult<()> {self.native.prepare_sm80_paged_attention()}
    pub fn uses_sm80_paged_attention(&self)->bool {self.native.supports_sm80_paged_attention(0)}
    pub fn supports_sm80_paged_attention(&self,tokens:u64)->bool {tokens!=0&&self.native.supports_sm80_paged_attention(tokens)}

    pub fn supports_bounded_sm80_gateup_rows(&self)->bool {self.native.bounded_sm80_gateup_qualified()}
    pub fn supports_exact_decode_chunk(&self)->bool {self.native.decode_chunk_qualified()}

    /// Heterogeneous Q16/KV2/D128 singleton requests, with unchanged QK/PV shapes.
    #[allow(clippy::too_many_arguments)]
    pub fn execute_hf_attention_chunk<S:CudaExecutionStream+?Sized>(&mut self,query:CudaBufferSpan<'_>,key:CudaBufferSpan<'_>,value:CudaBufferSpan<'_>,output:CudaBufferSpanMut<'_>,scratch:&mut[CudaDeviceBuffer;3],workspace:&mut CudaDeviceBuffer,scaled_trace:Option<&mut CudaDeviceBuffer>,batch:crate::PackedBatchV1<'_>,begin:usize,requests:usize,stream:&mut S)->CudaResult<()> {
        const OP:&str="CudaPreparedCublasGemmProbe::execute_hf_attention_chunk";
        let host=batch.host();let (tokens,total)=exact_decode_chunk_tokens(host.row_positions(),host.row_sequence_slots(),begin,requests).ok_or_else(||CudaError::invalid_argument(OP,"distinct singleton slots, R2..8 and eachT1..512 required"))?;
        if self.poisoned || self.config.m<1 || self.config.k!=128 || tokens[..requests].iter().any(|t|*t>self.config.n) || !self.supports_exact_decode_chunk(){return Err(CudaError::invalid_argument(OP,"unqualified owned decode chunk"));}
        let physical=host.physical_block_count();let q=requests as u64*16*128*2;let pool=physical*2*16*128*2;
        let ids=batch.device_block_ids();let slots=batch.device_row_sequence_slots().subspan(begin as u64*4,requests as u64*4)?;let offsets=batch.device_sequence_block_offsets();
        let stream=execution_stream_mut(stream);ensure_same_context(&self.context,&stream.context,OP)?;
        for (span,dtype,n) in [(query,CudaDType::BF16,q),(key,CudaDType::BF16,pool),(value,CudaDType::BF16,pool),(ids,CudaDType::U32,host.block_ids().len() as u64*4),(slots,CudaDType::U32,requests as u64*4),(offsets,CudaDType::U32,(host.sequence_count()+1)*4)]{ensure_same_context(&self.context,span.buffer().context_owner(),OP)?;if span.dtype()!=dtype||span.byte_len()!=n{return Err(CudaError::invalid_argument(OP,"decode chunk input geometry"));}}
        ensure_same_context(&self.context,output.buffer().context_owner(),OP)?;if output.dtype()!=CudaDType::BF16||output.byte_len()!=q{return Err(CudaError::invalid_argument(OP,"decode chunk output geometry"));}
        let mut spans=[query.raw();12];spans[1]=key.raw();spans[2]=value.raw();spans[3]=ids.raw();spans[4]=output.raw();spans[9]=slots.raw();spans[10]=offsets.raw();
        for (i,b) in scratch.iter_mut().enumerate(){ensure_same_context(&self.context,b.context_owner(),OP)?;let n=if i<2{total*16*128*2}else{total*16*2};spans[5+i]=CudaBufferSpan::new(b,CudaDType::BF16,0,n)?.raw();}
        ensure_same_context(&self.context,workspace.context_owner(),OP)?;spans[8]=CudaBufferSpan::new(workspace,CudaDType::U8,0,16777216)?.raw();
        let span_count=if let Some(trace)=scaled_trace{ensure_same_context(&self.context,trace.context_owner(),OP)?;spans[11]=CudaBufferSpan::new(trace,CudaDType::F32,0,total*16*4)?.raw();12}else{11};
        let result=self.native.attention_chunk(&spans,span_count,&tokens,requests as u64,physical,host.sequence_count(),host.block_ids().len() as u64,&mut stream.native);if result.is_err(){self.poisoned=true;}result
    }

    /// Heterogeneous Q32/KV8/D128 singleton requests, with unchanged QK/PV shapes.
    #[allow(clippy::too_many_arguments)]
    pub fn execute_hf_attention_chunk_wide<S:CudaExecutionStream+?Sized>(&mut self,query:CudaBufferSpan<'_>,key:CudaBufferSpan<'_>,value:CudaBufferSpan<'_>,output:CudaBufferSpanMut<'_>,scratch:&mut[CudaDeviceBuffer;3],workspace:&mut CudaDeviceBuffer,scaled_trace:Option<&mut CudaDeviceBuffer>,batch:crate::PackedBatchV1<'_>,begin:usize,requests:usize,stream:&mut S)->CudaResult<()> {
        const OP:&str="CudaPreparedCublasGemmProbe::execute_hf_attention_chunk_wide";
        let host=batch.host();let (tokens,total)=exact_wide_decode_chunk_tokens(host.row_positions(),host.row_sequence_slots(),begin,requests).ok_or_else(||CudaError::invalid_argument(OP,"distinct singleton slots, R2..32 and eachT1..512 required"))?;
        let sm80=self.uses_sm80_paged_attention();
        if sm80 && tokens[..requests].iter().any(|t|!self.supports_sm80_paged_attention(*t)){return Err(CudaError::invalid_argument(OP,"unsupported SM80 native attention family"));}
        if self.poisoned || self.config.m<1 || self.config.k!=128 || tokens[..requests].iter().any(|t|*t>self.config.n) || !self.supports_exact_decode_chunk(){return Err(CudaError::invalid_argument(OP,"unqualified owned decode chunk"));}
        let physical=host.physical_block_count();let q=requests as u64*32*128*2;let pool=physical*8*16*128*2;
        let ids=batch.device_block_ids();let slots=batch.device_row_sequence_slots().subspan(begin as u64*4,requests as u64*4)?;let offsets=batch.device_sequence_block_offsets();
        let stream=execution_stream_mut(stream);ensure_same_context(&self.context,&stream.context,OP)?;
        for (span,dtype,n) in [(query,CudaDType::BF16,q),(key,CudaDType::BF16,pool),(value,CudaDType::BF16,pool),(ids,CudaDType::U32,host.block_ids().len() as u64*4),(slots,CudaDType::U32,requests as u64*4),(offsets,CudaDType::U32,(host.sequence_count()+1)*4)]{ensure_same_context(&self.context,span.buffer().context_owner(),OP)?;if span.dtype()!=dtype||span.byte_len()!=n{return Err(CudaError::invalid_argument(OP,"decode chunk input geometry"));}}
        ensure_same_context(&self.context,output.buffer().context_owner(),OP)?;if output.dtype()!=CudaDType::BF16||output.byte_len()!=q{return Err(CudaError::invalid_argument(OP,"decode chunk output geometry"));}
        let mut spans=[query.raw();12];spans[1]=key.raw();spans[2]=value.raw();spans[3]=ids.raw();spans[4]=output.raw();spans[9]=slots.raw();spans[10]=offsets.raw();
        for (i,b) in scratch.iter_mut().enumerate(){ensure_same_context(&self.context,b.context_owner(),OP)?;let n=if i<2 && !sm80{total*32*128*2}else{total*32*2};spans[5+i]=CudaBufferSpan::new(b,CudaDType::BF16,0,n)?.raw();}
        ensure_same_context(&self.context,workspace.context_owner(),OP)?;spans[8]=CudaBufferSpan::new(workspace,CudaDType::U8,0,16777216)?.raw();
        let span_count=if let Some(trace)=scaled_trace{ensure_same_context(&self.context,trace.context_owner(),OP)?;spans[11]=CudaBufferSpan::new(trace,CudaDType::F32,0,total*32*4)?.raw();12}else{11};
        let result=self.native.attention_chunk_wide(&spans,span_count,&tokens,requests as u64,physical,host.sequence_count(),host.block_ids().len() as u64,&mut stream.native);if result.is_err(){self.poisoned=true;}result
    }

    /// Fixed-stride device-metadata attention for whole-body decode graphs.
    #[allow(clippy::too_many_arguments)]
    pub fn execute_hf_attention_chunk_wide_dynamic<S:CudaExecutionStream+?Sized>(&mut self,query:CudaBufferSpan<'_>,key:CudaBufferSpan<'_>,value:CudaBufferSpan<'_>,output:CudaBufferSpanMut<'_>,scratch:&mut[CudaDeviceBuffer;3],workspace:&mut CudaDeviceBuffer,batch:crate::PackedBatchV1<'_>,begin:usize,requests:usize,stream:&mut S)->CudaResult<()> {
        const OP:&str="CudaPreparedCublasGemmProbe::execute_hf_attention_chunk_wide_dynamic";
        let host=batch.host();let (tokens,total)=exact_wide_decode_chunk_tokens(host.row_positions(),host.row_sequence_slots(),begin,requests).ok_or_else(||CudaError::invalid_argument(OP,"distinct singleton slots, R2..32 and eachT1..512 required"))?;
        let sm80=self.uses_sm80_paged_attention();
        if !sm80{return Err(CudaError::invalid_argument(OP,"dynamic route requires SM80 paged attention"));}
        let total=requests as u64*512;
        if sm80 && tokens[..requests].iter().any(|t|!self.supports_sm80_paged_attention(*t)){return Err(CudaError::invalid_argument(OP,"unsupported SM80 native attention family"));}
        if self.poisoned || self.config.m<1 || self.config.k!=128 || tokens[..requests].iter().any(|t|*t>self.config.n) || !self.supports_exact_decode_chunk(){return Err(CudaError::invalid_argument(OP,"unqualified owned decode chunk"));}
        let physical=host.physical_block_count();let q=requests as u64*32*128*2;let pool=physical*8*16*128*2;
        let ids=batch.device_block_ids();let slots=batch.device_row_sequence_slots().subspan(begin as u64*4,requests as u64*4)?;let offsets=batch.device_sequence_block_offsets();
        let stream=execution_stream_mut(stream);ensure_same_context(&self.context,&stream.context,OP)?;
        for (span,dtype,n) in [(query,CudaDType::BF16,q),(key,CudaDType::BF16,pool),(value,CudaDType::BF16,pool),(ids,CudaDType::U32,host.block_ids().len() as u64*4),(slots,CudaDType::U32,requests as u64*4),(offsets,CudaDType::U32,(host.sequence_count()+1)*4)]{ensure_same_context(&self.context,span.buffer().context_owner(),OP)?;if span.dtype()!=dtype||span.byte_len()!=n{return Err(CudaError::invalid_argument(OP,"decode chunk input geometry"));}}
        ensure_same_context(&self.context,output.buffer().context_owner(),OP)?;if output.dtype()!=CudaDType::BF16||output.byte_len()!=q{return Err(CudaError::invalid_argument(OP,"decode chunk output geometry"));}
        let mut spans=[query.raw();12];spans[1]=key.raw();spans[2]=value.raw();spans[3]=ids.raw();spans[4]=output.raw();spans[9]=slots.raw();spans[10]=offsets.raw();
        for (i,b) in scratch.iter_mut().enumerate(){ensure_same_context(&self.context,b.context_owner(),OP)?;let n=if i<2 && !sm80{total*32*128*2}else{total*32*2};spans[5+i]=CudaBufferSpan::new(b,CudaDType::BF16,0,n)?.raw();}
        ensure_same_context(&self.context,workspace.context_owner(),OP)?;spans[8]=CudaBufferSpan::new(workspace,CudaDType::U8,0,16777216)?.raw();
        let positions=batch.device_row_positions().subspan(begin as u64*4,requests as u64*4)?;
        ensure_same_context(&self.context,positions.buffer().context_owner(),OP)?;
        spans[11]=positions.raw();let span_count=12;
        let result=self.native.attention_chunk_wide(&spans,span_count,&tokens,requests as u64,physical,host.sequence_count(),host.block_ids().len() as u64,&mut stream.native);if result.is_err(){self.poisoned=true;}result
    }

    /// Exact logical/storage contract fixed at cold prepare time.
    #[must_use]
    pub const fn config(&self) -> CudaGemmConfig {
        self.config
    }

    /// Immutable native cuBLAS handle provenance.
    #[must_use]
    pub const fn metadata(&self) -> CublasGemmProbeMetadata {
        self.metadata
    }

    /// Device ordinal retained by this diagnostic plan.
    #[must_use]
    pub fn device_ordinal(&self) -> u32 {
        self.context.ordinal
    }

    /// Whether a prior native execution failure disabled safe reuse.
    #[must_use]
    pub const fn is_poisoned(&self) -> bool {
        self.poisoned
    }

    /// Executes one direct `cublasGemmEx` raw projection.
    /// Probe plans synchronize before return. Explicit owned plans may submit
    /// to a command batch whose completion retains their resource lifetimes.
    ///
    /// Any native execution failure poisons the safe owner. The native plan
    /// rejects graph capture. Probe plans also reject command batches; only
    /// the explicit owned constructor enables batch submission.
    pub fn execute<S: CudaExecutionStream + ?Sized>(
        &mut self,
        params: &mut CublasGemmProbeParams<'_>,
        stream: &mut S,
    ) -> CudaResult<()> {
        const OPERATION: &str = "CudaPreparedCublasGemmProbe::execute";
        let stream = execution_stream_mut(stream);
        if self.poisoned {
            return Err(CudaError::invalid_state(
                OPERATION,
                "the direct-cuBLAS GEMM probe was poisoned by a prior native execution failure",
            ));
        }
        self.validate_execution(params, stream)?;
        let result = self.native.execute(
            params.input.raw(),
            params.weight.raw(),
            params.output.raw(),
            &mut stream.native,
        );
        if result.is_err() {
            self.poisoned = true;
        }
        result
    }

    /// Explicitly closes the independent native diagnostic owner.
    ///
    /// # Errors
    ///
    /// A poisoned plan cannot be reported as cleanly closed. Drop retains the
    /// existing fail-closed best-effort native close semantics.
    pub fn close(self) -> CudaResult<()> {
        let mut this = self;
        if this.poisoned {
            return Err(CudaError::invalid_state(
                "CudaPreparedCublasGemmProbe::close",
                "a poisoned direct-cuBLAS GEMM probe cannot be reported as cleanly closed",
            ));
        }
        this.native.close()
    }

    fn validate_execution(
        &self,
        params: &CublasGemmProbeParams<'_>,
        stream: &CudaStream,
    ) -> CudaResult<()> {
        const OPERATION: &str = "CudaPreparedCublasGemmProbe::execute";
        ensure_same_context(&self.context, &stream.context, OPERATION)?;
        validate_span(
            OPERATION,
            params.input.buffer(),
            params.input.dtype(),
            params.input.byte_offset(),
            params.input.byte_len(),
            CudaDType::BF16,
            self.config.input_bytes,
            "input",
        )?;
        validate_span(
            OPERATION,
            params.weight.buffer(),
            params.weight.dtype(),
            params.weight.byte_offset(),
            params.weight.byte_len(),
            CudaDType::BF16,
            self.config.weight_bytes,
            "weight",
        )?;
        validate_span(
            OPERATION,
            params.output.buffer(),
            params.output.dtype(),
            params.output.byte_offset(),
            params.output.byte_len(),
            CudaDType::BF16,
            self.config.output_bytes,
            "output",
        )?;
        let buffers = [
            ("input", params.input.buffer()),
            ("weight", params.weight.buffer()),
            ("output", params.output.buffer()),
        ];
        for (_, buffer) in buffers {
            ensure_same_context(&self.context, buffer.context_owner(), OPERATION)?;
        }
        ensure_distinct_buffers(&buffers, OPERATION)
    }
}

#[cfg(feature = "cuda-cublas-gemm-probe")]
impl CublasGemmProbeMetadata {
    fn from_native(
        config: CudaGemmConfig,
        native: ffi::NativeCublasGemmProbeInfo,
    ) -> CudaResult<Self> {
        const OPERATION: &str = "CudaContext::prepare_cublas_gemm_probe";
        if native.backend != NATIVE_CUBLAS_GEMM_PROBE_BACKEND_ID
            || native.requested_math_mode != CUBLAS_DEFAULT_MATH_MODE
            || native.actual_math_mode != CUBLAS_DEFAULT_MATH_MODE
            || native.requested_pointer_mode != CUBLAS_POINTER_MODE_HOST
            || native.actual_pointer_mode != CUBLAS_POINTER_MODE_HOST
            || native.requested_atomics_mode != CUBLAS_ATOMICS_NOT_ALLOWED
            || native.actual_atomics_mode != CUBLAS_ATOMICS_NOT_ALLOWED
            || native.runtime_version <= 0
            || native.cublas_version <= 0
            || native.compute_capability_major == 0
            || native.workspace_bytes != 0
            || (native.m, native.n, native.k) != (config.m, config.n, config.k)
        {
            return Err(CudaError::new(
                CudaErrorKind::Internal,
                CudaErrorDomain::Internal,
                CudaErrorStage::Prepare,
                0,
                OPERATION,
                format!(
                    "native direct-cuBLAS metadata violates the diagnostic contract: {native:?}"
                ),
            ));
        }
        Ok(Self {
            backend_id: native.backend,
            requested_math_mode: native.requested_math_mode,
            actual_math_mode: native.actual_math_mode,
            requested_pointer_mode: native.requested_pointer_mode,
            actual_pointer_mode: native.actual_pointer_mode,
            requested_atomics_mode: native.requested_atomics_mode,
            actual_atomics_mode: native.actual_atomics_mode,
            runtime_version: native.runtime_version,
            cublas_version: native.cublas_version,
            compute_capability_major: native.compute_capability_major,
            compute_capability_minor: native.compute_capability_minor,
            m: native.m,
            n: native.n,
            k: native.k,
        })
    }
}

#[cfg(feature = "cuda")]
impl CudaFixed37GemmMetadata {
    fn from_native(
        config: CudaGemmConfig,
        native: ffi::NativeFixed37GemmPlanInfo,
    ) -> CudaResult<Self> {
        const OPERATION: &str = "CudaContext::prepare_fixed37_gemm";
        let expected_chunks = config.k.div_ceil(u64::from(FIXED37_CHUNK_ELEMENTS));
        let expected_shared_bytes = expected_chunks * 2 * 4;
        if native.backend != NATIVE_FIXED37_BACKEND_ID
            || native.reduction_version != FIXED37_REDUCTION_VERSION
            || native.chunk_elements != FIXED37_CHUNK_ELEMENTS
            || native.accumulator_dtype != ffi::DTYPE_F32
            || native.output_dtype != ffi::DTYPE_BF16
            || native.threads_per_block != 256
            || native.deterministic != DETERMINISTIC_REQUIRED
            || native.workspace_bytes != 0
            || native.dynamic_shared_memory_bytes != expected_shared_bytes
            || (native.m, native.n, native.k) != (config.m, config.n, config.k)
        {
            return Err(CudaError::new(
                CudaErrorKind::Internal,
                CudaErrorDomain::Internal,
                CudaErrorStage::Prepare,
                0,
                OPERATION,
                format!("native fixed37 metadata violates the prepared contract: {native:?}"),
            ));
        }
        Ok(Self {
            backend_id: native.backend,
            reduction_version: native.reduction_version,
            chunk_elements: native.chunk_elements,
            accumulator_dtype: CudaDType::F32,
            output_dtype: CudaDType::BF16,
            threads_per_block: native.threads_per_block,
            deterministic: true,
            dynamic_shared_memory_bytes: native.dynamic_shared_memory_bytes,
            workspace_bytes: 0,
            m: native.m,
            n: native.n,
            k: native.k,
        })
    }
}

#[cfg(feature = "cuda")]
fn fixed37_not_supported(operation: &'static str, message: impl Into<String>) -> CudaError {
    CudaError::new(
        CudaErrorKind::NotSupported,
        CudaErrorDomain::Rust,
        CudaErrorStage::Validation,
        0,
        operation,
        message,
    )
}

#[cfg(feature = "cuda")]
impl CudaGemmAlgorithmMetadata {
    fn from_native(
        config: CudaGemmConfig,
        native: ffi::NativeGemmAlgorithmInfo,
    ) -> CudaResult<Self> {
        if native.backend != NATIVE_CUBLASLT_BACKEND_ID {
            return Err(native_metadata_error(format!(
                "native GEMM backend id {} does not identify cuBLASLt",
                native.backend
            )));
        }
        if native.deterministic != DETERMINISTIC_REQUIRED {
            return Err(native_metadata_error(
                "native GEMM algorithm is not marked deterministic",
            ));
        }
        if !is_deterministic_reduction_configuration(
            config.reduction_policy,
            native.split_k,
            native.reduction_scheme,
        ) {
            return Err(native_metadata_error(format!(
                "native GEMM algorithm violates the deterministic reduction contract: split_k={}, reduction_scheme={}",
                native.split_k, native.reduction_scheme
            )));
        }
        if (native.m, native.n, native.k) != (config.m, config.n, config.k) {
            return Err(native_metadata_error(format!(
                "native GEMM metadata dimensions ({}, {}, {}) differ from prepared ({}, {}, {})",
                native.m, native.n, native.k, config.m, config.n, config.k
            )));
        }
        if native.workspace_bytes > config.max_workspace_bytes {
            return Err(native_metadata_error(format!(
                "native GEMM workspace requirement {} exceeds configured cap {}",
                native.workspace_bytes, config.max_workspace_bytes
            )));
        }
        Ok(Self {
            backend_id: native.backend,
            algorithm_id: native.algorithm_id,
            tile_id: native.tile_id,
            stages_id: native.stages_id,
            split_k: native.split_k,
            reduction_scheme: native.reduction_scheme,
            cta_swizzling: native.cta_swizzling,
            custom_option: native.custom_option,
            deterministic: true,
            workspace_bytes: native.workspace_bytes,
            numerical_implementation_flags: native.numerical_implementation_flags,
            compute_capability_major: native.compute_capability_major,
            compute_capability_minor: native.compute_capability_minor,
            runtime_version: native.runtime_version,
            cublaslt_version: native.cublaslt_version,
            m: native.m,
            n: native.n,
            k: native.k,
        })
    }
}

#[cfg(feature = "cuda")]
fn native_metadata_error(message: impl Into<String>) -> CudaError {
    CudaError::new(
        CudaErrorKind::Internal,
        CudaErrorDomain::Internal,
        CudaErrorStage::Prepare,
        0,
        "CudaContext::prepare_gemm",
        message,
    )
}

#[allow(clippy::too_many_arguments)]
fn validate_span(
    operation: &'static str,
    buffer: &CudaDeviceBuffer,
    actual_dtype: CudaDType,
    byte_offset: u64,
    actual_bytes: u64,
    required_dtype: CudaDType,
    required_bytes: u64,
    name: &'static str,
) -> CudaResult<()> {
    if actual_dtype != required_dtype {
        return Err(CudaError::invalid_argument(
            operation,
            format!("{name} dtype must be {required_dtype}, got {actual_dtype}"),
        ));
    }
    if actual_bytes != required_bytes {
        return Err(CudaError::invalid_argument(
            operation,
            format!("{name} span must contain exactly {required_bytes} bytes, got {actual_bytes}"),
        ));
    }
    if byte_offset % GEMM_OFFSET_ALIGNMENT != 0 {
        return Err(CudaError::invalid_argument(
            operation,
            format!("{name} byte offset {byte_offset} is not {GEMM_OFFSET_ALIGNMENT}-byte aligned"),
        ));
    }
    buffer.ensure_idle_for_operation(operation)
}

fn ensure_distinct_buffers<const BUFFER_COUNT: usize>(
    buffers: &[(&'static str, &CudaDeviceBuffer); BUFFER_COUNT],
    operation: &'static str,
) -> CudaResult<()> {
    for left_index in 0..buffers.len() {
        for right_index in left_index + 1..buffers.len() {
            let (left_name, left) = buffers[left_index];
            let (right_name, right) = buffers[right_index];
            if ptr::eq(left, right) {
                return Err(CudaError::invalid_argument(
                    operation,
                    format!("{left_name} and {right_name} alias the same device-buffer handle"),
                ));
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::{
        CudaGemmConfig, CudaGemmReductionPolicy, FIXED37_CHUNK_ELEMENTS, FIXED37_MAX_CHUNK_COUNT,
        FIXED37_MAX_REDUCTION_ELEMENTS, FIXED37_REDUCTION_VERSION, checked_bf16_matrix_bytes,
        is_deterministic_reduction_configuration,
    };
    use crate::{CudaDType, CudaErrorKind};

    #[test]
    fn config_pins_exact_dtype_and_checked_byte_arithmetic() {
        let config = CudaGemmConfig::new(3, 5, 7, 4096).expect("valid odd shape");
        assert_eq!((config.m(), config.n(), config.k()), (3, 5, 7));
        assert_eq!(config.input_bytes(), 42);
        assert_eq!(config.weight_bytes(), 70);
        assert_eq!(config.output_bytes(), 30);
        assert_eq!(config.bias_bytes(), 10);
        assert_eq!(config.max_workspace_bytes(), 4096);
        assert_eq!(
            config.reduction_policy(),
            CudaGemmReductionPolicy::StrictNoSplitV1
        );
        let relaxed =
            config.with_reduction_policy(CudaGemmReductionPolicy::AllowOutputTypeSplitKV1);
        assert_eq!(
            relaxed.reduction_policy(),
            CudaGemmReductionPolicy::AllowOutputTypeSplitKV1
        );
        assert_eq!(
            relaxed.reduction_policy().id(),
            "allow-output-type-split-k-v1"
        );
        let heuristic = config
            .with_reduction_policy(CudaGemmReductionPolicy::AllowInPlaceAndOutputTypeSplitKV1);
        assert_eq!(
            heuristic.reduction_policy(),
            CudaGemmReductionPolicy::AllowInPlaceAndOutputTypeSplitKV1
        );
        assert_eq!(
            heuristic.reduction_policy().id(),
            "allow-in-place-and-output-type-split-k-v1"
        );
        assert_eq!(config.input_dtype(), CudaDType::BF16);
        assert_eq!(config.weight_dtype(), CudaDType::BF16);
        assert_eq!(config.accumulator_dtype(), CudaDType::F32);
        assert_eq!(config.output_dtype(), CudaDType::BF16);
        assert!(config.deterministic());
    }

    #[test]
    fn config_rejects_zero_and_out_of_native_range_dimensions() {
        let zero = CudaGemmConfig::new(0, 1, 1, 0).expect_err("zero M must fail");
        assert_eq!(zero.kind(), CudaErrorKind::InvalidArgument);

        let native_dimension_overflow =
            CudaGemmConfig::new(super::MAX_CUBLASLT_DIMENSION + 1, 1, 1, 0)
                .expect_err("cuBLASLt dimensions must fit i32");
        assert_eq!(native_dimension_overflow.kind(), CudaErrorKind::OutOfRange);
    }

    #[test]
    fn bf16_matrix_byte_arithmetic_rejects_u64_overflow() {
        let overflow = checked_bf16_matrix_bytes(u64::MAX, 2, "test")
            .expect_err("matrix byte arithmetic must be checked");
        assert_eq!(overflow.kind(), CudaErrorKind::OutOfRange);
    }

    #[test]
    fn deterministic_cublaslt_reduction_contract_is_policy_scoped() {
        use CudaGemmReductionPolicy::{
            AllowInPlaceAndOutputTypeSplitKV1, AllowOutputTypeSplitKV1, StrictNoSplitV1,
        };

        for accepted in [(0, 0), (1, 0)] {
            assert!(
                is_deterministic_reduction_configuration(StrictNoSplitV1, accepted.0, accepted.1),
                "strict configuration {accepted:?} was rejected"
            );
        }
        for rejected in [(0, 4), (1, 4), (2, 0), (2, 1), (2, 2), (2, 4), (2, 7)] {
            assert!(
                !is_deterministic_reduction_configuration(StrictNoSplitV1, rejected.0, rejected.1),
                "strict policy accepted {rejected:?}"
            );
        }
        for accepted in [(0, 0), (1, 0), (2, 4), (42, 4)] {
            assert!(
                is_deterministic_reduction_configuration(
                    AllowOutputTypeSplitKV1,
                    accepted.0,
                    accepted.1
                ),
                "output-type split-K configuration {accepted:?} was rejected"
            );
        }
        for rejected in [(0, 4), (1, 4), (2, 0), (2, 1), (2, 2), (2, 7)] {
            assert!(
                !is_deterministic_reduction_configuration(
                    AllowOutputTypeSplitKV1,
                    rejected.0,
                    rejected.1
                ),
                "output-type split-K policy accepted {rejected:?}"
            );
        }
        for accepted in [(0, 0), (1, 0), (2, 1), (3, 4), (42, 1), (42, 4)] {
            assert!(
                is_deterministic_reduction_configuration(
                    AllowInPlaceAndOutputTypeSplitKV1,
                    accepted.0,
                    accepted.1
                ),
                "reviewed heuristic split-K configuration {accepted:?} was rejected"
            );
        }
        for rejected in [(0, 1), (0, 4), (1, 1), (1, 4), (2, 0), (2, 2), (2, 7)] {
            assert!(
                !is_deterministic_reduction_configuration(
                    AllowInPlaceAndOutputTypeSplitKV1,
                    rejected.0,
                    rejected.1
                ),
                "reviewed heuristic split-K policy accepted {rejected:?}"
            );
        }
    }

    #[test]
    fn hf_bias_compute_type_reduction_is_explicit_and_does_not_relax_older_policies() {
        use CudaGemmReductionPolicy::*;
        for split in [2,8,16] {
            assert!(is_deterministic_reduction_configuration(HfCompatibleBiasSplitKV1,split,2));
            for old in [StrictNoSplitV1,AllowOutputTypeSplitKV1,AllowInPlaceAndOutputTypeSplitKV1] {
                assert!(!is_deterministic_reduction_configuration(old,split,2));
            }
        }
        for (split,scheme) in [(1,2),(2,0),(8,3),(8,7)] {
            assert!(!is_deterministic_reduction_configuration(HfCompatibleBiasSplitKV1,split,scheme));
        }
    }

    #[test]
    fn fixed37_constants_and_order_sensitive_witness_are_pinned() {
        assert_eq!(FIXED37_REDUCTION_VERSION, 1);
        assert_eq!(FIXED37_CHUNK_ELEMENTS, 37);
        assert_eq!(FIXED37_MAX_CHUNK_COUNT, 4096);
        assert_eq!(FIXED37_MAX_REDUCTION_ELEMENTS, 151_552);

        // A flat logical-order fold loses each unit after 2^24, while the
        // fixed37 local fold first creates a 37.0 chunk partial. The adjacent
        // merge therefore retains 36.0 after F32 round-to-nearest-even.
        let mut values = [0.0_f32; 74];
        values[0] = 16_777_216.0;
        values[37..].fill(1.0);
        let canonical_flat = values
            .iter()
            .copied()
            .fold(0.0_f32, |sum, value| sum + value);
        let mut partials = values
            .chunks(37)
            .map(|chunk| {
                chunk
                    .iter()
                    .copied()
                    .fold(0.0_f32, |sum, value| sum + value)
            })
            .collect::<Vec<_>>();
        while partials.len() > 1 {
            let mut merged = partials
                .chunks_exact(2)
                .map(|pair| pair[0] + pair[1])
                .collect::<Vec<_>>();
            if partials.len() % 2 != 0 {
                merged.push(*partials.last().expect("non-empty partials"));
            }
            partials = merged;
        }
        assert_eq!(canonical_flat.to_bits(), 16_777_216.0_f32.to_bits());
        assert_eq!(partials[0].to_bits(), 16_777_252.0_f32.to_bits());
        assert_ne!(canonical_flat.to_bits(), partials[0].to_bits());
    }

    #[cfg(not(feature = "cuda"))]
    #[test]
    fn feature_off_gemm_error_is_actionable() {
        let error = crate::CudaError::unavailable("CudaContext::prepare_gemm");
        assert_eq!(error.kind(), CudaErrorKind::Unavailable);
        assert!(error.message().contains("--features cuda"));
    }
}

#[cfg(feature="cuda-cublas-gemm-probe")]
fn hf_attention_geometry_valid(config:CudaGemmConfig,rows:u64,tokens:u64,physical:u64,qh:u64,kvh:u64,head_size:u64)->bool {
    rows>0 && rows<=8192 && tokens>=rows && tokens<=9216 && physical>0 && physical<=u32::MAX as u64 && rows<=config.m && tokens<=config.n && matches!(head_size,64|128) && config.k==head_size && qh>0 && qh<=64 && kvh>0 && kvh<=qh && qh%kvh==0 && qh/kvh<=8
}
#[cfg(all(test,feature="cuda-cublas-gemm-probe"))]
mod hf_attention_contract_tests {
 use super::*;
 #[test]
 fn hf_attention_diagnostic_preflight_stops_at_cold_bounds() {
  let c=CudaGemmConfig::new(512,528,64,16777216).unwrap();
  for (m,t) in [(16,16),(128,128),(398,398),(1,149),(1,425),(512,528)] {assert!(hf_attention_geometry_valid(c,m,t,33,9,3,64));}
  for (m,t,p) in [(0,1,33),(513,528,33),(512,511,33),(1,529,33),(1,1025,33),(1,1,0),(1,1,u32::MAX as u64+1)] {assert!(!hf_attention_geometry_valid(c,m,t,p,9,3,64));}
  let c128=CudaGemmConfig::new(512,528,128,16777216).unwrap();
  for (h,k) in [(16,2),(16,8),(32,8)] {assert!(hf_attention_geometry_valid(c128,397,525,33,h,k,128));}
  for (h,k,d) in [(0,2,128),(65,8,128),(16,0,128),(17,2,128),(32,2,128),(16,8,96)] {assert!(!hf_attention_geometry_valid(c128,1,128,33,h,k,d));}
  let long=CudaGemmConfig::new(8192,9216,128,16777216).unwrap();
  for (m,t) in [(1,9216),(8192,8192),(8192,8704),(8192,9216)] {assert!(hf_attention_geometry_valid(long,m,t,576,32,8,128));}
  for (m,t) in [(8193,9216),(8192,8191),(1,9217)] {assert!(!hf_attention_geometry_valid(long,m,t,576,32,8,128));}
  let small=CudaGemmConfig::new(128,128,64,0).unwrap();assert!(!hf_attention_geometry_valid(small,129,129,33,9,3,64));assert!(!hf_attention_geometry_valid(small,1,129,33,9,3,64));
 }
}

fn exact_decode_chunk_tokens_bounded<const MAX:usize>(positions:&[u32],slots:&[u32],begin:usize,requests:usize)->Option<([u64;MAX],u64)>{
 if !(2..=MAX).contains(&requests)||positions.len()!=slots.len(){return None;}let end=begin.checked_add(requests)?;positions.get(begin..end)?;let mut tokens=[0;MAX];let mut total=0;
 for row in begin..end{let slot=slots[row];if (row>0&&slots[row-1]==slot)||(row+1<slots.len()&&slots[row+1]==slot)||slots[begin..row].contains(&slot){return None;}let t=u64::from(positions[row])+1;if t>512{return None;}tokens[row-begin]=t;total+=t;}
 Some((tokens,total))
}
fn exact_decode_chunk_tokens(p:&[u32],s:&[u32],begin:usize,requests:usize)->Option<([u64;8],u64)>{exact_decode_chunk_tokens_bounded::<8>(p,s,begin,requests)}
fn exact_wide_decode_chunk_tokens(p:&[u32],s:&[u32],begin:usize,requests:usize)->Option<([u64;32],u64)>{exact_decode_chunk_tokens_bounded::<32>(p,s,begin,requests)}
#[cfg(test)]mod exact_decode_chunk_tests{
 use super::exact_decode_chunk_tokens as chunk;
 #[test]fn heterogeneous_singletons_and_prefill_boundaries(){
  let slots=[0,1,2,3,4,5,6,7];let p=[0,1,14,31,127,256,510,511];let (ts,total)=chunk(&p,&slots,0,8).unwrap();assert_eq!(ts,[1,2,15,32,128,257,511,512]);assert_eq!(total,1458);assert!(chunk(&p,&slots,0,1).is_none());assert!(chunk(&p,&slots,0,9).is_none());assert!(chunk(&p,&slots,usize::MAX,2).is_none());assert!(chunk(&[512;8],&slots,0,2).is_none());assert!(chunk(&p,&slots[..7],0,2).is_none());
  let repeated=[0,0,1,2,3,4,5,6];assert!(chunk(&p,&repeated,0,2).is_none());assert!(chunk(&p,&repeated,1,2).is_none());assert!(chunk(&p,&repeated,2,2).is_some());
 }
}

#[cfg(test)]mod exact_wide_decode_chunk_tests{
 use super::{exact_wide_decode_chunk_tokens as chunk,exact_decode_chunk_tokens as legacy};
 #[test]fn all_counts_and_nonzero_offsets_preserve_tails(){
  let slots=(0u32..40).collect::<Vec<_>>();let p=(0u32..40).map(|i|i*13%512).collect::<Vec<_>>();
  for count in 2..=32{for begin in 0..=40-count{let(ts,total)=chunk(&p,&slots,begin,count).unwrap();assert_eq!(&ts[..count],&p[begin..begin+count].iter().map(|x|u64::from(*x)+1).collect::<Vec<_>>());assert_eq!(total,ts[..count].iter().sum::<u64>());assert!(ts[count..].iter().all(|x|*x==0));}}
  assert!(legacy(&p,&slots,0,9).is_none());
 }
 #[test]fn prefill_and_duplicate_slots_rejected_at_every_boundary(){
  let p=vec![511;40];let mut slots=(0u32..40).collect::<Vec<_>>();slots[0]=slots[1];assert!(chunk(&p,&slots,1,32).is_none());slots[0]=0;slots[34]=slots[33];assert!(chunk(&p,&slots,2,32).is_none());slots[34]=34;slots[16]=slots[2];assert!(chunk(&p,&slots,2,32).is_none());
 }
 #[test]fn wide_limits_overflow_and_maximum_total_checked(){
  let p=vec![511;32];let s=(0u32..32).collect::<Vec<_>>();let(ts,total)=chunk(&p,&s,0,32).unwrap();assert_eq!(ts,[512;32]);assert_eq!(total,16384);
  for count in [0,1,33,usize::MAX]{assert!(chunk(&p,&s,0,count).is_none());}assert!(chunk(&p,&s,usize::MAX,2).is_none());assert!(chunk(&p,&s[..31],0,2).is_none());assert!(chunk(&[512;32],&s,0,2).is_none());
 }
}
