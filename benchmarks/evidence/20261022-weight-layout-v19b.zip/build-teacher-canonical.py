from pathlib import Path
import json,subprocess,os,hashlib,time
n=Path(__file__).resolve().parent;rows=[]
for l in(n/'native-kv-regression.log').read_text().splitlines():
 try:rows.append(json.loads(l))
 except ValueError:pass
libs={}
for name in ['riley_cuda','riley_runtime','riley_model','serde_json','sha2']:
 matches=[x for x in rows if x.get('reason')=='compiler-artifact'and x.get('target',{}).get('name')==name and any(p.endswith('.rlib')for p in x.get('filenames',[]))];assert matches,('waiting for current library',name);libs[name]=next(p for p in matches[-1]['filenames']if p.endswith('.rlib'))
p=n/'teacher-canonical.rs';a=['/usr/bin/taskset','-c','48-51','/home/nlp/riley-261013/cargo/bin/rustc','--edition=2024','-O','-C','lto=thin','--test','--cfg','feature="cuda-cublas-gemm-probe"',str(p),'-o',str(n/'teacher-canonical'),'-L','dependency='+str(n/'target/release/deps')]
for name,path in libs.items():a+=['--extern',name+'='+path]
for x in rows:
 if x.get('reason')=='build-script-executed'and'riley-cuda'in x.get('package_id',''):
  for path in x['linked_paths']:a+=['-L',path]
(n/'teacher-canonical-build.argv.json').write_text(json.dumps(dict(argv=a,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rlib_sha256={v:hashlib.sha256(Path(v).read_bytes()).hexdigest()for v in libs.values()}),indent=2));env=dict(os.environ,RUSTUP_HOME='/home/nlp/riley-261013/rustup',CARGO_HOME='/home/nlp/riley-261013/cargo',RUSTUP_TOOLCHAIN='1.85.0',CUDA_VISIBLE_DEVICES='',TMPDIR=str(n/'tmp'),XDG_CACHE_HOME=str(n/'cache'))
with(n/'teacher-canonical-build.log').open('x')as f:result=subprocess.run(a,env=env,stdout=f,stderr=subprocess.STDOUT)
assert result.returncode==0
(n/'teacher-canonical-binary.json').write_text(json.dumps(dict(time_ns=time.time_ns(),sha256=hashlib.sha256((n/'teacher-canonical').read_bytes()).hexdigest()),indent=2))
