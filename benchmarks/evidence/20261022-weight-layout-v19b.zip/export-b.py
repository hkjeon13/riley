from pathlib import Path
import json,hashlib,re,time,zipfile,difflib,shutil
w=Path('/mnt/efs/nlp/psyche/riley-weight-layout-v19b-20261022');v=w.parent/'riley-prefill-host-v15c-20261021';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
assert read(w/'experiment-state.json')['phase']=='measured-and-audited'
for n in ['normal-analysis-state','accuracy-r3-state','bounded576-state','canonical-state','diagnostics-state','c16-accuracy-state']:assert read(w/(n+'.json'))['phase']=='complete',n
assert read(w/'packed-contract-v3/state.json')['phase']=='complete'
m=read(w/'source-manifest.json');base=read(v/'source-manifest.json');assert len(m)==len(base)==937;assert m==read(w/'pre-build-source.json')['source_sha256']and all(sha(w/'source'/f)==h for f,h in m.items())
l=read(w/'source-lineage.json');changed=l['changed_sources'];assert len(changed)==8 and l['qualified_source_count']==937
assert all(sha(Path(p))==h for p,h in l['normal_inputs_sha256'].items())and sha(Path(l['binary']))==l['binary_sha256']=='6d19091a3ea8d879730a2ced7c2a7c9a174d5d5fe35e6dd578732c97732c698f'
assert sha(w/'observe-finite.py')=='c0aad9d71eab4071eefb1f94d809c17ced2652d571e662e2af16bab765097947';assert sha(v/'riley-prefill-host-v15c')=='233c3a6a81bad76d65577bacd5837d59e2ebe1dd52a8fde73f3cd07a38cf937a'
patch=''
for f in changed:patch+=''.join(difflib.unified_diff((v/'source'/f).read_text().splitlines(True),(w/'source'/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
(w/'candidate.patch').write_text(patch)
# Include only actual qualified sources, not unapplied local generator revisions.
d=w/'qualified-changed-source';d.mkdir(exist_ok=False)
for f in changed:p=d/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(w/'source'/f,p)
teachers=read(w/'final-teacher-r3-audit.json')['runs'];mixed=read(w/'mixed-byte-r3-audit.json')['runs'];assert sum(x['files']for x in teachers)+sum(x['rows']for x in mixed)==4480;assert all(x['all_bytes_equal_to_original_native_and_HF']for x in teachers)and all(x['all_literal_equal_to_original_native_and_HF']for x in mixed)
a=read(w/'bounded576-byte-audit.json');assert a['files']==2048 and a['all_equal_to_original_native_and_HF'];a=read(w/'canonical-byte-audit.json');assert a['files']==1024 and a['all_literal_equal_to_original_HF_native'];a=read(w/'c16-byte-audit.json');assert a['files']==2544 and all(x['all_original_native_HF_bytes_equal'] for x in a['runs'])
counts=[tuple(map(int,x))for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',(w/'native-kv-regression.log').read_text())];assert tuple(sum(x[i]for x in counts)for i in range(3))==(520,4,40)
a=read(w/'recheck-c02.py.outer.log');assert a['all_passed']and len(a['tests'])==4
names=['memory_gpu','owned_hf_command_batch_gpu','host_runtime_gpu','sm80_prefill_alignment_gpu'];functions=sum(int(re.search(r'test result: ok\. (\d+) passed',(w/('observed-'+n+'.stdout')).read_text()).group(1))for n in names);assert functions==6
assert 'exact_view_cases=120'in(w/'observed-sm80_prefill_alignment_gpu.stderr').read_text()
(w/'extended-accuracy-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),original_BF16_files=4480,bounded576_files=2048,canonical_files=1024,additional_capacity16_budget576_files=2544,total_literal_BF16_files=10096,reference_and_tolerance_unchanged=True,CPU_passed=524,CPU_ignored=40,approved_C02_private_tmp_rechecks=4,GPU_contract_test_functions=6,additional_packed_Graph_identity_contract=True,original_alignment_view_cases=120,original_capacity32_suite_unchanged=True,capacity16_actual_packed_route_confirmed=True),indent=2))
resources=[]
audit=read(w/'qualification-resource-audit.json');assert len(audit['runs'])==15
for entry in audit['runs']:
 p=w/entry['name'];a=[json.loads(x)for x in p.read_text().splitlines()];assert max(x['device_memory_mib']for x in a)<=22528
 for x in a:assert all(p['pid']==2027915 or str(p['pid'])in x['verified_owned_start_ticks']for p in x['processes'])
 resources.append(entry)
for path,holder in [(w/'packed-contract-v3/observed-contract.samples.jsonl',2027915)]:
 a=[json.loads(x)for x in path.read_text().splitlines()];peak=max(x['device_memory_mib']for x in a);assert peak<=22528
 for x in a:assert all(p['pid']==holder or str(p['pid'])in x['verified_owned_start_ticks']for p in x['processes'])
 resources.append(dict(name=str(path.relative_to(w)),samples=len(a),whole_device_peak_MiB=peak,sha256=sha(path)))
a=read(w/'actual-candidate-dispatch.json');assert len(a['profiles'])==4 and all((x['packed_kernel_launches']>0 if '/profile-c16/' in x['trace'] else x['packed_kernel_launches']==0) for x in a['profiles']if not x['before'])and all(x['packed_kernel_launches']==0 for x in a['profiles']if x['before'])
a=read(w/'independent-audit.json');assert len(a['arms'])==34 and sum(x['run'].startswith('final-')for x in a['arms'])==30;assert read(w/'final-holder-audit.json')['passed']
(w/'resource-audit-final.json').write_text(json.dumps(dict(time_ns=time.time_ns(),resource_runs=resources,qualified_source_count=937,all_source_hashes_equal=True,changed_sources=changed,binary_sha256=l['binary_sha256'],normal_arms=30,separate_profile_arms=4,total_stored_SSE_structures_verified=a['total_full_SSE_values_verified'],Riley_native_HF_values_literal_equal=True,stock_HF_matches_reported_per_arm=True,normal_profile_peak_MiB=max(x['peak_whole_device_MiB']for x in a['arms']),whole_device_cap_MiB=22528,primary_qualification_GPU=7,additional_capacity16_qualification_GPU=7,normal_profile_GPU=7,original_GPU6_7_holder_PID_and_context_retained=True,completed_normal_arms_excluded=0,completed_normal_arms_repeated=0),indent=2))
stock=[]
for p in(w/'runs').glob('final-*/c*-vllm/server.log'):
 text=p.read_text();assert 'FLASH_ATTN'in text and 'FULL_AND_PIECEWISE'in text and ('version 2'in text or'version=2'in text),p;stock.append(dict(log=str(p),sha256=sha(p),FLASH_ATTN=True,FULL_AND_PIECEWISE=True,version2=True))
assert len(stock)==10;(w/'stock-startup-proof.json').write_text(json.dumps(stock,indent=2))
x=read(w/'final-statistics.json');policy=read(w/'adoption-policy.json');assert policy['any_paired_TTFT_TPOT_p95_p99_over_2_percent_prevents_adoption']
c16,c32=sorted(x['cells'],key=lambda c:c['concurrency']);assert c16['concurrency']==16 and c32['concurrency']==32
# Read the established paired-metric schema explicitly after results are available.
pairs=c16['paired'];assert len(pairs)==5
all_positive=all(p['percent_change']['output_tok_s']>0 for p in pairs)
eligible=not c16['tail_over_two_percent_flags'] and not c32['tail_over_two_percent_flags'] and c16['median_percent_change']['output_tok_s']>0 and all_positive and c32['median_percent_change']['output_tok_s']>=-2
(w/'adoption-decision.json').write_text(json.dumps(dict(time_ns=time.time_ns(),eligible_for_integration=eligible,integrated_into_main=False,normal_completed_arms_excluded=0,normal_completed_arms_repeated=0,accuracy_threshold_changed=False,registered_policy=policy,C16_all_five_throughput_pairs_positive=all_positive,tail_flags={str(c['concurrency']):c['tail_over_two_percent_flags']for c in x['cells']},throughput_changes={str(c['concurrency']):c['median_percent_change']['output_tok_s']for c in x['cells']},reason='Preregistered capacity-aware B policy: C16 positive median and all five pairs; C32 original-path noninferiority >=-2%; zero paired TTFT/TPOT p95/p99 >2% flags, unchanged accuracy/resource/actual-dispatch gates. Main integration is a separate step.'),indent=2))
# Preserve both functional lanes separately; neither enters192keep normal statistics.
for old,name in [(w.parent/'riley-weight-layout-v19b-functional-20261022','functional-GPU7')]:
 assert read(old/'pilot-state.json')['phase']=='complete';assert len(read(old/'audit-partial.json')['arms'])==2;dest=w/name;dest.mkdir()
 for p in old.rglob('*'):
  if not p.is_file()or any(x in ['tmp','cache','__pycache__']for x in p.relative_to(old).parts)or p.suffix not in ['.json','.log','.py','.txt']:continue
  q=dest/p.relative_to(old);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
skip={'source','target','tmp','cache','vllm-cache','ipc6','ipc7','__pycache__','torch_compile_cache','torchinductor_cache'};allowed={'.json','.jsonl','.log','.txt','.py','.sh','.stdout','.stderr','.cu','.cuh','.cpp','.sse','.h','.hpp','.exit','.sha256','.rs','.patch'};files=[];heavy={}
for p in w.rglob('*'):
 if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
 with p.open('rb')as f:magic=f.read(4)
 if p.suffix in ['.bf16','.sqlite','.nsys-rep','.safetensors']or magic==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
 if p.suffix in allowed or '.attempt'in p.name:
  if p.name not in ['evidence-archive-receipt.json','heavy-evidence-index.json']:files.append(p)
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2));files.append(w/'heavy-evidence-index.json');manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)};z=w/'evidence-archive.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
 for p in sorted(files):out.write(p,str(p.relative_to(w)))
 out.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
a=dict(time_ns=time.time_ns(),archive=str(z),bytes=z.stat().st_size,entries=len(files)+1,sha256=sha(z),heavy_files=len(heavy));(w/'evidence-archive-receipt.json').write_text(json.dumps(a,indent=2));print(json.dumps(a))
