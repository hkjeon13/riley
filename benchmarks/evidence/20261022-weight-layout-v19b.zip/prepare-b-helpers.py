from pathlib import Path
import json,shutil
p=Path('/mnt/efs/nlp/psyche');a=p/'riley-weight-layout-v19a-20261022';w=p/'riley-weight-layout-v19b-20261022'
s=(a/'queue-accuracy.py').read_text().replace(a.name,w.name).replace("'--index','6'","'--index','7'").replace('GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7','GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0');(w/'queue-accuracy.py').write_text(s)
for n in ['packed-graph-contract.rs','run-packed-contract-v3.py']:(w/n).write_text((a/n).read_text().replace(a.name,w.name).replace("'--index','6'","'--index','7'"))
# The standalone contract resource check is independent of selected GPU; its native observer owns the identity checks.
s=(w/'dispatch-v19.py').read_text();s=s.replace("assert (not a)if before else bool(a),(p,len(a));", "c16='profile-c16'in str(p);assert (not a)if before or not c16 else bool(a),(p,len(a));")
s=s.replace("for p in logs:assert 'RILEY_V19_PACKED_GATE_UP layers=32 bytes=3187671040' in p.read_text(),p", "for p in logs:\n c16='final-c16'in str(p)or'profile-c16'in str(p);assert ('RILEY_V19_PACKED_GATE_UP layers=32 bytes=3187671040'in p.read_text())==c16,p")
s=s.replace('32/36 layers eligible for R2..16 by source.','32/36 layers eligible for R2..16 only at configured capacity<=16; capacity32 has no packed allocations or launches.');(w/'dispatch-v19.py').write_text(s)
