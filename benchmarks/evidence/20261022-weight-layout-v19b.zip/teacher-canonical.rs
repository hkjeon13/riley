//! Source-bound teacher-forced diagnostics; numerical metrics do not imply acceptance.
#![cfg(feature = "cuda-cublas-gemm-probe")]
use riley_cuda::CudaRuntime;
use riley_model::{LoadLimits, LoadedModel};
use riley_runtime::{
    llama::{
        LlamaBatchBlockTable, LlamaBatchMetadataConfig, LlamaBatchRow, LlamaBatchRowKind,
        PreparedLlamaBatchExecutor, PreparedLlamaBatchExecutorConfig, PreparedLlamaForwardConfig,
    },
    paged_kv::{BLOCK_TABLE_V1_VERSION, KV_BLOCK_SIZE},
};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{error::Error, fs, path::Path};
type Result<T = ()> = std::result::Result<T, Box<dyn Error>>;
fn sha(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|v| format!("{v:02x}"))
        .collect()
}
fn ids(v: &Value) -> Result<Vec<u32>> {
    v.as_array()
        .ok_or("IDs missing")?
        .iter()
        .map(|v| Ok(u32::try_from(v.as_u64().ok_or("ID not unsigned")?)?))
        .collect()
}
fn leaf(s: &str) -> Result<&str> {
    if s.is_empty()
        || s.len() > 128
        || s.contains("..")
        || !s
            .bytes()
            .all(|v| v.is_ascii_alphanumeric() || b"-_.".contains(&v))
    {
        Err("invalid diagnostic leaf".into())
    } else {
        Ok(s)
    }
}
fn values(bytes: &[u8]) -> Result<Vec<f64>> {
    if bytes.len() % 2 != 0 {
        return Err("unaligned BF16 bytes".into());
    }
    bytes
        .chunks_exact(2)
        .map(|v| {
            let f = f32::from_bits(u32::from(u16::from_le_bytes([v[0], v[1]])) << 16);
            if f.is_finite() {
                Ok(f64::from(f))
            } else {
                Err("nonfinite logits".into())
            }
        })
        .collect()
}
fn metrics(a: &[u8], b: &[u8]) -> Result<Value> {
    if a.len() != b.len() {
        return Err("logit row lengths differ".into());
    }
    let (a, b) = (values(a)?, values(b)?);
    let top = |v: &[f64]| {
        let mut best = 0;
        for i in 1..v.len() {
            if v[i] > v[best] {
                best = i;
            }
        }
        best
    };
    let (at, bt) = (top(&a), top(&b));
    let (mut dot, mut aa, mut bb, mut mae, mut maximum) = (0.0, 0.0, 0.0, 0.0, 0.0f64);
    for (&x, &y) in a.iter().zip(&b) {
        dot += x * y;
        aa += x * x;
        bb += y * y;
        mae += (x - y).abs();
        maximum = maximum.max((x - y).abs());
    }
    let lse = |v: &[f64]| {
        let max = v[top(v)];
        max + v.iter().map(|x| (x - max).exp()).sum::<f64>().ln()
    };
    let (la, lb) = (lse(&a), lse(&b));
    let kl = b
        .iter()
        .zip(&a)
        .map(|(&y, &x)| (y - lb).exp() * ((y - lb) - (x - la)))
        .sum::<f64>();
    Ok(
        json!({"native_top1":at,"hf_top1":bt,"top1_equal":at==bt,"cosine":dot/(aa*bb).sqrt(),"mean_abs":mae/a.len() as f64,"max_abs":maximum,"hf_to_native_kl":kl,"native_choice_hf_rank":1+b.iter().filter(|&&x|x>b[at]).count(),"hf_margin_over_native_choice":b[bt]-b[at],"hf_choice_native_logprob":a[bt]-la,"hf_choice_hf_logprob":b[bt]-lb,"verdict":"diagnostic only; no fitted tolerance or quality acceptance"}),
    )
}
fn table(length: usize) -> Result<(Vec<u32>, Vec<u16>)> {
    let n = length.div_ceil(KV_BLOCK_SIZE);
    Ok((
        (0..n)
            .map(u32::try_from)
            .collect::<std::result::Result<_, _>>()?,
        (0..n)
            .map(|i| u16::try_from((length - i * KV_BLOCK_SIZE).min(KV_BLOCK_SIZE)))
            .collect::<std::result::Result<_, _>>()?,
    ))
}
#[test]
#[ignore = "GPU6/7 only; checksum-bound HF diagnostic fixture required"]
fn owned_batch_teacher_forced_logits_are_finite_and_reported() -> Result {
    let root = std::path::PathBuf::from(std::env::var("RILEY_DIVERGENCE_FIXTURE_ROOT")?);
    let output = std::path::PathBuf::from(std::env::var("RILEY_DIVERGENCE_NATIVE_OUTPUT")?);
    fs::create_dir(&output)?;
    assert!(root.is_absolute() && output.is_absolute());
    let fixture_bytes = fs::read(root.join("fixture.json"))?;
    let fixture: Value = serde_json::from_slice(&fixture_bytes)?;
    let completion = std::env::var("RILEY_DIVERGENCE_COMPLETION")
        .unwrap_or_else(|_| "per-operation".to_owned());
    assert!(matches!(completion.as_str(), "per-operation" | "iteration-batch"));
    let copies:usize=std::env::var("RILEY_TEACHER_COPIES").unwrap_or_else(|_|"1".into()).parse()?;
    assert!((1..=32).contains(&copies));
    let shrink_mode = std::env::var("RILEY_TEACHER_SHRINK").unwrap_or_default();
    let all_counts = shrink_mode == "all-v1";
    let shrink = shrink_mode == "v1" || all_counts;
    let chunked_prefill = std::env::var("RILEY_TEACHER_CHUNK_PREFILL").as_deref() == Ok("v1");
    assert!(!shrink || copies == 32);
    assert!(!all_counts || chunked_prefill, "all counts require every original prefix");
    let rt = CudaRuntime::initialize()?;
    assert_eq!(rt.device_count(), 1);
    let c = rt.device(0)?.create_context()?;
    let mut stream = c.create_stream()?;
    let mut reports = Vec::new();
    for model_case in fixture["models"].as_array().ok_or("models missing")? {
        let path = Path::new(model_case["path"].as_str().ok_or("model path missing")?);
        assert_eq!(
            sha(&fs::read(path.join("riley-checkpoint.json"))?),
            model_case["checkpoint_manifest_sha256"]
                .as_str()
                .ok_or("manifest hash missing")?
        );
        let model = LoadedModel::load(
            path,
            LoadLimits::default().with_weight_byte_limits(32 << 30, 32 << 30)?,
        )?;
        // Match riley-server/main.rs owned_wide_query routing. Keep the
        // existing geometry/projection validation intact.
        let wide_query = model.spec().blocks().first().is_some_and(|b|
            b.attention().query_heads()*b.attention().head_dimension()
                > model.spec().embedding().hidden_size());
        let forward = if wide_query {
            PreparedLlamaForwardConfig::default().with_merged_qkv_projection()
        } else { PreparedLlamaForwardConfig::default() };
        println!("RILEY_TEACHER_FORWARD wide_query={wide_query}");
        let config = PreparedLlamaBatchExecutorConfig::new(
            LlamaBatchMetadataConfig::new(copies, 512*copies.min(8), 64*copies, copies, 64*copies)?,
            forward,
        )
        .with_active_row_buckets()
        .with_serving_sequence_token_bound(1024)
        .with_owned_hf_eager_bf16();
        // Match the second owned_wide_query branch in server/main.rs:2250.
        // Bias-free Qwen3 head normalization requires the fused RoPE split.
        let config = if wide_query { config.with_fused_qkv_rope() } else { config };
        let config = if completion == "iteration-batch" {
            config.with_iteration_batch_completion()
        } else {
            config
        };
        let config = if std::env::var("RILEY_OWNED_GRAPH").as_deref() == Ok("segments-v1") {
            config.with_owned_decode_graph()
        } else { config };
        let config = match std::env::var("RILEY_OWNED_BATCH").as_deref() {
            Ok("grouped-v1") => config.with_owned_decode_batch(),
            Ok("lt-mlp-v2") => config.with_owned_mlp_decode_batch(),
            Ok("exact-smallrows-v5") => config.with_exact_smallrows_decode_batch(),
            Ok("bounded-gateup-sm80-v1") => config.with_bounded_sm80_gateup_batch(),
            Ok("bounded-projections-sm80-v2")=>config.with_bounded_sm80_projection_batch(),
            Ok("native-kv-sm80-v3")=>config.with_bounded_sm80_projection_kv_batch(),
            Ok("native-attention-sm80-v4")=>config.with_bounded_sm80_attention_batch(),
            Ok("native-prefill-sm80-v5")=>config.with_bounded_sm80_prefill_batch(),
            Ok("exact-r2-v3") => {println!("RILEY_EXACT_R2_PROFILE mode=3 atomic_prefill=true cached_CSR=true");config.with_exact_r2_decode_batch()},
            Ok("exact-r2-global-v4") => {println!("RILEY_EXACT_R2_PROFILE mode=4 atomic_prefill=true cached_CSR=true");config.with_exact_r2_global_decode_batch()},
            _ => config,
        };
        let config = config.with_staged_step_uploads().with_fused_silu_multiply();
        let mut owner = PreparedLlamaBatchExecutor::prepare(&model, &c, &mut stream, config)?;
        owner.warm_owned_qwen_decode_graphs(false,&mut stream)?;
        let stable = c.allocation_stats()?;
        let row_bytes = model.spec().embedding().vocabulary_size() * 2;
        let mut bytes = vec![0; row_bytes*copies];
        let mut cases = Vec::new();
        let operation = (|| -> Result {
            // A bad prefill must be rejected before the valid decode partition
            // can run, without replacing the last successful shape or outputs.
            let snapshot=owner.last_shape_observation();let stats=owner.owned_mlp_graph_stats();
            let invalid=[model.spec().embedding().vocabulary_size() as u32];let good=[0u32];
            let (db,dv)=table(129)?;let pb=[64u32];let pv=[1u16];
            let bad_rows=[LlamaBatchRow::new(90001,LlamaBatchRowKind::Decode,&good,129,LlamaBatchBlockTable::new(BLOCK_TABLE_V1_VERSION,&db,&dv,129),Some(0)),
                LlamaBatchRow::new(90002,LlamaBatchRowKind::Prefill,&invalid,1,LlamaBatchBlockTable::new(BLOCK_TABLE_V1_VERSION,&pb,&pv,1),Some(1))];
            let err=owner.execute(&bad_rows,&mut stream).expect_err("whole-batch token admission must fail");
            assert!(matches!(err,riley_runtime::llama::LlamaBatchExecutorError::TokenOutOfRange{..}));
            assert!(!owner.is_poisoned());assert_eq!(owner.last_shape_observation(),snapshot);assert_eq!(owner.owned_mlp_graph_stats(),stats);assert_eq!(c.allocation_stats()?,stable);
            println!("RILEY_SPLIT_PREFLIGHT invalid_prefill_rejected=true shape_unchanged=true owner_reusable=true output_not_published=true");
            let no_output_prefill=std::env::var("RILEY_MIXED_NO_OUTPUT_PREFILL").as_deref()==Ok("1");
            let case=model_case["cases"].as_array().ok_or("cases missing")?.iter().find(|v|v["id"]=="natural-128").ok_or("natural128 missing")?;
            let prompt=ids(&case["prompt_ids"])?;let teacher=ids(&case["teacher_ids"])?;
            let steps=case["steps"].as_array().ok_or("steps")?;assert_eq!(teacher.len(),32);assert_eq!(copies,32);
            let original=std::path::PathBuf::from("/mnt/efs/nlp/psyche/riley-qkv-gateup-v214-20261019/v226-qwen3-4b-before-C1-eager");
            let mut rows=Vec::new();let mut mixed=0;
            for tick in 0..(copies+teacher.len()-1) {
                let mut order=(0..copies).filter(|&r|tick>=r&&tick-r<teacher.len()).collect::<Vec<_>>();
                if tick%2==1 {order.reverse();}
                let active=order.len();let token_store=order.iter().map(|&r|if tick==r {0}else{teacher[tick-r-1]}).collect::<Vec<_>>();
                let lengths=order.iter().map(|&r|prompt.len()+tick-r).collect::<Vec<_>>();
                let tables=lengths.iter().zip(order.iter()).map(|(&length,&copy)|{let(b,v)=table(length).unwrap();(b.iter().map(|x|*x+copy as u32*64).collect::<Vec<_>>(),v)}).collect::<Vec<_>>();
                let batch_rows=order.iter().enumerate().map(|(idx,&copy)|LlamaBatchRow::new(
                    (copy+1)as u64,if tick==copy {LlamaBatchRowKind::Prefill}else{LlamaBatchRowKind::Decode},
                    if tick==copy {prompt.as_slice()}else{&token_store[idx..idx+1]},lengths[idx]as u32,
                    LlamaBatchBlockTable::new(BLOCK_TABLE_V1_VERSION,&tables[idx].0,&tables[idx].1,lengths[idx]as u32),if no_output_prefill&&tick==copy {None}else{Some((if tick==copy {active-1}else{order[..idx].iter().filter(|&&r|r!=tick).count()})as u32)})).collect::<Vec<_>>();
                owner.execute(&batch_rows,&mut stream)?;bytes.resize(row_bytes*order.iter().filter(|&&r|!no_output_prefill||tick!=r).count(),0);owner.download_logits(&mut bytes,&mut stream)?;
                let prefills=order.iter().filter(|&&copy|copy==tick).count();if prefills>0&&active>prefills {mixed+=1;}
                for (idx,&copy)in order.iter().enumerate(){if no_output_prefill&&tick==copy {continue;}let step=tick-copy;let slot=(if tick==copy {active-1}else{order[..idx].iter().filter(|&&r|r!=tick).count()});let got=&bytes[slot*row_bytes..(slot+1)*row_bytes];let expected=steps.iter().find(|v|v["step"].as_u64()==Some(step as u64)).ok_or("full32 HF step missing")?;let filename=leaf(expected["file"].as_str().ok_or("HF file missing")?)?;let hf=fs::read(root.join(filename))?;assert_eq!(sha(&hf),fixture["files"][filename]["sha256"].as_str().ok_or("HF SHA")?);let native=fs::read(original.join(format!("qwen3-4b-natural-128-s{step}.native.bf16")))?;
                    assert_eq!(got,hf.as_slice(),"mixed HF bytes tick={tick} copy={copy} step={step} slot={slot}");assert_eq!(got,native.as_slice(),"mixed original native bytes");
                    let file=format!("mixed-t{tick}-copy{copy}-s{step}.bf16");fs::write(output.join(&file),got)?;
                    rows.push(json!({"tick":tick,"copy":copy,"step":step,"output_slot":slot,"file":file,"sha256":sha(got),"HF_sha256":sha(&hf),"native_sha256":sha(&native),"bytes_equal":true}));
                }
                assert_eq!(c.allocation_stats()?,stable,"mixed hot CUDA allocation");
                println!("RILEY_MIXED_TEACHER tick={tick} active={active} prefill={prefills} reverse={} permuted_outputs=true",tick%2==1);
            }
            assert_eq!(mixed,31);assert_eq!(rows.len(),if no_output_prefill{992}else{1024});
            cases.push(json!({"id":"staggered-natural128","no_output_prefill":no_output_prefill,"mixed_steps":mixed,"rows":rows}));
            Ok(())
        })();
        let graph_stats=owner.owned_mlp_graph_stats();
        owner.close()?;
        operation?;
        assert!(c.allocation_stats()?.is_zero());
        reports.push(json!({"tag":model_case["tag"],"cases":cases,"mlp_graph":graph_stats.map(|v|json!({"captures":v.captures,"hits":v.hits,"fallbacks":v.eager_fallbacks}))}));
    }
    stream.close()?;
    c.close()?;
    fs::write(
        output.join("result.json"),
        serde_json::to_vec_pretty(
            &json!({"scope":"teacher-forced numerical diagnostic, not quality acceptance","completion":completion,"copies":copies,"all_counts":all_counts,"chunked_prefill":chunked_prefill,"fixture_sha256":sha(&fixture_bytes),"models":reports}),
        )?,
    )?;
    Ok(())
}
