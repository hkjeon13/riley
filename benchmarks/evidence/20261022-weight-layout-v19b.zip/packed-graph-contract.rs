use riley_cuda::*;
use std::error::Error;
type Result<T=()> = std::result::Result<T,Box<dyn Error>>;
fn span(b:&CudaDeviceBuffer)->CudaResult<CudaBufferSpan<'_>>{CudaBufferSpan::new(b,CudaDType::BF16,0,b.byte_len())}
fn upload(c:&CudaContext,s:&mut CudaStream,h:&mut CudaPinnedHostBuffer,b:&[u8])->Result<CudaDeviceBuffer>{let mut p=c.allocate_device_buffer(b.len()as u64)?;p.upload_from_slice(0,b,h,s)?;Ok(p)}
fn constant(n:usize,word:u16)->Vec<u8>{word.to_le_bytes().repeat(n)}
fn main()->Result {
 let rt=CudaRuntime::initialize()?;let c=rt.device(0)?.create_context()?;let mut s=c.create_stream()?;let mut h=c.allocate_pinned_host_buffer(4*1024*1024)?;
 let half=9728*2560*2;let g=constant(half/2,0x3b80);let u=constant(half/2,0x3c00);
 let gate_w=upload(&c,&mut s,&mut h,&g)?;let up_w=upload(&c,&mut s,&mut h,&u)?;let down_w=upload(&c,&mut s,&mut h,&constant(2560*9728,0x3b00))?;
 let mut merged=g.clone();merged.extend_from_slice(&u);let merged=upload(&c,&mut s,&mut h,&merged)?;
 let mut packed=vec![0u8;2*half];for it in 0..40 {for tile in 0..304 {for row in 0..64 {let a=if row<32{&g}else{&u};let from=((tile*32+row%32)*2560+it*64)*2;let to=(((it*304+tile)*64+row)*64)*2;packed[to..to+128].copy_from_slice(&a[from..from+128]);}}}
 let a=upload(&c,&mut s,&mut h,&packed)?;let b=upload(&c,&mut s,&mut h,&vec![0u8;2*half])?;
 let input=upload(&c,&mut s,&mut h,&constant(16*2560,0x3c80))?;let mut gate=c.allocate_device_buffer(16*9728*4)?;let mut up=c.allocate_device_buffer(16*9728*2)?;let mut product=c.allocate_device_buffer(16*9728*2)?;let mut output=c.allocate_device_buffer(16*2560*2)?;
 let mut graph=CudaOwnedHfMlpGraph::prepare(&c,16,2560,9728,32)?;graph.enable_piecewise_sm80(&c)?;graph.set_capture_allowed(true);
 let mut first=Vec::new();
 for (turn,packed) in [&a,&a,&b].iter().enumerate(){
  let mut p=CudaOwnedHfMlpParams{input:span(&input)?,gate_weight:span(&gate_w)?,up_weight:span(&up_w)?,down_weight:span(&down_w)?,gate:&mut gate,up:&mut up,product:&mut product,output:&mut output,active_rows:2};
  let mut batch=s.begin_command_batch()?;graph.execute_with_projection(&mut p,span(&merged)?,Some(span(packed)?),&mut batch.commands())?;batch.finish()?;
  let mut bytes=vec![0u8;2*9728*2];product.download_to_slice(0,&mut bytes,&mut h,&mut s)?;
  match turn {0=>{assert!(bytes.iter().any(|&v|v!=0));first=bytes;assert_eq!(graph.stats().captures,1);},1=>{assert_eq!(bytes,first);assert_eq!(graph.stats().hits,1);},_=>{assert!(bytes.iter().all(|&v|v==0));assert_eq!(graph.stats().captures,2);}}
 }
 graph.close()?;
 // A full-length, unaligned packed span must fail before launch, independently of short-span rejection.
 let padded=upload(&c,&mut s,&mut h,&vec![0u8;2*half+32])?;let mut plan=c.prepare_owned_hf_gemm(CudaGemmConfig::new(16,9728,2560,0)?)?;plan.prepare_sm80_prefill()?;
 assert!(plan.try_execute_hf_sm80_fused_gate_up_packed(CudaBufferSpan::new(&padded,CudaDType::BF16,2,(2*half)as u64)?,span(&gate_w)?,span(&up_w)?,CudaBufferSpan::new(&input,CudaDType::BF16,0,2*2560*2)?,CudaBufferSpanMut::new(&mut product,CudaDType::BF16,0,2*9728*2)?,2,&mut s).is_err());assert!(plan.close().is_err());
 println!("PACKED_GRAPH_CONTRACT passed captures=2 hits=1 allocation_identity=true full_length_unaligned_rejected=true");
 padded.close()?;output.close()?;product.close()?;up.close()?;gate.close()?;input.close()?;b.close()?;a.close()?;merged.close()?;down_w.close()?;up_w.close()?;gate_w.close()?;h.close()?;s.close()?;c.close()?;Ok(())
}
