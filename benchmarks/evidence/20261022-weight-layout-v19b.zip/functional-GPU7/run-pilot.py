from pathlib import Path
import json,subprocess,time,traceback
w=Path(__file__).parent;s=dict(phase='functional-pilot',started_ns=time.time_ns())
def save():(w/'pilot-state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 for n in ['pilot-c16','pilot-c32']:
  s['current']=n;save()
  with(w/(n+'.outer.log')).open('x')as f:q=subprocess.run(['python3',str(w/'run-job.py'),n],stdout=f,stderr=f)
  assert q.returncode==0,(n,q.returncode)
 with(w/'audit.outer.log').open('x')as f:q=subprocess.run(['python3',str(w/'audit-complete.py'),'--partial'],stdout=f,stderr=f)
 assert q.returncode==0
 a=json.loads((w/'audit-partial.json').read_text());assert len(a['arms'])==2
 s.update(phase='complete',verified_SSE_values=a['total_full_SSE_values_verified'],finished_ns=time.time_ns());save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
