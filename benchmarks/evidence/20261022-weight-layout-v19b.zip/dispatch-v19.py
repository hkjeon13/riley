from pathlib import Path
import sqlite3,json,sys,hashlib,time
out=[]
for arg in sys.argv[1:]:
 p=Path(arg);d=sqlite3.connect(p);d.row_factory=sqlite3.Row;strings=dict(d.execute('select id,value from StringIds'));r=list(d.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL'));a=[x for x in r if 'v19_kmajor_gate'in strings[x['demangledName']]];before='owned-before'in str(p);c16='profile-c16'in str(p);assert (not a)if before or not c16 else bool(a),(p,len(a));out.append(dict(trace=str(p),trace_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),before=before,packed_kernel_launches=len(a),packed_kernel_ms=sum(x['end']-x['start']for x in a)/1e6,packed_kernels_in_graph=sum(bool(x['graphId'])for x in a),total_kernel_ms=sum(x['end']-x['start']for x in r)/1e6))
w=Path(__file__).parent
logs=sorted(w.glob('runs/*/*-owned-after/server.log'));assert len(logs)==12,len(logs)
for p in logs:
 c16='final-c16'in str(p)or'profile-c16'in str(p);assert ('RILEY_V19_PACKED_GATE_UP layers=32 bytes=3187671040'in p.read_text())==c16,p
(w/'actual-candidate-dispatch.json').write_text(json.dumps(dict(time_ns=time.time_ns(),profiles=out,scope='Separate64warm64keep diagnostic windows; actual packed GateUp launches verified, 32/36 layers eligible for R2..16 only at configured capacity<=16; capacity32 has no packed allocations or launches. No normal-arm throughput inferred from aggregate kernel sums. Down and R17..32 unchanged.'),indent=2));print(json.dumps(out,indent=2))
