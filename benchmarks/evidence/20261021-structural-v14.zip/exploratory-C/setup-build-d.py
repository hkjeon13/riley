from pathlib import Path
import shutil,json
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14d-20261021');b=w.parent/'riley-piecewise-v13b-20261020'
w.mkdir(exist_ok=False)
for n in ['tmp','cache','research','runs','ipc6','ipc7']:(w/n).mkdir()
for n in ['holder.py','observe-finite.py']:shutil.copy2(b/n,w/n)
shutil.copytree(b/'source',w/'source')
for n in ['build.sh','recheck-c02.py','build-teacher-final.py','teacher-probe-final.rs','run-teacher-final.py','prepare-body-teacher.py','audit-teachers-e.py','measure-matched.py','measure-profile.py','analyze-profiles.py','audit-complete.py','analyze-final.py','run-job.py','stock-runtime-proof.py','final-holds.py']:
 s=(b/n).read_text().replace(str(b),str(w)).replace('riley-piecewise-v13b','riley-structural-v14d');(w/n).write_text(s)
# Teacher mixed output name must differ from its executable.
s=(b/'prepare-mixed-teacher.py').read_text().replace(str(b),str(w)).replace("RILEY_DIVERGENCE_NATIVE_OUTPUT=str(W/'teacher-mixed')","RILEY_DIVERGENCE_NATIVE_OUTPUT=str(W/'teacher-mixed-output')");(w/'prepare-mixed-teacher.py').write_text(s)
shutil.copy2(b/'call-inspection-nvtx.so',w/'call-inspection-nvtx.so')
for c in [16,32]:
 a=json.loads((b/f'final-c{c}.argv.json').read_text());a=[v.replace(str(b),str(w)).replace('riley-piecewise-v13b','riley-structural-v14d')for v in a];a[a.index('--baseline-server')+1]=str(b/'riley-piecewise-v13b');a[a.index('--gpu')+1]='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0';a[a.index('--index')+1]='7';(w/f'final-c{c}.argv.json').write_text(json.dumps(a,indent=2))
 a[a.index('--repeats')+1]='1';a[a.index('--keep')+1]='64';a[a.index('--modes')+1]='owned-before,owned-after';a[a.index('--out')+1]=str(w/f'runs/screen-c{c}');(w/f'screen-c{c}.argv.json').write_text(json.dumps(a,indent=2))
