from pathlib import Path
import json,time,subprocess,os,traceback
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14c-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';old=w.parent/'riley-qkv-gateup-v214-20261019';state=dict(phase='waiting-mixed',started_ns=time.time_ns())
def save():(w/'additional-diagnostics-state.json').write_text(json.dumps(state,indent=2))
def wait_receipt(name):
 end=time.monotonic()+1200
 while True:
  assert time.monotonic()<end,('receipt timeout',name)
  p=w/(name+'.json')
  if p.exists():
   s=json.loads(p.read_text())
   if s['status']!='running':assert s['status']=='complete',s;return
  time.sleep(2)
def run(name,a,env):
 (w/(name+'.argv.json')).write_text(json.dumps(a,indent=2))
 with(w/(name+'.launch.log')).open('x')as f:s=subprocess.run(a,env=env,stdout=f,stderr=f)
 assert s.returncode==0,(name,s.returncode)
try:
 save();wait_receipt('observed-teacher-mixed');state['phase']='mixed-no-output';save()
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'teacher-mixed-no-output'),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES='32',RILEY_TEACHER_SHRINK='',RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH='segments-v1',RILEY_OWNED_BATCH='native-prefill-sm80-v5',RILEY_MIXED_NO_OUTPUT_PREFILL='1')
 a=json.loads((w/'teacher-mixed.argv.json').read_text());a[a.index('--out')+1]=str(w/'observed-teacher-mixed-no-output');run('teacher-mixed-no-output',a,env)
 state['phase']='fused-attention-component';save();env['RILEY_DIVERGENCE_NATIVE_OUTPUT']=str(w/'research/fused-attention-output')
 a=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','24-31','python3',str(w/'observe-finite.py'),'--out',str(w/'research/fused-attention-observed'),'--',str(w/'research/fused-attention')];run('fused-attention-component',a,env)
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
