from pathlib import Path
import subprocess,json,os
W=Path('/mnt/efs/nlp/psyche/riley-structural-v14d-20261021');s=(W/'teacher-probe-final.rs').read_text();a=s.index('            let mut remaining_live =');b=s.index('            Ok(())\n        })();',a)
s=s[:a]+r'''            let case=model_case["cases"].as_array().ok_or("cases missing")?.iter().find(|v|v["id"]=="natural-128").ok_or("natural128 missing")?;
            let prompt=ids(&case["prompt_ids"])?;let teacher=ids(&case["teacher_ids"])?;
            let steps=case["steps"].as_array().ok_or("steps")?;assert_eq!(teacher.len(),32);assert_eq!(copies,32);
            let original=std::path::PathBuf::from("/mnt/efs/nlp/psyche/riley-qkv-gateup-v214-20261019/v226-qwen3-4b-before-C1-eager");
            let mut rows=Vec::new();let mut mixed=0;
            for tick in 0..(copies+teacher.len()-1) {
                let mut order=(0..copies).filter(|&r|tick>=r&&tick-r<teacher.len()).collect::<Vec<_>>();
                if tick%2==1 {order.reverse();}
                let active=order.len();let token_store=order.iter().map(|&r|if tick==r {0}else{teacher[tick-r-1]}).collect::<Vec<_>>();
                let lengths=order.iter().map(|&r|prompt.len()+tick-r).collect::<Vec<_>>();
                let tables=lengths.iter().zip(order.iter()).map(|(&length,&copy)|{let(b,v)=table(length).unwrap();(b.iter().map(|x|*x+copy as u32*64).collect::<Vec<_>>(),v)}).collect::<Vec<_>>();
                let batch_rows=order.iter().enumerate().map(|(idx,&copy)|LlamaBatchRow::new(
                    (copy+1)as u64,if tick==copy {LlamaBatchRowKind::Prefill}else{LlamaBatchRowKind::Decode},
                    if tick==copy {prompt.as_slice()}else{&token_store[idx..idx+1]},lengths[idx]as u32,
                    LlamaBatchBlockTable::new(BLOCK_TABLE_V1_VERSION,&tables[idx].0,&tables[idx].1,lengths[idx]as u32),Some((active-idx-1)as u32))).collect::<Vec<_>>();
                owner.execute(&batch_rows,&mut stream)?;bytes.resize(row_bytes*active,0);owner.download_logits(&mut bytes,&mut stream)?;
                let prefills=order.iter().filter(|&&copy|copy==tick).count();if prefills>0&&active>prefills {mixed+=1;}
                for (idx,&copy)in order.iter().enumerate(){let step=tick-copy;let slot=active-idx-1;let got=&bytes[slot*row_bytes..(slot+1)*row_bytes];let expected=steps.iter().find(|v|v["step"].as_u64()==Some(step as u64)).ok_or("full32 HF step missing")?;let filename=leaf(expected["file"].as_str().ok_or("HF file missing")?)?;let hf=fs::read(root.join(filename))?;assert_eq!(sha(&hf),fixture["files"][filename]["sha256"].as_str().ok_or("HF SHA")?);let native=fs::read(original.join(format!("qwen3-4b-natural-128-s{step}.native.bf16")))?;
                    assert_eq!(got,hf.as_slice(),"mixed HF bytes tick={tick} copy={copy} step={step} slot={slot}");assert_eq!(got,native.as_slice(),"mixed original native bytes");
                    let file=format!("mixed-t{tick}-copy{copy}-s{step}.bf16");fs::write(output.join(&file),got)?;
                    rows.push(json!({"tick":tick,"copy":copy,"step":step,"output_slot":slot,"file":file,"sha256":sha(got),"HF_sha256":sha(&hf),"native_sha256":sha(&native),"bytes_equal":true}));
                }
                assert_eq!(c.allocation_stats()?,stable,"mixed hot CUDA allocation");
                println!("RILEY_MIXED_TEACHER tick={tick} active={active} prefill={prefills} reverse={} permuted_outputs=true",tick%2==1);
            }
            assert_eq!(mixed,31);assert_eq!(rows.len(),1024);
            cases.push(json!({"id":"staggered-natural128","mixed_steps":mixed,"rows":rows}));
''' + s[b:];(W/'teacher-mixed.rs').write_text(s)
s=(W/'build-teacher-final.py').read_text();a=s.index("with(n/'teacher-final-launch.log')");s=s[:a].replace('teacher-probe-final.rs','teacher-mixed.rs').replace('teacher-probe-final','teacher-mixed').replace('teacher-final-build','teacher-mixed-build').replace('teacher-final-binary','teacher-mixed-binary');(W/'build-teacher-mixed.py').write_text(s)
with(W/'teacher-mixed-build.outer.log').open('x')as f:r=subprocess.run(['python3',str(W/'build-teacher-mixed.py')],stdout=f,stderr=f)
assert r.returncode==0
R=W.parent/'riley-w0-a100-gpu67-20261019';old=W.parent/'riley-qkv-gateup-v214-20261019';env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(W/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(W/'teacher-mixed-output'),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES='32',RILEY_TEACHER_SHRINK='',RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH='segments-v1',RILEY_OWNED_BATCH='native-prefill-sm80-v5');a=['python3',str(R/'control.py'),'--lease-dir',str(R/'leases-v2'),'--index','6','run','--','taskset','-c','24-31','python3',str(W/'observe-finite.py'),'--out',str(W/'observed-teacher-mixed'),'--',str(W/'teacher-mixed'),'--ignored','--exact','owned_batch_teacher_forced_logits_are_finite_and_reported','--nocapture','--test-threads=1'];(W/'teacher-mixed.argv.json').write_text(json.dumps(a,indent=2))
with(W/'teacher-mixed.launch.log').open('x')as f:r=subprocess.run(a,env=env,stdout=f,stderr=f)
assert r.returncode==0
