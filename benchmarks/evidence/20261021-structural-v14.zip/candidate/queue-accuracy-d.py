from pathlib import Path
import json,subprocess,time,os,traceback,re
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14d-20261021');old=w.parent/'riley-qkv-gateup-v214-20261019';state=dict(phase='waiting-CPU',started_ns=time.time_ns())
def save():(w/'accuracy-state.json').write_text(json.dumps(state,indent=2))
def run(script):
 state['phase']=script;save()
 with(w/(script+'.queue.log')).open('x')as f:r=subprocess.run(['python3',str(w/script)],stdout=f,stderr=f)
 assert r.returncode==0,(script,r.returncode)
def wait_receipt(name):
 end=time.monotonic()+1200
 while True:
  assert time.monotonic()<end,('receipt timeout',name);p=w/(name+'.json')
  if p.exists():
   x=json.loads(p.read_text())
   if x['status']!='running':assert x['status']=='complete',x;return
  time.sleep(2)
try:
 save();end=time.monotonic()+1200
 while not(w/'native-kv-build-and-cpu.exit').exists():assert time.monotonic()<end;time.sleep(2)
 s=(w/'native-kv-regression.log').read_text();assert s.count('test result: FAILED.')==1 and '38 passed; 4 failed;'in s
 with(w/'c02-fixture.queue.log').open('x')as f:r=subprocess.run(['python3',str(w/'recheck-c02.py'),'--allow-test-tmp'],stdout=f,stderr=f)
 assert r.returncode==0
 run('build-teacher-only.py');run('run-teacher-final.py');run('prepare-body-teacher.py');wait_receipt('observed-teacher-body-allR');run('audit-teachers-e.py');run('prepare-advanced-teacher.py')
 state['phase']='mixed-no-output';save();env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'teacher-mixed-no-output'),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES='32',RILEY_TEACHER_SHRINK='',RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH='segments-v1',RILEY_OWNED_BATCH='native-prefill-sm80-v5',RILEY_MIXED_NO_OUTPUT_PREFILL='1')
 a=json.loads((w/'teacher-mixed.argv.json').read_text());a[a.index('--out')+1]=str(w/'observed-teacher-mixed-no-output');(w/'teacher-mixed-no-output.argv.json').write_text(json.dumps(a,indent=2))
 with(w/'teacher-mixed-no-output.launch.log').open('x')as f:r=subprocess.run(a,env=env,stdout=f,stderr=f)
 assert r.returncode==0
 run('audit-mixed-c.py');state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
