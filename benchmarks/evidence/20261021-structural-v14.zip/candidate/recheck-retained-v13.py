from pathlib import Path
import os,json,re,subprocess,tempfile,hashlib,argparse,time
p=argparse.ArgumentParser();p.add_argument('--allow-test-tmp',action='store_true');a=p.parse_args();assert a.allow_test_tmp,'Existing user authorization is required for only four C02 fixture trees'
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14d-20261021');v=w.parent/'riley-piecewise-v13b-20261020';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((v/'source-manifest.json').read_text());assert len(m)==935 and all(sha(v/'source'/f)==h for f,h in m.items());assert sha(v/'riley-piecewise-v13b')=='9dd87720ceb5c9f99532b8b01851557598032a6fe5ba037316e327eba1505566';rows=[]
for l in(v/'native-kv-regression.log').read_text().splitlines():
 try:rows.append(json.loads(l))
 except ValueError:pass
bins={x['executable']:x['target']['name']for x in rows if x.get('reason')=='compiler-artifact'and x.get('profile',{}).get('test')and x.get('executable')};assert len(bins)==5,bins
names=['tests::c02_audit_directory_is_private_held_and_descriptor_relative','tests::c02_generation_audit_writer_creates_a_bound_leaf_and_marker_once','tests::c02_generation_audit_writer_refuses_schema_oversize_without_evidence','tests::c02_shutdown_writer_binds_raw_final_metrics_to_a_nonhidden_marker'];env=dict(os.environ,CUDA_VISIBLE_DEVICES='',TMPDIR=str(w/'tmp'),LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64');proof=[];passed=ignored=0;server=None
for i,(binary,name)in enumerate(bins.items()):
 args=['taskset','-c','48-51',binary,'--test-threads=1']
 if name=='riley':
  server=binary
  for n in names:args+=['--skip',n]
 r=subprocess.run(args,env=env,cwd=w,capture_output=True,text=True);log=r.stdout+r.stderr;(w/f'retained-v13-unit-{i}.log').write_text(log);assert r.returncode==0,(name,r.returncode);mat=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',log);assert len(mat)==1;passed+=int(mat[0][0]);ignored+=int(mat[0][1]);proof.append(dict(name=name,binary=binary,binary_sha256=sha(Path(binary)),argv=args,returncode=0,passed=int(mat[0][0]),ignored=int(mat[0][1])))
assert passed==520 and ignored==40 and server,(passed,ignored)
os.umask(0o077)
with tempfile.TemporaryDirectory(prefix='riley-c02-retained-v13-',dir='/tmp')as temporary:
 env['TMPDIR']=temporary
 for i,name in enumerate(names):
  args=['taskset','-c','48-51',server,'--exact',name,'--test-threads=1'];r=subprocess.run(args,env=env,cwd=w,capture_output=True,text=True);(w/f'retained-v13-c02-{i}.log').write_text(r.stdout+r.stderr);assert r.returncode==0,name;proof.append(dict(name=name,argv=args,returncode=0,passed=1,fixture_only_tmp_exception=True));passed+=1
assert not Path(temporary).exists();x=dict(time_ns=time.time_ns(),source_manifest_sha256=sha(v/'source-manifest.json'),source_files=935,binary_sha256=sha(v/'riley-piecewise-v13b'),CPU_passed=passed,CPU_ignored=ignored,fixture_temporary_root=temporary,fixture_temporary_tree_removed=True,tests=proof,scope='Fresh execution of the unchanged retained v13 compiled CPU test artifacts. CUDA invisible; only four C02 fixture trees use authorized private/tmp; source/model/scripts/build/runtime remain on EFS. Fresh10native baseline API arms independently audited.')
(w/'retained-v13-cpu-recheck.json').write_text(json.dumps(x,indent=2));print('retained v13 fresh CPU',passed,'passed',ignored,'ignored')
