from pathlib import Path
import json,time,subprocess,traceback
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14d-20261021');state=dict(phase='waiting-normal',started_ns=time.time_ns())
def save():(w/'profile-queue-state.json').write_text(json.dumps(state,indent=2))
try:
 save();end=time.monotonic()+5400
 for name in ['final-c16','final-c32']:
  while True:
   assert time.monotonic()<end,'normal matrix timeout';p=w/(name+'.state.json')
   if p.exists():
    x=json.loads(p.read_text())
    if x['status']!='running':assert x['status']=='complete',x;break
   time.sleep(3)
 for name in ['profile-c16','profile-c32','stock-profile-c32','route-proof-c32-r2']:
  state.update(phase='profiling',current=name);save()
  with(w/(name+'.queue.log')).open('x')as f:s=subprocess.run(['python3',str(w/'run-job.py'),name],stdout=f,stderr=f)
  assert s.returncode==0,(name,s.returncode)
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
