from pathlib import Path
import json,subprocess,os,time,traceback,threading
p=Path(__file__).resolve().parent;r=p.parent/'riley-w0-a100-gpu67-20261019';old=p.parent/'riley-qkv-gateup-v214-20261019'
state=dict(pid=os.getpid(),status='running',completed=[],current={});lock=threading.Lock();errors=[]
def save():
 q=p/'final-teacher-state.next';q.write_text(json.dumps(state,indent=2));q.replace(p/'final-teacher-state.json')
with lock:save()
def run(name,index,copies,graph,shrink):
 try:
  gpu='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7'if index==6 else'GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0'
  env=dict(os.environ,CUDA_VISIBLE_DEVICES=gpu,LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(p/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(p/name),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES=copies,RILEY_TEACHER_SHRINK=shrink,RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH=graph,RILEY_OWNED_BATCH='native-prefill-sm80-v5')
  env.pop('CUBLAS_WORKSPACE_CONFIG',None);env.pop('CUDA_MPS_ACTIVE_THREAD_PERCENTAGE',None)
  a=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index',str(index),'run','--','/usr/bin/taskset','-c','24-31'if index==6 else'32-39','python3',str(p/'observe-finite.py'),'--out',str(p/('observed-'+name)),'--',str(p/'teacher-probe-final'),'--ignored','--exact','owned_batch_teacher_forced_logits_are_finite_and_reported','--nocapture','--test-threads=1']
  with(p/(name+'.launch.log')).open('x')as f:
   proc=subprocess.Popen(a,env=env,stdout=f,stderr=f)
   with lock:state['current'][name]=proc.pid;save()
   rc=proc.wait()
  assert rc==0,(name,rc)
  with lock:state['completed'].append(name);del state['current'][name];save()
 except BaseException as e:
  with lock:errors.append(dict(name=name,error=repr(e),traceback=traceback.format_exc()));save()
run('final-teacher-C1-eager',6,'1','off','')
run('final-teacher-allR-Graph',6,'32','segments-v1','all-v1')
with lock:state.update(status='failed'if errors else'complete',errors=errors,finished_ns=time.time_ns());save()
if errors:raise SystemExit(1)
