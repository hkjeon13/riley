from pathlib import Path
import json,hashlib,re,time,sqlite3
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14d-20261021');b=w.parent/'riley-piecewise-v13b-20261020';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((w/'campaign-state.json').read_text())['phase']=='complete'
assert json.loads((w/'accuracy-state.json').read_text())['phase']=='complete'
assert json.loads((w/'profile-queue-state.json').read_text())['phase']=='complete'
assert json.loads((w/'route-proof-c32-r3.state.json').read_text())['status']=='complete'
frozen=json.loads((w/'route-proof-r3-inputs.json').read_text());assert all(sha(Path(p))==h for p,h in frozen['sha256'].items())
source=json.loads((w/'source-manifest.json').read_text());assert len(source)==935 and all(sha(w/'source'/f)==h for f,h in source.items());lineage=json.loads((w/'source-lineage.json').read_text());assert sha(w/'riley-structural-v14d')==lineage['binary_sha256'];assert sha(b/'riley-piecewise-v13b')=='9dd87720ceb5c9f99532b8b01851557598032a6fe5ba037316e327eba1505566'
for f,r in lineage['changed'].items():assert sha(w/'source'/f)==r['after'] and sha(b/'source'/f)==r['before']
stock=json.loads((w/'stock-installed-source-proof.json').read_text());assert all(sha(Path(r['path']))==r['sha256']for r in stock['sources'])
c02=json.loads((w/'c02-fixture-recheck-v2/complete.json').read_text());assert c02['all_passed']and len(c02['tests'])==4 and not Path(c02['temporary_root']).exists()
ordinary=re.findall(r'test result:.*',(w/'native-kv-regression.log').read_text());assert sum(int(re.search(r'(\d+) passed',s)[1])for s in ordinary)==521;assert sum(int(re.search(r'(\d+) ignored',s)[1])for s in ordinary)==40
teacher=json.loads((w/'final-teacher-audit.json').read_text())['runs'];assert sum(r['files']for r in teacher)==2464 and all(r['all_bytes_equal_to_original_native_and_HF']for r in teacher)
mixed=json.loads((w/'mixed-byte-audit.json').read_text());assert mixed['total_rows']==2016 and all(r['all_literal_equal_to_original_native_and_HF']for r in mixed['runs'])
a=json.loads((w/'independent-audit.json').read_text());normal=[r for r in a['arms']if r['run']in ['final-c16','final-c32']];assert len(normal)==30;startup=[]
for r in normal:
 if r['record']['mode']=='vllm':continue
 p=w/'runs'/r['run']/r['arm'];argv=json.loads((p/'argv.json').read_text());assert argv[argv.index('--owned-decode-graph')+1]=='segments-v1';s=(p/'server.log').read_text();pre,post=s.split('riley listening on',1);assert 'capture=true'not in post
 c=r['record']['concurrency'];assert f'RILEY_OWNED_BODY_WARMUP rows=1..{c} greedy=true complete=true'in pre
 keys=sorted(set(map(int,re.findall(r'RILEY_OWNED_BODY_KEY active_rows=(\d+)',pre))));after=r['record']['mode']=='owned-after';assert keys==list(range(1 if after else 2,c+1)),(p,keys)
 piece=None
 if after:
  sealed=re.findall(r'RILEY_PIECEWISE_SEALED captures=(\d+) entries=(\d+)',pre);assert sealed and tuple(map(int,sealed[-1]))==(36*c,36*c)
  close=re.findall(r'RILEY_OWNED_SM80_MLP captures=(\d+) hits=(\d+) eager_fallbacks=(\d+) stream_resets=(\d+)',post);assert len(close)==1;cap,hits,fallback,resets=map(int,close[0]);assert cap==36*c and hits>0 and fallback==resets==0
  piece=dict(captures=cap,hits=hits,eager_fallbacks=fallback,stream_resets=resets,additional_captures_after_listen=cap-int(sealed[-1][0]))
 startup.append(dict(arm=str(p),body_keys_before_listen=keys,body_captures_before_listen=pre.count('capture=true'),body_captures_after_listen=post.count('capture=true'),piece=piece))
route=w/'runs/route-proof-c32-r3/c32-r0-owned-after/server.log';assert 'cannot be preloaded'not in route.read_text();lines=[s for s in route.read_text().splitlines()if s.startswith('RILEY_MERGED_LT_EXECUTED')];assert lines,'No actual merged Lt calls'
rows=set()
for s in lines:
 m=re.search(r'N=19456 M=(\d+) K=2560 status=(\d+) recipe=([^ ]+)',s);assert m and m[2]=='0' and m[3]=='31,15,17,0,0,0,0',s;rows.add(int(m[1]))
assert rows==set(range(1,33)),rows
counts={int(m):int(n)for m,n in re.findall(r'RILEY_MERGED_LT_CALL_COUNT M=(\d+) calls=(\d+)',route.read_text())};assert set(counts)==set(range(1,33))
merged=dict(executed_rows=sorted(rows),recorded_first_call_per_row=len(lines),host_cublasLtMatmul_calls_including_startup_and_capture=counts,not_a_GPU_graph_replay_counter=True,lines=lines,normal_throughput_instrumented=False);(w/'merged-dispatch-proof.json').write_text(json.dumps(merged,indent=2))
fused=[]
for name,c in [('profile-c16',16),('profile-c32',32)]:
 for mode in ['owned-before','owned-after']:
  p=w/'runs'/name/f'c{c}-r0-{mode}'/'trace.sqlite';db=sqlite3.connect(p);records=[dict(gridX=x,gridY=y,gridZ=z,blockX=bx,blockY=by,blockZ=bz,count=n,ms=ms)for x,y,z,bx,by,bz,n,ms in db.execute("select k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ,count(*),sum(k.end-k.start)/1e6 from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds s on s.id=k.demangledName where s.value like '%sm80_fused_softpv_dispatch%' group by k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ")];db.close()
  if name=='profile-c32'and mode=='owned-after':assert records and all(24<=r['gridY']<=32 and r['gridX']==16 and r['gridZ']==1 and r['blockX']==128 for r in records)
  else:assert not records,(name,mode,records)
  fused.append(dict(campaign=name,mode=mode,trace=str(p),fused_kernel_geometries=records))
(w/'fused-attention-dispatch-proof.json').write_text(json.dumps(fused,indent=2))
stats=json.loads((w/'final-statistics.json').read_text());result=dict(time_ns=time.time_ns(),correctness_source_resource_passed=True,source_files=935,changed_files=len(lineage['changed']),CPU_passed=525,CPU_ignored=40,C02_fixture_tree_removed=True,teacher_BF16_files=2464,mixed_teacher_BF16_files=2016,normal_arms=30,all_full_SSE_values_verified=a['total_full_SSE_values_verified'],normal_full_SSE_values_verified=sum(r['full_SSE_values_verified']for r in normal),Riley_normal_full_native_values_verified=sum(r['full_SSE_values_verified']for r in normal if r['record']['mode']!='vllm'),stock_normal_self_SSE_verified=sum(r['full_SSE_values_verified']for r in normal if r['record']['mode']=='vllm'),stock_source_unchanged=True,normal_same_physical_GPU=7,normal_whole_device_peak_MiB=max(r['peak_whole_device_MiB']for r in normal),normal_foreign_GPU_pids=sorted({p for r in normal for p in r['foreign_gpu_pids']}),normal_admitted_coexisting_GPU_pids=sorted({p for r in normal for p in r.get('admitted_coexisting_gpu_pids',[])}),startup_and_graph_replay=startup,performance_tail_flags_preserved={str(c['concurrency']):c['tail_over_two_percent_flags']for c in stats['cells']},all_repeat_tail_two_percent_gate_passed=all(not c['tail_over_two_percent_flags']for c in stats['cells']),merged_recipe_actual_rows=sorted(rows),fused_dispatch=fused)
retained=json.loads((w/'retained-v13-cpu-recheck.json').read_text());assert retained['CPU_passed']==524 and retained['CPU_ignored']==40 and retained['fixture_temporary_tree_removed']
local=json.loads((w/'local-source-and-patch-audit.json').read_text());assert local['candidate_D_not_applied'] and local['reconstructed_D_all_sha256_match']
decision=json.loads((w/'adoption-decision.json').read_text());assert not decision['adopted']
result.update(candidate_D_adopted=False,retained_default_source='v13B',retained_source_manifest_sha256=retained['source_manifest_sha256'],retained_CPU_fresh_passed=524,retained_CPU_ignored=40,local_retained_source_and_prototype_reconstruction_verified=True)
(w/'final-integrity-audit.json').write_text(json.dumps(result,indent=2));(w/'finish-state.json').write_text(json.dumps(dict(phase='complete',time_ns=time.time_ns()),indent=2));print({k:v for k,v in result.items()if k not in ['startup_and_graph_replay','fused_dispatch']})
