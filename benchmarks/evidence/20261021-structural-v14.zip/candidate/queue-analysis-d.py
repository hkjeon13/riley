from pathlib import Path
import json,subprocess,time,traceback,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14d-20261021');state=dict(phase='waiting-normal',started_ns=time.time_ns())
def save():(w/'normal-analysis-state.json').write_text(json.dumps(state,indent=2))
def run(script,args=[]):
 with(w/(script+'.normal-analysis.log')).open('x')as f:r=subprocess.run(['python3',str(w/script)]+args,stdout=f,stderr=f)
 assert r.returncode==0,(script,r.returncode)
try:
 save();end=time.monotonic()+5400
 while True:
  a=json.loads((w/'campaign-state.json').read_text());assert a['phase']!='failed',a
  if a['phase']=='complete':break
  assert time.monotonic()<end;time.sleep(3)
 state['phase']='auditing-normal';save();run('audit-complete.py',['--partial']);a=json.loads((w/'audit-partial.json').read_text());normal=[r for r in a['arms']if r['run']in ['final-c16','final-c32']];assert len(normal)==30
 matrix=[]
 for c in [16,32]:
  rows=[dict(**r['record'],campaign=r['run'])for r in normal if r['record']['concurrency']==c];assert len(rows)==15 and all(sum(r['mode']==m for r in rows)==5 for m in ['owned-before','owned-after','vllm']);matrix.append(dict(concurrency=c,records=rows))
 (w/'primary-matrix-audit.json').write_text(json.dumps(matrix,indent=2));run('analyze-final.py');run('audit-tail-d.py')
 f=json.loads((w/'frozen-inputs.json').read_text());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in f['sha256'].items())
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
