r"""
Compile-time auto-tuning block: 

import torch
from math import inf, nan
from torch._dynamo.testing import rand_strided
from torch._dynamo.utils import preserve_rng_state
from torch._inductor.select_algorithm import AlgorithmSelectorCache
from torch._inductor.async_compile import AsyncCompile

async_compile = AsyncCompile()
generate_example_value = AlgorithmSelectorCache.generate_example_value
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
get_raw_stream = torch._C._cuda_getCurrentRawStream


# kernel path: /mnt/efs/nlp/psyche/riley-structural-v14d-20261021/runs/final-c32/vllm-cache/torch_compile_cache/torch_aot_compile/16c9d24dc678867c54465dd2416ecc3d7621e4d3894cfcbb764ed415740d7f17/inductor_cache/qy/cqyznjxs2zqs6cufwqydmayc5q6hdvvnbthbveamta2r5jdzknye.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace], Original ATen: [vllm_ir.fused_add_rms_norm]
# Source node to ATen node mapping:
#   fused_add_rms_norm_maybe_inplace => add_tensor_4, add_tensor_5, convert_element_type_default_11, convert_element_type_default_8, convert_element_type_default_9, mean_dim_3, mul_tensor_6, mul_tensor_7, pow_tensor_scalar_3, rsqrt_default_3
# Graph fragment:
#   %mm : Tensor "bf16[s72, 2560][2560, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg4_1 : Tensor "bf16[s72, 2560][2560, 1]cuda:0" = PlaceHolder[target=arg4_1]
#   %buf1 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf1]
#   %arg3_1 : Tensor "bf16[2560][1]cuda:0" = PlaceHolder[target=arg3_1]
#   %convert_element_type_default_8 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm, torch.float32), kwargs = {})
#   %convert_element_type_default_9 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_tensor_4 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_8, %convert_element_type_default_9), kwargs = {})
#   %pow_tensor_scalar_3 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_4, 2), kwargs = {})
#   %mean_dim_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_3, [-1], True), kwargs = {})
#   %add_tensor_5 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_3, 1e-06), kwargs = {})
#   %rsqrt_default_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_5,), kwargs = {})
#   %mul_tensor_6 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_4, %rsqrt_default_3), kwargs = {})
#   %convert_element_type_default_11 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_6, torch.bfloat16), kwargs = {})
#   %mul_tensor_7 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_11, %arg3_1), kwargs = {})
#   return %buf1,%mul_tensor_7
triton_red_fused_fused_add_rms_norm_0 = async_compile.triton('triton_red_fused_fused_add_rms_norm_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1024, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_fused_add_rms_norm_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 11801600}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.00885248, 'kernel_flop': 0, 'backend_hash': '41920D6E87A21DB940AA33B2A7227B6DDEA7760E860450D00BA57747C0845BFF', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_fused_add_rms_norm_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp1 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr0 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp21 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp10 + tmp12
        tmp14 = tl.full([1, 1], 2560.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1, 1], 1e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp20 = tmp19.to(tl.float32)
        tmp22 = tmp20 * tmp21
        tl.store(out_ptr1 + (r0_1 + 2560*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /mnt/efs/nlp/psyche/riley-structural-v14d-20261021/runs/final-c32/vllm-cache/torch_compile_cache/torch_aot_compile/16c9d24dc678867c54465dd2416ecc3d7621e4d3894cfcbb764ed415740d7f17/inductor_cache/id/cidijtqut524vcbfz7lk7t4yunjlzasvvhpas3dd52cfyadvqvco.py
# Topologically Sorted Source Nodes: [getitem_2, silu, getitem_3, mul], Original ATen: [aten.slice, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   getitem_2 => slice_1
#   getitem_3 => slice_2
#   mul => mul_16
#   silu => add_18, convert_element_type_4, convert_element_type_5, div, exp, neg
# Graph fragment:
#   %mm_1 : Tensor "bf16[s72, 19456][19456, 1]cuda:0" = PlaceHolder[target=mm_1]
#   %slice_1 : Tensor "bf16[s72, 9728][19456, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%mm_1, 1, 0, 9728), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[s72, 9728][9728, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_1, torch.float32), kwargs = {})
#   %neg : Tensor "f32[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_4,), kwargs = {})
#   %exp : Tensor "f32[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_18 : Tensor "f32[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_4, %add_18), kwargs = {})
#   %convert_element_type_5 : Tensor "bf16[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %slice_2 : Tensor "bf16[s72, 9728][19456, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%mm_1, 1, 9728, 9223372036854775807), kwargs = {})
#   %mul_16 : Tensor "bf16[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_5, %slice_2), kwargs = {})
#   return %mul_16
triton_poi_fused_mul_silu_slice_1 = async_compile.triton('triton_poi_fused_mul_silu_slice_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8388608}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_mul_silu_slice_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 44826624}, 'kernel_num_gb': 0.033619968, 'kernel_flop': 0, 'backend_hash': '41920D6E87A21DB940AA33B2A7227B6DDEA7760E860450D00BA57747C0845BFF', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_mul_silu_slice_1(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 9728)
    x1 = xindex // 9728
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 19456*x1), xmask).to(tl.float32)
    tmp8 = tl.load(in_ptr0 + (9728 + x0 + 19456*x1), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = -tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp4 = tl.full([1], 1.0, tl.float32)
    tmp5 = tmp3 + tmp4
    tmp6 = (tmp1 / tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tmp7 * tmp8
    tl.store(out_ptr0 + (x2), tmp9, xmask)
''', device_str='cuda')


# kernel path: /mnt/efs/nlp/psyche/riley-structural-v14d-20261021/runs/final-c32/vllm-cache/torch_compile_cache/torch_aot_compile/16c9d24dc678867c54465dd2416ecc3d7621e4d3894cfcbb764ed415740d7f17/inductor_cache/dm/cdmygxqcimipuz4o7htf5nsyu55melaywr5caobrnifd3vlynuwv.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, fused_add_rms_norm_maybe_inplace_1], Original ATen: [vllm_ir.fused_add_rms_norm]
# Source node to ATen node mapping:
#   fused_add_rms_norm_maybe_inplace => add_tensor_4, convert_element_type_default_10, convert_element_type_default_8, convert_element_type_default_9
#   fused_add_rms_norm_maybe_inplace_1 => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_6, convert_element_type_default_7, mean_dim_2, mul_tensor_4, mul_tensor_5, pow_tensor_scalar_2, rsqrt_default_2
# Graph fragment:
#   %mm_2 : Tensor "bf16[s72, 2560][2560, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %mm : Tensor "bf16[s72, 2560][2560, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg4_1 : Tensor "bf16[s72, 2560][2560, 1]cuda:0" = PlaceHolder[target=arg4_1]
#   %buf7 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf7]
#   %arg7_1 : Tensor "bf16[2560][1]cuda:0" = PlaceHolder[target=arg7_1]
#   %convert_element_type_default_8 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm, torch.float32), kwargs = {})
#   %convert_element_type_default_9 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_tensor_4 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_8, %convert_element_type_default_9), kwargs = {})
#   %convert_element_type_default_10 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor_4, torch.bfloat16), kwargs = {})
#   %convert_element_type_default_4 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm_2, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type_default_10, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %convert_element_type_default_6 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor_2, torch.bfloat16), kwargs = {})
#   %pow_tensor_scalar_2 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_2 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_2, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_2, 1e-06), kwargs = {})
#   %rsqrt_default_2 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_4 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_2), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_4, torch.bfloat16), kwargs = {})
#   %mul_tensor_5 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg7_1), kwargs = {})
#   return %buf7,%convert_element_type_default_6,%mul_tensor_5
triton_red_fused_fused_add_rms_norm_2 = async_compile.triton('triton_red_fused_fused_add_rms_norm_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1024, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_fused_add_rms_norm_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 20648960}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.01475072, 'kernel_flop': 0, 'backend_hash': '41920D6E87A21DB940AA33B2A7227B6DDEA7760E860450D00BA57747C0845BFF', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_fused_add_rms_norm_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tl.load(in_ptr2 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp3 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp1 + tmp8
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask & xmask, tmp13, _tmp12)
        tmp14 = tmp9.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2560*x0), tmp14, r0_mask & xmask)
    tmp12 = tl.sum(_tmp12, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp15 = tl.load(in_ptr0 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tl.load(in_ptr1 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp19 = tl.load(in_ptr2 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp32 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp16 = tmp15.to(tl.float32)
        tmp18 = tmp17.to(tl.float32)
        tmp20 = tmp19.to(tl.float32)
        tmp21 = tmp18 + tmp20
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp16 + tmp23
        tmp25 = tl.full([1, 1], 2560.0, tl.float32)
        tmp26 = (tmp12 / tmp25)
        tmp27 = tl.full([1, 1], 1e-06, tl.float32)
        tmp28 = tmp26 + tmp27
        tmp29 = libdevice.rsqrt(tmp28)
        tmp30 = tmp24 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tmp33 = tmp31 * tmp32
        tl.store(out_ptr2 + (r0_1 + 2560*x0), tmp33, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /mnt/efs/nlp/psyche/riley-structural-v14d-20261021/runs/final-c32/vllm-cache/torch_compile_cache/torch_aot_compile/16c9d24dc678867c54465dd2416ecc3d7621e4d3894cfcbb764ed415740d7f17/inductor_cache/uo/cuosjxc2m5alndhtlqhdbqcztehsaivm6zx4b24dfla5wqkypul7.py
# Unsorted Source Nodes: [], Original ATen: []
# Source node to ATen node mapping:
triton_red_fused_3 = async_compile.triton('triton_red_fused_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

from torch._dynamo.testing import rand_strided
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import torch

@triton_heuristics.reduction(
    size_hints={'x': 32768, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*i64', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'out_ptr3': '*bf16', 'xnumel_0': 'i32', 'xnumel_1': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'SequentialComboKernelGrid', 'combo_grid_meta': {'num_kernels': 2, 'min_blocks': None, 'autotune_grouping': True, 'default_config': None, 'no_x_dim_0': False, 'xnumel_0': None, 'no_x_dim_1': None, 'xnumel_1': None}, 'kernel_name': 'triton_red_fused_3', 'mutated_arg_names': [], 'optimize_mem': True, 'backend_hash': '41920D6E87A21DB940AA33B2A7227B6DDEA7760E860450D00BA57747C0845BFF', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'max_persistent_rblock': 128}
)
@triton.jit
def triton_red_fused_3(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, out_ptr3, xnumel_0, xnumel_1, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    pid = tl.program_id(0)
    num_xblocks_0 = tl.cdiv(xnumel_0, XBLOCK)
    num_xblocks_1 = num_xblocks_0 + tl.cdiv(xnumel_1, XBLOCK)
    if pid < num_xblocks_0:
        pid_offset = pid
        r0_numel = 128
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK
        xoffset = pid_offset * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel_0
        r0_base = tl.arange(0, R0_BLOCK)[None, :]
        rbase = r0_base
        x0 = (xindex % 32)
        x1 = xindex // 32
        _tmp4 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        x3 = xindex
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_2 = r0_index
            tmp0 = tl.load(in_ptr0 + (r0_2 + 128*x0 + 6144*x1), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp1 = tmp0.to(tl.float32)
            tmp2 = tmp1 * tmp1
            tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
            tmp5 = _tmp4 + tmp3
            _tmp4 = tl.where(r0_mask & xmask, tmp5, _tmp4)
        tmp4 = tl.sum(_tmp4, 1)[:, None]
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_2 = r0_index
            tmp6 = (r0_2).to(tl.int32)
            tmp7 = tl.full([1, 1], 0, tl.int64)
            tmp8 = tmp6 >= tmp7
            tmp9 = (r0_2).to(tl.int64)
            tmp10 = (tmp9).to(tl.int64)
            tmp11 = tl.full([1, 1], 64, tl.int64)
            tmp12 = tmp10 < tmp11
            tmp13 = tl.load(in_ptr0 + (128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp14 = tmp13.to(tl.float32)
            tmp15 = tl.full([1, 1], 128.0, tl.float32)
            tmp16 = (tmp4 / tmp15)
            tmp17 = tl.full([1, 1], 1e-06, tl.float32)
            tmp18 = tmp16 + tmp17
            tmp19 = libdevice.rsqrt(tmp18)
            tmp20 = tmp14 * tmp19
            tmp21 = tmp20.to(tl.float32)
            tmp22 = tl.load(in_ptr1 + (tl.broadcast_to(r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp23 = tmp21 * tmp22
            tmp24 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0)
            tmp25 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp26 = tmp24 + tmp25
            tmp27 = tmp24 < 0
            tmp28 = tl.where(tmp27, tmp26, tmp24)
            tl.device_assert(((0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp12 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960")
            tmp30 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp31 = tmp23 * tmp30
            tmp32 = tl.load(in_ptr0 + (64 + 128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp33 = tmp32.to(tl.float32)
            tmp34 = tmp33 * tmp19
            tmp35 = tmp34.to(tl.float32)
            tmp36 = tl.load(in_ptr1 + (tl.broadcast_to(64 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp37 = tmp35 * tmp36
            tmp38 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp39 = tmp37 * tmp38
            tmp40 = tmp31 - tmp39
            tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
            tmp42 = tl.where(tmp12, tmp40, tmp41)
            tmp43 = tmp6 >= tmp11
            tmp44 = tl.full([1, 1], 128, tl.int64)
            tmp45 = tmp6 < tmp44
            tmp46 = tl.load(in_ptr0 + (64 + 128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp47 = tmp46.to(tl.float32)
            tmp48 = tl.full([1, 1], 128.0, tl.float32)
            tmp49 = (tmp4 / tmp48)
            tmp50 = tl.full([1, 1], 1e-06, tl.float32)
            tmp51 = tmp49 + tmp50
            tmp52 = libdevice.rsqrt(tmp51)
            tmp53 = tmp47 * tmp52
            tmp54 = tmp53.to(tl.float32)
            tmp55 = tl.load(in_ptr1 + (tl.broadcast_to(64 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp56 = tmp54 * tmp55
            tmp57 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0)
            tmp58 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp59 = tmp57 + tmp58
            tmp60 = tmp57 < 0
            tmp61 = tl.where(tmp60, tmp59, tmp57)
            tl.device_assert(((0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp43 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960")
            tmp63 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp64 = tmp56 * tmp63
            tmp65 = tl.load(in_ptr0 + (128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp66 = tmp65.to(tl.float32)
            tmp67 = tmp66 * tmp52
            tmp68 = tmp67.to(tl.float32)
            tmp69 = tl.load(in_ptr1 + (tl.broadcast_to((-64) + r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp70 = tmp68 * tmp69
            tmp71 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp72 = tmp70 * tmp71
            tmp73 = tmp64 + tmp72
            tmp74 = tl.full(tmp73.shape, 0.0, tmp73.dtype)
            tmp75 = tl.where(tmp43, tmp73, tmp74)
            tmp76 = tl.where(tmp12, tmp42, tmp75)
            tl.store(out_ptr1 + (r0_2 + 128*x3), tmp76, r0_mask & xmask)
    elif pid < num_xblocks_1:
        pid_offset = pid - num_xblocks_0
        r0_numel = 128
        R0_BLOCK_1: tl.constexpr = 128
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK_1
        xoffset = pid_offset * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel_1
        r0_index = tl.arange(0, R0_BLOCK_1)[None, :]
        r0_offset = 0
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_6 = r0_index
        x4 = (xindex % 8)
        x5 = xindex // 8
        x7 = xindex
        tmp77 = tl.load(in_ptr0 + (4096 + r0_6 + 128*x4 + 6144*x5), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp78 = tmp77.to(tl.float32)
        tmp79 = tmp78 * tmp78
        tmp80 = tl.broadcast_to(tmp79, [XBLOCK, R0_BLOCK_1])
        tmp82 = tl.where(r0_mask & xmask, tmp80, 0)
        tmp83 = tl.sum(tmp82, 1)[:, None].to(tl.float32)
        tmp84 = (r0_6).to(tl.int32)
        tmp85 = tl.full([1, 1], 0, tl.int64)
        tmp86 = tmp84 >= tmp85
        tmp87 = (r0_6).to(tl.int64)
        tmp88 = (tmp87).to(tl.int64)
        tmp89 = tl.full([1, 1], 64, tl.int64)
        tmp90 = tmp88 < tmp89
        tmp91 = tl.load(in_ptr0 + (4096 + 128*x4 + 6144*x5 + (r0_6)), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp92 = tmp91.to(tl.float32)
        tmp93 = tl.full([1, 1], 128.0, tl.float32)
        tmp94 = (tmp83 / tmp93)
        tmp95 = tl.full([1, 1], 1e-06, tl.float32)
        tmp96 = tmp94 + tmp95
        tmp97 = libdevice.rsqrt(tmp96)
        tmp98 = tmp92 * tmp97
        tmp99 = tmp98.to(tl.float32)
        tmp100 = tl.load(in_ptr4 + (tl.broadcast_to(r0_6, [XBLOCK, R0_BLOCK_1])), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp101 = tmp99 * tmp100
        tmp102 = tl.load(in_ptr2 + (tl.broadcast_to(x5, [XBLOCK, R0_BLOCK_1])), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0)
        tmp103 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
        tmp104 = tmp102 + tmp103
        tmp105 = tmp102 < 0
        tmp106 = tl.where(tmp105, tmp104, tmp102)
        tl.device_assert(((0 <= tl.broadcast_to(tmp106, [XBLOCK, R0_BLOCK_1])) & (tl.broadcast_to(tmp106, [XBLOCK, R0_BLOCK_1]) < 40960)) | ~(r0_mask & tmp90 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp106, [XBLOCK, R0_BLOCK_1]) < 40960")
        tmp108 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp106 + (r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp109 = tmp101 * tmp108
        tmp110 = tl.load(in_ptr0 + (4160 + 128*x4 + 6144*x5 + (r0_6)), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp111 = tmp110.to(tl.float32)
        tmp112 = tmp111 * tmp97
        tmp113 = tmp112.to(tl.float32)
        tmp114 = tl.load(in_ptr4 + (tl.broadcast_to(64 + (r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp115 = tmp113 * tmp114
        tmp116 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp106 + (r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp117 = tmp115 * tmp116
        tmp118 = tmp109 - tmp117
        tmp119 = tl.full(tmp118.shape, 0.0, tmp118.dtype)
        tmp120 = tl.where(tmp90, tmp118, tmp119)
        tmp121 = tmp84 >= tmp89
        tmp122 = tl.full([1, 1], 128, tl.int64)
        tmp123 = tmp84 < tmp122
        tmp124 = tl.load(in_ptr0 + (4160 + 128*x4 + 6144*x5 + ((-64) + r0_6)), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp125 = tmp124.to(tl.float32)
        tmp126 = tl.full([1, 1], 128.0, tl.float32)
        tmp127 = (tmp83 / tmp126)
        tmp128 = tl.full([1, 1], 1e-06, tl.float32)
        tmp129 = tmp127 + tmp128
        tmp130 = libdevice.rsqrt(tmp129)
        tmp131 = tmp125 * tmp130
        tmp132 = tmp131.to(tl.float32)
        tmp133 = tl.load(in_ptr4 + (tl.broadcast_to(64 + ((-64) + r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp134 = tmp132 * tmp133
        tmp135 = tl.load(in_ptr2 + (tl.broadcast_to(x5, [XBLOCK, R0_BLOCK_1])), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0)
        tmp136 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
        tmp137 = tmp135 + tmp136
        tmp138 = tmp135 < 0
        tmp139 = tl.where(tmp138, tmp137, tmp135)
        tl.device_assert(((0 <= tl.broadcast_to(tmp139, [XBLOCK, R0_BLOCK_1])) & (tl.broadcast_to(tmp139, [XBLOCK, R0_BLOCK_1]) < 40960)) | ~(r0_mask & tmp121 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp139, [XBLOCK, R0_BLOCK_1]) < 40960")
        tmp141 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp139 + ((-64) + r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp142 = tmp134 * tmp141
        tmp143 = tl.load(in_ptr0 + (4096 + 128*x4 + 6144*x5 + ((-64) + r0_6)), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp144 = tmp143.to(tl.float32)
        tmp145 = tmp144 * tmp130
        tmp146 = tmp145.to(tl.float32)
        tmp147 = tl.load(in_ptr4 + (tl.broadcast_to((-64) + r0_6, [XBLOCK, R0_BLOCK_1])), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp148 = tmp146 * tmp147
        tmp149 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp139 + ((-64) + r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp150 = tmp148 * tmp149
        tmp151 = tmp142 + tmp150
        tmp152 = tl.full(tmp151.shape, 0.0, tmp151.dtype)
        tmp153 = tl.where(tmp121, tmp151, tmp152)
        tmp154 = tl.where(tmp90, tmp120, tmp153)
        tl.store(out_ptr3 + (r0_6 + 128*x7), tmp154, r0_mask & xmask)
    else:
        pass


def get_args():
    arg_0 = rand_strided((576, 6144), (6144, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_1 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_2 = rand_strided((576,), (1,), device='cuda:0', dtype=torch.int64)
    arg_3 = rand_strided((40960, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_4 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_5 = rand_strided((576, 32, 128), (4096, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_6 = rand_strided((576, 8, 128), (1024, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    return arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, 18432, 4608,


def call(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_3.run(*args, stream=raw_stream0)


def benchmark_all_configs(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        return triton_red_fused_3.benchmark_all_configs(*args)


if __name__ == '__main__':
    from torch._inductor.runtime.benchmarking import benchmarker

    args = get_args()
    ms = benchmarker.benchmark(call, fn_args=(args,), device='cuda',rep=40)
    num_gb = 0.058992128
    gb_per_s = num_gb / (ms / 1e3)
    print(f"{ms:.3f}ms    {num_gb:.3f}GB    {gb_per_s:.2f}GB/s")
''', device_str='cuda')

async_compile.wait(globals())
del async_compile

import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
with torch.cuda._DeviceGuard(0):
    raw_stream0 = get_raw_stream(0)
raw_stream0 = get_raw_stream(0)
buf0 = generate_example_value((576, 2560), (2560, 1), 'cuda:0', torch.bfloat16, 0, (576, 2560))
arg4_1 = generate_example_value((576, 2560), (2560, 1), 'cuda:0', torch.bfloat16, 0, (576, 2560))
arg3_1 = generate_example_value((2560,), (1,), 'cuda:0', torch.bfloat16, 0, (2560,))
buf2 = generate_example_value((576, 2560), (2560, 1), 'cuda:0', torch.bfloat16, 0, (576, 2560))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_fused_add_rms_norm_0.run(buf0, arg4_1, arg3_1, buf2, 576, 2560, stream=raw_stream0)
del arg3_1, buf2

raw_stream0 = get_raw_stream(0)
buf3 = generate_example_value((576, 19456), (19456, 1), 'cuda:0', torch.bfloat16, 0, (576, 19456))
buf4 = generate_example_value((576, 9728), (9728, 1), 'cuda:0', torch.bfloat16, 0, (576, 9728))
with torch.cuda._DeviceGuard(0):
    triton_poi_fused_mul_silu_slice_1.run(buf3, buf4, 5603328, stream=raw_stream0)
del buf3, buf4

raw_stream0 = get_raw_stream(0)
buf5 = generate_example_value((576, 2560), (2560, 1), 'cuda:0', torch.bfloat16, 0, (576, 2560))
arg7_1 = generate_example_value((2560,), (1,), 'cuda:0', torch.bfloat16, 0, (2560,))
buf6 = generate_example_value((576, 2560), (2560, 1), 'cuda:0', torch.bfloat16, 0, (576, 2560))
buf8 = generate_example_value((576, 2560), (2560, 1), 'cuda:0', torch.bfloat16, 0, (576, 2560))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_fused_add_rms_norm_2.run(buf5, buf0, arg4_1, arg7_1, buf6, buf8, 576, 2560, stream=raw_stream0)
del buf0, arg4_1, buf5, arg7_1, buf6, buf8

raw_stream0 = get_raw_stream(0)
buf9 = generate_example_value((576, 6144), (6144, 1), 'cuda:0', torch.bfloat16, 0, (576, 6144))
arg9_1 = generate_example_value((128,), (1,), 'cuda:0', torch.bfloat16, 0, (128,))
arg11_1 = generate_example_value((576,), (1,), 'cuda:0', torch.int64, 0, (576,))
arg12_1 = generate_example_value((40960, 128), (128, 1), 'cuda:0', torch.bfloat16, 0, (40960, 128))
arg10_1 = generate_example_value((128,), (1,), 'cuda:0', torch.bfloat16, 0, (128,))
buf13 = generate_example_value((576, 32, 128), (4096, 128, 1), 'cuda:0', torch.bfloat16, 0, (576, 32, 128))
buf12 = generate_example_value((576, 8, 128), (1024, 128, 1), 'cuda:0', torch.bfloat16, 0, (576, 8, 128))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_3.run(buf9, arg9_1, arg11_1, arg12_1, arg10_1, buf13, buf12, 18432, 4608, stream=raw_stream0)
del buf9, arg9_1, arg11_1, arg12_1, arg10_1, buf13, buf12

"""
# AOT ID: ['1_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /mnt/efs/nlp/psyche/riley-structural-v14d-20261021/runs/final-c32/vllm-cache/torch_compile_cache/torch_aot_compile/16c9d24dc678867c54465dd2416ecc3d7621e4d3894cfcbb764ed415740d7f17/inductor_cache/qy/cqyznjxs2zqs6cufwqydmayc5q6hdvvnbthbveamta2r5jdzknye.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace], Original ATen: [vllm_ir.fused_add_rms_norm]
# Source node to ATen node mapping:
#   fused_add_rms_norm_maybe_inplace => add_tensor_4, add_tensor_5, convert_element_type_default_11, convert_element_type_default_8, convert_element_type_default_9, mean_dim_3, mul_tensor_6, mul_tensor_7, pow_tensor_scalar_3, rsqrt_default_3
# Graph fragment:
#   %mm : Tensor "bf16[s72, 2560][2560, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg4_1 : Tensor "bf16[s72, 2560][2560, 1]cuda:0" = PlaceHolder[target=arg4_1]
#   %buf1 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf1]
#   %arg3_1 : Tensor "bf16[2560][1]cuda:0" = PlaceHolder[target=arg3_1]
#   %convert_element_type_default_8 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm, torch.float32), kwargs = {})
#   %convert_element_type_default_9 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_tensor_4 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_8, %convert_element_type_default_9), kwargs = {})
#   %pow_tensor_scalar_3 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_4, 2), kwargs = {})
#   %mean_dim_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_3, [-1], True), kwargs = {})
#   %add_tensor_5 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_3, 1e-06), kwargs = {})
#   %rsqrt_default_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_5,), kwargs = {})
#   %mul_tensor_6 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_4, %rsqrt_default_3), kwargs = {})
#   %convert_element_type_default_11 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_6, torch.bfloat16), kwargs = {})
#   %mul_tensor_7 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_11, %arg3_1), kwargs = {})
#   return %buf1,%mul_tensor_7
triton_red_fused_fused_add_rms_norm_0 = async_compile.triton('triton_red_fused_fused_add_rms_norm_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1024, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_fused_add_rms_norm_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 11801600}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.00885248, 'kernel_flop': 0, 'backend_hash': '41920D6E87A21DB940AA33B2A7227B6DDEA7760E860450D00BA57747C0845BFF', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_fused_add_rms_norm_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp1 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr0 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp21 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp10 + tmp12
        tmp14 = tl.full([1, 1], 2560.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1, 1], 1e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp20 = tmp19.to(tl.float32)
        tmp22 = tmp20 * tmp21
        tl.store(out_ptr1 + (r0_1 + 2560*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /mnt/efs/nlp/psyche/riley-structural-v14d-20261021/runs/final-c32/vllm-cache/torch_compile_cache/torch_aot_compile/16c9d24dc678867c54465dd2416ecc3d7621e4d3894cfcbb764ed415740d7f17/inductor_cache/id/cidijtqut524vcbfz7lk7t4yunjlzasvvhpas3dd52cfyadvqvco.py
# Topologically Sorted Source Nodes: [getitem_2, silu, getitem_3, mul], Original ATen: [aten.slice, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   getitem_2 => slice_1
#   getitem_3 => slice_2
#   mul => mul_16
#   silu => add_18, convert_element_type_4, convert_element_type_5, div, exp, neg
# Graph fragment:
#   %mm_1 : Tensor "bf16[s72, 19456][19456, 1]cuda:0" = PlaceHolder[target=mm_1]
#   %slice_1 : Tensor "bf16[s72, 9728][19456, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%mm_1, 1, 0, 9728), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[s72, 9728][9728, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_1, torch.float32), kwargs = {})
#   %neg : Tensor "f32[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_4,), kwargs = {})
#   %exp : Tensor "f32[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_18 : Tensor "f32[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_4, %add_18), kwargs = {})
#   %convert_element_type_5 : Tensor "bf16[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %slice_2 : Tensor "bf16[s72, 9728][19456, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%mm_1, 1, 9728, 9223372036854775807), kwargs = {})
#   %mul_16 : Tensor "bf16[s72, 9728][9728, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_5, %slice_2), kwargs = {})
#   return %mul_16
triton_poi_fused_mul_silu_slice_1 = async_compile.triton('triton_poi_fused_mul_silu_slice_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8388608}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_mul_silu_slice_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 44826624}, 'kernel_num_gb': 0.033619968, 'kernel_flop': 0, 'backend_hash': '41920D6E87A21DB940AA33B2A7227B6DDEA7760E860450D00BA57747C0845BFF', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_mul_silu_slice_1(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 9728)
    x1 = xindex // 9728
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 19456*x1), xmask).to(tl.float32)
    tmp8 = tl.load(in_ptr0 + (9728 + x0 + 19456*x1), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = -tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp4 = tl.full([1], 1.0, tl.float32)
    tmp5 = tmp3 + tmp4
    tmp6 = (tmp1 / tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tmp7 * tmp8
    tl.store(out_ptr0 + (x2), tmp9, xmask)
''', device_str='cuda')


# kernel path: /mnt/efs/nlp/psyche/riley-structural-v14d-20261021/runs/final-c32/vllm-cache/torch_compile_cache/torch_aot_compile/16c9d24dc678867c54465dd2416ecc3d7621e4d3894cfcbb764ed415740d7f17/inductor_cache/dm/cdmygxqcimipuz4o7htf5nsyu55melaywr5caobrnifd3vlynuwv.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, fused_add_rms_norm_maybe_inplace_1], Original ATen: [vllm_ir.fused_add_rms_norm]
# Source node to ATen node mapping:
#   fused_add_rms_norm_maybe_inplace => add_tensor_4, convert_element_type_default_10, convert_element_type_default_8, convert_element_type_default_9
#   fused_add_rms_norm_maybe_inplace_1 => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_6, convert_element_type_default_7, mean_dim_2, mul_tensor_4, mul_tensor_5, pow_tensor_scalar_2, rsqrt_default_2
# Graph fragment:
#   %mm_2 : Tensor "bf16[s72, 2560][2560, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %mm : Tensor "bf16[s72, 2560][2560, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg4_1 : Tensor "bf16[s72, 2560][2560, 1]cuda:0" = PlaceHolder[target=arg4_1]
#   %buf7 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf7]
#   %arg7_1 : Tensor "bf16[2560][1]cuda:0" = PlaceHolder[target=arg7_1]
#   %convert_element_type_default_8 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm, torch.float32), kwargs = {})
#   %convert_element_type_default_9 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_tensor_4 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_8, %convert_element_type_default_9), kwargs = {})
#   %convert_element_type_default_10 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor_4, torch.bfloat16), kwargs = {})
#   %convert_element_type_default_4 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm_2, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type_default_10, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %convert_element_type_default_6 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor_2, torch.bfloat16), kwargs = {})
#   %pow_tensor_scalar_2 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_2 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_2, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_2, 1e-06), kwargs = {})
#   %rsqrt_default_2 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_4 : Tensor "f32[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_2), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_4, torch.bfloat16), kwargs = {})
#   %mul_tensor_5 : Tensor "bf16[s72, 2560][2560, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg7_1), kwargs = {})
#   return %buf7,%convert_element_type_default_6,%mul_tensor_5
triton_red_fused_fused_add_rms_norm_2 = async_compile.triton('triton_red_fused_fused_add_rms_norm_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1024, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_fused_add_rms_norm_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 20648960}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.01475072, 'kernel_flop': 0, 'backend_hash': '41920D6E87A21DB940AA33B2A7227B6DDEA7760E860450D00BA57747C0845BFF', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_fused_add_rms_norm_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tl.load(in_ptr2 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp3 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp1 + tmp8
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask & xmask, tmp13, _tmp12)
        tmp14 = tmp9.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2560*x0), tmp14, r0_mask & xmask)
    tmp12 = tl.sum(_tmp12, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp15 = tl.load(in_ptr0 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tl.load(in_ptr1 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp19 = tl.load(in_ptr2 + (r0_1 + 2560*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp32 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp16 = tmp15.to(tl.float32)
        tmp18 = tmp17.to(tl.float32)
        tmp20 = tmp19.to(tl.float32)
        tmp21 = tmp18 + tmp20
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp16 + tmp23
        tmp25 = tl.full([1, 1], 2560.0, tl.float32)
        tmp26 = (tmp12 / tmp25)
        tmp27 = tl.full([1, 1], 1e-06, tl.float32)
        tmp28 = tmp26 + tmp27
        tmp29 = libdevice.rsqrt(tmp28)
        tmp30 = tmp24 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tmp33 = tmp31 * tmp32
        tl.store(out_ptr2 + (r0_1 + 2560*x0), tmp33, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /mnt/efs/nlp/psyche/riley-structural-v14d-20261021/runs/final-c32/vllm-cache/torch_compile_cache/torch_aot_compile/16c9d24dc678867c54465dd2416ecc3d7621e4d3894cfcbb764ed415740d7f17/inductor_cache/uo/cuosjxc2m5alndhtlqhdbqcztehsaivm6zx4b24dfla5wqkypul7.py
# Unsorted Source Nodes: [], Original ATen: []
# Source node to ATen node mapping:
triton_red_fused_3 = async_compile.triton('triton_red_fused_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

from torch._dynamo.testing import rand_strided
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import torch

@triton_heuristics.reduction(
    size_hints={'x': 32768, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*i64', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'out_ptr3': '*bf16', 'xnumel_0': 'i32', 'xnumel_1': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'SequentialComboKernelGrid', 'combo_grid_meta': {'num_kernels': 2, 'min_blocks': None, 'autotune_grouping': True, 'default_config': None, 'no_x_dim_0': False, 'xnumel_0': None, 'no_x_dim_1': None, 'xnumel_1': None}, 'kernel_name': 'triton_red_fused_3', 'mutated_arg_names': [], 'optimize_mem': True, 'backend_hash': '41920D6E87A21DB940AA33B2A7227B6DDEA7760E860450D00BA57747C0845BFF', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'max_persistent_rblock': 128}
)
@triton.jit
def triton_red_fused_3(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, out_ptr3, xnumel_0, xnumel_1, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    pid = tl.program_id(0)
    num_xblocks_0 = tl.cdiv(xnumel_0, XBLOCK)
    num_xblocks_1 = num_xblocks_0 + tl.cdiv(xnumel_1, XBLOCK)
    if pid < num_xblocks_0:
        pid_offset = pid
        r0_numel = 128
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK
        xoffset = pid_offset * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel_0
        r0_base = tl.arange(0, R0_BLOCK)[None, :]
        rbase = r0_base
        x0 = (xindex % 32)
        x1 = xindex // 32
        _tmp4 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        x3 = xindex
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_2 = r0_index
            tmp0 = tl.load(in_ptr0 + (r0_2 + 128*x0 + 6144*x1), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp1 = tmp0.to(tl.float32)
            tmp2 = tmp1 * tmp1
            tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
            tmp5 = _tmp4 + tmp3
            _tmp4 = tl.where(r0_mask & xmask, tmp5, _tmp4)
        tmp4 = tl.sum(_tmp4, 1)[:, None]
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_2 = r0_index
            tmp6 = (r0_2).to(tl.int32)
            tmp7 = tl.full([1, 1], 0, tl.int64)
            tmp8 = tmp6 >= tmp7
            tmp9 = (r0_2).to(tl.int64)
            tmp10 = (tmp9).to(tl.int64)
            tmp11 = tl.full([1, 1], 64, tl.int64)
            tmp12 = tmp10 < tmp11
            tmp13 = tl.load(in_ptr0 + (128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp14 = tmp13.to(tl.float32)
            tmp15 = tl.full([1, 1], 128.0, tl.float32)
            tmp16 = (tmp4 / tmp15)
            tmp17 = tl.full([1, 1], 1e-06, tl.float32)
            tmp18 = tmp16 + tmp17
            tmp19 = libdevice.rsqrt(tmp18)
            tmp20 = tmp14 * tmp19
            tmp21 = tmp20.to(tl.float32)
            tmp22 = tl.load(in_ptr1 + (tl.broadcast_to(r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp23 = tmp21 * tmp22
            tmp24 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0)
            tmp25 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp26 = tmp24 + tmp25
            tmp27 = tmp24 < 0
            tmp28 = tl.where(tmp27, tmp26, tmp24)
            tl.device_assert(((0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp12 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960")
            tmp30 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp31 = tmp23 * tmp30
            tmp32 = tl.load(in_ptr0 + (64 + 128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp33 = tmp32.to(tl.float32)
            tmp34 = tmp33 * tmp19
            tmp35 = tmp34.to(tl.float32)
            tmp36 = tl.load(in_ptr1 + (tl.broadcast_to(64 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp37 = tmp35 * tmp36
            tmp38 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp39 = tmp37 * tmp38
            tmp40 = tmp31 - tmp39
            tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
            tmp42 = tl.where(tmp12, tmp40, tmp41)
            tmp43 = tmp6 >= tmp11
            tmp44 = tl.full([1, 1], 128, tl.int64)
            tmp45 = tmp6 < tmp44
            tmp46 = tl.load(in_ptr0 + (64 + 128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp47 = tmp46.to(tl.float32)
            tmp48 = tl.full([1, 1], 128.0, tl.float32)
            tmp49 = (tmp4 / tmp48)
            tmp50 = tl.full([1, 1], 1e-06, tl.float32)
            tmp51 = tmp49 + tmp50
            tmp52 = libdevice.rsqrt(tmp51)
            tmp53 = tmp47 * tmp52
            tmp54 = tmp53.to(tl.float32)
            tmp55 = tl.load(in_ptr1 + (tl.broadcast_to(64 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp56 = tmp54 * tmp55
            tmp57 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0)
            tmp58 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp59 = tmp57 + tmp58
            tmp60 = tmp57 < 0
            tmp61 = tl.where(tmp60, tmp59, tmp57)
            tl.device_assert(((0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp43 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960")
            tmp63 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp64 = tmp56 * tmp63
            tmp65 = tl.load(in_ptr0 + (128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp66 = tmp65.to(tl.float32)
            tmp67 = tmp66 * tmp52
            tmp68 = tmp67.to(tl.float32)
            tmp69 = tl.load(in_ptr1 + (tl.broadcast_to((-64) + r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp70 = tmp68 * tmp69
            tmp71 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp72 = tmp70 * tmp71
            tmp73 = tmp64 + tmp72
            tmp74 = tl.full(tmp73.shape, 0.0, tmp73.dtype)
            tmp75 = tl.where(tmp43, tmp73, tmp74)
            tmp76 = tl.where(tmp12, tmp42, tmp75)
            tl.store(out_ptr1 + (r0_2 + 128*x3), tmp76, r0_mask & xmask)
    elif pid < num_xblocks_1:
        pid_offset = pid - num_xblocks_0
        r0_numel = 128
        R0_BLOCK_1: tl.constexpr = 128
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK_1
        xoffset = pid_offset * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel_1
        r0_index = tl.arange(0, R0_BLOCK_1)[None, :]
        r0_offset = 0
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_6 = r0_index
        x4 = (xindex % 8)
        x5 = xindex // 8
        x7 = xindex
        tmp77 = tl.load(in_ptr0 + (4096 + r0_6 + 128*x4 + 6144*x5), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp78 = tmp77.to(tl.float32)
        tmp79 = tmp78 * tmp78
        tmp80 = tl.broadcast_to(tmp79, [XBLOCK, R0_BLOCK_1])
        tmp82 = tl.where(r0_mask & xmask, tmp80, 0)
        tmp83 = tl.sum(tmp82, 1)[:, None].to(tl.float32)
        tmp84 = (r0_6).to(tl.int32)
        tmp85 = tl.full([1, 1], 0, tl.int64)
        tmp86 = tmp84 >= tmp85
        tmp87 = (r0_6).to(tl.int64)
        tmp88 = (tmp87).to(tl.int64)
        tmp89 = tl.full([1, 1], 64, tl.int64)
        tmp90 = tmp88 < tmp89
        tmp91 = tl.load(in_ptr0 + (4096 + 128*x4 + 6144*x5 + (r0_6)), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp92 = tmp91.to(tl.float32)
        tmp93 = tl.full([1, 1], 128.0, tl.float32)
        tmp94 = (tmp83 / tmp93)
        tmp95 = tl.full([1, 1], 1e-06, tl.float32)
        tmp96 = tmp94 + tmp95
        tmp97 = libdevice.rsqrt(tmp96)
        tmp98 = tmp92 * tmp97
        tmp99 = tmp98.to(tl.float32)
        tmp100 = tl.load(in_ptr4 + (tl.broadcast_to(r0_6, [XBLOCK, R0_BLOCK_1])), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp101 = tmp99 * tmp100
        tmp102 = tl.load(in_ptr2 + (tl.broadcast_to(x5, [XBLOCK, R0_BLOCK_1])), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0)
        tmp103 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
        tmp104 = tmp102 + tmp103
        tmp105 = tmp102 < 0
        tmp106 = tl.where(tmp105, tmp104, tmp102)
        tl.device_assert(((0 <= tl.broadcast_to(tmp106, [XBLOCK, R0_BLOCK_1])) & (tl.broadcast_to(tmp106, [XBLOCK, R0_BLOCK_1]) < 40960)) | ~(r0_mask & tmp90 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp106, [XBLOCK, R0_BLOCK_1]) < 40960")
        tmp108 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp106 + (r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp109 = tmp101 * tmp108
        tmp110 = tl.load(in_ptr0 + (4160 + 128*x4 + 6144*x5 + (r0_6)), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp111 = tmp110.to(tl.float32)
        tmp112 = tmp111 * tmp97
        tmp113 = tmp112.to(tl.float32)
        tmp114 = tl.load(in_ptr4 + (tl.broadcast_to(64 + (r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp115 = tmp113 * tmp114
        tmp116 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp106 + (r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp90 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp117 = tmp115 * tmp116
        tmp118 = tmp109 - tmp117
        tmp119 = tl.full(tmp118.shape, 0.0, tmp118.dtype)
        tmp120 = tl.where(tmp90, tmp118, tmp119)
        tmp121 = tmp84 >= tmp89
        tmp122 = tl.full([1, 1], 128, tl.int64)
        tmp123 = tmp84 < tmp122
        tmp124 = tl.load(in_ptr0 + (4160 + 128*x4 + 6144*x5 + ((-64) + r0_6)), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp125 = tmp124.to(tl.float32)
        tmp126 = tl.full([1, 1], 128.0, tl.float32)
        tmp127 = (tmp83 / tmp126)
        tmp128 = tl.full([1, 1], 1e-06, tl.float32)
        tmp129 = tmp127 + tmp128
        tmp130 = libdevice.rsqrt(tmp129)
        tmp131 = tmp125 * tmp130
        tmp132 = tmp131.to(tl.float32)
        tmp133 = tl.load(in_ptr4 + (tl.broadcast_to(64 + ((-64) + r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp134 = tmp132 * tmp133
        tmp135 = tl.load(in_ptr2 + (tl.broadcast_to(x5, [XBLOCK, R0_BLOCK_1])), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0)
        tmp136 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
        tmp137 = tmp135 + tmp136
        tmp138 = tmp135 < 0
        tmp139 = tl.where(tmp138, tmp137, tmp135)
        tl.device_assert(((0 <= tl.broadcast_to(tmp139, [XBLOCK, R0_BLOCK_1])) & (tl.broadcast_to(tmp139, [XBLOCK, R0_BLOCK_1]) < 40960)) | ~(r0_mask & tmp121 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp139, [XBLOCK, R0_BLOCK_1]) < 40960")
        tmp141 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp139 + ((-64) + r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp142 = tmp134 * tmp141
        tmp143 = tl.load(in_ptr0 + (4096 + 128*x4 + 6144*x5 + ((-64) + r0_6)), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp144 = tmp143.to(tl.float32)
        tmp145 = tmp144 * tmp130
        tmp146 = tmp145.to(tl.float32)
        tmp147 = tl.load(in_ptr4 + (tl.broadcast_to((-64) + r0_6, [XBLOCK, R0_BLOCK_1])), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp148 = tmp146 * tmp147
        tmp149 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp139 + ((-64) + r0_6), [XBLOCK, R0_BLOCK_1])), r0_mask & tmp121 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp150 = tmp148 * tmp149
        tmp151 = tmp142 + tmp150
        tmp152 = tl.full(tmp151.shape, 0.0, tmp151.dtype)
        tmp153 = tl.where(tmp121, tmp151, tmp152)
        tmp154 = tl.where(tmp90, tmp120, tmp153)
        tl.store(out_ptr3 + (r0_6 + 128*x7), tmp154, r0_mask & xmask)
    else:
        pass


def get_args():
    arg_0 = rand_strided((576, 6144), (6144, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_1 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_2 = rand_strided((576,), (1,), device='cuda:0', dtype=torch.int64)
    arg_3 = rand_strided((40960, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_4 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_5 = rand_strided((576, 32, 128), (4096, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_6 = rand_strided((576, 8, 128), (1024, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    return arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, 18432, 4608,


def call(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_3.run(*args, stream=raw_stream0)


def benchmark_all_configs(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        return triton_red_fused_3.benchmark_all_configs(*args)


if __name__ == '__main__':
    from torch._inductor.runtime.benchmarking import benchmarker

    args = get_args()
    ms = benchmarker.benchmark(call, fn_args=(args,), device='cuda',rep=40)
    num_gb = 0.058992128
    gb_per_s = num_gb / (ms / 1e3)
    print(f"{ms:.3f}ms    {num_gb:.3f}GB    {gb_per_s:.2f}GB/s")
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1 = args
        args.clear()
        s72 = arg1_1
        s80 = s72
        assert_size_stride(arg0_1, (s72, 32, 128), (4096, 128, 1), 'input')
        assert_size_stride(arg2_1, (2560, 4096), (4096, 1), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg2_1 = copy_if_misaligned(arg2_1)
            buf0 = empty_strided_cuda((s72, 2560), (2560, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [view, linear], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(arg0_1, (s72, 4096), (4096, 1), 0), reinterpret_tensor(arg2_1, (4096, 2560), (1, 4096), 0), out=buf0)
            del arg0_1
            del arg2_1
            assert_size_stride(arg4_1, (s72, 2560), (2560, 1), 'input')
            assert_size_stride(arg3_1, (2560, ), (1, ), 'input')
            arg4_1 = copy_if_misaligned(arg4_1)
            arg3_1 = copy_if_misaligned(arg3_1)
            buf2 = empty_strided_cuda((s72, 2560), (2560, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace], Original ATen: [vllm_ir.fused_add_rms_norm]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_fused_add_rms_norm_0.run(buf0, arg4_1, arg3_1, buf2, s72, 2560, stream=raw_stream0)
            del arg3_1
            assert_size_stride(arg5_1, (19456, 2560), (2560, 1), 'input')
            arg5_1 = copy_if_misaligned(arg5_1)
            buf3 = empty_strided_cuda((s72, 19456), (19456, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, linear_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten.t, aten.mm]
            extern_kernels.mm(buf2, reinterpret_tensor(arg5_1, (2560, 19456), (1, 2560), 0), out=buf3)
            del arg5_1
            del buf2
            buf4 = empty_strided_cuda((s72, 9728), (9728, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [getitem_2, silu, getitem_3, mul], Original ATen: [aten.slice, aten.silu, aten.mul]
            triton_poi_fused_mul_silu_slice_1_xnumel = 9728*s72
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_mul_silu_slice_1.run(buf3, buf4, triton_poi_fused_mul_silu_slice_1_xnumel, stream=raw_stream0)
            del buf3
            assert_size_stride(arg6_1, (2560, 9728), (9728, 1), 'input')
            arg6_1 = copy_if_misaligned(arg6_1)
            buf5 = empty_strided_cuda((s72, 2560), (2560, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [getitem_2, silu, getitem_3, mul, linear_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten.t, aten.mm]
            extern_kernels.mm(buf4, reinterpret_tensor(arg6_1, (9728, 2560), (1, 9728), 0), out=buf5)
            del arg6_1
            del buf4
            assert_size_stride(arg7_1, (2560, ), (1, ), 'input')
            arg7_1 = copy_if_misaligned(arg7_1)
            buf6 = empty_strided_cuda((s72, 2560), (2560, 1), torch.bfloat16)
            buf8 = empty_strided_cuda((s72, 2560), (2560, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, fused_add_rms_norm_maybe_inplace_1], Original ATen: [vllm_ir.fused_add_rms_norm]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_fused_add_rms_norm_2.run(buf5, buf0, arg4_1, arg7_1, buf6, buf8, s72, 2560, stream=raw_stream0)
            del arg4_1
            del arg7_1
            del buf0
            del buf5
            assert_size_stride(arg8_1, (6144, 2560), (2560, 1), 'input')
            arg8_1 = copy_if_misaligned(arg8_1)
            buf9 = empty_strided_cuda((s72, 6144), (6144, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, fused_add_rms_norm_maybe_inplace_1, linear_3], Original ATen: [vllm_ir.fused_add_rms_norm, aten.t, aten.mm]
            extern_kernels.mm(buf8, reinterpret_tensor(arg8_1, (2560, 6144), (1, 2560), 0), out=buf9)
            del arg8_1
            del buf8
            assert_size_stride(arg9_1, (128, ), (1, ), 'input')
            assert_size_stride(arg11_1, (s72, ), (1, ), 'input')
            assert_size_stride(arg12_1, (40960, 128), (128, 1), 'input')
            assert_size_stride(arg10_1, (128, ), (1, ), 'input')
            arg9_1 = copy_if_misaligned(arg9_1)
            arg11_1 = copy_if_misaligned(arg11_1)
            arg12_1 = copy_if_misaligned(arg12_1)
            arg10_1 = copy_if_misaligned(arg10_1)
            buf13 = empty_strided_cuda((s72, 32, 128), (4096, 128, 1), torch.bfloat16)
            buf12 = empty_strided_cuda((s72, 8, 128), (1024, 128, 1), torch.bfloat16)
            # Unsorted Source Nodes: [], Original ATen: []
            triton_red_fused_3_xnumel_0 = 32*s72
            triton_red_fused_3_xnumel_1 = 8*s72
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_3.run(buf9, arg9_1, arg11_1, arg12_1, arg10_1, buf13, buf12, triton_red_fused_3_xnumel_0, triton_red_fused_3_xnumel_1, stream=raw_stream0)
            del arg10_1
            del arg11_1
            del arg12_1
            del arg9_1
            buf14 = empty_strided_cuda((s72, 4096), (4096, 1), torch.bfloat16)
        return (buf12, reinterpret_tensor(buf9, (s72, 8, 128), (6144, 128, 1), 5120), buf13, reinterpret_tensor(buf14, (s72, 32, 128), (4096, 128, 1), 0), buf6, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((576, 32, 128), (4096, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = 576
    arg2_1 = rand_strided((2560, 4096), (4096, 1), device='cuda:0', dtype=torch.bfloat16)
    arg3_1 = rand_strided((2560, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg4_1 = rand_strided((576, 2560), (2560, 1), device='cuda:0', dtype=torch.bfloat16)
    arg5_1 = rand_strided((19456, 2560), (2560, 1), device='cuda:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((2560, 9728), (9728, 1), device='cuda:0', dtype=torch.bfloat16)
    arg7_1 = rand_strided((2560, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg8_1 = rand_strided((6144, 2560), (2560, 1), device='cuda:0', dtype=torch.bfloat16)
    arg9_1 = rand_strided((128, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg10_1 = rand_strided((128, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg11_1 = rand_strided((576, ), (1, ), device='cuda:0', dtype=torch.int64)
    arg12_1 = rand_strided((40960, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
