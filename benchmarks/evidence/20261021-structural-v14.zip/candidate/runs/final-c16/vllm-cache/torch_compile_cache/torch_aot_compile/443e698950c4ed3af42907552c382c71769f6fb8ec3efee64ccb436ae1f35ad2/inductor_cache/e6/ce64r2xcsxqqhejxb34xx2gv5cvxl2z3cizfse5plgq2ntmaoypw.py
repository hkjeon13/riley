
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

from torch._dynamo.testing import rand_strided
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import torch

@triton_heuristics.persistent_reduction(
    size_hints={'x': 8192, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*i64', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'Placeholder.DESCRIPTIVE_NAME', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 11, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'kernel_num_gb': 0.011801344, 'kernel_flop': 0, 'backend_hash': '41920D6E87A21DB940AA33B2A7227B6DDEA7760E860450D00BA57747C0845BFF', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    r0_numel = 128
    R0_BLOCK: tl.constexpr = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_2 = r0_index
    x0 = (xindex % 8)
    x1 = xindex // 8
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (4096 + r0_2 + 128*x0 + 6144*x1), xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tmp1 * tmp1
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
    tmp5 = tl.where(xmask, tmp3, 0)
    tmp6 = tl.sum(tmp5, 1)[:, None].to(tl.float32)
    tmp7 = (r0_2).to(tl.int32)
    tmp8 = tl.full([1, 1], 0, tl.int64)
    tmp9 = tmp7 >= tmp8
    tmp10 = (r0_2).to(tl.int64)
    tmp11 = (tmp10).to(tl.int64)
    tmp12 = tl.full([1, 1], 64, tl.int64)
    tmp13 = tmp11 < tmp12
    tmp14 = tl.load(in_ptr0 + (4096 + 128*x0 + 6144*x1 + (r0_2)), tmp13 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tl.full([1, 1], 128.0, tl.float32)
    tmp17 = (tmp6 / tmp16)
    tmp18 = tl.full([1, 1], 1e-06, tl.float32)
    tmp19 = tmp17 + tmp18
    tmp20 = libdevice.rsqrt(tmp19)
    tmp21 = tmp15 * tmp20
    tmp22 = tmp21.to(tl.float32)
    tmp23 = tl.load(in_ptr1 + (tl.broadcast_to(r0_2, [XBLOCK, R0_BLOCK])), tmp13 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp24 = tmp22 * tmp23
    tmp25 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), tmp13 & xmask, eviction_policy='evict_last', other=0.0)
    tmp26 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
    tmp27 = tmp25 + tmp26
    tmp28 = tmp25 < 0
    tmp29 = tl.where(tmp28, tmp27, tmp25)
    tl.device_assert(((0 <= tl.broadcast_to(tmp29, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp29, [XBLOCK, R0_BLOCK]) < 40960)) | ~(tmp13 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp29, [XBLOCK, R0_BLOCK]) < 40960")
    tmp31 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp29 + (r0_2), [XBLOCK, R0_BLOCK])), tmp13 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp32 = tmp24 * tmp31
    tmp33 = tl.load(in_ptr0 + (4160 + 128*x0 + 6144*x1 + (r0_2)), tmp13 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp34 = tmp33.to(tl.float32)
    tmp35 = tmp34 * tmp20
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tl.load(in_ptr1 + (tl.broadcast_to(64 + (r0_2), [XBLOCK, R0_BLOCK])), tmp13 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp38 = tmp36 * tmp37
    tmp39 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp29 + (r0_2), [XBLOCK, R0_BLOCK])), tmp13 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp40 = tmp38 * tmp39
    tmp41 = tmp32 - tmp40
    tmp42 = tl.full(tmp41.shape, 0.0, tmp41.dtype)
    tmp43 = tl.where(tmp13, tmp41, tmp42)
    tmp44 = tmp7 >= tmp12
    tmp45 = tl.full([1, 1], 128, tl.int64)
    tmp46 = tmp7 < tmp45
    tmp47 = tl.load(in_ptr0 + (4160 + 128*x0 + 6144*x1 + ((-64) + r0_2)), tmp44 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp48 = tmp47.to(tl.float32)
    tmp49 = tl.full([1, 1], 128.0, tl.float32)
    tmp50 = (tmp6 / tmp49)
    tmp51 = tl.full([1, 1], 1e-06, tl.float32)
    tmp52 = tmp50 + tmp51
    tmp53 = libdevice.rsqrt(tmp52)
    tmp54 = tmp48 * tmp53
    tmp55 = tmp54.to(tl.float32)
    tmp56 = tl.load(in_ptr1 + (tl.broadcast_to(64 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), tmp44 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp57 = tmp55 * tmp56
    tmp58 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), tmp44 & xmask, eviction_policy='evict_last', other=0.0)
    tmp59 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
    tmp60 = tmp58 + tmp59
    tmp61 = tmp58 < 0
    tmp62 = tl.where(tmp61, tmp60, tmp58)
    tl.device_assert(((0 <= tl.broadcast_to(tmp62, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp62, [XBLOCK, R0_BLOCK]) < 40960)) | ~(tmp44 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp62, [XBLOCK, R0_BLOCK]) < 40960")
    tmp64 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp62 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), tmp44 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp65 = tmp57 * tmp64
    tmp66 = tl.load(in_ptr0 + (4096 + 128*x0 + 6144*x1 + ((-64) + r0_2)), tmp44 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp67 = tmp66.to(tl.float32)
    tmp68 = tmp67 * tmp53
    tmp69 = tmp68.to(tl.float32)
    tmp70 = tl.load(in_ptr1 + (tl.broadcast_to((-64) + r0_2, [XBLOCK, R0_BLOCK])), tmp44 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp71 = tmp69 * tmp70
    tmp72 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp62 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), tmp44 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp73 = tmp71 * tmp72
    tmp74 = tmp65 + tmp73
    tmp75 = tl.full(tmp74.shape, 0.0, tmp74.dtype)
    tmp76 = tl.where(tmp44, tmp74, tmp75)
    tmp77 = tl.where(tmp13, tmp43, tmp76)
    tl.store(out_ptr1 + (r0_2 + 128*x3), tmp77, xmask)


def get_args():
    arg_0 = rand_strided((576, 6144), (6144, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_1 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_2 = rand_strided((576,), (1,), device='cuda:0', dtype=torch.int64)
    arg_3 = rand_strided((40960, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_4 = rand_strided((576, 8, 128), (1024, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    return arg_0, arg_1, arg_2, arg_3, arg_4, 4608, 128,


def call(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        raw_stream0 = get_raw_stream(0)
        triton_.run(*args, stream=raw_stream0)


def benchmark_all_configs(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        return triton_.benchmark_all_configs(*args)


if __name__ == '__main__':
    from torch._inductor.runtime.benchmarking import benchmarker

    args = get_args()
    ms = benchmarker.benchmark(lambda: call(args), device='cuda', rep=40)
    num_gb = 0.011801344
    gb_per_s = num_gb / (ms / 1e3)
    print(f"{ms:.3f}ms    {num_gb:.3f}GB    {gb_per_s:.2f}GB/s")
