from pathlib import Path
import json,hashlib,subprocess,time,traceback
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14d-20261021');state=dict(phase='waiting-binary',started_ns=time.time_ns());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(w/'campaign-state.json').write_text(json.dumps(state,indent=2))
try:
 save();end=time.monotonic()+1200
 while not(w/'qualification-binary.sha256').exists():assert time.monotonic()<end;time.sleep(2)
 receipt=(w/'qualification-binary.sha256').read_text().split();assert receipt[0]==sha(w/'riley-structural-v14d');s=json.loads((w/'source-lineage-pending.json').read_text());s['binary_sha256']=receipt[0];(w/'source-lineage.json').write_text(json.dumps(s,indent=2))
 m=json.loads((w/'source-manifest.json').read_text());assert len(m)==935 and all(sha(w/'source'/f)==h for f,h in m.items())
 for name in ['final-c16','final-c32']:
  state.update(phase='measuring',current=name);save()
  if name=='final-c32':
   a=json.loads((w/'accuracy-state.json').read_text());assert a['phase']=='complete',a
  with(w/(name+'.orchestrator.log')).open('x')as f:r=subprocess.run(['python3',str(w/'run-job.py'),name],stdout=f,stderr=f)
  assert r.returncode==0,(name,r.returncode)
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
