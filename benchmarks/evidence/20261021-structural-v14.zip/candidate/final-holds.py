from pathlib import Path
import json,subprocess,time,os
from holder import admitted_process
W=Path(__file__).resolve().parent;R=W.parent/'riley-w0-a100-gpu67-20261019';rows=[]
assert json.loads((W/'finish-state.json').read_text())['phase']=='complete'
for attempt in range(3):
 sample=dict(time_ns=time.time_ns(),gpus=[])
 for index,pid,ticks in [(6,2027914,'6083215119'),(7,2027915,'6083215121')]:
  h=json.loads((R/f'leases-v2/gpu{index}.status.json').read_text());assert h['phase']=='idle'and h['allocation_bytes']==21474836480 and h['pid']==pid and h['start_ticks']==ticks;assert str(Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19])==ticks;assert time.time_ns()-h['updated_ns']<10**10
  raw=subprocess.check_output(['nvidia-smi','-i',str(index),'--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'],text=True);processes=[dict(pid=int(l.split(',')[0]),MiB=float(l.split(',')[1]))for l in raw.splitlines()if l.strip()];assert all(r['pid']==pid or (index==6 and admitted_process(R/'leases-v2',index,r['pid'],r['MiB']))for r in processes),(index,processes);sample['gpus'].append(dict(index=index,holder=h,processes=processes))
 rows.append(sample);time.sleep(.8)
x=dict(time_ns=time.time_ns(),passed=True,samples=rows,context_restart_or_release=False,scope='Three fresh idle20GiB allocation, original holder PID/start ticks, GPU7 only original holder; GPU6 original holder and separately admitted <=2GiB fresh-demand child if present; all finite runtime jobs closed');(W/'final-holder-audit.json').write_text(json.dumps(x,indent=2));print('original GPU6/7 holder contexts and20GiB idle allocations verified in3fresh samples')
