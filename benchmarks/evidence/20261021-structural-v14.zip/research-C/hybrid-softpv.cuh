// Experimental single-CTA paged attention. Preserve all native BF16 boundaries
// and per-element accumulation/softmax trees; shared storage replaces globals.
template<int HEADS> __device__ __forceinline__ void fused_softpv_body(const __nv_bfloat16*scores,const __nv_bfloat16*v,const uint32_t*ids,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions,int head,__nv_bfloat16*stage,float*result,float*partial,__nv_bfloat16*probability){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 int r=blockIdx.y,t=positions[r]+1,kind=sm80_paged_qk_family(t);if(kind<0)return;
 int tid=threadIdx.x,warp=tid/32,lane=tid%32,kh=head/4;
 out+=r*32*128;
 __syncthreads();int log=0;while((1<<log)<t)log++;int wb=log<=7?2:1;
 if(warp<(HEADS+wb-1)/wb){
#define FUSED_SM(L) case L:hf_wide_chunk_softmax_body<__nv_bfloat16,__nv_bfloat16,float,L,false,false,32,true>(probability,scores+uint64_t(r)*512*32+head*t,HEADS,t,t,lane,warp,4,nullptr,-1,false,warp*wb);break;
  switch(log){FUSED_SM(5) FUSED_SM(6) FUSED_SM(7) FUSED_SM(8)}
#undef FUSED_SM
 }
 __syncthreads();
 if(t%8==0){
  using namespace nvcuda;auto*st=stage+warp*512;auto*res=result+warp*256;
  for(int first=warp*16;first<128;first+=64){
   wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::col_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c;wmma::fill_fragment(c,0.f);
   for(int base=0;base<t;base+=16){uint64_t id=sm80_paged_id(ids,slots,offsets,r,base/16,physical,sequences,id_count);int token=base+lane/2,depth=first/8+lane%2;uint4 vec=make_uint4(0,0,0,0);if(token<t)vec=id<physical?reinterpret_cast<const uint4*>(v)[((id*8+kh)*16+token%16)*16+depth]:make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);reinterpret_cast<uint4*>(st)[lane]=vec;
    for(int i=lane;i<256;i+=32){int token=base+i%16;st[256+i]=i/16<HEADS&&token<t?probability[(i/16)*t+token]:__float2bfloat16_rn(0.f);}__syncwarp();wmma::load_matrix_sync(a,st,16);wmma::load_matrix_sync(b,st+256,16);wmma::mma_sync(c,a,b,c);__syncwarp();}
   wmma::store_matrix_sync(res,c,16,wmma::mem_col_major);__syncwarp();if(lane<16){
    #pragma unroll
    for(int h=0;h<HEADS;h++)out[(head+h)*128+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,res[h*16+lane],0.f));}__syncwarp();
  }
 }else{
  int chain=tid/64;
  for(int first=0;first<128;first+=64){int depth=first+tid%64;float sum[4]={};
   for(int page=0;page<(t+15)/16;page++){uint64_t id=sm80_paged_id(ids,slots,offsets,r,page,physical,sequences,id_count),base=((id*8+kh)*16)*128+depth;
    #pragma unroll
    for(int j=chain;j<16;j+=2){int token=page*16+j;if(token<t){float a=id<physical?__bfloat162float(v[base+j*128]):CUDART_NAN_F;
     #pragma unroll
     for(int h=0;h<HEADS;h++)sum[h]=__fmaf_rn(a,__bfloat162float(probability[h*t+token]),sum[h]);}}}
   #pragma unroll
   for(int h=0;h<HEADS;h++)partial[h*128+tid]=sum[h];__syncthreads();if(tid<64){
    #pragma unroll
    for(int h=0;h<HEADS;h++)out[(head+h)*128+depth]=__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(partial[h*128+tid],partial[h*128+tid+64]),0.f));}__syncthreads();
  }
 }
#endif
}


__global__ void sm80_fused_softpv_dispatch(const __nv_bfloat16*scores,const __nv_bfloat16*v,const uint32_t*ids,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
 int t=positions[blockIdx.y]+1;if(t<24||t>216)return;
 __shared__ __align__(32) __nv_bfloat16 stage[4*512];
 __shared__ __align__(32) float result[4*256];
 __shared__ __align__(32) float partial[4*128];
 __shared__ __align__(32) __nv_bfloat16 probability[4*216];
 int head=blockIdx.x*2;
 if(t%8==0){if(blockIdx.x%2)return;fused_softpv_body<4>(scores,v,ids,out,physical,sequences,id_count,slots,offsets,positions,head,stage,result,partial,probability);}
 else{fused_softpv_body<2>(scores,v,ids,out,physical,sequences,id_count,slots,offsets,positions,head,stage,result,partial,probability);}
}
