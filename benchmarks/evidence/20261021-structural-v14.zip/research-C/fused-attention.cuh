// Experimental single-CTA paged attention. Preserve all native BF16 boundaries
// and per-element accumulation/softmax trees; shared storage replaces globals.
__global__ void fused_exact_paged(const __nv_bfloat16*q,const __nv_bfloat16*k,const __nv_bfloat16*v,const uint32_t*ids,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 int r=blockIdx.y,t=positions[r]+1,kind=sm80_paged_qk_family(t);if(kind<0)return;
 int tid=threadIdx.x,warp=tid/32,lane=tid%32,head=blockIdx.x*4,kh=head/4;
 q+=r*32*128;out+=r*32*128;
 __shared__ __align__(32) __nv_bfloat16 stage[4*4096];
 __shared__ __align__(32) float result[4*256];
 __shared__ __align__(32) float partial[4*128];
 __shared__ __align__(32) __nv_bfloat16 probability[4*216];
 if(kind==2){
  using namespace nvcuda;auto*st=stage+warp*4096;auto*res=result+warp*256;
  for(int first=warp*16;first<t;first+=64){
   for(int i=lane;i<256;i+=32){int token=first+i/16,depth=i%16;uint64_t id=token<t?sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count):physical;uint4 vec=make_uint4(0,0,0,0);if(token<t)vec=id<physical?reinterpret_cast<const uint4*>(k)[((id*8+kh)*16+token%16)*16+depth]:make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);reinterpret_cast<uint4*>(st)[i]=vec;reinterpret_cast<uint4*>(st+2048)[i]=i<64?reinterpret_cast<const uint4*>(q)[head*16+i]:make_uint4(0,0,0,0);}
   __syncwarp();wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c;wmma::fill_fragment(c,0.f);
   #pragma unroll
   for(int j=0;j<128;j+=16){wmma::load_matrix_sync(a,st+j,128);wmma::load_matrix_sync(b,st+2048+j,128);wmma::mma_sync(c,a,b,c);}
   wmma::store_matrix_sync(res,c,16,wmma::mem_col_major);__syncwarp();if(lane<16&&first+lane<t){
    #pragma unroll
    for(int h=0;h<4;h++)probability[h*t+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,res[h*16+lane],0.f));}
   __syncwarp();
  }
 }else{
  int L=kind==1?16:8,local=tid%L;
  for(int first=0;first<t;first+=128/L){int token=first+tid/L;float sum[4]={};
   if(token<t){uint64_t id=sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count);
    for(int j=0;j<128/L;j++){int d=kind==1?local+j*16:local*16+j;float a=id<physical?__bfloat162float(k[((id*8+kh)*16+token%16)*128+d]):CUDART_NAN_F;
     #pragma unroll
     for(int h=0;h<4;h++)sum[h]=__fmaf_rn(a,__bfloat162float(q[(head+h)*128+d]),sum[h]);}}
   #pragma unroll
   for(int h=0;h<4;h++)partial[h*128+tid]=sum[h];__syncthreads();
   if(local==0&&token<t){
    #pragma unroll
    for(int h=0;h<4;h++){float*p=partial+h*128+tid,val=p[0];if(kind==1){
     #pragma unroll
     for(int j=1;j<16;j++)val=__fadd_rn(val,p[j]);
    }else{float a=__fadd_rn(p[0],p[4]),b=__fadd_rn(p[1],p[5]),c=__fadd_rn(p[2],p[6]),d=__fadd_rn(p[3],p[7]);val=__fadd_rn(__fadd_rn(a,c),__fadd_rn(b,d));}
    probability[h*t+token]=__float2bfloat16_rn(__fmaf_rn(1.f,val,0.f));}}
   __syncthreads();
  }
 }
 __syncthreads();int log=0;while((1<<log)<t)log++;int wb=log<=7?2:1;
 if(warp<(4+wb-1)/wb){
#define FUSED_SM(L) case L:hf_wide_chunk_softmax_body<__nv_bfloat16,__nv_bfloat16,float,L,false,false,32,true>(probability,probability,4,t,t,lane,warp,4,nullptr,-1,false,warp*wb);break;
  switch(log){FUSED_SM(5) FUSED_SM(6) FUSED_SM(7) FUSED_SM(8)}
#undef FUSED_SM
 }
 __syncthreads();
 if(t%8==0){
  using namespace nvcuda;auto*st=stage+warp*4096;auto*res=result+warp*256;
  for(int first=warp*16;first<128;first+=64){
   wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::col_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c;wmma::fill_fragment(c,0.f);
   for(int base=0;base<t;base+=16){uint64_t id=sm80_paged_id(ids,slots,offsets,r,base/16,physical,sequences,id_count);int token=base+lane/2,depth=first/8+lane%2;uint4 vec=make_uint4(0,0,0,0);if(token<t)vec=id<physical?reinterpret_cast<const uint4*>(v)[((id*8+kh)*16+token%16)*16+depth]:make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);reinterpret_cast<uint4*>(st)[lane]=vec;
    for(int i=lane;i<256;i+=32){int token=base+i%16;st[256+i]=i/16<4&&token<t?probability[(i/16)*t+token]:__float2bfloat16_rn(0.f);}__syncwarp();wmma::load_matrix_sync(a,st,16);wmma::load_matrix_sync(b,st+256,16);wmma::mma_sync(c,a,b,c);__syncwarp();}
   wmma::store_matrix_sync(res,c,16,wmma::mem_col_major);__syncwarp();if(lane<16){
    #pragma unroll
    for(int h=0;h<4;h++)out[(head+h)*128+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,res[h*16+lane],0.f));}__syncwarp();
  }
 }else{
  int chain=tid/64;
  for(int first=0;first<128;first+=64){int depth=first+tid%64;float sum[4]={};
   for(int page=0;page<(t+15)/16;page++){uint64_t id=sm80_paged_id(ids,slots,offsets,r,page,physical,sequences,id_count),base=((id*8+kh)*16)*128+depth;
    #pragma unroll
    for(int j=chain;j<16;j+=2){int token=page*16+j;if(token<t){float a=id<physical?__bfloat162float(v[base+j*128]):CUDART_NAN_F;
     #pragma unroll
     for(int h=0;h<4;h++)sum[h]=__fmaf_rn(a,__bfloat162float(probability[h*t+token]),sum[h]);}}}
   #pragma unroll
   for(int h=0;h<4;h++)partial[h*128+tid]=sum[h];__syncthreads();if(tid<64){
    #pragma unroll
    for(int h=0;h<4;h++)out[(head+h)*128+depth]=__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(partial[h*128+tid],partial[h*128+tid+64]),0.f));}__syncthreads();
  }
 }
#endif
}
