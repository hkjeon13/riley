#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <mma.h>
#include <vector>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <algorithm>
#include <cstdint>
#include <cmath>
#include "/mnt/efs/nlp/psyche/riley-structural-v14c-20261021/source/kernels/src/hf_softmax_diagnostic.cuh"
struct HfDecodeChunk{int count,total,starts[32],tokens[32];};
template <typename input_t, typename output_t, typename acc_t, int log2_elements, bool is_log_softmax, bool is_masked, int WARP_SIZE_PARAM, bool scaled_bf16_d128 = false, bool scaled_bf16_d64 = false, bool strided_rows = false>
__device__ __forceinline__ void hf_wide_chunk_softmax_body(output_t *dst, const input_t *src, int batch_size, int stride, int element_count, int virtual_x, int virtual_y, int virtual_warps, const bool *mask = nullptr, const int head_chunk_size = -1, bool is_transformer_mask = false, int first_batch_override = -1)
{
    // WARP_SIZE and WARP_BATCH must match the return values batches_per_warp and warp_size of method warp_softmax_forward_kernel.
    constexpr int next_power_of_two = 1 << log2_elements;
    constexpr int WARP_SIZE = (next_power_of_two < WARP_SIZE_PARAM) ? next_power_of_two : WARP_SIZE_PARAM;
    constexpr int WARP_ITERATIONS = next_power_of_two / WARP_SIZE;
    constexpr int WARP_BATCH = (next_power_of_two <= 128) ? 2 : 1;

    int first_batch = first_batch_override >= 0 ? first_batch_override : (virtual_warps * blockIdx.x + virtual_y) * WARP_BATCH;

    // batch_size might not be a multiple of WARP_BATCH. Check how
    // many batches have to computed within this WARP.
    int local_batches = batch_size - first_batch;
    if (local_batches > WARP_BATCH)
        local_batches = WARP_BATCH;

    // there might be multiple batches per warp. compute the index within the batch
    int local_idx = virtual_x;
    int idx_offset = first_batch * stride + local_idx;

    src += idx_offset;
    dst += idx_offset;

    if (is_transformer_mask) {
        mask += ((first_batch * stride) / head_chunk_size) * stride + local_idx;
    } else {
        mask += idx_offset;
    }
    // The nested loops over WARP_BATCH and then WARP_ITERATIONS can be simplified to one loop,
    // but I think doing so would obfuscate the logic of the algorithm, thus I chose to keep
    // the nested loops.
    // This should have no impact on performance because the loops are unrolled anyway.

    // load data from global memory
    acc_t elements[WARP_BATCH][WARP_ITERATIONS];
    for (int i = 0;  i < WARP_BATCH;  ++i) {
        int batch_element_count = (i >= local_batches) ? 0 : element_count;
        for (int it = 0;  it < WARP_ITERATIONS;  ++it) {
            int element_index = local_idx + it * WARP_SIZE;
            if (element_index < batch_element_count) {
                elements[i][it] = src[i*(strided_rows?stride:element_count)+it*WARP_SIZE];
                if constexpr (scaled_bf16_d64) {
                    elements[i][it] = __bfloat162float(__float2bfloat16_rn(__fmul_rn(elements[i][it],0.125f)));
                }
                if constexpr (scaled_bf16_d128) {
                    elements[i][it] = hf_decode_scaled_bf16_d128(elements[i][it]);
                }
            } else {
                elements[i][it] = -CUDART_INF_F;
            }
        }
    }

    // compute max_value
    acc_t max_value[WARP_BATCH];
    #pragma unroll
    for (int i = 0;  i < WARP_BATCH;  ++i) {
        int batch_element_count = (i >= local_batches) ? 0 : element_count;
        bool is_meaningful_max = false;
        max_value[i] = elements[i][0];
        #pragma unroll
        for (int it = 0;  it < WARP_ITERATIONS;  ++it) {
            if (is_masked) {
                int idx = it*WARP_SIZE;
                if ((idx + local_idx) < batch_element_count) {
                    if (!is_transformer_mask) {
                        idx += i*(strided_rows?stride:element_count);
                    }
                    if (!mask[idx]) {
                        max_value[i] = (is_meaningful_max && max_value[i] > elements[i][it]) ? max_value[i] : elements[i][it];
                        is_meaningful_max = true;
                    }
                }
            } else {
                max_value[i] = max_value[i] > elements[i][it] ? max_value[i] : elements[i][it];
            }
        }
        if (is_masked) {
            if (!is_meaningful_max) {
                max_value[i] = -CUDART_INF_F;
            }
        }
    }
    warp_reduce<acc_t, WARP_BATCH, WARP_SIZE, Max>(max_value);

    acc_t sum[WARP_BATCH] { 0.0f };
    #pragma unroll
    for (int i = 0;  i < WARP_BATCH;  ++i) {
        int batch_element_count = (i >= local_batches) ? 0 : element_count;
        #pragma unroll
        for (int it = 0;  it < WARP_ITERATIONS;  ++it) {
            if (!is_masked) {
                if (is_log_softmax) {
                    sum[i] += std::exp(elements[i][it] - max_value[i]);
                } else {
                    elements[i][it] = std::exp(elements[i][it] - max_value[i]);
                    sum[i] += elements[i][it];
                }
            } else {
                int idx = it*WARP_SIZE;
                bool valid = (idx + local_idx) < batch_element_count;
                if (!is_transformer_mask) {
                    idx += i*(strided_rows?stride:element_count);
                }
                if (valid) {
                    if (!mask[idx]) {
                        if (is_log_softmax) {
                            sum[i] += std::exp(elements[i][it] - max_value[i]);
                        } else {
                            elements[i][it] = std::exp(elements[i][it] - max_value[i]);
                            sum[i] += elements[i][it];
                        }
                    } else {
                        if (!is_log_softmax) {
                            // Masked values are treated as -infinity, and std::exp(-infinity) is 0.
                            elements[i][it] = 0;
                        }
                    }
                } else {
                    if (!is_log_softmax) {
                        elements[i][it] = 0.;
                    }
                }
            }
        }
    }
    warp_reduce<acc_t, WARP_BATCH, WARP_SIZE, Add>(sum);

    // store result
    #pragma unroll
    for (int i = 0;  i < WARP_BATCH;  ++i) {
        if (i >= local_batches)
            break;
        if (is_log_softmax) sum[i] = std::log(sum[i]);
        #pragma unroll
        for (int it = 0;  it < WARP_ITERATIONS;  ++it) {
            int element_index = local_idx + it * WARP_SIZE;
            if (element_index < element_count) {
                if (is_log_softmax) {
                    dst[i*(strided_rows?stride:element_count)+it*WARP_SIZE] = elements[i][it] - max_value[i] - sum[i];
                } else if (sum[i] == 0) {
                    dst[i*(strided_rows?stride:element_count)+it*WARP_SIZE] = CUDART_NAN_F;
                } else {
                    dst[i*(strided_rows?stride:element_count)+it*WARP_SIZE] = elements[i][it] / sum[i];
                }
            } else {
                break;
            }
        }
    }
}
__host__ __device__ static int sm80_paged_qk_family(uint64_t t){
 if(t<24 || t>216)return -1;
 if(t>=130 && t%2==0)return 2;
 if((t>=49 && t%2==1)||t%8==0)return 1;
 return 0;
}
struct HfSm80Group {int count=0,maximum=0,rows[32]{};};
__device__ __forceinline__ uint64_t sm80_paged_id(const uint32_t*ids,const uint32_t*slots,const uint32_t*offsets,int r,int page,uint64_t physical,uint64_t sequences,uint64_t id_count){
 uint64_t slot=slots[r];if(slot>=sequences)return physical;uint64_t start=offsets[slot],end=offsets[slot+1];if(start>end||end>id_count||uint64_t(page)>=end-start)return physical;uint64_t id=ids[start+page];return id<physical?id:physical;
}
// Pinned SM80 native reduction families. All scores and probabilities retain
// their original BF16 stores; queries and KV pages keep their existing layout.
template<bool Serial16> __global__ void sm80_chunk_paged_qk(const __nv_bfloat16*q,const __nv_bfloat16*k,const uint32_t*ids,__nv_bfloat16*score,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const HfDecodeChunk info,const HfSm80Group group){
 int r=group.rows[blockIdx.z],t=info.tokens[r];q+=r*32*128;score+=uint64_t(info.starts[r])*32;
 constexpr int L=Serial16?16:8;int lane=threadIdx.x,token=blockIdx.x*8+threadIdx.y,head=blockIdx.y;float sum=0.f;
 if(token<t){uint64_t id=sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count);
 #pragma unroll
 for(int j=0;j<128/L;j++){int d=Serial16?lane+j*16:lane*16+j;float a=id<physical?__bfloat162float(k[((id*8+head/4)*16+token%16)*128+d]):CUDART_NAN_F;float b=__bfloat162float(q[head*128+d]);sum=__fmaf_rn(a,b,sum);}}
 __shared__ float p[8][L];p[threadIdx.y][lane]=sum;__syncthreads();
 if(lane==0&&token<t){float v=p[threadIdx.y][0];if(Serial16){
 #pragma unroll
 for(int j=1;j<L;j++)v=__fadd_rn(v,p[threadIdx.y][j]);
 }else{float*pv=p[threadIdx.y];float a=__fadd_rn(pv[0],pv[4]),b=__fadd_rn(pv[1],pv[5]),c=__fadd_rn(pv[2],pv[6]),d=__fadd_rn(pv[3],pv[7]);v=__fadd_rn(__fadd_rn(a,c),__fadd_rn(b,d));}score[head*t+token]=__float2bfloat16_rn(__fmaf_rn(1.f,v,0.f));}
}
__global__ void sm80_chunk_paged_wmma_qk(const __nv_bfloat16*q,const __nv_bfloat16*k,const uint32_t*ids,__nv_bfloat16*score,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const HfDecodeChunk info,const HfSm80Group group){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800

 int r=group.rows[blockIdx.z],t=info.tokens[r];q+=r*32*128;score+=uint64_t(info.starts[r])*32;if(blockIdx.x*16>=t)return;
 using namespace nvcuda;int lane=threadIdx.x,head=blockIdx.y,first=blockIdx.x*16;
 __shared__ __align__(32) __nv_bfloat16 stage[4096];
 for(int i=lane;i<256;i+=32){int token=first+i/16,depth=i%16;uint64_t id=token<t?sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count):physical;uint4 v=make_uint4(0,0,0,0);if(token<t){if(id<physical)v=reinterpret_cast<const uint4*>(k)[((id*8+head/4)*16+token%16)*16+depth];else v=make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);}reinterpret_cast<uint4*>(stage)[i]=v;
  reinterpret_cast<uint4*>(stage+2048)[i]=i<16?reinterpret_cast<const uint4*>(q)[head*16+i]:make_uint4(0,0,0,0);
 }__syncwarp();
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>acc;wmma::fill_fragment(acc,0.f);
 #pragma unroll
 for(int j=0;j<128;j+=16){wmma::load_matrix_sync(a,stage+j,128);wmma::load_matrix_sync(b,stage+2048+j,128);wmma::mma_sync(acc,a,b,acc);}
 __shared__ __align__(32) float result[256];wmma::store_matrix_sync(result,acc,16,wmma::mem_col_major);__syncwarp();if(lane<16&&first+lane<t)score[head*t+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,result[lane],0.f));

#endif
}
__global__ void sm80_chunk_paged_pv(const __nv_bfloat16*values,const uint32_t*ids,const __nv_bfloat16*prob,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const HfDecodeChunk info,const HfSm80Group group){
 int r=group.rows[blockIdx.z],t=info.tokens[r];prob+=uint64_t(info.starts[r])*32;out+=r*32*128;
 int tid=threadIdx.x,head=blockIdx.y,depth=blockIdx.x*32+tid%32,lane=tid/32;float sum=0.f;
 for(int page=0;page<(t+15)/16;page++){uint64_t id=sm80_paged_id(ids,slots,offsets,r,page,physical,sequences,id_count),base=((id*8+head/4)*16)*128+depth;
 #pragma unroll
 for(int j=lane;j<16;j+=2){int token=page*16+j;if(token<t){float a=id<physical?__bfloat162float(values[base+j*128]):CUDART_NAN_F;float b=__bfloat162float(prob[head*t+token]);sum=__fmaf_rn(a,b,sum);}}}
 __shared__ float p[64];p[tid]=sum;__syncthreads();if(tid<32)out[head*128+depth]=__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(p[tid],p[tid+32]),0.f));
}
__global__ void sm80_chunk_paged_wmma_pv(const __nv_bfloat16*values,const uint32_t*ids,const __nv_bfloat16*prob,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const HfDecodeChunk info,const HfSm80Group group){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800

 int r=group.rows[blockIdx.z],t=info.tokens[r];prob+=uint64_t(info.starts[r])*32;out+=r*32*128;
 using namespace nvcuda;int head=blockIdx.y,kh=head/4,lane=threadIdx.x,first=blockIdx.x*16;
 __shared__ __align__(32) __nv_bfloat16 stage[512];
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::col_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>acc;wmma::fill_fragment(acc,0.f);
 for(int base=0;base<t;base+=16){uint64_t id=sm80_paged_id(ids,slots,offsets,r,base/16,physical,sequences,id_count);
  for(int i=lane;i<32;i+=32){int token=base+i/2,depth=first/8+i%2;uint4 v=make_uint4(0,0,0,0);if(token<t){if(id<physical)v=reinterpret_cast<const uint4*>(values)[((id*8+kh)*16+token%16)*16+depth];else v=make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);}reinterpret_cast<uint4*>(stage)[i]=v;}
  for(int i=lane;i<256;i+=32){int token=base+i%16;stage[256+i]=token<t?prob[head*t+token]:__float2bfloat16_rn(0.f);}__syncwarp();
  wmma::load_matrix_sync(a,stage,16);wmma::load_matrix_sync(b,stage+256,16);wmma::mma_sync(acc,a,b,acc);__syncwarp();
 }__shared__ __align__(32) float result[256];wmma::store_matrix_sync(result,acc,16,wmma::mem_col_major);__syncwarp();if(lane<16)out[head*128+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,result[lane],0.f));

#endif
}
template<bool Serial16>__device__ __forceinline__ void sm80_batched_qk_simt(const __nv_bfloat16*q,const __nv_bfloat16*k,const uint32_t*ids,__nv_bfloat16*score,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,int r,int t,float*p){
 constexpr int L=Serial16?16:8;int tid=threadIdx.x,lane=tid%L,token=blockIdx.x*8+tid/L,head=blockIdx.y*4;float sum[4]={};bool active=tid<8*L;
 if(active&&token<t){uint64_t id=sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count);
 #pragma unroll
 for(int j=0;j<128/L;j++){int d=Serial16?lane+j*16:lane*16+j;float a=id<physical?__bfloat162float(k[((id*8+head/4)*16+token%16)*128+d]):CUDART_NAN_F;
 #pragma unroll
 for(int h=0;h<4;h++)sum[h]=__fmaf_rn(a,__bfloat162float(q[(head+h)*128+d]),sum[h]);}}
 if(active){
 #pragma unroll
 for(int h=0;h<4;h++)p[h*128+tid]=sum[h];}__syncthreads();
 if(active&&lane==0&&token<t){
 #pragma unroll
 for(int h=0;h<4;h++){float*pv=p+h*128+tid,val=pv[0];if constexpr(Serial16){
 #pragma unroll
 for(int j=1;j<16;j++)val=__fadd_rn(val,pv[j]);
 }else{float a=__fadd_rn(pv[0],pv[4]),b=__fadd_rn(pv[1],pv[5]),c=__fadd_rn(pv[2],pv[6]),d=__fadd_rn(pv[3],pv[7]);val=__fadd_rn(__fadd_rn(a,c),__fadd_rn(b,d));}score[(head+h)*t+token]=__float2bfloat16_rn(__fmaf_rn(1.f,val,0.f));}}
}
__global__ void sm80_batched_qk_dispatch(const __nv_bfloat16*q,const __nv_bfloat16*k,const uint32_t*ids,__nv_bfloat16*score,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 int r=blockIdx.z,t=positions[r]+1,kind=sm80_paged_qk_family(t);if(kind<0||blockIdx.x*8>=t)return;q+=r*32*128;score+=uint64_t(r)*512*32;
 if(kind!=2){__shared__ float partial[4*128];if(kind==1)sm80_batched_qk_simt<true>(q,k,ids,score,physical,sequences,id_count,slots,offsets,r,t,partial);else sm80_batched_qk_simt<false>(q,k,ids,score,physical,sequences,id_count,slots,offsets,r,t,partial);return;}
 if(blockIdx.x%2||threadIdx.x>=32)return;int lane=threadIdx.x,head=blockIdx.y*4,first=blockIdx.x*8;using namespace nvcuda;
 __shared__ __align__(32)__nv_bfloat16 stage[4096];
 for(int i=lane;i<256;i+=32){int token=first+i/16,depth=i%16;uint64_t id=token<t?sm80_paged_id(ids,slots,offsets,r,token/16,physical,sequences,id_count):physical;uint4 vec=make_uint4(0,0,0,0);if(token<t)vec=id<physical?reinterpret_cast<const uint4*>(k)[((id*8+head/4)*16+token%16)*16+depth]:make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);reinterpret_cast<uint4*>(stage)[i]=vec;reinterpret_cast<uint4*>(stage+2048)[i]=i<64?reinterpret_cast<const uint4*>(q)[head*16+i]:make_uint4(0,0,0,0);}
 __syncwarp();wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c;wmma::fill_fragment(c,0.f);
 #pragma unroll
 for(int j=0;j<128;j+=16){wmma::load_matrix_sync(a,stage+j,128);wmma::load_matrix_sync(b,stage+2048+j,128);wmma::mma_sync(c,a,b,c);}
 __shared__ __align__(32)float result[256];wmma::store_matrix_sync(result,c,16,wmma::mem_col_major);__syncwarp();if(lane<16&&first+lane<t){
 #pragma unroll
 for(int h=0;h<4;h++)score[(head+h)*t+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,result[h*16+lane],0.f));}
#endif
}
__global__ void sm80_batched_pv_dispatch(const __nv_bfloat16*v,const uint32_t*ids,const __nv_bfloat16*prob,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 int r=blockIdx.z,t=positions[r]+1;if(t<24||t>216)return;prob+=uint64_t(r)*512*32;out+=r*32*128;int tid=threadIdx.x;
 if(t%8!=0){int head=blockIdx.y*2,depth=blockIdx.x*16+tid%16,chain=tid/16;float sum[2]={};
  for(int page=0;page<(t+15)/16;page++){uint64_t id=sm80_paged_id(ids,slots,offsets,r,page,physical,sequences,id_count),base=((id*8+head/4)*16)*128+depth;
   #pragma unroll
   for(int j=chain;j<16;j+=2){int token=page*16+j;if(token<t){float a=id<physical?__bfloat162float(v[base+j*128]):CUDART_NAN_F;
    #pragma unroll
    for(int h=0;h<2;h++)sum[h]=__fmaf_rn(a,__bfloat162float(prob[(head+h)*t+token]),sum[h]);}}}
  #pragma unroll
  for(int h=0;h<2;h++){float other=__shfl_down_sync(0xffffffffu,sum[h],16);if(tid<16)out[(head+h)*128+depth]=__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(sum[h],other),0.f));}return;
 }
 if(blockIdx.y%2)return;using namespace nvcuda;int head=blockIdx.y*2,kh=head/4,first=blockIdx.x*16;
 __shared__ __align__(32)__nv_bfloat16 stage[512];wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::col_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c;wmma::fill_fragment(c,0.f);
 for(int base=0;base<t;base+=16){uint64_t id=sm80_paged_id(ids,slots,offsets,r,base/16,physical,sequences,id_count);int token=base+tid/2,depth=first/8+tid%2;uint4 vec=make_uint4(0,0,0,0);if(token<t)vec=id<physical?reinterpret_cast<const uint4*>(v)[((id*8+kh)*16+token%16)*16+depth]:make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);reinterpret_cast<uint4*>(stage)[tid]=vec;
  for(int i=tid;i<256;i+=32){int token=base+i%16;stage[256+i]=i/16<4&&token<t?prob[(head+i/16)*t+token]:__float2bfloat16_rn(0.f);}__syncwarp();wmma::load_matrix_sync(a,stage,16);wmma::load_matrix_sync(b,stage+256,16);wmma::mma_sync(c,a,b,c);__syncwarp();}
 __shared__ __align__(32)float result[256];wmma::store_matrix_sync(result,c,16,wmma::mem_col_major);__syncwarp();if(tid<16){
 #pragma unroll
 for(int h=0;h<4;h++)out[(head+h)*128+first+tid]=__float2bfloat16_rn(__fmaf_rn(1.f,result[h*16+tid],0.f));}
#endif
}

__global__ void sm80_batched_softmax(__nv_bfloat16*prob,const uint32_t*positions){
 int r=blockIdx.y,t=positions[r]+1;if(t<24||t>216)return;int log=0;while((1<<log)<t)log++;int width=log<5?(1<<log):32,warps=128/width,wb=log<=7?2:1;if(blockIdx.x>=(32+warps*wb-1)/(warps*wb))return;int tid=threadIdx.x;auto*p=prob+uint64_t(r)*512*32;
#define BATCH_SM(L) case L:hf_wide_chunk_softmax_body<__nv_bfloat16,__nv_bfloat16,float,L,false,false,32,true>(p,p,32,t,t,tid%width,tid/width,warps);break;
 switch(log){BATCH_SM(5) BATCH_SM(6) BATCH_SM(7) BATCH_SM(8)}
#undef BATCH_SM
}
// Experimental single-CTA paged attention. Preserve all native BF16 boundaries
// and per-element accumulation/softmax trees; shared storage replaces globals.
template<int HEADS,int DEPTH> __device__ __forceinline__ void fused_softpv_body(const __nv_bfloat16*scores,const __nv_bfloat16*v,const uint32_t*ids,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions,int head,__nv_bfloat16*stage,float*result,float*partial,__nv_bfloat16*probability){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 int r=blockIdx.y,t=positions[r]+1,kind=sm80_paged_qk_family(t);if(kind<0)return;
 int tid=threadIdx.x,warp=tid/32,lane=tid%32,kh=head/4;
 out+=r*32*128;
 __syncthreads();int log=0;while((1<<log)<t)log++;int wb=log<=7?2:1;
 if(warp<(HEADS+wb-1)/wb){
#define FUSED_SM(L) case L:hf_wide_chunk_softmax_body<__nv_bfloat16,__nv_bfloat16,float,L,false,false,32,true>(probability,scores+uint64_t(r)*512*32+head*t,HEADS,t,t,lane,warp,4,nullptr,-1,false,warp*wb);break;
  switch(log){FUSED_SM(5) FUSED_SM(6) FUSED_SM(7) FUSED_SM(8)}
#undef FUSED_SM
 }
 __syncthreads();
 if(t%8==0){
  using namespace nvcuda;auto*st=stage+warp*512;auto*res=result+warp*256;
  for(int first=blockIdx.z*DEPTH+warp*16;first<(blockIdx.z+1)*DEPTH;first+=64){
   wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::col_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c;wmma::fill_fragment(c,0.f);
   for(int base=0;base<t;base+=16){uint64_t id=sm80_paged_id(ids,slots,offsets,r,base/16,physical,sequences,id_count);int token=base+lane/2,depth=first/8+lane%2;uint4 vec=make_uint4(0,0,0,0);if(token<t)vec=id<physical?reinterpret_cast<const uint4*>(v)[((id*8+kh)*16+token%16)*16+depth]:make_uint4(0x7fff7fff,0x7fff7fff,0x7fff7fff,0x7fff7fff);reinterpret_cast<uint4*>(st)[lane]=vec;
    for(int i=lane;i<256;i+=32){int token=base+i%16;st[256+i]=i/16<HEADS&&token<t?probability[(i/16)*t+token]:__float2bfloat16_rn(0.f);}__syncwarp();wmma::load_matrix_sync(a,st,16);wmma::load_matrix_sync(b,st+256,16);wmma::mma_sync(c,a,b,c);__syncwarp();}
   wmma::store_matrix_sync(res,c,16,wmma::mem_col_major);__syncwarp();if(lane<16){
    #pragma unroll
    for(int h=0;h<HEADS;h++)out[(head+h)*128+first+lane]=__float2bfloat16_rn(__fmaf_rn(1.f,res[h*16+lane],0.f));}__syncwarp();
  }
 }else{
  int depth_base=blockIdx.z*DEPTH;int chain=tid/DEPTH;
  for(int first=depth_base;first<depth_base+DEPTH;first+=DEPTH){int depth=first+tid%DEPTH;float sum[4]={};
   if(tid<2*DEPTH)for(int page=0;page<(t+15)/16;page++){uint64_t id=sm80_paged_id(ids,slots,offsets,r,page,physical,sequences,id_count),base=((id*8+kh)*16)*128+depth;
    #pragma unroll
    for(int j=chain;j<16;j+=2){int token=page*16+j;if(token<t){float a=id<physical?__bfloat162float(v[base+j*128]):CUDART_NAN_F;
     #pragma unroll
     for(int h=0;h<HEADS;h++)sum[h]=__fmaf_rn(a,__bfloat162float(probability[h*t+token]),sum[h]);}}}
   #pragma unroll
   for(int h=0;h<HEADS;h++)partial[h*128+tid]=sum[h];__syncthreads();if(tid<DEPTH){
    #pragma unroll
    for(int h=0;h<HEADS;h++)out[(head+h)*128+depth]=__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(partial[h*128+tid],partial[h*128+tid+DEPTH]),0.f));}__syncthreads();
  }
 }
#endif
}


template<int DEPTH> __global__ void sm80_fused_softpv_dispatch(const __nv_bfloat16*scores,const __nv_bfloat16*v,const uint32_t*ids,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
 int t=positions[blockIdx.y]+1;if(t<24||t>216)return;
 __shared__ __align__(32) __nv_bfloat16 stage[4*512];
 __shared__ __align__(32) float result[4*256];
 __shared__ __align__(32) float partial[4*128];
 __shared__ __align__(32) __nv_bfloat16 probability[4*216];
 int head=blockIdx.x*2;
 if(t%8==0){if(blockIdx.x%2)return;fused_softpv_body<4,DEPTH>(scores,v,ids,out,physical,sequences,id_count,slots,offsets,positions,head,stage,result,partial,probability);}
 else{fused_softpv_body<2,DEPTH>(scores,v,ids,out,physical,sequences,id_count,slots,offsets,positions,head,stage,result,partial,probability);}
}
__global__ void evict_cache(uint4*p,int count,int salt){int i=blockIdx.x*256+threadIdx.x;if(i<count){unsigned a=unsigned(i)*1664525u+unsigned(salt);p[i]=make_uint4(a,a^0x71517211u,a*1013904223u,a^(a>>17));}}
#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"cuda error line%d %s\n",__LINE__,cudaGetErrorString(e));return 3;}}while(0)
using B=__nv_bfloat16;
int main(int argc,char**argv){int heads=argc>1?atoi(argv[1]):64;cudaStream_t stream;CU(cudaStreamCreate(&stream));B*q,*k,*v,*prob,*base,*got;uint32_t*ids,*slots,*offsets,*pos;const int blocks=512;
 CU(cudaMalloc(&q,32*32*128*2));CU(cudaMalloc(&k,blocks*8*16*128*2));CU(cudaMalloc(&v,blocks*8*16*128*2));CU(cudaMalloc(&prob,32*32*512*2));CU(cudaMalloc(&base,32*32*128*2));CU(cudaMalloc(&got,32*32*128*2));CU(cudaMalloc(&ids,512*4));CU(cudaMalloc(&slots,32*4));CU(cudaMalloc(&offsets,33*4));CU(cudaMalloc(&pos,32*4));
 std::vector<uint32_t>hi(512),hs(32),ho(33),hp(32);for(int i=0;i<512;i++)hi[i]=(i*137+19)%512;for(int i=0;i<32;i++){hs[i]=31-i;ho[i]=i*16;}ho[32]=512;
 CU(cudaMemcpy(ids,hi.data(),512*4,cudaMemcpyHostToDevice));CU(cudaMemcpy(slots,hs.data(),32*4,cudaMemcpyHostToDevice));CU(cudaMemcpy(offsets,ho.data(),33*4,cudaMemcpyHostToDevice));
 std::vector<B>hq(32*32*128),hk(blocks*8*16*128),hv(hk.size()),hb(hq.size()),hg(hq.size());uint32_t seed=1729;auto sample=[&](){seed=1664525u*seed+1013904223u;return int((seed>>16)%257)-128;};
 auto original=[&](int r){sm80_batched_qk_dispatch<<<dim3(27,8,r),128,0,stream>>>(q,k,ids,prob,blocks,32,512,slots,offsets,pos);sm80_batched_softmax<<<dim3(8,r),128,0,stream>>>(prob,pos);sm80_batched_pv_dispatch<<<dim3(8,16,r),32,0,stream>>>(v,ids,prob,base,blocks,32,512,slots,offsets,pos);};
 auto candidate=[&](int r){sm80_batched_qk_dispatch<<<dim3(27,8,r),128,0,stream>>>(q,k,ids,prob,blocks,32,512,slots,offsets,pos);if(heads==64)sm80_fused_softpv_dispatch<64><<<dim3(16,r,2),128,0,stream>>>(prob,v,ids,got,blocks,32,512,slots,offsets,pos);else sm80_fused_softpv_dispatch<32><<<dim3(16,r,4),128,0,stream>>>(prob,v,ids,got,blocks,32,512,slots,offsets,pos);};
 uint4*flush;CU(cudaMalloc(&flush,64ul<<20));
 int checked=0;
 for(int state=0;state<6;state++){
  float scale=state==1?0.0001f:state==2?0.0625f:0.015625f;
  for(auto&x:hq)x=__float2bfloat16_rn(sample()*scale);for(auto&x:hk)x=__float2bfloat16_rn(sample()*scale);for(auto&x:hv)x=__float2bfloat16_rn(sample()*scale);
  CU(cudaMemcpy(q,hq.data(),hq.size()*2,cudaMemcpyHostToDevice));CU(cudaMemcpy(k,hk.data(),hk.size()*2,cudaMemcpyHostToDevice));CU(cudaMemcpy(v,hv.data(),hv.size()*2,cudaMemcpyHostToDevice));
  for(int t=24;t<=216;t++){for(int i=0;i<32;i++)hp[i]=state<3?t-1:23+(t-24+i*17)%193;CU(cudaMemcpy(pos,hp.data(),128,cudaMemcpyHostToDevice));
   for(int r=1;r<=32;r++){original(r);candidate(r);CU(cudaGetLastError());CU(cudaStreamSynchronize(stream));CU(cudaMemcpy(hb.data(),base,r*32*128*2,cudaMemcpyDeviceToHost));CU(cudaMemcpy(hg.data(),got,r*32*128*2,cudaMemcpyDeviceToHost));
    if(memcmp(hb.data(),hg.data(),r*32*128*2)){for(int j=0;j<r*32*128;j++)if(memcmp(&hb[j],&hg[j],2)){printf("MISMATCH state=%d T=%d R=%d index=%d expected=%04x got=%04x\n",state,t,r,j,*reinterpret_cast<uint16_t*>(&hb[j]),*reinterpret_cast<uint16_t*>(&hg[j]));return 4;}}
    checked++;
   }
  }printf("EXACT state=%d cumulative_combinations=%d\n",state,checked);fflush(stdout);
 }
 auto timing=[&](auto fn,int r){cudaGraph_t graph;cudaGraphExec_t exec;cudaStreamBeginCapture(stream,cudaStreamCaptureModeGlobal);for(int i=0;i<64;i++)fn(r);cudaStreamEndCapture(stream,&graph);cudaGraphInstantiate(&exec,graph,nullptr,nullptr,0);for(int i=0;i<4;i++)cudaGraphLaunch(exec,stream);cudaStreamSynchronize(stream);cudaEvent_t a,b;cudaEventCreate(&a);cudaEventCreate(&b);cudaEventRecord(a,stream);for(int i=0;i<8;i++)cudaGraphLaunch(exec,stream);cudaEventRecord(b,stream);cudaEventSynchronize(b);float ms=0;cudaEventElapsedTime(&ms,a,b);cudaEventDestroy(a);cudaEventDestroy(b);cudaGraphExecDestroy(exec);cudaGraphDestroy(graph);return ms*1000/(64*8);};
 for(int t:{128,129,144,159,192,213}){for(int r:{1,2,8,16,24,32}){for(int i=0;i<32;i++)hp[i]=t-1;CU(cudaMemcpy(pos,hp.data(),128,cudaMemcpyHostToDevice));for(int rep=0;rep<3;rep++){float a,b;if(rep%2){b=timing(candidate,r);a=timing(original,r);}else{a=timing(original,r);b=timing(candidate,r);}printf("TIMING H=%d T=%d R=%d rep=%d baseline_us=%.6f fused_us=%.6f\n",heads,t,r,rep,a,b);fflush(stdout);}}}

 auto cold_timing=[&](auto fn,int r){cudaGraph_t graph;cudaGraphExec_t exec;cudaStreamBeginCapture(stream,cudaStreamCaptureModeGlobal);fn(r);cudaStreamEndCapture(stream,&graph);cudaGraphInstantiate(&exec,graph,nullptr,nullptr,0);cudaEvent_t a,b;cudaEventCreate(&a);cudaEventCreate(&b);float total=0;for(int rep=0;rep<20;rep++){evict_cache<<<16384,256,0,stream>>>(flush,4194304,rep);cudaEventRecord(a,stream);cudaGraphLaunch(exec,stream);cudaEventRecord(b,stream);cudaEventSynchronize(b);float ms=0;cudaEventElapsedTime(&ms,a,b);if(rep>=4)total+=ms;}cudaEventDestroy(a);cudaEventDestroy(b);cudaGraphExecDestroy(exec);cudaGraphDestroy(graph);return total*1000/16;};
 for(int pattern=0;pattern<2;pattern++)for(int r:{8,16,24,32}){for(int i=0;i<32;i++)hp[i]=pattern?114+(i*7)%48:127;CU(cudaMemcpy(pos,hp.data(),128,cudaMemcpyHostToDevice));for(int rep=0;rep<3;rep++){float a,b;if(rep%2){b=cold_timing(candidate,r);a=cold_timing(original,r);}else{a=cold_timing(original,r);b=cold_timing(candidate,r);}printf("COLD DEPTH=%d pattern=%d R=%d rep=%d baseline_us=%.6f fused_us=%.6f\n",heads,pattern,r,rep,a,b);fflush(stdout);}}
 CU(cudaFree(flush));
 printf("COMPLETE H=%d exact_combinations=%d unchanged_BF16_QK_probability_PV=true\n",heads,checked);CU(cudaGetLastError());for(auto p:{q,k,v,prob,base,got})CU(cudaFree(p));for(auto p:{ids,slots,offsets,pos})CU(cudaFree(p));CU(cudaStreamDestroy(stream));return 0;
}
