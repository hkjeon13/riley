from pathlib import Path
import os,subprocess,json
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14c-20261021');s=(w/'source/kernels/src/cublas_gemm_probe.cu').read_text();header='''#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <mma.h>
#include <vector>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <algorithm>
#include <cstdint>
#include <cmath>
#include "'''+str(w/'source/kernels/src/hf_softmax_diagnostic.cuh')+'''"
struct HfDecodeChunk{int count,total,starts[32],tokens[32];};
''';a=s.index('template <typename input_t, typename output_t, typename acc_t, int log2_elements, bool is_log_softmax, bool is_masked, int WARP_SIZE_PARAM, bool scaled_bf16_d128');b=s.index('__global__ void hf_wide_chunk_softmax(',a);header+=s[a:b];a=s.index('__host__ __device__ static int sm80_paged_qk_family');b=s.index('\n}\n\nextern "C" RileyCudaStatus riley_cuda_cublas_hf_attention_chunk_wide_execute',a);header+=s[a:b]
header+=(w/'research/fused-attention.cuh').read_text()
header+=r'''
#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"cuda error line%d %s\n",__LINE__,cudaGetErrorString(e));return 3;}}while(0)
using B=__nv_bfloat16;
int main(){cudaStream_t stream;CU(cudaStreamCreate(&stream));B*q,*k,*v,*prob,*base,*got;uint32_t*ids,*slots,*offsets,*pos;const int blocks=512;
 CU(cudaMalloc(&q,32*32*128*2));CU(cudaMalloc(&k,blocks*8*16*128*2));CU(cudaMalloc(&v,blocks*8*16*128*2));CU(cudaMalloc(&prob,32*32*512*2));CU(cudaMalloc(&base,32*32*128*2));CU(cudaMalloc(&got,32*32*128*2));CU(cudaMalloc(&ids,512*4));CU(cudaMalloc(&slots,32*4));CU(cudaMalloc(&offsets,33*4));CU(cudaMalloc(&pos,32*4));
 std::vector<uint32_t>hi(512),hs(32),ho(33),hp(32);for(int i=0;i<512;i++)hi[i]=(i*137+19)%512;for(int i=0;i<32;i++){hs[i]=31-i;ho[i]=i*16;}ho[32]=512;
 CU(cudaMemcpy(ids,hi.data(),512*4,cudaMemcpyHostToDevice));CU(cudaMemcpy(slots,hs.data(),32*4,cudaMemcpyHostToDevice));CU(cudaMemcpy(offsets,ho.data(),33*4,cudaMemcpyHostToDevice));
 std::vector<B>hq(32*32*128),hk(blocks*8*16*128),hv(hk.size()),hb(hq.size()),hg(hq.size());uint32_t seed=1729;auto sample=[&](){seed=1664525u*seed+1013904223u;return int((seed>>16)%257)-128;};
 auto original=[&](int r){sm80_batched_qk_dispatch<<<dim3(27,8,r),128,0,stream>>>(q,k,ids,prob,blocks,32,512,slots,offsets,pos);sm80_batched_softmax<<<dim3(8,r),128,0,stream>>>(prob,pos);sm80_batched_pv_dispatch<<<dim3(8,16,r),32,0,stream>>>(v,ids,prob,base,blocks,32,512,slots,offsets,pos);};
 auto candidate=[&](int r){fused_exact_paged<<<dim3(8,r),128,0,stream>>>(q,k,v,ids,got,blocks,32,512,slots,offsets,pos);};
 int checked=0;
 for(int state=0;state<6;state++){
  float scale=state==1?0.0001f:state==2?0.0625f:0.015625f;
  for(auto&x:hq)x=__float2bfloat16_rn(sample()*scale);for(auto&x:hk)x=__float2bfloat16_rn(sample()*scale);for(auto&x:hv)x=__float2bfloat16_rn(sample()*scale);
  CU(cudaMemcpy(q,hq.data(),hq.size()*2,cudaMemcpyHostToDevice));CU(cudaMemcpy(k,hk.data(),hk.size()*2,cudaMemcpyHostToDevice));CU(cudaMemcpy(v,hv.data(),hv.size()*2,cudaMemcpyHostToDevice));
  for(int t=24;t<=216;t++){for(int i=0;i<32;i++)hp[i]=state<3?t-1:23+(t-24+i*17)%193;CU(cudaMemcpy(pos,hp.data(),128,cudaMemcpyHostToDevice));
   for(int r=1;r<=32;r++){original(r);candidate(r);CU(cudaGetLastError());CU(cudaStreamSynchronize(stream));CU(cudaMemcpy(hb.data(),base,r*32*128*2,cudaMemcpyDeviceToHost));CU(cudaMemcpy(hg.data(),got,r*32*128*2,cudaMemcpyDeviceToHost));
    if(memcmp(hb.data(),hg.data(),r*32*128*2)){for(int j=0;j<r*32*128;j++)if(memcmp(&hb[j],&hg[j],2)){printf("MISMATCH state=%d T=%d R=%d index=%d expected=%04x got=%04x\n",state,t,r,j,*reinterpret_cast<uint16_t*>(&hb[j]),*reinterpret_cast<uint16_t*>(&hg[j]));return 4;}}
    checked++;
   }
  }printf("EXACT state=%d cumulative_combinations=%d\n",state,checked);fflush(stdout);
 }
 auto timing=[&](auto fn,int r){cudaGraph_t graph;cudaGraphExec_t exec;cudaStreamBeginCapture(stream,cudaStreamCaptureModeGlobal);for(int i=0;i<64;i++)fn(r);cudaStreamEndCapture(stream,&graph);cudaGraphInstantiate(&exec,graph,nullptr,nullptr,0);for(int i=0;i<4;i++)cudaGraphLaunch(exec,stream);cudaStreamSynchronize(stream);cudaEvent_t a,b;cudaEventCreate(&a);cudaEventCreate(&b);cudaEventRecord(a,stream);for(int i=0;i<8;i++)cudaGraphLaunch(exec,stream);cudaEventRecord(b,stream);cudaEventSynchronize(b);float ms=0;cudaEventElapsedTime(&ms,a,b);cudaEventDestroy(a);cudaEventDestroy(b);cudaGraphExecDestroy(exec);cudaGraphDestroy(graph);return ms*1000/(64*8);};
 for(int t:{128,129,144,159,192,213}){for(int r:{1,2,8,16,32}){for(int i=0;i<32;i++)hp[i]=t-1;CU(cudaMemcpy(pos,hp.data(),128,cudaMemcpyHostToDevice));for(int rep=0;rep<3;rep++){float a,b;if(rep%2){b=timing(candidate,r);a=timing(original,r);}else{a=timing(original,r);b=timing(candidate,r);}printf("TIMING T=%d R=%d rep=%d baseline_us=%.6f fused_us=%.6f\n",t,r,rep,a,b);fflush(stdout);}}}
 printf("COMPLETE exact_combinations=%d unchanged_BF16_QK_probability_PV=true\n",checked);CU(cudaGetLastError());for(auto p:{q,k,v,prob,base,got})CU(cudaFree(p));for(auto p:{ids,slots,offsets,pos})CU(cudaFree(p));CU(cudaStreamDestroy(stream));return 0;
}
'''
p=w/'research/fused-attention.cu';p.write_text(header);a=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-O3','-std=c++17','-arch=sm_80',str(p),'-o',str(w/'research/fused-attention')];(w/'research/fused-attention-build.argv.json').write_text(json.dumps(a));env=dict(os.environ,TMPDIR=str(w/'tmp'),CUDA_VISIBLE_DEVICES='')
with(w/'research/fused-attention-build.log').open('x')as f:r=subprocess.run(a,env=env,stdout=f,stderr=f)
assert r.returncode==0
