from pathlib import Path
import json,subprocess,os
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14c-20261021');s=(w/'research/hybrid-softpv.cu').read_text();t=(w/'research/softpv-split.cu').read_text();a=t.index('__global__ void evict_cache(');b=t.index('#define CU(x)',a);s=s.replace('#define CU(x)',t[a:b]+'#define CU(x)');s=s.replace(' int checked=0;',' uint4*flush;CU(cudaMalloc(&flush,64ul<<20));\n int checked=0;');a=t.index(' auto cold_timing=');b=t.index(' printf("COMPLETE H=',a);i=s.index(' printf("COMPLETE H=');s=s[:i]+t[a:b]+s[i:];p=w/'research/cold-hybrid.cu';p.write_text(s)
a=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-O3','-std=c++17','-arch=sm_80',str(p),'-o',str(w/'research/cold-hybrid')];(w/'research/cold-hybrid-build.argv.json').write_text(json.dumps(a));env=dict(os.environ,TMPDIR=str(w/'tmp'),CUDA_VISIBLE_DEVICES='')
with(w/'research/cold-hybrid-build.log').open('x')as f:p=subprocess.run(a,env=env,stdout=f,stderr=f)
assert p.returncode==0
r=w.parent/'riley-w0-a100-gpu67-20261019';env.update(CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'research/cold-hybrid-output'))
a=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','24-31','python3',str(w/'observe-finite.py'),'--out',str(w/'research/cold-hybrid-observed'),'--',str(w/'research/cold-hybrid')];(w/'research/cold-hybrid.argv.json').write_text(json.dumps(a))
with(w/'research/cold-hybrid.launch.log').open('x')as f:p=subprocess.run(a,env=env,stdout=f,stderr=f)
assert p.returncode==0
