from pathlib import Path
import subprocess,os,json,time
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14c-20261021');s=(w/'research/fused-softpv.cu').read_text();a=s.index('// Experimental single-CTA');b=s.index('#define CU(x)',a);f=s[a:b];f=f.replace('template<int HEADS> __global__ void fused_exact_softpv','template<int HEADS> __device__ __forceinline__ void fused_softpv_body');f=f.replace('const uint32_t*positions){','const uint32_t*positions,int head,__nv_bfloat16*stage,float*result,float*partial,__nv_bfloat16*probability){',1);f=f.replace('int tid=threadIdx.x,warp=tid/32,lane=tid%32,head=blockIdx.x*HEADS,kh=head/4;','int tid=threadIdx.x,warp=tid/32,lane=tid%32,kh=head/4;')
for line in [' __shared__ __align__(32) __nv_bfloat16 stage[4*512];\n',' __shared__ __align__(32) float result[4*256];\n',' __shared__ __align__(32) float partial[HEADS*128];\n',' __shared__ __align__(32) __nv_bfloat16 probability[HEADS*216];\n']:
 assert line in f;f=f.replace(line,'')
f+=r'''
__global__ void sm80_fused_softpv_dispatch(const __nv_bfloat16*scores,const __nv_bfloat16*v,const uint32_t*ids,__nv_bfloat16*out,uint64_t physical,uint64_t sequences,uint64_t id_count,const uint32_t*slots,const uint32_t*offsets,const uint32_t*positions){
 int t=positions[blockIdx.y]+1;if(t<24||t>216)return;
 __shared__ __align__(32) __nv_bfloat16 stage[4*512];
 __shared__ __align__(32) float result[4*256];
 __shared__ __align__(32) float partial[4*128];
 __shared__ __align__(32) __nv_bfloat16 probability[4*216];
 int head=blockIdx.x*2;
 if(t%8==0){if(blockIdx.x%2)return;fused_softpv_body<4>(scores,v,ids,out,physical,sequences,id_count,slots,offsets,positions,head,stage,result,partial,probability);}
 else{fused_softpv_body<2>(scores,v,ids,out,physical,sequences,id_count,slots,offsets,positions,head,stage,result,partial,probability);}
}
'''
(w/'research/hybrid-softpv.cuh').write_text(f);s=s[:a]+f+s[b:];a=s.index(' auto candidate=');b=s.index('\n int checked=',a);s=s[:a]+''' auto candidate=[&](int r){sm80_batched_qk_dispatch<<<dim3(27,8,r),128,0,stream>>>(q,k,ids,prob,blocks,32,512,slots,offsets,pos);sm80_fused_softpv_dispatch<<<dim3(16,r),128,0,stream>>>(prob,v,ids,got,blocks,32,512,slots,offsets,pos);};'''+s[b:];s=s.replace('for(int r:{1,2,8,16,32})','for(int r:{1,2,8,16,24,32})');p=w/'research/hybrid-softpv.cu';p.write_text(s)
a=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-O3','-std=c++17','-arch=sm_80',str(p),'-o',str(w/'research/hybrid-softpv')];(w/'research/hybrid-softpv-build.argv.json').write_text(json.dumps(a));env=dict(os.environ,TMPDIR=str(w/'tmp'),CUDA_VISIBLE_DEVICES='')
with(w/'research/hybrid-softpv-build.log').open('x')as f:r=subprocess.run(a,env=env,stdout=f,stderr=f)
assert r.returncode==0
end=time.monotonic()+1200
while json.loads((w/'final-c16.state.json').read_text())['status']=='running':
 assert time.monotonic()<end;time.sleep(2)
assert json.loads((w/'final-c16.state.json').read_text())['status']=='complete'
r=w.parent/'riley-w0-a100-gpu67-20261019';env.update(CUDA_VISIBLE_DEVICES='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'research/hybrid-softpv-output'))
a=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'research/hybrid-softpv-observed'),'--',str(w/'research/hybrid-softpv')];(w/'research/hybrid-softpv.argv.json').write_text(json.dumps(a))
with(w/'research/hybrid-softpv.launch.log').open('x')as f:p=subprocess.run(a,env=env,stdout=f,stderr=f)
assert p.returncode==0
