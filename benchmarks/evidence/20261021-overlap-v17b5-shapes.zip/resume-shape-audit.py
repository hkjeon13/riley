from pathlib import Path
import hashlib,json,time,subprocess,shutil,tarfile,difflib,traceback,re,zipfile
w=Path('/mnt/efs/nlp/psyche/riley-overlap-v17b5-shapes-20261021');b=w.parent/'riley-overlap-v17b5-20261021';r=w.parent/'riley-w0-a100-gpu67-20261019';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=dict(phase='waiting-b5',started_ns=time.time_ns())
def save():(w/'shape-state.json').write_text(json.dumps(s,indent=2))
def run(args,log):
 with(w/log).open('x')as f:q=subprocess.run(args,stdout=f,stderr=f)
 assert q.returncode==0,(args,q.returncode)
try:
 assert json.loads((w/'shape-state.json').read_text())['phase']=='failed'
 assert not(w/'runs/shapes-c16/result.json').exists()
 failure=w/'failed-first-attempt';failure.mkdir()
 for n in ['shape-state.json','shapes-c16.argv.json','shapes-c16.state.json','shapes-c16.log','shapes-c16.outer.log']:
  shutil.copy2(w/n,failure/n) if n=='shape-state.json' else shutil.move(str(w/n),str(failure/n))
 (failure/'runs').mkdir();shutil.move(str(w/'runs/shapes-c16'),str(failure/'runs/shapes-c16'))
 (w/'diagnostic-resume.json').write_text(json.dumps(dict(time_ns=time.time_ns(),reason='Missing holder.py dependency in diagnostic runner; original complete B5 normal/profile arms unchanged.',failed_artifacts=str(failure),binary_rebuilt=False,completed_timed_arms_excluded=0),indent=2))
 shutil.copy2(b/'holder.py',w/'holder.py');assert sha(b/'holder.py')==sha(w/'holder.py')
 script=(b/'audit-holders.py').read_text().replace('final-holder-audit.json','pre-resume-holder-audit.json');(w/'audit-pre-resume.py').write_text(script);run(['python3',str(w/'audit-pre-resume.py'),str(w)],'pre-resume-holder-audit.outer.log')
 manifest=json.loads((w/'source-manifest.json').read_text());assert len(manifest)==937 and all(sha(w/'source'/f)==h for f,h in manifest.items())
 binary=w/'riley-overlap-v17b5-shapes';assert sha(binary)=='00c25c46b2377681c92809b87d0cda90bdae7b9ab2f4bff70b9dff24bb29ee01'
 s.update(phase='resuming',resumed_ns=time.time_ns(),same_binary_sha256=sha(binary));save()
 for n in ['measure-matched.py','run-job.py','audit-complete.py']:shutil.copy2(b/n,w/n)
 for c in [16,32]:
  args=json.loads((b/f'final-c{c}.argv.json').read_text());args=[a.replace(str(b/'measure-matched.py'),str(w/'measure-matched.py'))for a in args]
  for flag,value in [('--out',str(w/f'runs/shapes-c{c}')),('--candidate-binary',str(binary)),('--repeats','1'),('--warm','64'),('--keep','64'),('--modes','owned-after'),('--repeat-start','0')]:args[args.index(flag)+1]=value
  name=f'shapes-c{c}';(w/(name+'.argv.json')).write_text(json.dumps(args,indent=2));s.update(phase='diagnosing',current=c);save();run(['python3',str(w/'run-job.py'),name],name+'.outer.log')
 run(['python3',str(w/'audit-complete.py'),'--partial'],'audit.outer.log');audit=json.loads((w/'audit-partial.json').read_text());assert len(audit['arms'])==2 and audit['total_full_SSE_values_verified']==218
 results=[]
 for c in [16,32]:
  p=w/f'runs/shapes-c{c}/c{c}-r0-owned-after/server.log';t=p.read_text();summaries=[tuple(map(int,m))for m in re.findall(r'RILEY_MIXED_AUDIT total=(\d+) canonical=(\d+) key_hits=(\d+) canonical_key_misses=(\d+)',t)];assert summaries and sum(x[0]for x in summaries)>0
  totals={k:sum(x[i]for x in summaries)for i,k in enumerate(['mixed_batches','canonical','key_hits','canonical_key_misses'])}
  hist={}
  for d,n,count in re.findall(r'RILEY_MIXED_REQUESTS decode=(\d+) prefill_requests=(\d+) count=(\d+)',t):hist[(int(d),int(n))]=hist.get((int(d),int(n)),0)+int(count)
  shapes={}
  for d,l,count,hits in re.findall(r'RILEY_MIXED_SINGLE decode=(\d+) prefill=(\d+) count=(\d+) key_hits=(\d+)',t):
   key=(int(d),int(l));x=shapes.setdefault(key,[0,0]);x[0]+=int(count);x[1]+=int(hits)
  assert sum(hist.values())==totals['mixed_batches'] and totals['key_hits']<=totals['canonical']
  results.append(dict(concurrency=c,totals=totals,multiple_prefill_batches=sum(v for(d,n),v in hist.items()if n>1),request_histogram=[dict(decode=d,prefill_requests=n,count=count)for(d,n),count in sorted(hist.items())],single_prefill_geometry=[dict(decode=d,prefill_tokens=l,count=count,key_hits=hits)for(d,l),(count,hits)in sorted(shapes.items())],log_sha256=sha(p),scope='Post-startup whole process including correctness/warmup; prefill_requests counts suffix request slots, not necessarily new requests. Instrumented timings excluded; not a normal192keep miss-reason counter.'))
 (w/'shape-summary.json').write_text(json.dumps(results,indent=2));assert all(sha(w/'source'/f)==h for f,h in manifest.items())
 text=(b/'audit-holders.py').read_text().replace('final-holder-audit.json','final-holder-audit.json');(w/'audit-holders.py').write_text(text);run(['python3',str(w/'audit-holders.py'),str(w)],'holder-audit.outer.log')
 s.update(phase='complete',skipped=False,finished_ns=time.time_ns());save()
 files=[];heavy={};skip={'source','target','tmp','cache','__pycache__'}
 for p in w.rglob('*'):
  if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
  with p.open('rb')as f:magic=f.read(4)
  if magic==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
  if p.suffix in ['.json','.jsonl','.log','.txt','.py','.sh','.patch','.exit','.sha256']:files.append(p)
 (w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2));files.append(w/'heavy-evidence-index.json');index={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in files}
 with zipfile.ZipFile(w/'evidence-archive.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in files:z.write(p,str(p.relative_to(w)))
  z.writestr('ARCHIVE-MANIFEST.json',json.dumps(index,indent=2))
 p=w/'evidence-archive.zip';(w/'evidence-archive-receipt.json').write_text(json.dumps(dict(bytes=p.stat().st_size,sha256=sha(p),entries=len(files)+1),indent=2))
except BaseException as e:s.update(phase="failed",error=repr(e),traceback=traceback.format_exc());save();raise
