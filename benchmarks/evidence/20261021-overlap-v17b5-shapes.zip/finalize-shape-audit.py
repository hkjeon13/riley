from pathlib import Path
import hashlib,json,time,subprocess,shutil,tarfile,difflib,traceback,re,zipfile
w=Path('/mnt/efs/nlp/psyche/riley-overlap-v17b5-shapes-20261021');b=w.parent/'riley-overlap-v17b5-20261021';r=w.parent/'riley-w0-a100-gpu67-20261019';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=dict(phase='waiting-b5',started_ns=time.time_ns())
def save():(w/'shape-state.json').write_text(json.dumps(s,indent=2))
def run(args,log):
 with(w/log).open('x')as f:q=subprocess.run(args,stdout=f,stderr=f)
 assert q.returncode==0,(args,q.returncode)
try:
 prior=json.loads((w/'shape-state.json').read_text());assert prior['phase']=='failed'
 assert not(w/'evidence-archive.zip').exists()
 shutil.copy2(w/'shape-state.json',w/'failed-audit-count-state.json')
 audit=json.loads((w/'audit-partial.json').read_text());assert len(audit['arms'])==2 and audit['total_full_SSE_values_verified']==224
 for arm in audit['arms']:
  path=w/'runs'/arm['run']/arm['arm'];assert len(json.loads((path/'recovery.json').read_text())['retries'])==3
  assert arm['record']['requests']==64 and arm['record']['correctness_requests']==45 and arm['full_SSE_values_verified']==112
  assert json.loads((w/(arm['run']+'.state.json')).read_text())['status']=='complete'
 assert sha(w/'audit-complete.py')==sha(b/'audit-complete.py')
 (w/'audit-count-correction.json').write_text(json.dumps(dict(time_ns=time.time_ns(),original_expected=218,correct_expected=224,reason='Original strict auditor includes three disconnect/recovery retry values per arm: 64 measured +45 correctness +3 recovery =112, times2. Both completed arms already passed all original oracle/SSE/resource assertions. No native criteria, values, source, or binary changed; no arm repeated/excluded.',original_auditor_unchanged=True,original_auditor_sha256=sha(w/'audit-complete.py')),indent=2))
 manifest=json.loads((w/'source-manifest.json').read_text());assert len(manifest)==937
 binary=w/'riley-overlap-v17b5-shapes';assert sha(binary)=='00c25c46b2377681c92809b87d0cda90bdae7b9ab2f4bff70b9dff24bb29ee01'
 s.update(phase='finalizing',same_binary_sha256=sha(binary),resolved_failures=['missing holder.py dependency','caller expected value omitted6 original recovery SSE values']);save()
 results=[]
 for c in [16,32]:
  p=w/f'runs/shapes-c{c}/c{c}-r0-owned-after/server.log';t=p.read_text();summaries=[tuple(map(int,m))for m in re.findall(r'RILEY_MIXED_AUDIT total=(\d+) canonical=(\d+) key_hits=(\d+) canonical_key_misses=(\d+)',t)];assert summaries and sum(x[0]for x in summaries)>0
  totals={k:sum(x[i]for x in summaries)for i,k in enumerate(['mixed_batches','canonical','key_hits','canonical_key_misses'])}
  hist={}
  for d,n,count in re.findall(r'RILEY_MIXED_REQUESTS decode=(\d+) prefill_requests=(\d+) count=(\d+)',t):hist[(int(d),int(n))]=hist.get((int(d),int(n)),0)+int(count)
  shapes={}
  for d,l,count,hits in re.findall(r'RILEY_MIXED_SINGLE decode=(\d+) prefill=(\d+) count=(\d+) key_hits=(\d+)',t):
   key=(int(d),int(l));x=shapes.setdefault(key,[0,0]);x[0]+=int(count);x[1]+=int(hits)
  assert sum(hist.values())==totals['mixed_batches'] and totals['key_hits']<=totals['canonical']
  results.append(dict(concurrency=c,totals=totals,multiple_prefill_batches=sum(v for(d,n),v in hist.items()if n>1),request_histogram=[dict(decode=d,prefill_requests=n,count=count)for(d,n),count in sorted(hist.items())],single_prefill_geometry=[dict(decode=d,prefill_tokens=l,count=count,key_hits=hits)for(d,l),(count,hits)in sorted(shapes.items())],log_sha256=sha(p),scope='Post-startup whole process including correctness/warmup; prefill_requests counts suffix request slots, not necessarily new requests. Instrumented timings excluded; not a normal192keep miss-reason counter.'))
 (w/'shape-summary.json').write_text(json.dumps(results,indent=2));assert all(sha(w/'source'/f)==h for f,h in manifest.items())
 text=(b/'audit-holders.py').read_text().replace('final-holder-audit.json','final-holder-audit.json');(w/'audit-holders.py').write_text(text);run(['python3',str(w/'audit-holders.py'),str(w)],'holder-audit.outer.log')
 s.update(phase='complete',skipped=False,finished_ns=time.time_ns());save()
 files=[];heavy={};skip={'source','target','tmp','cache','__pycache__'}
 for p in w.rglob('*'):
  if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
  with p.open('rb')as f:magic=f.read(4)
  if magic==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
  if p.suffix in ['.json','.jsonl','.log','.txt','.py','.sh','.patch','.exit','.sha256']:files.append(p)
 (w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2));files.append(w/'heavy-evidence-index.json');index={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in files}
 with zipfile.ZipFile(w/'evidence-archive.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in files:z.write(p,str(p.relative_to(w)))
  z.writestr('ARCHIVE-MANIFEST.json',json.dumps(index,indent=2))
 p=w/'evidence-archive.zip';(w/'evidence-archive-receipt.json').write_text(json.dumps(dict(bytes=p.stat().st_size,sha256=sha(p),entries=len(files)+1),indent=2))
except BaseException as e:s.update(phase="failed",error=repr(e),traceback=traceback.format_exc());save();raise
