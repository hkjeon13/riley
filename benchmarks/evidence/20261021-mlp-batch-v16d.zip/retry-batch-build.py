from pathlib import Path
import json,subprocess,hashlib,os,time,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16d-20261021');c=w.parent/'riley-mlp-prefill-v16c-20261021';e=w.parent/'riley-mlp-small-v16e-20261021';r=w.parent/'riley-w0-a100-gpu67-20261019';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=dict(phase='compile-recheck',started_ns=time.time_ns())
def save():(w/'component-r5-state.json').write_text(json.dumps(s,indent=2))
try:
 save();assert json.loads((c/'diagnostics-r5-state.json').read_text())['phase']=='complete';assert json.loads((e/'mixed-small-state.json').read_text())['phase']=='complete'
 source=w/'batch-merged-lt.cu';before=sha(source);binary=w/'batch-merged-lt-r2';env=dict(os.environ,CUDA_VISIBLE_DEVICES='',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'))
 cmd=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-std=c++17','-O3','-arch=sm_80',str(source),'-lcublas','-lcublasLt','-o',str(binary)];(w/'build-r2.argv.json').write_text(json.dumps(cmd,indent=2))
 with(w/'build-r2.log').open('x')as f:q=subprocess.run(cmd,stdout=f,stderr=f,env=env)
 s['compiler_returncode']=q.returncode;save();assert q.returncode==0,('compiler',q.returncode);assert sha(source)==before
 (w/'build-r2-proof.json').write_text(json.dumps(dict(source_sha256=before,source_unchanged_during_compile=True,binary_sha256=sha(binary),returncode=q.returncode,prior_empty_build_log_bytes=(w/'build.log').stat().st_size,prior_returncode_not_recorded=True),indent=2))
 x=w.parent/'riley-qkv-gateup-v214-20261019/v215-inputs/qwen4b-x.bf16';weight=c/'research2/merged-gate-up.bf16';down=c/'research2/down.bf16'
 (w/'input-proof-r2.json').write_text(json.dumps(dict(scope='Actual layer0 merged Gate/Up weights,6finite seed transforms; both original native balanced65..130 groups and original two pinned Lt21 references. Only two-Lt vs one-Lt timed; M131..160 research correctness, existing coalesced server baselineM>=161.',used_inputs={str(p):dict(bytes=p.stat().st_size,sha256=sha(p))for p in [x,weight]},unused_compatibility_argument=str(down),C_tensor_extraction_proof_sha256=sha(c/'research2/input-proof.json')),indent=2))
 env.update(CUDA_VISIBLE_DEVICES='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0',RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'component-r2-output'));env.pop('CUBLAS_WORKSPACE_CONFIG',None)
 cmd=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'observed-batch-merged-r2'),'--',str(binary),str(x),str(weight),str(down)];(w/'component-r2.argv.json').write_text(json.dumps(cmd,indent=2));s['phase']='component-references';save()
 with(w/'component-r2.launch.log').open('x')as f:q=subprocess.run(cmd,stdout=f,stderr=f,env=env)
 s['GPU_returncode']=q.returncode;save();assert q.returncode==0,('GPU',q.returncode)
 rows=[json.loads(l)for l in(w/'observed-batch-merged-r2.stdout').read_text().splitlines()if l.startswith('{')];assert len(rows)==2676 and all(x.get('mismatch')==0 for x in rows)
 s.update(phase='complete',finished_ns=time.time_ns(),cases=len(rows));save()
except BaseException as err:s.update(phase='failed',error=repr(err),finished_ns=time.time_ns(),traceback=traceback.format_exc());save();raise
