from pathlib import Path
import json,subprocess,time,traceback,os,hashlib,shutil
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16d-20261021');c=w.parent/'riley-mlp-prefill-v16c-20261021';r=w.parent/'riley-w0-a100-gpu67-20261019';s=dict(phase='waiting-C-diagnostics',started_ns=time.time_ns())
def save():(w/'component-state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 while True:
  p=c/'diagnostics-state.json';a=json.loads(p.read_text())if p.exists()else{}
  assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 s['phase']='building';save();shutil.copy2(c/'observe-finite.py',w/'observe-finite.py')
 cmd=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-std=c++17','-O3','-arch=sm_80',str(w/'batch-merged-lt.cu'),'-lcublas','-lcublasLt','-o',str(w/'batch-merged-lt')];(w/'build.argv.json').write_text(json.dumps(cmd))
 with(w/'build.log').open('x')as f:q=subprocess.run(cmd,stdout=f,stderr=f)
 assert q.returncode==0
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'));env.pop('CUBLAS_WORKSPACE_CONFIG',None);(w/'tmp').mkdir(exist_ok=True)
 x=w.parent/'riley-qkv-gateup-v214-20261019/v215-inputs/qwen4b-x.bf16';weight=c/'research2/merged-gate-up.bf16';down=c/'research2/down.bf16';cmd=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'observed-batch-merged'),'--',str(w/'batch-merged-lt'),str(x),str(weight),str(down)];(w/'component.argv.json').write_text(json.dumps(cmd,indent=2));s['phase']='running';save()
 with(w/'component.launch.log').open('x')as f:q=subprocess.run(cmd,stdout=f,stderr=f,env=env)
 assert q.returncode==0
 rows=[json.loads(l)for l in(w/'observed-batch-merged.stdout').read_text().splitlines()if l.startswith('{')];assert len(rows)==446*6 and all(x.get('mismatch')==0 for x in rows)
 sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(w/'input-proof.json').write_text(json.dumps(dict(scope='Actual layer0 weights; six transformed finite seed states; original two pinned Lt21 GEMMs vs merged Lt21. Server coalesced-preill baseline eligible at M>=161 only; M131..160 research only, not server qualification.',inputs={str(p):dict(bytes=p.stat().st_size,sha256=sha(p))for p in [x,weight,down]},baseline_C_input_proof_sha256=sha(c/'research2/input-proof.json'),cases=len(rows),timings=[v for v in rows if 'original_us'in v]),indent=2))
 s.update(phase='complete',finished_ns=time.time_ns(),cases=len(rows));save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
