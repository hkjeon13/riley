#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cublas_v2.h>
#include <cublasLt.h>
#include <vector>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <string>
using U=__nv_bfloat16;
#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"CUDA line%d %s\n",__LINE__,cudaGetErrorString(e));return 2;}}while(0)
#define BL(x) do{auto e=(x);if(e!=CUBLAS_STATUS_SUCCESS){fprintf(stderr,"BLAS line%d %d\n",__LINE__,int(e));return 3;}}while(0)
std::vector<U> read(const char*p){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error("input");size_t n=f.tellg();std::vector<U>b(n/2);f.seekg(0);f.read((char*)b.data(),n);if(!f)throw std::runtime_error("read");return b;}
float cv(U u){uint16_t v;memcpy(&v,&u,2);uint32_t z=uint32_t(v)<<16;float f;memcpy(&f,&z,4);return f;}
U bf(float f){uint32_t z;memcpy(&z,&f,4);uint16_t b=(z+0x7fff+((z>>16)&1))>>16;U x;memcpy(&x,&b,2);return x;}
__global__ void pack(const U*g,const U*u,U*out,int m){int i=blockIdx.x*256+threadIdx.x;if(i<m*19456){int row=i/19456,j=i%19456;out[i]=j<9728?g[row*9728+j]:u[row*9728+j-9728];}}
__global__ void cmp(const U*a,const U*b,int n,unsigned*p){int i=blockIdx.x*256+threadIdx.x;if(i<n&&__bfloat16_as_ushort(a[i])!=__bfloat16_as_ushort(b[i]))atomicAdd(p,1u);}
int main(int argc,char**argv){if(argc!=4)return 1;auto seed=read(argv[1]);cudaStream_t s;CU(cudaStreamCreate(&s));cublasHandle_t h;BL(cublasCreate(&h));BL(cublasSetStream(h,s));BL(cublasSetMathMode(h,CUBLAS_DEFAULT_MATH));BL(cublasSetAtomicsMode(h,CUBLAS_ATOMICS_NOT_ALLOWED));cublasLtHandle_t lt;BL(cublasLtCreate(&lt));auto alloc=[](size_t n){void*p;cudaMalloc(&p,n);return p;};void*ws=alloc(16ul<<20);unsigned*bad=(unsigned*)alloc(4);float alpha=1,beta=0;
 for(int op=0;op<1;op++){
  int n=op?2560:19456,k=op?9728:2560;auto weights=read(argv[op?3:2]);if(weights.size()!=size_t(n)*k)return 5;U*w=(U*)alloc(weights.size()*2),*x=(U*)alloc(576ul*k*2),*gold=(U*)alloc(576ul*n*2),*y=(U*)alloc(576ul*n*2),*g=(U*)alloc(576ul*9728*2),*u=(U*)alloc(576ul*9728*2);CU(cudaMemcpy(w,weights.data(),weights.size()*2,cudaMemcpyHostToDevice));
  cublasLtMatmulDesc_t desc;BL(cublasLtMatmulDescCreate(&desc,CUBLAS_COMPUTE_32F,CUDA_R_32F));cublasOperation_t trans=CUBLAS_OP_T;BL(cublasLtMatmulDescSetAttribute(desc,CUBLASLT_MATMUL_DESC_TRANSA,&trans,sizeof(trans)));cublasLtMatrixLayout_t A;BL(cublasLtMatrixLayoutCreate(&A,CUDA_R_16BF,k,n,k));cublasLtMatrixLayout_t Ag;BL(cublasLtMatrixLayoutCreate(&Ag,CUDA_R_16BF,k,9728,k));cublasLtMatmulAlgo_t algo;BL(cublasLtMatmulAlgoInit(lt,CUBLAS_COMPUTE_32F,CUDA_R_32F,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,op?6:21,&algo));uint32_t vals[]={op?24u:20u,op?15u:11u,op?5u:0u,op?4u:0u,op?1u:0u,0};int j=0;for(auto attr:{CUBLASLT_ALGO_CONFIG_TILE_ID,CUBLASLT_ALGO_CONFIG_STAGES_ID,CUBLASLT_ALGO_CONFIG_SPLITK_NUM,CUBLASLT_ALGO_CONFIG_REDUCTION_SCHEME,CUBLASLT_ALGO_CONFIG_CTA_SWIZZLING,CUBLASLT_ALGO_CONFIG_CUSTOM_OPTION})BL(cublasLtMatmulAlgoConfigSetAttribute(&algo,attr,&vals[j++],4));
  for(int m=131;m<=576;m++){
   cublasLtMatrixLayout_t B,C;BL(cublasLtMatrixLayoutCreate(&B,CUDA_R_16BF,k,m,k));BL(cublasLtMatrixLayoutCreate(&C,CUDA_R_16BF,n,m,n));cublasLtMatrixLayout_t Cg;BL(cublasLtMatrixLayoutCreate(&Cg,CUDA_R_16BF,9728,m,9728));cublasLtMatmulHeuristicResult_t ch{};auto status=cublasLtMatmulAlgoCheck(lt,desc,A,B,C,C,&algo,&ch);if(status||ch.state||ch.workspaceSize>(16ul<<20)){printf("{\"op\":%d,\"M\":%d,\"unsupported\":true}\n",op,m);continue;}
   for(int state=0;state<6;state++){
    std::vector<U>xx(size_t(m)*k);for(size_t i=0;i<xx.size();i++){float f=cv(seed[state==5?(i*13+37)%seed.size():i%seed.size()]);if(state==1)f*=8;if(state==2)f*=.0078125f;if(state==3&&i%7)f=0;if(state==4&&i%2)f=-f;if(state==5)f*=1.5f;xx[i]=bf(f);}CU(cudaMemcpy(x,xx.data(),xx.size()*2,cudaMemcpyHostToDevice));
    auto original=[&](){auto e=cublasLtMatmul(lt,desc,&alpha,w,Ag,x,B,&beta,g,Cg,g,Cg,&algo,ws,16ul<<20,s);if(e)return e;return cublasLtMatmul(lt,desc,&alpha,w+9728ul*k,Ag,x,B,&beta,u,Cg,u,Cg,&algo,ws,16ul<<20,s);};
    auto candidate=[&](){return cublasLtMatmul(lt,desc,&alpha,w,A,x,B,&beta,y,C,y,C,&algo,ws,16ul<<20,s);};
    BL(original());if(!op)pack<<<(m*n+255)/256,256,0,s>>>(g,u,gold,m);BL(candidate());CU(cudaMemsetAsync(bad,0,4,s));cmp<<<(m*n+255)/256,256,0,s>>>(gold,y,m*n,bad);
    // A second independent reference uses the original native65..130 groups,
    // not only the already coalesced Lt baseline. Keep timings on two Lt calls.
    int groups=(m+129)/130,offset=0;
    for(int group=0;group<groups;group++){int count=m/groups+(group<m%groups);if(count<65||count>130)return 7;
     BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,9728,count,k,&alpha,w,CUDA_R_16BF,k,x+size_t(offset)*k,CUDA_R_16BF,k,&beta,g+size_t(offset)*9728,CUDA_R_16BF,9728,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));
     BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,9728,count,k,&alpha,w+9728ul*k,CUDA_R_16BF,k,x+size_t(offset)*k,CUDA_R_16BF,k,&beta,u+size_t(offset)*9728,CUDA_R_16BF,9728,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));offset+=count;
    }
    pack<<<(m*n+255)/256,256,0,s>>>(g,u,gold,m);cmp<<<(m*n+255)/256,256,0,s>>>(gold,y,m*n,bad);unsigned count;CU(cudaMemcpyAsync(&count,bad,4,cudaMemcpyDeviceToHost,s));CU(cudaStreamSynchronize(s));printf("{\"op\":%d,\"M\":%d,\"state\":%d,\"mismatch\":%u",op,m,state,count);
    if(state==0&&(m==192||m==256||m==384||m==512||m==576)){float us[2];for(int z=0;z<2;z++){for(int q=0;q<3;q++)if(z)BL(candidate());else BL(original());cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaEventRecord(a,s));for(int q=0;q<64;q++)if(z)BL(candidate());else BL(original());CU(cudaEventRecord(b,s));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));us[z]=ms*1000/64;CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));}printf(",\"original_us\":%.3f,\"candidate_us\":%.3f",us[0],us[1]);}puts("}");fflush(stdout);
   }
   BL(cublasLtMatrixLayoutDestroy(Cg));BL(cublasLtMatrixLayoutDestroy(B));BL(cublasLtMatrixLayoutDestroy(C));
  }
  BL(cublasLtMatrixLayoutDestroy(Ag));BL(cublasLtMatrixLayoutDestroy(A));BL(cublasLtMatmulDescDestroy(desc));for(auto p:{w,x,gold,y,g,u})CU(cudaFree(p));
 }return 0;
}
