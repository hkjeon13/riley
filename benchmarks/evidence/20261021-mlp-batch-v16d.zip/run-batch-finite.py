from pathlib import Path
import json,time,os,subprocess,hashlib,shutil,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16d-20261021');c=w.parent/'riley-mlp-prefill-v16c-20261021';v=w.parent/'riley-prefill-host-v15c-20261021';r=w.parent/'riley-w0-a100-gpu67-20261019';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=dict(phase='observer-import-recheck',started_ns=time.time_ns())
def save():(w/'component-r6-state.json').write_text(json.dumps(s,indent=2))
try:
 save();shutil.copy2(v/'holder.py',w/'holder.py');proof=json.loads((w/'build-r2-proof.json').read_text());assert sha(w/'batch-merged-lt.cu')==proof['source_sha256'];binary=w/'batch-merged-lt-r2';assert sha(binary)==proof['binary_sha256'];assert sha(w/'observe-finite.py')=='c0aad9d71eab4071eefb1f94d809c17ced2652d571e662e2af16bab765097947'
 x=w.parent/'riley-qkv-gateup-v214-20261019/v215-inputs/qwen4b-x.bf16';weight=c/'research2/merged-gate-up.bf16';down=c/'research2/down.bf16';inputproof=json.loads((w/'input-proof-r2.json').read_text());assert all(sha(Path(p))==z['sha256']for p,z in inputproof['used_inputs'].items())
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'component-r3-output'));env.pop('CUBLAS_WORKSPACE_CONFIG',None)
 cmd=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'observed-batch-merged-r3'),'--',str(binary),str(x),str(weight),str(down)];(w/'component-r3.argv.json').write_text(json.dumps(cmd,indent=2));s['phase']='component-references';save()
 with(w/'component-r3.launch.log').open('x')as f:q=subprocess.run(cmd,stdout=f,stderr=f,env=env)
 s['returncode']=q.returncode;save();assert q.returncode==0
 rows=[json.loads(l)for l in(w/'observed-batch-merged-r3.stdout').read_text().splitlines()if l.startswith('{')];assert len(rows)==2676 and all(z.get('mismatch')==0 for z in rows)
 s.update(phase='complete',finished_ns=time.time_ns(),cases=len(rows));save()
except BaseException as err:s.update(phase='failed',error=repr(err),finished_ns=time.time_ns(),traceback=traceback.format_exc());save();raise
