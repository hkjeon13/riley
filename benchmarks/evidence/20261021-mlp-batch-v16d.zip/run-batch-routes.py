from pathlib import Path
import os,json,time,hashlib,subprocess,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16d-20261021');f=w.parent/'riley-mlp-batch-v16f-20261021';r=w.parent/'riley-w0-a100-gpu67-20261019';c=w.parent/'riley-mlp-prefill-v16c-20261021';s=dict(phase='waiting-F-accuracy',started_ns=time.time_ns());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(w/'routes-state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 while True:
  p=f/'accuracy-r3-state.json';a=json.loads(p.read_text())if p.exists()else{};assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 s['phase']='compiling';save();source=w/'batch-routes.cu';before=sha(source);binary=w/'batch-routes';env=dict(os.environ,CUDA_VISIBLE_DEVICES='',TMPDIR=str(w/'tmp'),LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64')
 cmd=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-std=c++17','-O3','-arch=sm_80',str(source),'-lcublas','-lcublasLt','-o',str(binary)];(w/'routes-build.argv.json').write_text(json.dumps(cmd,indent=2))
 with(w/'routes-build.log').open('x')as out:q=subprocess.run(cmd,stdout=out,stderr=out,env=env)
 s['compile_returncode']=q.returncode;save();assert q.returncode==0 and sha(source)==before
 (w/'routes-build-proof.json').write_text(json.dumps(dict(source_sha256=before,binary_sha256=sha(binary),baseline_selection='nativegroups below161; classic161..256 and513..576; Lt21 in257..512, from qualified v15C execute_row_groups_cached_from; vendor GEMM only, not Rust/Graph overhead',original_hf_reference_unchanged=True),indent=2))
 x=w.parent/'riley-qkv-gateup-v214-20261019/v215-inputs/qwen4b-x.bf16';weight=c/'research2/merged-gate-up.bf16';down=c/'research2/down.bf16';env.update(CUDA_VISIBLE_DEVICES='GPU-d9e89dc4-e4e2-00d2-8a22-9d696d5b9ff0',RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'routes-output'));env.pop('CUBLAS_WORKSPACE_CONFIG',None)
 cmd=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'observed-routes'),'--',str(binary),str(x),str(weight),str(down)];(w/'routes.argv.json').write_text(json.dumps(cmd,indent=2));s['phase']='running';save()
 with(w/'routes.launch.log').open('x')as out:q=subprocess.run(cmd,stdout=out,stderr=out,env=env)
 s['returncode']=q.returncode;save();assert q.returncode==0
 rows=[json.loads(l)for l in(w/'observed-routes.stdout').read_text().splitlines()if l.startswith('{')];assert len(rows)==2676 and all(v['mismatch']==0 for v in rows)
 (w/'routes-analysis.json').write_text(json.dumps(dict(scope='Native65..130 original-group byte equality remains required. Old merged-route mismatches are observational and never substitute a new HF reference. One CUDA-event screen eachM>=161.',cases=len(rows),native_all_zero=True,old_route_mismatches=[v for v in rows if v['old_route_mismatch']],timings=[dict(**v,percent_change=(v['candidate_us']/v['original_us']-1)*100)for v in rows if 'original_us'in v]),indent=2))
 s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as err:s.update(phase='failed',error=repr(err),finished_ns=time.time_ns(),traceback=traceback.format_exc());save();raise
