from pathlib import Path
import json,shutil,hashlib,zipfile,time
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16d-20261021');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert json.loads((w/'routes-state.json').read_text())['phase']=='complete';a=json.loads((w/'routes-analysis.json').read_text());assert a['native_all_zero']and not a['old_route_mismatches']and len(a['timings'])==416
p=w/'observed-routes.json';r=json.loads(p.read_text());assert r['status']=='complete'and r['returncode']==0;samples=[json.loads(l)for l in p.with_suffix('.samples.jsonl').read_text().splitlines()];assert max(x['device_memory_mib']for x in samples)<=22528
shutil.copy2(w/'component-audit.json',w/'initial-component-audit.json')
combined=dict(time_ns=time.time_ns(),runtime_adopted=False,selected_for_independent_model_qualification='v16G coalesced prefill merged Gate/Up',scope='Layer0 actual checkpoint weights and six transformed finite seed states. Vendor GEMM timing only, not Rust/Graph or server throughput. Existing dispatcher classic/Lt choice matched.',cases=2676,all_BF16_equal_to_original_native_groups_and_current_route=True,baseline_selection=dict(below161='original65..130 groups',from161to256='classic separate Gate/Up over coalesced rows',from257to512='two pinned Lt21 calls',from513to576='classic separate Gate/Up over coalesced rows'),timings=a['timings'],whole_device_peak_MiB=max(x['device_memory_mib']for x in samples),receipt_sha256=sha(p),initial_always_Lt21_comparator_is_not_actual_dispatch_for_every_M=True,original_accuracy_tolerance_unchanged=True)
(w/'component-audit.json').write_text(json.dumps(combined,indent=2));skip={'tmp','cache','__pycache__'};files=[];heavy={};allowed={'.json','.jsonl','.log','.txt','.py','.cu','.cuh','.sh','.stdout','.stderr'}
for p in w.rglob('*'):
 if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
 with p.open('rb')as f:magic=f.read(4)
 if magic==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
 if p.suffix in allowed and p.name not in ['heavy-evidence-index.json','routes-archive-receipt.json']:files.append(p)
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2));files.append(w/'heavy-evidence-index.json');manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)};z=w/'evidence-archive-routes.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
 for p in sorted(files):out.write(p,str(p.relative_to(w)))
 out.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
r=dict(archive=str(z),bytes=z.stat().st_size,entries=len(files)+1,sha256=sha(z));(w/'routes-archive-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
