from pathlib import Path
import subprocess,os,json,shutil,time
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16a-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';c=w.parent/'riley-prefill-host-v15c-20261021';w.mkdir(exist_ok=True)
for n in ['tmp','cache','research']:(w/n).mkdir(exist_ok=True)
for n in ['holder.py','observe-finite.py']:shutil.copy2(c/n,w/n)
state=dict(phase='compiling',started_ns=time.time_ns());p=w/'research-state.json'
def save():p.write_text(json.dumps(state,indent=2))
save()
try:
 env=dict(os.environ,TMPDIR=str(w/'tmp'),CUDA_VISIBLE_DEVICES='',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64')
 argv=['taskset','-c','48-51','/usr/local/cuda-12.4/bin/nvcc','-O3','-std=c++17','-arch=sm_80',str(w/'research/probe.cu'),'-o',str(w/'research/probe')]
 with(w/'research/build.log').open('x')as f:ret=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert ret.returncode==0,'compile failed'
 state['phase']='component-qualification';save()
 argv=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','7','run','--','taskset','-c','32-39','python3',str(w/'observe-finite.py'),'--out',str(w/'research/observed-probe'),'--timeout','900','--',str(w/'research/probe')]
 env.update(RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'research/probe-output'))
 (w/'research/argv.json').write_text(json.dumps(argv,indent=2))
 with(w/'research/run.log').open('x')as f:ret=subprocess.run(argv,env=env,stdout=f,stderr=f)
 assert ret.returncode==0,'component failed'
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e));save();raise
