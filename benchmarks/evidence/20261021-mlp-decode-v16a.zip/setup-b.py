from pathlib import Path
import shutil,json,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16b-20261021');c=w.parent/'riley-prefill-host-v15c-20261021';w.mkdir(exist_ok=False)
for n in ['tmp','cache','research','runs','ipc6','ipc7']:(w/n).mkdir()
shutil.copytree(c/'source',w/'source')
for n in ['build.sh','build-gpu-c.sh','recheck-c02.py','build-teacher-final.py','teacher-probe-final.rs','teacher-body.rs','teacher-mixed.rs','build-teacher-body.py','build-teacher-mixed.py','measure-matched.py','measure-profile.py','analyze-profiles.py','audit-complete.py','analyze-final.py','run-job.py','stock-runtime-proof.py','holder.py','observe-finite.py','audit-tail-b.py','pointer-inspection.cpp','analyze-profile-v15.py','attribute-graphs.py','audit-teachers-r2.py','audit-mixed-r2.py','queue-normal-analysis-c.py']:
 s=(c/n).read_text().replace(str(c),str(w)).replace('riley-prefill-host-v15c','riley-mlp-decode-v16b');(w/n).write_text(s)
for name in ['build-teacher-final.py','build-teacher-body.py','build-teacher-mixed.py']:
 p=w/name;s=p.read_text();start=s.index('from pathlib import Path',s.index('from pathlib import Path')+1)if s.count('from pathlib import Path')>1 else 0
 if start:s=s[start:]
 p.write_text(s)
for n in ['pointer-inspection.so','call-inspection-nvtx.so']:shutil.copy2(c/n,w/n)
for cc in [16,32]:
 a=json.loads((c/f'final-c{cc}.argv.json').read_text());a=[x.replace(str(c),str(w)).replace('riley-prefill-host-v15c','riley-mlp-decode-v16b')for x in a];a[a.index('--baseline-server')+1]=str(c/'riley-prefill-host-v15c');(w/f'final-c{cc}.argv.json').write_text(json.dumps(a,indent=2))
print(w)
