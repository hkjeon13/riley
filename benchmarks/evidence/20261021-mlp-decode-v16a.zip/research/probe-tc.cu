#include "probe-kernels.cuh"
#include "tc-chain.cuh"
#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"CUDA line%d %s\n",__LINE__,cudaGetErrorString(e));return 2;}}while(0)
__global__ void fill(U*p,size_t n,int st){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n){uint32_t z=uint32_t(i)*1664525u+1013904223u+st*1237;float v=float(int(z%2047)-1023)/32768.f;if(st%6==1)v*=8;if(st%6==2)v*=.0078125f;if(st%6==3)v=i%7?0:v;if(st%6==4)v=i%2?-v:v;if(st%6==5)v*=32;p[i]=__float2bfloat16_rn(v);}}
__global__ void cmp(const U*a,const U*b,size_t n,unsigned*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n&&__bfloat16_as_ushort(a[i])!=__bfloat16_as_ushort(b[i]))atomicAdd(p,1u);}
int main(){cudaStream_t stream;CU(cudaStreamCreate(&stream));auto alloc=[](size_t n){void*p;auto e=cudaMalloc(&p,n);if(e)throw std::runtime_error("alloc");return p;};U*wg=(U*)alloc(19456ul*2560*2),*wu=wg+9728ul*2560,*wd=(U*)alloc(2560ul*9728*2),*x=(U*)alloc(32ul*9728*2),*gold=(U*)alloc(32ul*9728*2),*y=(U*)alloc(32ul*9728*2);float*parts=(float*)alloc(32*32*1024*4);unsigned*bad=(unsigned*)alloc(4);
 for(int rows:{2,4,8,16,17,24,32})for(int st=0;st<6;st++){
  fill<<<(19456ul*2560+255)/256,256,0,stream>>>(wg,19456ul*2560,st);fill<<<(2560ul*9728+255)/256,256,0,stream>>>(wd,2560ul*9728,st+1);fill<<<(32ul*9728+255)/256,256,0,stream>>>(x,32ul*9728,st+2);
  auto run=[&](int op,int variant){
   if(op==0){if(!variant){if(rows<=16)sm80_fused_gateup<4,16,16,2><<<304,128,0,stream>>>(wg,wu,x,y,rows);else sm80_fused_gateup<4,32,8,2><<<304,128,0,stream>>>(wg,wu,x,y,rows);}
    else if(variant==1){if(rows<=16)v16_gateup<4,16,16,2,128><<<304,128,46080,stream>>>(wg,wu,x,y,rows);else v16_gateup<4,32,8,2,128><<<304,128,52224,stream>>>(wg,wu,x,y,rows);}
    else{if(rows<=16)v16_gateup<4,16,16,2,256><<<304,128,87040,stream>>>(wg,wu,x,y,rows);else v16_gateup<4,32,8,2,256><<<304,128,101376,stream>>>(wg,wu,x,y,rows);}}
   else if(op==1){if(!variant){if(rows<=16)sm80_v9_down<8,16,8,4><<<dim3(20,1,4),256,0,stream>>>(wd,x,parts,rows);else sm80_v9_down<4,32,16,4><<<dim3(40,1,4),128,0,stream>>>(wd,x,parts,rows);}
    else if(variant==1)v16_down<2,16,8,2,128><<<dim3(80,(rows+15)/16,4),64,0,stream>>>(wd,x,parts,rows);
    else v16_down<4,16,8,2,64><<<dim3(40,(rows+15)/16,4),128,0,stream>>>(wd,x,parts,rows);
    sm80_v9_down_reduce<<<(rows*2560+255)/256,256,0,stream>>>(parts,y,rows*2560);}
   else{if(!variant){if(rows<=12)owned_sm80_tiled_kv<8,4><<<dim3(128,(rows+3)/4),dim3(32,8),0,stream>>>((uint16_t*)wg,(uint16_t*)x,(uint16_t*)y,rows);else if(rows<=23)owned_sm80_tiled_kv<4,8><<<dim3(256,(rows+7)/8),dim3(32,4),0,stream>>>((uint16_t*)wg,(uint16_t*)x,(uint16_t*)y,rows);else owned_sm80_tiled_kv<8,8><<<dim3(128,(rows+7)/8),dim3(32,8),0,stream>>>((uint16_t*)wg,(uint16_t*)x,(uint16_t*)y,rows);}
    else {v16_tc_kv<<<dim3(16,(rows+7)/8,32),128,0,stream>>>(wg,x,parts,rows);v16_tc_kv_reduce<<<(rows*1024+7)/8,256,0,stream>>>(parts,y,rows);}}
  };
  CU(cudaFuncSetAttribute(v16_gateup<4,32,8,2,128>,cudaFuncAttributeMaxDynamicSharedMemorySize,52224));CU(cudaFuncSetAttribute(v16_gateup<4,16,16,2,128>,cudaFuncAttributeMaxDynamicSharedMemorySize,46080));CU(cudaFuncSetAttribute(v16_gateup<4,32,8,2,256>,cudaFuncAttributeMaxDynamicSharedMemorySize,101376));CU(cudaFuncSetAttribute(v16_gateup<4,16,16,2,256>,cudaFuncAttributeMaxDynamicSharedMemorySize,87040));
  for(int op=2;op<3;op++){
   size_t n=rows*(op==0?9728:op==1?2560:1024);run(op,0);CU(cudaMemcpyAsync(gold,y,n*2,cudaMemcpyDeviceToDevice,stream));
   for(int v=1;v<=(op==2?1:2);v++){run(op,v);CU(cudaMemsetAsync(bad,0,4,stream));cmp<<<(n+255)/256,256,0,stream>>>(gold,y,n,bad);unsigned count;CU(cudaMemcpyAsync(&count,bad,4,cudaMemcpyDeviceToHost,stream));CU(cudaStreamSynchronize(stream));printf("{\"rows\":%d,\"state\":%d,\"op\":%d,\"variant\":%d,\"mismatch\":%u",rows,st,op,v,count);if(count){puts("");return 4;}
    if(st==0){float us[2];for(int z=0;z<2;z++){cudaGraph_t graph;cudaGraphExec_t exe;CU(cudaStreamBeginCapture(stream,cudaStreamCaptureModeThreadLocal));for(int i=0;i<32;i++)run(op,z?v:0);CU(cudaStreamEndCapture(stream,&graph));CU(cudaGraphInstantiate(&exe,graph,0));for(int i=0;i<3;i++)CU(cudaGraphLaunch(exe,stream));cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaEventRecord(a,stream));for(int i=0;i<8;i++)CU(cudaGraphLaunch(exe,stream));CU(cudaEventRecord(b,stream));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));us[z]=ms*1000/256;CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));CU(cudaGraphExecDestroy(exe));CU(cudaGraphDestroy(graph));}printf(",\"old_us\":%.3f,\"new_us\":%.3f",us[0],us[1]);}
    puts("}");fflush(stdout);
   }
  }
 }
 return 0;
}
