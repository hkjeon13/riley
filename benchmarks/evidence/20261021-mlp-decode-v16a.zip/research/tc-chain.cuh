// Research: zero-inserted TF32 MMA over exactly representable BF16 inputs.
// Each instruction contributes one product to one original FP32 chain.
__device__ __forceinline__ void v16_one_product(float (&c)[4],float a0,float a1,float b){
 asm volatile("mma.sync.aligned.m16n8k4.row.col.f32.tf32.tf32.f32 {%0,%1,%2,%3}, {%4,%5}, {%6}, {%0,%1,%2,%3};"
  : "+f"(c[0]),"+f"(c[1]),"+f"(c[2]),"+f"(c[3]):"r"(__float_as_uint(a0)),"r"(__float_as_uint(a1)),"r"(__float_as_uint(b)));
}
__global__ void v16_tc_kv(const U*w,const U*x,float*parts,int rows){
 int lane=threadIdx.x%32,warp=threadIdx.x/32,gr=lane/4,quad=lane%4,col=(blockIdx.x*4+warp)*16,first=blockIdx.y*8,chain=blockIdx.z;float c[4]={};
 for(int it=0;it<80;it++){int k=it*32+chain;float a=quad==0?__bfloat162float(w[(col+gr)*2560+k]):0.f;float d=quad==0?__bfloat162float(w[(col+gr+8)*2560+k]):0.f;float b=quad==0&&first+gr<rows?__bfloat162float(x[(first+gr)*2560+k]):0.f;v16_one_product(c,a,d,b);}
 #pragma unroll
 for(int i=0;i<4;i++){int row=first+quad*2+(i&1),outcol=col+gr+(i>=2?8:0);if(row<rows)parts[(chain*rows+row)*1024+outcol]=c[i];}
}
__global__ void v16_tc_kv_reduce(const float*p,U*y,int rows){
 int lane=threadIdx.x%32,index=(blockIdx.x*8+threadIdx.x/32),n=rows*1024;if(index>=n)return;float a=p[lane*n+index];
 for(int d=16;d;d/=2){float b=__shfl_down_sync(0xffffffff,a,d);if(lane<d)a=__fadd_rn(a,b);}
 if(lane==0)y[index]=__float2bfloat16_rn(__fmaf_rn(1.f,a,0.f));
}
