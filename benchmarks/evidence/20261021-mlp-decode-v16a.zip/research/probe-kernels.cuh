#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <mma.h>
#include <vector>
#include <cstdio>
#include <algorithm>
#include <stdexcept>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
using U=__nv_bfloat16;
__device__ __forceinline__ void sm80_down_copy16(void*dst,const void*src,bool valid){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
unsigned sm=static_cast<unsigned>(__cvta_generic_to_shared(dst));asm volatile("cp.async.cg.shared.global [%0], [%1], 16, %2;"::"r"(sm),"l"(src),"r"(valid?16:0));
#endif
}
template<int W,int R,int P,int S>__device__ __forceinline__ void sm80_v9_down_stage(__nv_bfloat16*dst,const __nv_bfloat16*w,const __nv_bfloat16*x,int rows,int col,int first,int part,int it){
 constexpr int N=W*16,L=32+P;int kbase=(part/2)*4864+(part%2)*32+it*64;
 for(int i=threadIdx.x;i<(N+R)*4;i+=W*32){int row=i/4,k=(i%4)*8;bool a=row<N;int xr=row-N;bool valid=it<76&&(a||first+xr<rows);const __nv_bfloat16*src=valid?(a?w+(col+row)*9728+kbase+k:x+(first+xr)*9728+kbase+k):w;sm80_down_copy16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void sm80_v9_down(const __nv_bfloat16*w,const __nv_bfloat16*x,float*parts,int rows){
 #if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=32+P,Stage=(N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];int col=blockIdx.x*N,first=blockIdx.y*R,part=blockIdx.z,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB];
 #pragma unroll
 for(int rb=0;rb<RB;rb++)wmma::fill_fragment(c[rb],0.f);
 #pragma unroll
 for(int st=0;st<S;st++)sm80_v9_down_stage<W,R,P,S>(shared+st*Stage,w,x,rows,col,first,part,st);
 for(int it=0;it<76;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+(it%S)*Stage;
 #pragma unroll
 for(int j=0;j<2;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb],a,b,c[rb]);}}
 __syncthreads();sm80_v9_down_stage<W,R,P,S>(t,w,x,rows,col,first,part,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){float*out=reinterpret_cast<float*>(shared)+(warp*RB+rb)*256;wmma::store_matrix_sync(out,c[rb],16,wmma::mem_col_major);__syncwarp();for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows)parts[(part*rows+row)*2560+col+warp*16+i%16]=out[i];}}
#endif
}
__global__ void sm80_v9_down_reduce(const float*p,__nv_bfloat16*y,int n){int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n){float a=__bfloat162float(__float2bfloat16_rn(__fadd_rn(p[i],p[n+i])));float b=__bfloat162float(__float2bfloat16_rn(__fadd_rn(p[2*n+i],p[3*n+i])));y[i]=__float2bfloat16_rn(__fadd_rn(a,b));}}

template<int W,int R,int P,int S>__device__ __forceinline__ void gateup_stage(__nv_bfloat16*dst,const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,int rows,int col,int first,int it){
 constexpr int N=W*16,L=64+P;for(int i=threadIdx.x;i<(N+R)*8;i+=W*32){int row=i/8,k=i%8*8;bool weight=row<N,valid=it<40&&(weight||first+row-N<rows);const __nv_bfloat16*src=wg;if(valid)src=weight?((row<N/2?wg:wu)+(col+row%(N/2))*2560+it*64+k):(x+(first+row-N)*2560+it*64+k);sm80_down_copy16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void sm80_fused_gateup(const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,__nv_bfloat16*y,int rows){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=64+P,Stage=(N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];auto results=reinterpret_cast<float (*)[RB][256]>(shared);int col=blockIdx.x*(N/2),first=blockIdx.y*R,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB][2];
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::fill_fragment(c[rb][0],0.f);wmma::fill_fragment(c[rb][1],0.f);}
 #pragma unroll
 for(int st=0;st<S;st++)gateup_stage<W,R,P,S>(shared+st*Stage,wg,wu,x,rows,col,first,st);
 for(int it=0;it<40;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+it%S*Stage;
 #pragma unroll
 for(int j=0;j<4;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb][j/2],a,b,c[rb][j/2]);}}
 __syncthreads();gateup_stage<W,R,P,S>(t,wg,wu,x,rows,col,first,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){for(int i=0;i<c[rb][0].num_elements;i++)c[rb][0].x[i]=__fadd_rn(c[rb][0].x[i],c[rb][1].x[i]);wmma::store_matrix_sync(results[warp][rb],c[rb][0],16,wmma::mem_col_major);}
 __syncthreads();if(warp<W/2){
 #pragma unroll
 for(int rb=0;rb<RB;rb++)for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows){float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp][rb][i],0.f)));float u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp+W/2][rb][i],0.f)));float activated=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[row*9728+col+warp*16+i%16]=__float2bfloat16_rn(__fmul_rn(activated,u));}}}
#endif
}

template<int W,int R,int P,int S,int K>__device__ __forceinline__ void v16_gate_stage(__nv_bfloat16*dst,const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,int rows,int col,int first,int it){
 constexpr int N=W*16,L=K+P;for(int i=threadIdx.x;i<(N+R)*(K/8);i+=W*32){int row=i/(K/8),k=i%(K/8)*8;bool weight=row<N,valid=it<2560/K&&(weight||first+row-N<rows);const __nv_bfloat16*src=wg;if(valid)src=weight?((row<N/2?wg:wu)+(col+row%(N/2))*2560+it*K+k):(x+(first+row-N)*2560+it*K+k);sm80_down_copy16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S,int K>__global__ void v16_gateup(const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,__nv_bfloat16*y,int rows){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=K+P,Stage=(N+R)*L,RB=R/16;extern __shared__ __align__(32)__nv_bfloat16 shared[];auto results=reinterpret_cast<float (*)[RB][256]>(shared);int col=blockIdx.x*(N/2),first=blockIdx.y*R,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB][2];
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::fill_fragment(c[rb][0],0.f);wmma::fill_fragment(c[rb][1],0.f);}
 #pragma unroll
 for(int st=0;st<S;st++)v16_gate_stage<W,R,P,S,K>(shared+st*Stage,wg,wu,x,rows,col,first,st);
 for(int it=0;it<2560/K;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+it%S*Stage;
 #pragma unroll
 for(int j=0;j<K/16;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb][(j/2)%2],a,b,c[rb][(j/2)%2]);}}
 __syncthreads();v16_gate_stage<W,R,P,S,K>(t,wg,wu,x,rows,col,first,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){for(int i=0;i<c[rb][0].num_elements;i++)c[rb][0].x[i]=__fadd_rn(c[rb][0].x[i],c[rb][1].x[i]);wmma::store_matrix_sync(results[warp][rb],c[rb][0],16,wmma::mem_col_major);}
 __syncthreads();if(warp<W/2){
 #pragma unroll
 for(int rb=0;rb<RB;rb++)for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows){float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp][rb][i],0.f)));float u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp+W/2][rb][i],0.f)));float activated=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[row*9728+col+warp*16+i%16]=__float2bfloat16_rn(__fmul_rn(activated,u));}}}
#endif
}

template<int W,int R,int P,int S,int K>__device__ __forceinline__ void v16_down_stage(__nv_bfloat16*dst,const __nv_bfloat16*w,const __nv_bfloat16*x,int rows,int col,int first,int part,int it){
 constexpr int N=W*16,L=K+P;int kbase=(part/2)*4864+(part%2)*32+it*(K*2);
 for(int i=threadIdx.x;i<(N+R)*(K/8);i+=W*32){int row=i/(K/8),k=(i%(K/8))*8;bool a=row<N;int xr=row-N;bool valid=it<2432/K&&(a||first+xr<rows);const __nv_bfloat16*src=valid?(a?w+(col+row)*9728+kbase+(k/32)*64+k%32:x+(first+xr)*9728+kbase+(k/32)*64+k%32):w;sm80_down_copy16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S,int K>__global__ void v16_down(const __nv_bfloat16*w,const __nv_bfloat16*x,float*parts,int rows){
 #if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=K+P,Stage=(N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];int col=blockIdx.x*N,first=blockIdx.y*R,part=blockIdx.z,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB];
 #pragma unroll
 for(int rb=0;rb<RB;rb++)wmma::fill_fragment(c[rb],0.f);
 #pragma unroll
 for(int st=0;st<S;st++)v16_down_stage<W,R,P,S,K>(shared+st*Stage,w,x,rows,col,first,part,st);
 for(int it=0;it<2432/K;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+(it%S)*Stage;
 #pragma unroll
 for(int j=0;j<K/16;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb],a,b,c[rb]);}}
 __syncthreads();v16_down_stage<W,R,P,S,K>(t,w,x,rows,col,first,part,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){float*out=reinterpret_cast<float*>(shared)+(warp*RB+rb)*256;wmma::store_matrix_sync(out,c[rb],16,wmma::mem_col_major);__syncwarp();for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows)parts[(part*rows+row)*2560+col+warp*16+i%16]=out[i];}}
#endif
}
template<int R>__global__ void owned_sm80_native_kv_rows(const uint16_t*__restrict__ w,const uint16_t*__restrict__ x,uint16_t*y,int rows){
 int lane=threadIdx.x,col=blockIdx.x*4+threadIdx.y,first=blockIdx.y*R;float a[R]={};
 #pragma unroll 16
 for(int j=0;j<80;j++){int k=lane+j*32;float ww=__bfloat162float(__ushort_as_bfloat16(w[col*2560+k]));
  #pragma unroll
  for(int r=0;r<R;r++)if(first+r<rows)a[r]=__fmaf_rn(ww,__bfloat162float(__ushort_as_bfloat16(x[(first+r)*2560+k])),a[r]);
 }
 #pragma unroll
 for(int d=16;d;d/=2){
  #pragma unroll
  for(int r=0;r<R;r++){float other=__shfl_down_sync(0xffffffffu,a[r],d);if(lane<d)a[r]=__fadd_rn(a[r],other);}
 }
 if(lane==0){
  #pragma unroll
  for(int r=0;r<R;r++)if(first+r<rows)y[(first+r)*1024+col]=__bfloat16_as_ushort(__float2bfloat16_rn(__fmaf_rn(1.f,a[r],0.f)));
 }
}

__device__ __forceinline__ void owned_sm80_kv_copy16(void*dst,const void*src,bool valid){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 unsigned sm=static_cast<unsigned>(__cvta_generic_to_shared(dst));asm volatile("cp.async.cg.shared.global [%0], [%1], 16, %2;"::"r"(sm),"l"(src),"r"(valid?16:0));
#else
 if(valid)*reinterpret_cast<uint4*>(dst)=*reinterpret_cast<const uint4*>(src);
#endif
}
template<int C,int R>__device__ __forceinline__ void owned_sm80_kv_stage(uint16_t*dst,const uint16_t*w,const uint16_t*x,int rows,int first,int col,int it){for(int i=threadIdx.x+32*threadIdx.y;i<(C+R)*32;i+=C*32){int r=i/32,k=i%32*8;bool valid=it<10&&(r<C||first+r-C<rows);const uint16_t*src=valid?(r<C?w+(col+r)*2560+it*256+k:x+(first+r-C)*2560+it*256+k):w;owned_sm80_kv_copy16(dst+r*256+k,src,valid);}
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 asm volatile("cp.async.commit_group;");
#endif
}
template<int C,int R>__global__ void owned_sm80_tiled_kv(const uint16_t*w,const uint16_t*x,uint16_t*y,int rows){

#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 constexpr int Stage=(C+R)*256;__shared__ __align__(32)uint16_t sh[Stage*2];int lane=threadIdx.x,col=blockIdx.x*C+threadIdx.y,first=blockIdx.y*R;float a[R]={};owned_sm80_kv_stage<C,R>(sh,w,x,rows,first,blockIdx.x*C,0);owned_sm80_kv_stage<C,R>(sh+Stage,w,x,rows,first,blockIdx.x*C,1);
 for(int it=0;it<10;it++){asm volatile("cp.async.wait_group 1;");__syncthreads();auto*t=sh+it%2*Stage;
 #pragma unroll
 for(int j=0;j<8;j++){int d=lane+j*32;float ww=__bfloat162float(__ushort_as_bfloat16(t[threadIdx.y*256+d]));
 #pragma unroll
 for(int r=0;r<R;r++)if(first+r<rows)a[r]=__fmaf_rn(ww,__bfloat162float(__ushort_as_bfloat16(t[(C+r)*256+d])),a[r]);}
 __syncthreads();owned_sm80_kv_stage<C,R>(t,w,x,rows,first,blockIdx.x*C,it+2);}
 asm volatile("cp.async.wait_group 0;");
 #pragma unroll
 for(int d=16;d;d/=2){
 #pragma unroll
 for(int r=0;r<R;r++){float b=__shfl_down_sync(0xffffffff,a[r],d);if(lane<d)a[r]=__fadd_rn(a[r],b);}}
 if(lane==0){
 #pragma unroll
 for(int r=0;r<R;r++)if(first+r<rows)y[(first+r)*1024+col]=__bfloat16_as_ushort(__float2bfloat16_rn(__fmaf_rn(1.f,a[r],0.f)));}
#endif

}


// Independent rows occupy lane groups, not a serial per-thread row loop.
// Four FP32 registers retain each original K32 chain and its reduction tree.
__global__ void v16_kv(const U*w,const U*x,U*y,int rows){
 int lane=threadIdx.x%32,warp=threadIdx.x/32,r=blockIdx.y*4+lane/8,col=blockIdx.x*8+warp,c=lane%8;float a[4]={};
 for(int it=0;it<80;it++){
  #pragma unroll
  for(int z=0;z<4;z++){int k=it*32+c+z*8;float weight=lane<8?__bfloat162float(w[col*2560+k]):0.f;weight=__shfl_sync(0xffffffff,weight,c);if(r<rows)a[z]=__fmaf_rn(weight,__bfloat162float(x[r*2560+k]),a[z]);}
 }
 float val=__fadd_rn(__fadd_rn(a[0],a[2]),__fadd_rn(a[1],a[3]));
 for(int d=4;d;d/=2){float b=__shfl_down_sync(0xffffffff,val,d,8);if(c<d)val=__fadd_rn(val,b);}
 if(c==0&&r<rows)y[r*1024+col]=__float2bfloat16_rn(__fmaf_rn(1.f,val,0.f));
}
