__global__ void v16_transpose(const U*w,U*p){int i=blockIdx.x*256+threadIdx.x;if(i<1024*2560)p[(i%2560)*1024+i/2560]=w[i];}
template<int R>__global__ void v16_transposed_kv(const U*w,const U*x,U*y,int rows){
 int col=blockIdx.x*32+threadIdx.x,lane=threadIdx.y,first=blockIdx.y*R;float acc[R][4]={};
 for(int it=0;it<80;it++){
  #pragma unroll
  for(int z=0;z<4;z++){int k=it*32+lane+z*8;float a=__bfloat162float(w[k*1024+col]);
   #pragma unroll
   for(int r=0;r<R;r++)if(first+r<rows)acc[r][z]=__fmaf_rn(a,__bfloat162float(x[(first+r)*2560+k]),acc[r][z]);
  }
 }
 __shared__ float p[8][R][32];
 #pragma unroll
 for(int r=0;r<R;r++)p[lane][r][threadIdx.x]=__fadd_rn(__fadd_rn(acc[r][0],acc[r][2]),__fadd_rn(acc[r][1],acc[r][3]));
 __syncthreads();if(lane==0){
  #pragma unroll
  for(int r=0;r<R;r++)if(first+r<rows){float a[4];
   #pragma unroll
   for(int j=0;j<4;j++)a[j]=__fadd_rn(p[j][r][threadIdx.x],p[j+4][r][threadIdx.x]);
   float sum=__fadd_rn(__fadd_rn(a[0],a[2]),__fadd_rn(a[1],a[3]));y[(first+r)*1024+col]=__float2bfloat16_rn(__fmaf_rn(1.f,sum,0.f));}
 }
}
