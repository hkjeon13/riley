#include "probe-kernels.cuh"
#include "row-specialized.cuh"
#include <cublas_v2.h>
#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"cuda line%d %s\n",__LINE__,cudaGetErrorString(e));return 2;}}while(0)
#define BL(x) do{if((x)!=CUBLAS_STATUS_SUCCESS)return 3;}while(0)
__global__ void fill(U*p,size_t n,int st){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n){uint32_t z=uint32_t(i)*1664525u+1013904223u+st*1237;float v=float(int(z%4093)-2046)/32768.f;if(st%6==1)v*=8;if(st%6==2)v*=.0078125f;if(st%6==3)v=i%7?0:v;if(st%6==4)v=i%2?-v:v;if(st%6==5)v*=32;p[i]=__float2bfloat16_rn(v);}}
__global__ void epilogue(const U*g,const U*u,U*y,int n){int i=blockIdx.x*256+threadIdx.x;if(i<n){float a=__bfloat162float(g[i]),b=__bfloat162float(u[i]);float z=__bfloat162float(__float2bfloat16_rn(a/(1.f+expf(-a))));y[i]=__float2bfloat16_rn(__fmul_rn(z,b));}}
__global__ void cmp(const U*a,const U*b,size_t n,unsigned*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n&&__bfloat16_as_ushort(a[i])!=__bfloat16_as_ushort(b[i]))atomicAdd(p,1u);}
int main(){cudaStream_t stream;CU(cudaStreamCreate(&stream));cublasHandle_t h;BL(cublasCreate(&h));BL(cublasSetStream(h,stream));BL(cublasSetMathMode(h,CUBLAS_DEFAULT_MATH));BL(cublasSetAtomicsMode(h,CUBLAS_ATOMICS_NOT_ALLOWED));auto alloc=[](size_t n){void*p;cudaMalloc(&p,n);return p;};U*w=(U*)alloc(19456ul*2560*2),*x=(U*)alloc(160ul*2560*2),*g=(U*)alloc(160ul*9728*2),*u=(U*)alloc(160ul*9728*2),*gold=(U*)alloc(160ul*9728*2),*y=(U*)alloc(160ul*9728*2);unsigned*bad=(unsigned*)alloc(4);float alpha=1,beta=0;
 CU(cudaFuncSetAttribute(v16_row_gateup<10,1>,cudaFuncAttributeMaxDynamicSharedMemorySize,61440));CU(cudaFuncSetAttribute(v16_row_gateup<10,2>,cudaFuncAttributeMaxDynamicSharedMemorySize,61440));CU(cudaFuncSetAttribute(v16_row_gateup<10,4>,cudaFuncAttributeMaxDynamicSharedMemorySize,61440));
 for(int m:{16,64,115,128,129,130,144,160})for(int state=0;state<6;state++){
 fill<<<(19456ul*2560+255)/256,256,0,stream>>>(w,19456ul*2560,state);fill<<<(160ul*2560+255)/256,256,0,stream>>>(x,160ul*2560,state+2);
 BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,9728,m,2560,&alpha,w,CUDA_R_16BF,2560,x,CUDA_R_16BF,2560,&beta,g,CUDA_R_16BF,9728,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,9728,m,2560,&alpha,w+9728ul*2560,CUDA_R_16BF,2560,x,CUDA_R_16BF,2560,&beta,u,CUDA_R_16BF,9728,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));epilogue<<<(m*9728+255)/256,256,0,stream>>>(g,u,gold,m*9728);
 for(int family:{1,2,4}){if(family==1)v16_row_gateup<10,1><<<608,640,61440,stream>>>(w,w+9728ul*2560,x,y,m,0);else if(family==2)v16_row_gateup<10,2><<<608,640,61440,stream>>>(w,w+9728ul*2560,x,y,m,0);else v16_row_gateup<10,4><<<608,640,61440,stream>>>(w,w+9728ul*2560,x,y,m,0);CU(cudaMemsetAsync(bad,0,4,stream));cmp<<<(m*9728+255)/256,256,0,stream>>>(gold,y,m*9728,bad);unsigned count;CU(cudaMemcpyAsync(&count,bad,4,cudaMemcpyDeviceToHost,stream));CU(cudaStreamSynchronize(stream));printf("{\"M\":%d,\"state\":%d,\"family\":%d,\"mismatch\":%u}\n",m,state,family,count);fflush(stdout);}
 }return 0;
}
