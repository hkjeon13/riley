__global__ void v16_expand(const U*in,float*out,int count){int i=blockIdx.x*256+threadIdx.x;if(i<count)out[i]=__bfloat162float(in[i]);}
template<int C,int R,int K>__device__ __forceinline__ void expanded_stage(float*dst,const float*w,const float*x,int rows,int first,int col,int it){
 for(int i=threadIdx.x+32*threadIdx.y;i<(C+R)*(K/4);i+=C*32){int r=i/(K/4),k=i%(K/4)*4;bool valid=it<2560/K&&(r<C||first+r-C<rows);const float*src=valid?(r<C?w+(col+r)*2560+it*K+k:x+(first+r-C)*2560+it*K+k):w;owned_sm80_kv_copy16(dst+r*K+k,src,valid);}
 asm volatile("cp.async.commit_group;");
}
template<int C,int R,int K>__global__ void v16_expanded_kv(const float*w,const float*x,U*y,int rows){
 constexpr int Stage=(C+R)*K;__shared__ __align__(32)float sh[Stage*2];int lane=threadIdx.x,col=blockIdx.x*C+threadIdx.y,first=blockIdx.y*R;float acc[R]={};
 expanded_stage<C,R,K>(sh,w,x,rows,first,blockIdx.x*C,0);expanded_stage<C,R,K>(sh+Stage,w,x,rows,first,blockIdx.x*C,1);
 for(int it=0;it<2560/K;it++){asm volatile("cp.async.wait_group 1;");__syncthreads();auto*t=sh+it%2*Stage;
  #pragma unroll
  for(int j=0;j<K/32;j++){int d=lane+j*32;float a=t[threadIdx.y*K+d];
   #pragma unroll
   for(int r=0;r<R;r++)if(first+r<rows)acc[r]=__fmaf_rn(a,t[(C+r)*K+d],acc[r]);}
  __syncthreads();expanded_stage<C,R,K>(t,w,x,rows,first,blockIdx.x*C,it+2);
 }asm volatile("cp.async.wait_group 0;");
 #pragma unroll
 for(int d=16;d;d/=2){
  #pragma unroll
  for(int r=0;r<R;r++){float b=__shfl_down_sync(0xffffffff,acc[r],d);if(lane<d)acc[r]=__fadd_rn(acc[r],b);}}
 if(lane==0){
  #pragma unroll
  for(int r=0;r<R;r++)if(first+r<rows)y[(first+r)*1024+col]=__float2bfloat16_rn(__fmaf_rn(1.f,acc[r],0.f));}
}
