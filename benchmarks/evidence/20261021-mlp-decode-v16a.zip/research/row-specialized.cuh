// Row-specialized CTA: one shared Gate/Up weight tile serves all row warps.
// Each pair of warps owns one16-row tile, with its native accumulator family.
template<int RB,int S=2>__device__ __forceinline__ void row_stage(U*dst,const U*wg,const U*wu,const U*x,int rows,int decode,int col,int it){
 constexpr int N=32,R=RB*16,L=80;int tid=threadIdx.x,padded=(decode+15)/16*16;
 for(int i=tid;i<(N+R)*8;i+=RB*64){int r=i/8,k=i%8*8,source=r-N;if(r>=N)source=source<padded?(source<decode?source:-1):source-padded+decode;bool valid=it<40&&(r<N||(source>=0&&source<rows));const U*src=wg;if(valid)src=r<N?(r<16?wg:wu)+(col+r%16)*2560+it*64+k:x+source*2560+it*64+k;sm80_down_copy16(dst+r*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int RB,int Family>__global__ void v16_row_gateup(const U*wg,const U*wu,const U*x,U*y,int rows,int decode){
 using namespace nvcuda;constexpr int N=32,R=RB*16,L=80,Stage=(N+R)*L;extern __shared__ __align__(32)U sh[];
 int warp=threadIdx.x/32,lane=threadIdx.x%32,rb=warp/2,which=warp%2,col=blockIdx.x*16,padded=(decode+15)/16*16;bool isdecode=rb*16<padded;
 wmma::fragment<wmma::matrix_a,16,16,16,U,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,U,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[4];
 #pragma unroll
 for(int i=0;i<4;i++)wmma::fill_fragment(c[i],0.f);
 row_stage<RB>(sh,wg,wu,x,rows,decode,col,0);row_stage<RB>(sh+Stage,wg,wu,x,rows,decode,col,1);
 for(int it=0;it<40;it++){asm volatile("cp.async.wait_group 1;");__syncthreads();auto*t=sh+(it%2)*Stage;
  #pragma unroll
  for(int j=0;j<4;j++){wmma::load_matrix_sync(a,t+which*16*L+j*16,L);wmma::load_matrix_sync(b,t+(32+rb*16)*L+j*16,L);int chain=isdecode?j/2:Family==1?0:Family==2?j/2:j;wmma::mma_sync(c[chain],a,b,c[chain]);}
  __syncthreads();row_stage<RB>(t,wg,wu,x,rows,decode,col,it+2);
 }asm volatile("cp.async.wait_group 0;");__syncthreads();
 for(int i=0;i<c[0].num_elements;i++){if(isdecode||Family==2)c[0].x[i]=__fadd_rn(c[0].x[i],c[1].x[i]);else if(Family==4)c[0].x[i]=__fadd_rn(__fadd_rn(c[0].x[i],c[1].x[i]),__fadd_rn(c[2].x[i],c[3].x[i]));}
 float*res=reinterpret_cast<float*>(sh)+warp*256;wmma::store_matrix_sync(res,c[0],16,wmma::mem_col_major);__syncthreads();
 if(which==0)for(int i=lane;i<256;i+=32){int r=rb*16+i/16,source=r<padded?(r<decode?r:-1):r-padded+decode;if(source>=0&&source<rows){float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,res[i],0.f))),u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,res[256+i],0.f)));float activated=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[source*9728+col+i%16]=__float2bfloat16_rn(__fmul_rn(activated,u));}}
}
