from pathlib import Path
import json,time,hashlib,zipfile,re,statistics,shutil
w=Path('/mnt/efs/nlp/psyche/riley-mlp-decode-v16a-20261021');c=w.parent/'riley-prefill-host-v15c-20261021';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['probe','tc','attention','transposed','expanded','row','row-timing','row-timing-r2','row-timing-r3','mixed-column','mixed-wide','pv-multiwarp','qk-warp'];receipts=[]
for name in names:
 p=w/'research'/('observed-'+name+'.json');a=json.loads(p.read_text());assert a['status'] in ['complete','failed']
 samples=[json.loads(s)for s in p.with_suffix('.samples.jsonl').read_text().splitlines()];assert samples and max(s['device_memory_mib']for s in samples)<=22528
 assert a['returncode']==(4 if name in ['tc','row-timing']else 0),(name,a)
 receipts.append(dict(name=name,status=a['status'],returncode=a['returncode'],failure=a['failure'],whole_device_peak_MiB=max(s['device_memory_mib']for s in samples),receipt_sha256=sha(p)))
text=(w/'research/observed-qk-warp.stdout').read_text();assert 'COMPLETE exact_combinations=37056'in text
cells=[]
for t in [128,129,144,159,192,213]:
 for r in [16,32]:
  a=[tuple(map(float,m))for m in re.findall(f'TIMING T={t} R={r} rep=[0-9]+ baseline_us=([0-9.]+) fused_us=([0-9.]+)',text)];assert len(a)==3
  before=statistics.median(x[0]for x in a);after=statistics.median(x[1]for x in a);cells.append(dict(T=t,R=r,before_us=before,after_us=after,percent_change=(after/before-1)*100))
shutil.copy2(c/'source-manifest.json',w/'baseline-source-manifest.json')
(w/'component-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),baseline_commit='57502e7a0fafd165966071e88b3e8a56cdea0e3d',baseline_source937_manifest_sha256=sha(w/'baseline-source-manifest.json'),scope='GPU7 finite component research, not whole-model/native-HF qualification or HTTP throughput; generated finite weights/activations, not checkpoint activations',receipts=receipts,selected_for_whole_model_validation='QK register shuffle preserving native serial/tree reductions + four-warp PV CTAs',selected_context_combinations=37056,paired_three_repeat_component_times=cells,whole_model_adopted=False),indent=2))
heavy={}
for p in w.rglob('*'):
 if p.is_file()and not any(x in ['tmp','cache']for x in p.relative_to(w).parts)and p.stat().st_size>=4 and p.open('rb').read(4)==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p))
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2))
files=[p for p in w.rglob('*')if p.is_file()and not any(x in ['tmp','cache']for x in p.relative_to(w).parts)and p.suffix in ['.json','.jsonl','.py','.cu','.cuh','.log','.stdout','.stderr','.txt']and p.name!='evidence-archive-receipt.json'];manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)};z=w/'evidence-v16a.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
 for p in sorted(files):out.write(p,str(p.relative_to(w)))
 out.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
r=dict(time_ns=time.time_ns(),archive=str(z),bytes=z.stat().st_size,entries=len(files)+1,sha256=sha(z),heavy_files=len(heavy));(w/'evidence-archive-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
