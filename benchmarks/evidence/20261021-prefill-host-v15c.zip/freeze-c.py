from pathlib import Path
import json,hashlib,time
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15c-20261021');v=w.parent/'riley-piecewise-v13b-20261020';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();base=json.loads((v/'source-manifest.json').read_text());files=list(base)+['kernels/src/command_batch_index.hpp','crates/riley-cuda/tests/sm80_prefill_alignment_gpu.rs'];m={f:sha(w/'source'/f)for f in sorted(files)};assert len(m)==937
(w/'source-manifest.json').write_text(json.dumps(m,indent=2));binary=w/'riley-prefill-host-v15c';assert sha(binary)==(w/'qualification-binary.sha256').read_text().split()[0]
inputs={str(p):sha(p)for p in [binary,w/'measure-matched.py',w/'final-c16.argv.json',w/'final-c32.argv.json']}
(w/'source-lineage.json').write_text(json.dumps(dict(time_ns=time.time_ns(),baseline_binary=str(v/'riley-piecewise-v13b'),baseline_sha256=sha(v/'riley-piecewise-v13b'),binary=str(binary),binary_sha256=sha(binary),qualified_source_count=937,changed_sources=[f for f,h in m.items()if base.get(f)!=h],source_manifest_sha256=sha(w/'source-manifest.json'),normal_inputs_sha256=inputs),indent=2));print('source937 and normal inputs frozen')
