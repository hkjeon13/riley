"""Four fixture-only reruns. Requires the user's explicit /tmp exception."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,tempfile,time
p=argparse.ArgumentParser();p.add_argument('--allow-test-tmp',action='store_true');a=p.parse_args();assert a.allow_test_tmp,'Do not run until the user approves the fixture-location exception'
os.umask(0o077)
r=Path(__file__).resolve().parent;out=r/'c02-fixture-recheck-v2';assert not out.exists();out.mkdir(mode=0o700)
rows=[]
for line in (r/'native-kv-regression.log').read_text().splitlines():
 try:rows.append(json.loads(line))
 except ValueError:pass
binaries=[x['executable'] for x in rows if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='riley' and x.get('profile',{}).get('test') and x.get('executable')]
assert len(binaries)==1,binaries
binary=Path(binaries[0]);assert binary.is_file();names=['tests::c02_audit_directory_is_private_held_and_descriptor_relative','tests::c02_generation_audit_writer_creates_a_bound_leaf_and_marker_once','tests::c02_generation_audit_writer_refuses_schema_oversize_without_evidence','tests::c02_shutdown_writer_binds_raw_final_metrics_to_a_nonhidden_marker'];results=[]
with tempfile.TemporaryDirectory(prefix='riley-c02-gpu67-',dir='/tmp')as temporary:
 env=dict(os.environ,TMPDIR=temporary,CUDA_VISIBLE_DEVICES='',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64')
 for index,name in enumerate(names):
  argv=['/usr/bin/taskset','-c','48-51',str(binary),'--exact',name,'--test-threads=1']
  result=subprocess.run(argv,cwd=r,env=env,capture_output=True,text=True);(out/f'test{index}.log').write_text(result.stdout+result.stderr);results.append(dict(name=name,argv=argv,returncode=result.returncode));assert result.returncode==0,results[-1]
 receipt=dict(time_ns=time.time_ns(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),temporary_root=temporary,scope='Only four C02 unit-test fixture trees; scripts/models/benchmarks remain under EFS; GPU invisible; private temporary tree removed on exit.',tests=results,all_passed=True)
(out/'complete.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
