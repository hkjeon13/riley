from pathlib import Path
import shutil
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15c-20261021');shutil.copy2(w/'observe-finite.py',w/'observe-finite-v17.original.py');shutil.copy2(w/'observe-finite-v18.py',w/'observe-finite.py')
s=(w/'audit-teachers.py').read_text()
for name in ['final-teacher-C1-eager','final-teacher-allR-Graph','teacher-body-allR']:s=s.replace(name,name+'-r2')
s=s.replace("w/'final-teacher-audit.json'","w/'final-teacher-r2-audit.json'").replace("p/'final-teacher-audit.json'","p/'final-teacher-r2-audit.json'");(w/'audit-teachers-r2.py').write_text(s)
s=(w/'audit-mixed.py').read_text();s=s.replace("('teacher-mixed','teacher-mixed-output',1024),('teacher-mixed-no-output','teacher-mixed-no-output',992)","('teacher-mixed-r2','teacher-mixed-output-r2',1024),('teacher-mixed-no-output-r2','teacher-mixed-no-output-r2',992)").replace("w/'mixed-byte-audit.json'","w/'mixed-byte-r2-audit.json'");(w/'audit-mixed-r2.py').write_text(s)
