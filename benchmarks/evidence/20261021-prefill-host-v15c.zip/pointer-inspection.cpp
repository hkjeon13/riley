#include <cublas_v2.h>
#include <nvToolsExt.h>
#include <dlfcn.h>
#include <cstdio>
extern "C" cublasStatus_t CUBLASWINAPI cublasGemmBatchedEx(
 cublasHandle_t h,cublasOperation_t ta,cublasOperation_t tb,int m,int n,int k,
 const void*alpha,const void*const A[],cudaDataType_t at,int lda,
 const void*const B[],cudaDataType_t bt,int ldb,const void*beta,
 void*const C[],cudaDataType_t ct,int ldc,int batch,cublasComputeType_t compute,
 cublasGemmAlgo_t algorithm){
 using Function=cublasStatus_t(CUBLASWINAPI *)(cublasHandle_t,cublasOperation_t,cublasOperation_t,int,int,int,const void*,const void*const*,cudaDataType_t,int,const void*const*,cudaDataType_t,int,const void*,void*const*,cudaDataType_t,int,int,cublasComputeType_t,cublasGemmAlgo_t);
 static auto real=reinterpret_cast<Function>(dlsym(RTLD_NEXT,"cublasGemmBatchedEx"));
 if(!real)return CUBLAS_STATUS_NOT_INITIALIZED;
 char label[192];std::snprintf(label,sizeof(label),"W0/BatchedEx/N%d/M%d/K%d/B%d/lda%d/ldb%d/ldc%d",m,n,k,batch,lda,ldb,ldc);
 nvtxRangePushA(label);auto status=real(h,ta,tb,m,n,k,alpha,A,at,lda,B,bt,ldb,beta,C,ct,ldc,batch,compute,algorithm);nvtxRangePop();return status;
}
