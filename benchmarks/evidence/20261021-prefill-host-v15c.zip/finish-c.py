from pathlib import Path
import hashlib,json,time,zipfile,subprocess
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15c-20261021');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['campaign-r2-state','normal-analysis-state','dispatch-proof-state','accuracy-r2-state']:
 assert json.loads((w/(name+'.json')).read_text())['phase']=='complete',name
a=json.loads((w/'independent-audit.json').read_text());assert len(a['arms'])==31
stats=json.loads((w/'final-statistics.json').read_text());assert all(not c['tail_over_two_percent_flags'] and c['median_percent_change']['output_tok_s']>0 for c in stats['cells'])
m=json.loads((w/'source-manifest.json').read_text());assert len(m)==937 and all(sha(w/'source'/f)==h for f,h in m.items())
lineage=json.loads((w/'source-lineage.json').read_text());assert sha(w/'riley-prefill-host-v15c')==lineage['binary_sha256']
assert sha(w/'observe-finite.py')=='c0aad9d71eab4071eefb1f94d809c17ced2652d571e662e2af16bab765097947'
resource=[]
for n in ['final-teacher-C1-eager-r2','final-teacher-allR-Graph-r2','teacher-body-allR-r2','teacher-mixed-r2','teacher-mixed-no-output-r2','memory_gpu','owned_hf_command_batch_gpu','host_runtime_gpu','sm80_prefill_alignment_gpu']:
 r=json.loads((w/('observed-'+n+'.json')).read_text());assert r['status']=='complete' and r['returncode']==0
 samples=[json.loads(s)for s in(w/('observed-'+n+'.samples.jsonl')).read_text().splitlines()];peak=max(s['device_memory_mib']for s in samples);assert 0<peak<=22528
 resource.append(dict(name=n,samples=len(samples),whole_device_peak_MiB=peak,receipt_sha256=sha(w/('observed-'+n+'.json'))))
(w/'resource-audit-final.json').write_text(json.dumps(dict(time_ns=time.time_ns(),resource_reruns=resource,source937_verified=True,binary_sha256=lineage['binary_sha256'],normal_and_profile_arms=31,stored_SSE_verified=a['total_full_SSE_values_verified'],normal_and_profile_peak_MiB=max(r['peak_whole_device_MiB']for r in a['arms'])),indent=2))
stock=[]
for p in(w/'runs').glob('*/c*-vllm/server.log'):
 s=p.read_text();assert 'FLASH_ATTN'in s and 'FULL_AND_PIECEWISE'in s and ('version 2'in s or 'version=2'in s),p
 stock.append(dict(log=str(p),sha256=sha(p),FLASH_ATTN=True,FULL_AND_PIECEWISE=True,version2=True))
assert len(stock)==10
(w/'stock-startup-proof.json').write_text(json.dumps(stock,indent=2))
(w/'adoption-decision.json').write_text(json.dumps(dict(time_ns=time.time_ns(),adopted=True,scope='SM80 qualified owned-hf-eager-bf16-v1 native-prefill-sm80-v5 segments-v1 lane, general command-batch resource index',reason='Unchanged native/HF literal BF16 gates, compatibility/ownership GPU tests, five fresh paired C16/C32 throughput improvements and no >2% paired tail flags',prior_B_C32_tail_flag_preserved=True,alignment_guard_is_not_claimed_as_tail_cause=True,target_ten_percent_reached=False),indent=2))
# Check persistent contexts after all finite jobs; retain any authorized external GPU6 work.
R=w.parent/'riley-w0-a100-gpu67-20261019';rows=[]
for attempt in range(3):
 sample=dict(time_ns=time.time_ns(),gpus=[])
 for index,pid,ticks in [(6,2027914,'6083215119'),(7,2027915,'6083215121')]:
  h=json.loads((R/f'leases-v2/gpu{index}.status.json').read_text());assert h['phase']=='idle' and h['allocation_bytes']==21474836480 and h['pid']==pid and h['start_ticks']==ticks
  assert Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]==ticks
  assert time.time_ns()-h['updated_ns']<10**10
  raw=subprocess.check_output(['nvidia-smi','-i',str(index),'--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'],text=True)
  processes=[dict(pid=int(l.split(',')[0]),MiB=float(l.split(',')[1]))for l in raw.splitlines()if l.strip()]
  assert [r['pid'] for r in processes]==[pid],(index,processes)
  sample['gpus'].append(dict(index=index,holder=h,processes=processes))
 rows.append(sample);time.sleep(.8)
(w/'final-holder-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),passed=True,samples=rows,context_restart_or_release=False,scope='Three fresh samples: original holder PID/start ticks, idle20GiB each, no finite jobs or foreign compute present on GPU6/7'),indent=2))
heavy={};skip={'source','target','tmp','cache','vllm-cache','ipc6','ipc7','__pycache__','torch_compile_cache','torchinductor_cache'}
for p in w.rglob('*'):
 if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
 if p.suffix=='.bf16' or p.suffix in ['.sqlite','.nsys-rep']or (p.stat().st_size>4 and p.open('rb').read(4)==b'\x7fELF'):
  heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p))
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2))
allowed={'.json','.jsonl','.log','.txt','.py','.sh','.stdout','.stderr','.cu','.cuh','.cpp','.sse','.h','.hpp','.exit','.sha256','.rs'}
files=[p for p in w.rglob('*')if p.is_file()and not any(x in skip for x in p.relative_to(w).parts)and p.suffix in allowed and p.name!='evidence-archive-receipt.json']
manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)}
z=w/'evidence-archive-v15c.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as f:
 for p in sorted(files):f.write(p,str(p.relative_to(w)))
 f.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
receipt=dict(time_ns=time.time_ns(),archive=str(z),bytes=z.stat().st_size,entries=len(files)+1,sha256=sha(z),heavy_files=len(heavy))
(w/'evidence-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
