from pathlib import Path
import json
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15c-20261021')
a=json.loads((w/'final-c32.argv.json').read_text());a[a.index(str(w/'measure-matched.py'))]=str(w/'measure-profile.py');a[a.index('--out')+1]=str(w/'runs/profile-c32');a[a.index('--repeats')+1]='1';a[a.index('--keep')+1]='64';a[a.index('--modes')+1]='owned-after';a+=['--profile','--inspect'];(w/'profile-c32.argv.json').write_text(json.dumps(a,indent=2))
s=(w/'audit-complete.py').read_text();old="['final-c16','final-c32','profile-c16','profile-c32']";assert old in s;s=s.replace(old,"['final-c16','final-c32','profile-c32']",1);(w/'audit-final-c.py').write_text(s)
