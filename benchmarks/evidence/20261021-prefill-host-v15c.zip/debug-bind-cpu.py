from pathlib import Path
import subprocess,os,signal,time,json
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15c-20261021');binary=w/'teacher-probe-final';out=str(w/'debug-cpu-only');env=dict(os.environ,CUDA_VISIBLE_DEVICES='',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',RILEY_DIVERGENCE_NATIVE_OUTPUT=out)
rows=[]
for i in range(3):
 p=subprocess.Popen([str(binary),'--list'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:
  proc=Path('/proc')/str(p.pid);ticks=(proc/'stat').read_text().rsplit(')',1)[1].split()[19];os.kill(p.pid,signal.SIGSTOP)
  for attempt in range(3):
   fields=dict(x.split(':',1)for x in(proc/'status').read_text().splitlines()if ':'in x)
   rows.append(dict(pid=p.pid,ticks=ticks,attempt=attempt,uid=proc.stat().st_uid,expected_uid=os.getuid(),exe=str((proc/'exe').resolve()),expected_exe=str(binary.resolve()),tgid=fields['Tgid'],expected_tgid=p.pid,env_marker=(b'RILEY_DIVERGENCE_NATIVE_OUTPUT='+out.encode())in(proc/'environ').read_bytes().split(b'\0')));time.sleep(.005)
  os.kill(p.pid,signal.SIGCONT)
 finally:
  if p.poll()is None:
   try:os.kill(p.pid,signal.SIGCONT)
   except ProcessLookupError:pass
  p.communicate(timeout=5)
print(json.dumps(rows,indent=2));(w/'debug-bind-cpu.json').write_text(json.dumps(rows,indent=2))
