from pathlib import Path
import shutil,time,json,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15c-20261021');p=w/'observe-finite.py';shutil.copy2(p,w/'observe-finite-v16.original.py');shutil.copy2(w/'observe-finite-v17.py',p)
(w/'observer-version-transition.json').write_text(json.dumps(dict(time_ns=time.time_ns(),old_sha256=hashlib.sha256((w/'observe-finite-v16.original.py').read_bytes()).hexdigest(),new_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Same early root/thread-group binding and whole-device guard; initial binding failure now reaches child cleanup. Raw prior receipts retained.'),indent=2))
