from pathlib import Path
import importlib.metadata as m,hashlib,json,time
p=Path(__file__).resolve().parent;dist=m.distribution('vllm');names=['vllm/model_executor/models/qwen3.py','vllm/model_executor/models/qwen2.py','vllm/model_executor/layers/linear.py','vllm/model_executor/layers/activation.py','vllm/attention/layer.py'];rows=[]
for n in names:
 f=Path(dist.locate_file(n))
 if not f.is_file():continue
 lines=f.read_text().splitlines();matches=[dict(line=i+1,text=l.strip())for i,l in enumerate(lines)if any(x in l for x in ['Qwen2MLP','gate_up_proj','SiluAndMul','QKVParallelLinear','MergedColumnParallelLinear'])]
 rows.append(dict(path=str(f),sha256=hashlib.sha256(f.read_bytes()).hexdigest(),selected_lines=matches))
x=dict(time_ns=time.time_ns(),vllm=m.version('vllm'),torch=m.version('torch'),sources=rows,scope='Read-only installed source/metadata; actual backend and Graph path require the saved startup/trace evidence')
(p/'stock-installed-source-proof.json').write_text(json.dumps(x,indent=2));print(x['vllm'],x['torch'],len(rows))
