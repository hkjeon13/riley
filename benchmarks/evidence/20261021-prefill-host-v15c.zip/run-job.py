from pathlib import Path
import json,subprocess,time,os,traceback,sys
p=Path(__file__).resolve().parent;name=sys.argv[1];a=json.loads((p/(name+'.argv.json')).read_text());s=dict(pid=os.getpid(),start_ticks=Path('/proc/self/stat').read_text().split()[21],started_ns=time.time_ns(),status='running',argv=a)
def save():(p/(name+'.state.json')).write_text(json.dumps(s,indent=2))
save()
try:
 with(p/(name+'.log')).open('x')as f:
  c=subprocess.Popen(a,stdout=f,stderr=subprocess.STDOUT);s['child_pid']=c.pid;save();rc=c.wait()
 s.update(status='complete'if rc==0 else'failed',returncode=rc,finished_ns=time.time_ns());save();raise SystemExit(rc)
except Exception as e:s.update(status='failed',error=repr(e),traceback=traceback.format_exc());save();raise
