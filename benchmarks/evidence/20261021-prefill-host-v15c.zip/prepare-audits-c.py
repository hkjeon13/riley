from pathlib import Path
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15c-20261021');b=w.parent/'riley-prefill-host-v15b-20261021'
s=(b/'audit-teachers-e.py').read_text().replace(str(b),str(w));(w/'audit-teachers.py').write_text(s)
s=(b/'audit-mixed-b.py').read_text().replace(str(b),str(w));(w/'audit-mixed.py').write_text(s)
