from pathlib import Path
import json,statistics,math,time
p=Path(__file__).parent;matrix=json.loads((p/'primary-matrix-audit.json').read_text());keys=['output_tok_s']+[m+'_'+q for m in ['ttft_ms','tpot_ms','e2e_ms']for q in ['p50','p95','p99']];out=[];tail=[]
for cell in matrix:
 c=cell['concurrency'];rows=cell['records'];modes={mode:{k:statistics.median(r[k]for r in rows if r['mode']==mode)for k in keys}for mode in ['owned-before','owned-after','vllm']};pairs=[];flags=[]
 for rep in range(5):
  by={r['mode']:r for r in rows if r['repeat']==rep};delta={k:100*(by['owned-after'][k]/by['owned-before'][k]-1)for k in keys};pairs.append(dict(repeat=rep,percent_change=delta))
  for k in ['ttft_ms_p95','ttft_ms_p99','tpot_ms_p95','tpot_ms_p99']:
   if delta[k]>2:flags.append(dict(repeat=rep,metric=k,percent_change=delta[k]))
 out.append(dict(concurrency=c,medians=modes,median_percent_change={k:100*(modes['owned-after'][k]/modes['owned-before'][k]-1)for k in keys},before_stock_ratio=modes['owned-before']['output_tok_s']/modes['vllm']['output_tok_s'],after_stock_ratio=modes['owned-after']['output_tok_s']/modes['vllm']['output_tok_s'],paired=pairs,tail_over_two_percent_flags=flags))
 for r in rows:
  if r['mode']=='vllm':continue
  arm=p/'runs'/r['campaign']/f"c{c}-r{r['repeat']}-{r['mode']}";requests=json.loads((arm/'w0/requests.json').read_text());ordered=sorted(enumerate(requests),key=lambda x:x[1]['ttft_ms']);j=(len(ordered)-1)*.95;start=min(v['start']for v in requests);brackets=[]
  for rank in sorted({math.floor(j),math.ceil(j)}):
   ordinal,v=ordered[rank];brackets.append(dict(rank=rank,request_ordinal=ordinal,id=v['id'],start_offset_ms=(v['start']-start)*1000,ttft_ms=v['ttft_ms'],prompt_tokens=v['value']['usage']['prompt_tokens'],completion_tokens=v['value']['usage']['completion_tokens']))
  tail.append(dict(concurrency=c,repeat=r['repeat'],mode=r['mode'],campaign=r['campaign'],p95_brackets=brackets))
(p/'final-statistics.json').write_text(json.dumps(dict(time_ns=time.time_ns(),scope='Five independent fresh-process repetitions; medians per metric, not pooled percentiles',cells=out),indent=2));(p/'initial-cohort-tail-audit.json').write_text(json.dumps(tail,indent=2));print(json.dumps(out,indent=2))
