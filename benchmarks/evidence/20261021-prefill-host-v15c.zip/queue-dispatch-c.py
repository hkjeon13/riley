from pathlib import Path
import json,time,subprocess,traceback,sqlite3,collections,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15c-20261021');state=dict(phase='waiting-normal',started_ns=time.time_ns())
def save():(w/'dispatch-proof-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  a=json.loads((w/'campaign-r2-state.json').read_text())
  if a['phase']in ['complete','failed']:assert a['phase']=='complete',a;break
  time.sleep(3)
 state['phase']='profiling';save()
 with(w/'profile-c32.outer.log').open('x')as f:p=subprocess.run(['python3',str(w/'run-job.py'),'profile-c32'],stdout=f,stderr=f)
 assert p.returncode==0
 path=w/'runs/profile-c32/c32-r0-owned-after/trace.sqlite';d=sqlite3.connect(path);d.row_factory=sqlite3.Row;s=dict(d.execute('select id,value from StringIds'));kernels=d.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL').fetchall();counts={}
 for token in ['hf_sm80_compact_prefill','hf_q_gather','hf_output_rows','hf_scale_mask_tile','hf_scatter_bf16_tile']:
  rows=[r for r in kernels if token in s[r['demangledName']]];counts[token]=dict(count=len(rows),ms=sum(r['end']-r['start']for r in rows)/1e6)
 labels=[]
 for row in d.execute('select * from NVTX_EVENTS'):
  r=dict(row);label=r.get('text')or s.get(r.get('textId'),'')
  if '/BatchedEx/'in label:labels.append(label)
 assert counts['hf_sm80_compact_prefill']['count']==64*36 and len(labels)==64*36*2
 assert all(counts[n]['count']==0 for n in ['hf_q_gather','hf_output_rows','hf_scale_mask_tile','hf_scatter_bf16_tile'])
 (w/'actual-prefill-dispatch-proof.json').write_text(json.dumps(dict(scope='Separate64-keep profile of exact final C binary, not a normal performance arm or a before/stock timing comparison',binary_sha256=hashlib.sha256((w/'riley-prefill-host-v15c').read_bytes()).hexdigest(),trace=str(path),trace_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),kernel_counts=counts,pointer_batched_ranges=len(labels),geometries=dict(collections.Counter(labels))),indent=2))
 with(w/'audit-final-c.outer.log').open('x')as f:p=subprocess.run(['python3',str(w/'audit-final-c.py')],stdout=f,stderr=f)
 assert p.returncode==0
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
