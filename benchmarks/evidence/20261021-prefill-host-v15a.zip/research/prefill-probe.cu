#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cublas_v2.h>
#include <cstdio>
#include <vector>
#include <utility>
#include <cmath>
#include "hf_softmax_diagnostic.cuh"
namespace {
__global__ void hf_q_gather(const __nv_bfloat16*in,__nv_bfloat16*out,int m,int h,int d){int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<m*h*d){int depth=i%d,row=(i/d)%m,head=i/(d*m);out[i]=in[(row*h+head)*d+depth];}}
// One aligned load supplies all four GQA query heads. Copy BF16 bits only;
// retain the expanded operands and original cuBLAS strides and reduction.
__global__ void hf_sm80_vector_kv_gather(const uint4* __restrict__ kin,const uint4* __restrict__ vin,const uint32_t* __restrict__ ids,uint4* __restrict__ k,uint4* __restrict__ v,int t,uint64_t physical){
 int i=blockIdx.x*blockDim.x+threadIdx.x;
 if(i<t*8*16){int depth=i%16,token=(i/16)%t,head=i/(16*t);uint64_t id=ids[token/16];
  uint4 kk,vv;
  if(id>=physical){uint32_t nan=__bfloat16_as_ushort(__float2bfloat16_rn(CUDART_NAN_F));nan|=nan<<16;kk=vv=make_uint4(nan,nan,nan,nan);}
  else{uint64_t source=((id*8+head)*16+token%16)*16+depth;kk=kin[source];vv=vin[source];}
  #pragma unroll
  for(int g=0;g<4;g++){int target=((head*4+g)*t+token)*16+depth;k[target]=kk;v[target]=vv;}
 }
}
__global__ void hf_kv_gather(const __nv_bfloat16*kin,const __nv_bfloat16*vin,const uint32_t*ids,__nv_bfloat16*k,__nv_bfloat16*v,int t,uint64_t physical,int h,int kvh,int d){int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<t*h*d){int depth=i%d,row=(i/d)%t,head=i/(d*t);uint64_t id=ids[row/16];if(id>=physical){k[i]=v[i]=__float2bfloat16_rn(CUDART_NAN_F);}else{uint64_t j=((id*kvh+head/(h/kvh))*16+row%16)*d+depth;k[i]=kin[j];v[i]=vin[j];}}}
// Compact prefill GQA operands and per-head pointer tables in existing K
// scratch. Q and context stay row-major: their column stride is H*D.
// Every head retains the original M/N/K; no padding or reduction merge.
__global__ void hf_sm80_compact_prefill(const uint4* kin,const uint4* vin,const uint32_t* ids,uint4* k,uint4* v,const __nv_bfloat16* q,__nv_bfloat16* score,__nv_bfloat16* prob,__nv_bfloat16* out,void** tables,int m,int t,uint64_t physical){
 int i=blockIdx.x*blockDim.x+threadIdx.x;
 if(i<t*8*16){int depth=i%16,token=(i/16)%t,head=i/(16*t);uint64_t id=ids[token/16];uint4 kk,vv;
  if(id>=physical){uint32_t nan=__bfloat16_as_ushort(__float2bfloat16_rn(CUDART_NAN_F));nan|=nan<<16;kk=vv=make_uint4(nan,nan,nan,nan);}
  else {uint64_t src=((id*8+head)*16+token%16)*16+depth;kk=kin[src];vv=vin[src];}k[i]=kk;v[i]=vv;
 }
 if(i<32){auto* kb=reinterpret_cast<__nv_bfloat16*>(k);auto* vb=reinterpret_cast<__nv_bfloat16*>(v);
  tables[i]=kb+(i/4)*t*128;tables[32+i]=const_cast<__nv_bfloat16*>(q)+i*128;tables[64+i]=score+i*m*t;
  tables[96+i]=vb+(i/4)*t*128;tables[128+i]=prob+i*m*t;tables[160+i]=out+i*128;
 }
}
// Tile only independent softmax rows. Full BF16 QK/AV geometry is unchanged.
// Global score/probability tensors exceed INT32_MAX elements at 8k Q32.
__global__ void hf_scale_mask_tile(const __nv_bfloat16*in,float*out,int m,int t,int h,int start,int tile,float scale){
 uint64_t i=uint64_t(blockIdx.x)*blockDim.x+threadIdx.x;
 if(i<uint64_t(h)*tile*t){int key=i%t,row=(i/t)%tile,head=i/(uint64_t(tile)*t);uint64_t source=(uint64_t(head)*m+start+row)*t+key;
 out[i]=key>t-m+start+row?-3.3895313892515355e38f:__bfloat162float(__float2bfloat16_rn(__bfloat162float(in[source])*scale));}
}
__global__ void hf_scatter_bf16_tile(const float*in,__nv_bfloat16*out,int m,int t,int h,int start,int tile){
 uint64_t i=uint64_t(blockIdx.x)*blockDim.x+threadIdx.x;
 if(i<uint64_t(h)*tile*t){int key=i%t,row=(i/t)%tile,head=i/(uint64_t(tile)*t);uint64_t target=(uint64_t(head)*m+start+row)*t+key;out[target]=__float2bfloat16_rn(in[i]);}
}
__global__ void hf_output_rows(const __nv_bfloat16*in,__nv_bfloat16*out,int m,int h,int d){int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<m*h*d){int depth=i%d,head=(i/d)%h,row=i/(h*d);out[i]=in[(head*m+row)*d+depth];}}
}

#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"cuda %s:%d %s\n",__FILE__,__LINE__,cudaGetErrorString(e));return 2;}}while(0)
#define BL(x) do{auto e=(x);if(e!=CUBLAS_STATUS_SUCCESS){fprintf(stderr,"cublas %d line%d\n",int(e),__LINE__);return 3;}}while(0)
__global__ void fill(__nv_bfloat16*p,int n,int seed){int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n){uint32_t x=(uint32_t(i)*1664525u+1013904223u)^(uint32_t(seed+1)*2246822519u);x^=x>>13;float v=(float(int(x%4093)-2046)/2048.f);if(seed==1)v*=8;if(seed==2)v*=.0078125f;if(seed==3)v=(i%7)?0:v;if(seed==4)v=(i%2)?-v:v;if(seed==5)v*=32;p[i]=__float2bfloat16_rn(v);}}
__global__ void compare(const __nv_bfloat16*a,const __nv_bfloat16*b,uint64_t n,unsigned int*result,int index){uint64_t i=uint64_t(blockIdx.x)*blockDim.x+threadIdx.x;if(i<n && __bfloat16_as_ushort(a[i])!=__bfloat16_as_ushort(b[i]))atomicAdd(result+index,1u);}
int main(){cudaStream_t stream;CU(cudaStreamCreate(&stream));cublasHandle_t handle;BL(cublasCreate(&handle));BL(cublasSetStream(handle,stream));BL(cublasSetMathMode(handle,CUBLAS_DEFAULT_MATH));BL(cublasSetAtomicsMode(handle,CUBLAS_ATOMICS_NOT_ALLOWED));
 const int maxm=576,maxt=2048,h=32,d=128,kh=8,physical=128;auto alloc=[](uint64_t n){void*p=nullptr;auto e=cudaMalloc(&p,n);if(e!=cudaSuccess){fprintf(stderr,"alloc %s",cudaGetErrorString(e));std::abort();}return p;};
 auto* q=(__nv_bfloat16*)alloc(maxm*h*d*2);auto*kpool=(__nv_bfloat16*)alloc(physical*kh*16*d*2);auto*vpool=(__nv_bfloat16*)alloc(physical*kh*16*d*2);auto*k=(__nv_bfloat16*)alloc(maxt*h*d*2);auto*v=(__nv_bfloat16*)alloc(maxt*h*d*2);auto*qg=(__nv_bfloat16*)alloc(maxm*h*d*2);auto*cg=(__nv_bfloat16*)alloc(maxm*h*d*2);auto*s=(__nv_bfloat16*)alloc(uint64_t(h)*maxm*maxt*2);auto*p=(__nv_bfloat16*)alloc(uint64_t(h)*maxm*maxt*2);auto*bs=(__nv_bfloat16*)alloc(uint64_t(h)*maxm*maxt*2);auto*bp=(__nv_bfloat16*)alloc(uint64_t(h)*maxm*maxt*2);auto*out=(__nv_bfloat16*)alloc(maxm*h*d*2);auto*bout=(__nv_bfloat16*)alloc(maxm*h*d*2);auto*f=(float*)alloc(uint64_t(h)*128*maxt*4);auto*fp=(float*)alloc(uint64_t(h)*128*maxt*4);auto*ids=(uint32_t*)alloc(128*4);auto*diff=(unsigned int*)alloc(12);void*workspace=alloc(16777216);BL(cublasSetWorkspace(handle,workspace,16777216));std::vector<uint32_t> hi(128);for(int i=0;i<128;i++)hi[i]=(i*37)%128;CU(cudaMemcpyAsync(ids,hi.data(),512,cudaMemcpyHostToDevice,stream));float alpha=1,beta=0,scale=float(1./std::sqrt(128.));
 std::vector<std::pair<int,int>> shapes={{2,2},{3,7},{7,16},{16,16},{16,127},{31,128},{32,129},{64,144},{115,115},{128,128},{130,130},{128,256},{129,257},{256,397},{397,397},{256,512},{512,512},{576,1024},{576,2048},{2,2048}};
 int checked=0;for(auto[m,t]:shapes)for(int seed=0;seed<6;seed++){
 fill<<<(m*h*d+255)/256,256,0,stream>>>(q,m*h*d,seed);fill<<<(physical*kh*16*d+255)/256,256,0,stream>>>(kpool,physical*kh*16*d,seed+1);fill<<<(physical*kh*16*d+255)/256,256,0,stream>>>(vpool,physical*kh*16*d,seed+2);
 hf_q_gather<<<(m*h*d+255)/256,256,0,stream>>>(q,qg,m,h,d);hf_sm80_vector_kv_gather<<<(t*8*16+255)/256,256,0,stream>>>((uint4*)kpool,(uint4*)vpool,ids,(uint4*)k,(uint4*)v,t,physical);
 BL(cublasGemmStridedBatchedEx(handle,CUBLAS_OP_T,CUBLAS_OP_N,t,m,d,&alpha,k,CUDA_R_16BF,d,t*d,qg,CUDA_R_16BF,d,m*d,&beta,bs,CUDA_R_16BF,t,m*t,h,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));
 int log=0;while((1<<log)<t)log++;int width=(1<<log)<32?(1<<log):32,warps=128/width,wb=log<=7?2:1;dim3 threads(width,warps);
 for(int start=0;start<m;start+=128){int tile=std::min(128,m-start);uint64_t n=uint64_t(h)*tile*t;hf_scale_mask_tile<<<(n+255)/256,256,0,stream>>>(bs,f,m,t,h,start,tile,scale);int blocks=(h*tile+warps*wb-1)/(warps*wb);
#define OLD(L) case L:softmax_warp_forward<float,float,float,L,false,false,32><<<blocks,threads,0,stream>>>(fp,f,h*tile,t,t);break;
 switch(log){OLD(0) OLD(1) OLD(2) OLD(3) OLD(4) OLD(5) OLD(6) OLD(7) OLD(8) OLD(9) OLD(10) OLD(11)}
#undef OLD
 hf_scatter_bf16_tile<<<(n+255)/256,256,0,stream>>>(fp,bp,m,t,h,start,tile);
 }
 BL(cublasGemmStridedBatchedEx(handle,CUBLAS_OP_N,CUBLAS_OP_N,d,m,t,&alpha,v,CUDA_R_16BF,d,t*d,bp,CUDA_R_16BF,t,m*t,&beta,cg,CUDA_R_16BF,d,m*d,h,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));hf_output_rows<<<(m*h*d+255)/256,256,0,stream>>>(cg,bout,m,h,d);
 auto**tables=reinterpret_cast<void**>(k+uint64_t(kh)*t*d);hf_sm80_compact_prefill<<<(t*8*16+255)/256,256,0,stream>>>((uint4*)kpool,(uint4*)vpool,ids,(uint4*)k,(uint4*)v,q,s,p,out,tables,m,t,physical);
 BL(cublasGemmBatchedEx(handle,CUBLAS_OP_T,CUBLAS_OP_N,t,m,d,&alpha,const_cast<const void**>(tables),CUDA_R_16BF,d,const_cast<const void**>(tables+32),CUDA_R_16BF,h*d,&beta,tables+64,CUDA_R_16BF,t,h,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));int blocks=(h*m+warps*wb-1)/(warps*wb);
#define NEW(L) case L:softmax_warp_forward<__nv_bfloat16,__nv_bfloat16,float,L,false,false,32,false,false,true><<<blocks,threads,0,stream>>>(p,s,h*m,t,t,nullptr,-1,false,m);break;
 switch(log){NEW(0) NEW(1) NEW(2) NEW(3) NEW(4) NEW(5) NEW(6) NEW(7) NEW(8) NEW(9) NEW(10) NEW(11)}
#undef NEW
 BL(cublasGemmBatchedEx(handle,CUBLAS_OP_N,CUBLAS_OP_N,d,m,t,&alpha,const_cast<const void**>(tables+96),CUDA_R_16BF,d,const_cast<const void**>(tables+128),CUDA_R_16BF,t,&beta,tables+160,CUDA_R_16BF,h*d,h,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));CU(cudaMemsetAsync(diff,0,12,stream));uint64_t n=uint64_t(h)*m*t;compare<<<(n+255)/256,256,0,stream>>>(bs,s,n,diff,0);compare<<<(n+255)/256,256,0,stream>>>(bp,p,n,diff,1);compare<<<(m*h*d+255)/256,256,0,stream>>>(bout,out,m*h*d,diff,2);unsigned int got[3];CU(cudaMemcpyAsync(got,diff,12,cudaMemcpyDeviceToHost,stream));CU(cudaStreamSynchronize(stream));printf("{\"m\":%d,\"t\":%d,\"state\":%d,\"qk_mismatch\":%u,\"prob_mismatch\":%u,\"context_mismatch\":%u}\n",m,t,seed,got[0],got[1],got[2]);fflush(stdout);if(got[0]||got[1]||got[2])return 4;checked++;
 }printf("PREFILL_EXACT checked=%d\n",checked);return 0;
}
