from pathlib import Path
import subprocess,json,time,traceback
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15a-20261021');state={'phase':'waiting-body'}
def save():(w/'screen-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  p=w/'observed-teacher-body-allR.json'
  if p.exists():
   a=json.loads(p.read_text())
   if a['status']!='running':assert a['status']=='complete'and a['returncode']==0,a;break
  time.sleep(2)
 for script in ['audit-teachers-e.py']:
  with(w/(script+'.outer.log')).open('x')as f:r=subprocess.run(['python3',str(w/script)],stdout=f,stderr=f)
  assert r.returncode==0,script
 for name in ['screen-c16','screen-c32']:
  state.update(phase='screen',current=name);save()
  with(w/(name+'.outer.log')).open('x')as f:r=subprocess.run(['python3',str(w/'run-job.py'),name],stdout=f,stderr=f)
  assert r.returncode==0,name
 state.update(phase='complete');save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
