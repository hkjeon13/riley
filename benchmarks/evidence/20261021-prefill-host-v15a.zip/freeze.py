from pathlib import Path
import hashlib,json,sys,time
w=Path(sys.argv[1]);b=w.parent/'riley-piecewise-v13b-20261020';base=json.loads((b/'source-manifest.json').read_text());files=list(base)
if (w/'source/kernels/src/command_batch_index.hpp').exists():files+=['kernels/src/command_batch_index.hpp']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest={f:sha(w/'source'/f)for f in sorted(files)};changed=[f for f,h in manifest.items()if base.get(f)!=h]
(w/'source-manifest.json').write_text(json.dumps(manifest,indent=2));scripts={str(p):sha(p)for p in w.glob('*.py')};scripts.update({str(p):sha(p)for p in w.glob('*.argv.json')});scripts[str(w/'build.sh')]=sha(w/'build.sh')
binary=next(w.glob('riley-prefill-host-v15?'));receipt=(w/'qualification-binary.sha256').read_text().split();assert receipt[0]==sha(binary)
(w/'source-lineage.json').write_text(json.dumps(dict(time_ns=time.time_ns(),baseline_root=str(b),baseline_binary_sha256=sha(b/'riley-piecewise-v13b'),source_file_count=len(manifest),changed_sources=changed,binary=str(binary),binary_sha256=sha(binary),source_manifest_sha256=sha(w/'source-manifest.json'),scripts_sha256=scripts),indent=2));print(changed)
