from pathlib import Path
import sqlite3,collections,json
w=Path('/mnt/efs/nlp/psyche/riley-structural-v14d-20261021/runs/profile-c32/c32-r0-owned-before')
d=sqlite3.connect(w/'trace.sqlite');d.row_factory=sqlite3.Row;s=dict(d.execute('select id,value from StringIds'))
print('tables',list(d.execute("select name from sqlite_master where name like '%GRAPH%'")))
print('graph group', [tuple(r)for r in d.execute('select graphId,count(*),count(distinct graphNodeId) from CUPTI_ACTIVITY_KIND_KERNEL group by graphId order by count(*) desc limit 8')])
rs=d.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL order by start').fetchall();g=d.execute('select graphId from CUPTI_ACTIVITY_KIND_KERNEL where graphId is not null group by graphId order by count(distinct graphNodeId) desc limit 1').fetchone()[0]
for r in [r for r in rs if r['graphId']==g][:55]:print(r['graphId'],r['graphNodeId'],r['gridX'],r['gridY'],r['gridZ'],s[r['demangledName']][:155])
