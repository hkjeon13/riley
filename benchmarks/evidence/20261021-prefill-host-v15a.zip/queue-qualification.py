from pathlib import Path
import subprocess,time,json,traceback
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15a-20261021')
s=dict(phase='waiting-build',started_ns=time.time_ns())
def save():(w/'qualification-state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 while not(w/'native-kv-build-and-cpu.exit').exists():time.sleep(3)
 s['phase']='cpu-recheck';save()
 with(w/'recheck-c02.outer.log').open('x')as f:r=subprocess.run(['python3',str(w/'recheck-c02.py')],stdout=f,stderr=f)
 assert r.returncode==0
 s['phase']='teacher-build';save()
 with(w/'teacher-build.outer.log').open('x')as f:r=subprocess.run(['python3',str(w/'build-teacher-final.py')],stdout=f,stderr=f)
 assert r.returncode==0
 s['phase']='teacher-running';save()
 while True:
  p=w/'final-teacher-state.json'
  if p.exists():
   a=json.loads(p.read_text())
   if a['status']!='running':assert a['status']=='complete',a;break
  time.sleep(3)
 s['phase']='teacher-complete';save()
except BaseException as e:s.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
