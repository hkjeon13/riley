from pathlib import Path
import json,hashlib,zipfile,time,shutil,sys
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15a-20261021');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((w/'screen-state.json').read_text())['phase']=='complete'
m=json.loads((w/'source-manifest.json').read_text());assert len(m)==935 and all(sha(w/'source'/f)==v for f,v in m.items())
lineage=json.loads((w/'source-lineage.json').read_text());assert sha(Path(lineage['binary']))==lineage['binary_sha256']
a=json.loads((w/'final-teacher-audit.json').read_text());assert sum(x['files']for x in a['runs'])==2464
heavy={}
for run in a['runs']:
 for name,h in run['raw_file_sha256'].items():
  p=w/run['name']/name;assert sha(p)==h;heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=h)
for p in [Path(lineage['binary']),w/'teacher-probe-final',w/'teacher-body',w/'research/prefill-probe',w/'research/prefill-probe-r2']:
 heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p))
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2))
(w/'diagnostics').mkdir(exist_ok=True)
d=w.parent/'riley-structural-v14d-20261021'
for c in [16,32]:
 p=d/f'runs/profile-c{c}/c{c}-r0-owned-before';out=w/'diagnostics'/f'baseline-c{c}';out.mkdir(exist_ok=True)
 for name in ['graph-attribution-v15.json','trace.sqlite.driver-aware-v15.json','trace.sqlite.combined-v15.json']:shutil.copy2(p/name,out/name)
rows=[]
for c in [16,32]:
 a=json.loads((w/f'runs/screen-c{c}/result.json').read_text());assert len(a['records'])==2
 before,after=a['records'];assert before['mode']=='owned-before'and after['mode']=='owned-after'
 rows.append(dict(concurrency=c,warm=64,keep=64 if c==16 else 192,host_step_trace=c==32,before=before,after=after,throughput_change_pct=(after['output_tok_s']/before['output_tok_s']-1)*100))
(w/'screen-summary.json').write_text(json.dumps(dict(time_ns=time.time_ns(),adopted=False,scope='Single screening pair each; C32 includes host trace, not final normal five-repeat vLLM comparison',rows=rows),indent=2))
allowed={'.json','.jsonl','.log','.txt','.py','.sh','.stdout','.stderr','.cu','.cuh','.cpp','.sse','.h','.hpp'}
files=[]
for p in w.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(w)
 if rel.parts[0]in ['source','target','tmp','cache','ipc6','ipc7']:continue
 if p.suffix in allowed and p.name not in ['evidence-archive-receipt.json']:files.append(p)
manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)}
z=w/'evidence-archive-v15a.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as f:
 for p in sorted(files):f.write(p,str(p.relative_to(w)))
 f.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
(w/'evidence-archive-receipt.json').write_text(json.dumps(dict(time_ns=time.time_ns(),archive=str(z),bytes=z.stat().st_size,sha256=sha(z),entries=len(manifest)+1,heavy_files=len(heavy)),indent=2));print((w/'evidence-archive-receipt.json').read_text())
