from pathlib import Path
import json,subprocess,time,traceback,hashlib,re
w=Path('/mnt/efs/nlp/psyche/riley-piecewise-v13b-20261020');state=dict(phase='waiting-profiles',started_ns=time.time_ns())
def save():(w/'route-queue-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  s=json.loads((w/'profile-queue-r2-state.json').read_text());assert s['phase']!='failed',s
  if s['phase']=='complete':break
  time.sleep(3)
 # Instrumentation is confined to this diagnostic; normal campaigns retain
 # their original runner/binary identity and never preload the proof wrapper.
 s=(w/'measure-profile.py').read_text();assert 'call-inspection-nvtx.so'in s;s=s.replace('call-inspection-nvtx.so','merged-route-proof.so');(w/'measure-route-proof.py').write_text(s)
 a=json.loads((w/'profile-c32.argv.json').read_text());a=[v.replace('measure-profile.py','measure-route-proof.py')for v in a];a[a.index('--out')+1]=str(w/'runs/route-proof-c32');a[a.index('--modes')+1]='owned-after';a[a.index('--warm')+1]='32';a[a.index('--keep')+1]='32';a.remove('--profile');(w/'route-proof-c32.argv.json').write_text(json.dumps(a,indent=2));state['phase']='route-proof';save()
 with(w/'route-proof-c32.queue.log').open('x')as f:r=subprocess.run(['python3',str(w/'run-job.py'),'route-proof-c32'],stdout=f,stderr=f)
 assert r.returncode==0
 log=(w/'runs/route-proof-c32/c32-r0-owned-after/server.log').read_text();lines=[l for l in log.splitlines()if l.startswith('RILEY_MERGED_LT_EXECUTED')];found={int(re.search(r' M=(\d+)',l)[1])for l in lines};assert found=={1,*range(17,33)},found;assert all('status=0 recipe=31,15,17,0,0,0,0'in l for l in lines)
 assert 'RILEY_PIECEWISE_WARMUP rows=1..32 complete=true capture_sealed=true'in log
 (w/'merged-dispatch-proof.json').write_text(json.dumps(dict(executed_rows=sorted(found),lines=lines,wrapper_sha256=hashlib.sha256((w/'merged-route-proof.so').read_bytes()).hexdigest(),scope='Separate instrumented finite serving child: actual successful cuBLASLt calls and read-back recipe at startup, not timing data; normal and profiler samples are separate'),indent=2))
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
