from pathlib import Path
import json,hashlib,time,subprocess,traceback,os
W=Path('/mnt/efs/nlp/psyche/riley-piecewise-v13b-20261020');B=W.parent/'riley-packed-v12b-20261020';state=dict(phase='waiting-accuracy',started_ns=time.time_ns())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():(W/'campaign-r2-state.json').write_text(json.dumps(state,indent=2))
def run(n):
 with(W/(n+'.orchestrator.log')).open('x')as f:r=subprocess.run(['python3',str(W/'run-job.py'),n],stdout=f,stderr=f)
 assert r.returncode==0,(n,r.returncode)
try:
 save()
 while True:
  p=W/'accuracy-r2-state.json'
  if p.exists():
   a=json.loads(p.read_text());assert a['phase']!='failed',a
   if a['phase']=='accuracy-complete':break
  time.sleep(3)
 manifest={f:sha(W/'source'/f)for f in json.loads((B/'source-manifest.json').read_text())};assert len(manifest)==935
 (W/'source-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True));changed={f:dict(before=v,after=manifest[f])for f,v in json.loads((B/'source-manifest.json').read_text()).items()if v!=manifest[f]}
 (W/'source-lineage.json').write_text(json.dumps(dict(parent=str(B),parent_manifest_sha256=sha(B/'source-manifest.json'),changed=changed,binary_sha256=sha(W/'riley-piecewise-v13b')),indent=2))
 # Independently verify new mixed teacher rows against both frozen references.
 receipt=json.loads((W/'observed-teacher-mixed-r2.json').read_text());assert receipt['status']=='complete'and receipt['returncode']==0
 out=W/'teacher-mixed-output';meta=json.loads((out/'result.json').read_text());rows=[r for m in meta['models']for c in m['cases']for r in c['rows']];assert len(rows)==1024
 old=W.parent/'riley-qkv-gateup-v214-20261019';hf=old/'qwen3-4b-fresh-A100-HF-v222';fixture=json.loads((hf/'fixture.json').read_text());case=next(c for c in fixture['models'][0]['cases']if c['id']=='natural-128')
 for r in rows:
  expected=next(x for x in case['steps']if x['step']==r['step']);p=hf/Path(expected['file']).name;native=old/'v226-qwen3-4b-before-C1-eager'/('qwen3-4b-natural-128-s%d.native.bf16'%r['step']);got=out/r['file'];assert got.read_bytes()==p.read_bytes()==native.read_bytes();assert sha(got)==r['sha256']==r['HF_sha256']==r['native_sha256']
 (W/'mixed-byte-audit.json').write_text(json.dumps(dict(rows=1024,all_literal_equal=True,receipt_sha256=sha(W/'observed-teacher-mixed-r2.json'),files={r['file']:r['sha256']for r in rows}),indent=2))
 state['phase']='matched-five-repeat';save()
 # Separate physical lanes. Each runner owns a finite child observer per arm.
 with(W/'final-c16.orchestrator.log').open('x')as f:
  c16=subprocess.Popen(['python3',str(W/'run-job.py'),'final-c16'],stdout=f,stderr=f)
  run('final-c32');assert c16.wait()==0
 state['phase']='matched-complete';save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
