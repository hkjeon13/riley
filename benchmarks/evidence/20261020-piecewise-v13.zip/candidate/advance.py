from pathlib import Path
import subprocess,json,time,traceback,re
W=Path('/mnt/efs/nlp/psyche/riley-piecewise-v13b-20261020');state=dict(phase='waiting-cpu',started_ns=time.time_ns())
def save():(W/'advance-state.json').write_text(json.dumps(state,indent=2))
def run(cmd,log):
 with(W/log).open('x')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(cmd,r.returncode,log)
try:
 save()
 while not(W/'native-kv-build-and-cpu.exit').exists():time.sleep(3)
 log=(W/'native-kv-regression.log').read_text();expected=['tests::c02_audit_directory_is_private_held_and_descriptor_relative','tests::c02_generation_audit_writer_creates_a_bound_leaf_and_marker_once','tests::c02_generation_audit_writer_refuses_schema_oversize_without_evidence','tests::c02_shutdown_writer_binds_raw_final_metrics_to_a_nonhidden_marker'];fail=[l.strip().split(' ... ')[0][5:]for l in log.splitlines()if l.startswith('test ')and l.endswith(' ... FAILED')];assert sorted(fail)==sorted(expected);assert sum(int(v)for v in re.findall(r'test result:.*? (\d+) passed;',log))==520
 state['phase']='c02';save();run(['python3',str(W/'recheck-c02.py'),'--allow-test-tmp'],'c02.outer.log')
 # No GPU job starts before the research child has closed and original idle hold returned.
 R=W.parent/'riley-w0-a100-gpu67-20261019'
 while any(json.loads((R/f'leases-v2/gpu{i}.status.json').read_text())['phase']!='idle'for i in [6,7]):time.sleep(2)
 state['phase']='teacher';save();run(['python3',str(W/'build-teacher-final.py')],'teacher-build.outer.log')
 while not(W/'final-teacher-state.json').exists()or json.loads((W/'final-teacher-state.json').read_text())['status']=='running':time.sleep(3)
 assert json.loads((W/'final-teacher-state.json').read_text())['status']=='complete'
 state['phase']='body-and-mixed';save();run(['python3',str(W/'prepare-body-teacher.py')],'teacher-body.outer.log')
 mix=subprocess.Popen(['python3',str(W/'prepare-mixed-teacher.py')],stdout=(W/'teacher-mixed.outer.log').open('x'),stderr=subprocess.STDOUT)
 while not(W/'observed-teacher-body-allR.json').exists()or json.loads((W/'observed-teacher-body-allR.json').read_text())['status']=='running':time.sleep(3)
 assert json.loads((W/'observed-teacher-body-allR.json').read_text())['status']=='complete';assert mix.wait()==0
 run(['python3',str(W/'audit-teachers-e.py')],'teacher-audit.outer.log')
 state.update(phase='accuracy-complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
