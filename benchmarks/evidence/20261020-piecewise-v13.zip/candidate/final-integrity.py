from pathlib import Path
import json,hashlib,re,time
W=Path(__file__).resolve().parent;E=W.parent/'riley-batched-v11e-20261020';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((W/'finish-state.json').read_text())['phase']=='complete';assert json.loads((W/'profile-stock.state.json').read_text())['status']=='complete'
frozen=json.loads((W/'frozen-identity.json').read_text());assert all(sha(W/k)==h for k,h in frozen['files'].items());manifest=json.loads((W/'source-manifest.json').read_text());assert len(manifest)==935 and all(sha(W/'source'/k)==h for k,h in manifest.items());assert sha(E/'riley-batched-v11e')==frozen['baseline_binary_sha256']
for r in json.loads((W/'changed-files.json').read_text()):assert sha(E/'source'/r['path'])==r['before_sha256']and sha(W/'source'/r['path'])==r['after_sha256']
stock=json.loads((W/'stock-installed-source-proof.json').read_text());assert all(sha(Path(r['path']))==r['sha256']for r in stock['sources'])
c02=json.loads((W/'c02-fixture-recheck-v2/complete.json').read_text());assert c02['all_passed']and len(c02['tests'])==4 and not Path(c02['temporary_root']).exists()
ordinary=re.findall(r'test result:.*',(W/'native-kv-regression.log').read_text());assert sum(int(re.search(r'(\d+) passed',v)[1])for v in ordinary)==519;assert sum(int(re.search(r'(\d+) ignored',v)[1])for v in ordinary)==40
teachers=json.loads((W/'final-teacher-audit.json').read_text())['runs'];assert sum(r['files']for r in teachers)==2464 and all(r['all_bytes_equal_to_original_native_and_HF']for r in teachers)
a=json.loads((W/'independent-audit.json').read_text());normal=[r for r in a['arms']if r['run']in ['final-c16','final-c32']];assert len(normal)==30;startup=[]
for r in normal:
 if r['record']['mode']=='vllm':continue
 p=W/'runs'/r['run']/r['arm'];argv=json.loads((p/'argv.json').read_text());assert argv[argv.index('--owned-decode-graph')+1]=='segments-v1'
 s=(p/'server.log').read_text();pre,post=s.split('riley listening on',1);assert 'capture=true'not in post;assert 'RILEY_OWNED_BODY_WARMUP rows=1..'+str(r['record']['concurrency'])+' greedy=true complete=true'in pre;startup.append(dict(arm=str(p),capture_count_before_listen=pre.count('capture=true'),capture_count_after_listen=post.count('capture=true')))
result=dict(time_ns=time.time_ns(),passed=True,source_files=935,CPU_passed=523,CPU_ignored=40,C02_fixture_temporary_tree_removed=True,teacher_BF16_files=2464,normal_arms=30,all_full_SSE_values_verified=a['total_full_SSE_values_verified'],normal_full_SSE_values_verified=sum(r['full_SSE_values_verified']for r in normal),Riley_normal_full_native_values_verified=sum(r['full_SSE_values_verified']for r in normal if r['record']['mode']!='vllm'),stock_normal_self_SSE_verified=sum(r['full_SSE_values_verified']for r in normal if r['record']['mode']=='vllm'),stock_source_unchanged=True,frozen_source_binary_runner_unchanged=True,whole_body_prelisten_startup=startup,performance_tail_flags_preserved=json.loads((W/'final-statistics.json').read_text())['cells'][0]['tail_over_two_percent_flags'])
(W/'final-integrity-audit.json').write_text(json.dumps(result,indent=2));print({k:v for k,v in result.items()if k!='whole_body_prelisten_startup'})
