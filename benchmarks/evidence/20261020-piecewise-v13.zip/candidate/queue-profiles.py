from pathlib import Path
import json,subprocess,time,traceback
W=Path('/mnt/efs/nlp/psyche/riley-piecewise-v13b-20261020');state=dict(phase='waiting-matched',started_ns=time.time_ns())
def save():(W/'profile-queue-state.json').write_text(json.dumps(state,indent=2))
def start(n):return subprocess.Popen(['python3',str(W/'run-job.py'),n],stdout=(W/(n+'.queue.log')).open('x'),stderr=subprocess.STDOUT)
try:
 save()
 while True:
  s=json.loads((W/'campaign-state.json').read_text());assert s['phase']!='failed',s
  if s['phase']=='matched-complete':break
  time.sleep(3)
 state['phase']='profiles';save();a=start('profile-c16');b=start('profile-c32');assert a.wait()==0;assert b.wait()==0
 argv=json.loads((W/'profile-c32.argv.json').read_text());argv[argv.index('--out')+1]=str(W/'runs/stock-profile-c32');argv[argv.index('--modes')+1]='vllm';argv.remove('--inspect');(W/'stock-profile-c32.argv.json').write_text(json.dumps(argv,indent=2));assert start('stock-profile-c32').wait()==0
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
