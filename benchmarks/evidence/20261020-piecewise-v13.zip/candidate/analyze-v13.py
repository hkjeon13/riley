from pathlib import Path
import json,statistics,time,ast,math,collections
w=Path('/mnt/efs/nlp/psyche/riley-piecewise-v13b-20261020');cells=[]
for c in [16,32]:
 name=f'final-c{c}';d=json.loads((w/'runs'/name/'result.json').read_text());rows=[dict(r,campaign=name)for r in d['records']];assert len(rows)==15;cells.append(dict(concurrency=c,records=rows))
(w/'primary-matrix-audit.json').write_text(json.dumps(cells,indent=2))
# TPOT tail is a percentile of per-request average inter-token latency.
# Preserve request-level evidence and the interpolation brackets independently.
proof=[]
for cell in cells:
 c=cell['concurrency']
 for r in cell['records']:
  if r['mode']=='vllm':continue
  arm=w/'runs'/r['campaign']/f"c{c}-r{r['repeat']}-{r['mode']}";req=json.loads((arm/'w0/requests.json').read_text());first=min(v['start']for v in req);values=sorted(enumerate(req),key=lambda x:x[1]['tpot_ms']);quantiles={}
  for label,q in [('p95',.95),('p99',.99)]:
   k=(len(values)-1)*q;br=[]
   for rank in sorted({math.floor(k),math.ceil(k)}):
    idx,v=values[rank];br.append(dict(rank=rank,ordinal=idx,id=v['id'],tpot_ms=v['tpot_ms'],ttft_ms=v['ttft_ms'],start_ms=(v['start']-first)*1000,output_tokens=len(v['value']['token_ids'])))
   quantiles[label]=br
  status,raw=ast.literal_eval((arm/'w0/metrics-after.txt').read_text());assert status==200;m=json.loads(raw)
  proof.append(dict(concurrency=c,repeat=r['repeat'],mode=r['mode'],tpot_brackets=quantiles,metrics=m))
(w/'tpot-tail-request-and-batch-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),scope='Request TPOT percentile brackets and final batch histograms; aggregate cadence evidence does not by itself prove causal per-request attribution',arms=proof),indent=2))
