#include <cublasLt.h>
#include <cuda_runtime_api.h>
#include <dlfcn.h>
#include <atomic>
#include <cstdio>
#include <cstdint>
#include <initializer_list>
static std::atomic<unsigned long long> calls[33]{};
using Fn=cublasStatus_t(*)(cublasLtHandle_t,cublasLtMatmulDesc_t,const void*,const void*,cublasLtMatrixLayout_t,const void*,cublasLtMatrixLayout_t,const void*,const void*,cublasLtMatrixLayout_t,void*,cublasLtMatrixLayout_t,const cublasLtMatmulAlgo_t*,void*,size_t,cudaStream_t);
extern "C" cublasStatus_t cublasLtMatmul(cublasLtHandle_t h,cublasLtMatmulDesc_t op,const void*alpha,const void*a,cublasLtMatrixLayout_t ad,const void*b,cublasLtMatrixLayout_t bd,const void*beta,const void*c,cublasLtMatrixLayout_t cd,void*d,cublasLtMatrixLayout_t dd,const cublasLtMatmulAlgo_t*algo,void*ws,size_t size,cudaStream_t stream){
 static Fn next=reinterpret_cast<Fn>(dlsym(RTLD_NEXT,"cublasLtMatmul"));
 const auto result=next(h,op,alpha,a,ad,b,bd,beta,c,cd,d,dd,algo,ws,size,stream);
 uint64_t k=0,n=0,m=0;size_t written=0;
 if(cublasLtMatrixLayoutGetAttribute(ad,CUBLASLT_MATRIX_LAYOUT_ROWS,&k,sizeof(k),&written)!=CUBLAS_STATUS_SUCCESS||cublasLtMatrixLayoutGetAttribute(ad,CUBLASLT_MATRIX_LAYOUT_COLS,&n,sizeof(n),&written)!=CUBLAS_STATUS_SUCCESS||cublasLtMatrixLayoutGetAttribute(bd,CUBLASLT_MATRIX_LAYOUT_COLS,&m,sizeof(m),&written)!=CUBLAS_STATUS_SUCCESS)return result;
 if(n==19456&&k==2560&&m>=1&&m<=32){
  auto count=calls[m].fetch_add(1);
  if(count==0){int vals[7]={};int j=0;for(auto at:{CUBLASLT_ALGO_CONFIG_ID,CUBLASLT_ALGO_CONFIG_TILE_ID,CUBLASLT_ALGO_CONFIG_STAGES_ID,CUBLASLT_ALGO_CONFIG_SPLITK_NUM,CUBLASLT_ALGO_CONFIG_REDUCTION_SCHEME,CUBLASLT_ALGO_CONFIG_CTA_SWIZZLING,CUBLASLT_ALGO_CONFIG_CUSTOM_OPTION}){if(cublasLtMatmulAlgoConfigGetAttribute(algo,at,&vals[j++],sizeof(int),&written)!=CUBLAS_STATUS_SUCCESS)j=0;}
   cudaStreamCaptureStatus capture;auto status=cudaStreamIsCapturing(stream,&capture);
   std::fprintf(stderr,"RILEY_MERGED_LT_EXECUTED N=%llu M=%llu K=%llu status=%d recipe=%d,%d,%d,%d,%d,%d,%d workspace=%zu capture_query=%d capture=%d\n",(unsigned long long)n,(unsigned long long)m,(unsigned long long)k,(int)result,vals[0],vals[1],vals[2],vals[3],vals[4],vals[5],vals[6],size,(int)status,(int)capture);
  }
 }
 return result;
}
__attribute__((destructor)) static void report(){for(int m=1;m<=32;m++)if(calls[m].load())std::fprintf(stderr,"RILEY_MERGED_LT_CALL_COUNT M=%d calls=%llu\n",m,calls[m].load());}
