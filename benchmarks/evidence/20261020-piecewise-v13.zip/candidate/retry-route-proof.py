from pathlib import Path
import json,subprocess,time,hashlib,re,traceback
w=Path('/mnt/efs/nlp/psyche/riley-piecewise-v13b-20261020');state=dict(phase='route-proof',started_ns=time.time_ns())
def save():(w/'route-queue-r2-state.json').write_text(json.dumps(state,indent=2))
try:
 save();a=json.loads((w/'route-proof-c32.argv.json').read_text());a[a.index('--out')+1]=str(w/'runs/route-proof-c32-r2');a.append('--profile');(w/'route-proof-c32-r2.argv.json').write_text(json.dumps(a,indent=2))
 with(w/'route-proof-c32-r2.queue.log').open('x')as f:r=subprocess.run(['python3',str(w/'run-job.py'),'route-proof-c32-r2'],stdout=f,stderr=f)
 assert r.returncode==0
 log=(w/'runs/route-proof-c32-r2/c32-r0-owned-after/server.log').read_text();lines=[l for l in log.splitlines()if l.startswith('RILEY_MERGED_LT_EXECUTED')];found={int(re.search(r' M=(\d+)',l)[1])for l in lines};assert found=={1,*range(17,33)},found;assert all('status=0 recipe=31,15,17,0,0,0,0'in l for l in lines)
 assert 'RILEY_PIECEWISE_WARMUP rows=1..32 complete=true capture_sealed=true'in log
 (w/'merged-dispatch-proof.json').write_text(json.dumps(dict(executed_rows=sorted(found),lines=lines,wrapper_sha256=hashlib.sha256((w/'merged-route-proof.so').read_bytes()).hexdigest(),scope='Separate instrumented profiler child: actual successful cuBLASLt calls and read-back recipe at startup, not normal timing data; failed initial non-profile invocation was refused by the runner before serving'),indent=2))
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
