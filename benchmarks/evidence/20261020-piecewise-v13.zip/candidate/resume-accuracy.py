from pathlib import Path
import subprocess,time,json,traceback
W=Path('/mnt/efs/nlp/psyche/riley-piecewise-v13b-20261020');state=dict(phase='waiting-body-and-mixed',started_ns=time.time_ns())
def save():(W/'accuracy-r2-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 for n in ['observed-teacher-body-allR','observed-teacher-mixed-r2']:
  while True:
   p=W/(n+'.json')
   if p.exists():
    s=json.loads(p.read_text())
    if s['status']!='running':assert s['status']=='complete'and s['returncode']==0,s;break
   time.sleep(3)
 with(W/'teacher-audit-r2.outer.log').open('x')as f:r=subprocess.run(['python3',str(W/'audit-teachers-e.py')],stdout=f,stderr=f)
 assert r.returncode==0
 state.update(phase='accuracy-complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
