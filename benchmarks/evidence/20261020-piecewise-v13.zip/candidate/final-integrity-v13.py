from pathlib import Path
import json,hashlib,re,time
w=Path('/mnt/efs/nlp/psyche/riley-piecewise-v13b-20261020');b=w.parent/'riley-packed-v12b-20261020';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['campaign-r2-state','profile-queue-r2-state','route-queue-r2-state']:assert json.loads((w/(n+'.json')).read_text())['phase'] in ['matched-complete','complete']
source=json.loads((w/'source-manifest.json').read_text());assert len(source)==935 and all(sha(w/'source'/f)==h for f,h in source.items());lineage=json.loads((w/'source-lineage.json').read_text());assert sha(w/'riley-piecewise-v13b')==lineage['binary_sha256'];assert sha(b/'riley-packed-v12b')=='e4a4f4cafe1d005b80e4a0dde9aed249fca3b42f2d721408895e0ce4cdca32c9'
for f,r in lineage['changed'].items():assert sha(w/'source'/f)==r['after']and sha(b/'source'/f)==r['before']
stock=json.loads((w/'stock-installed-source-proof.json').read_text());assert all(sha(Path(r['path']))==r['sha256']for r in stock['sources'])
c02=json.loads((w/'c02-fixture-recheck-v2/complete.json').read_text());assert c02['all_passed']and len(c02['tests'])==4 and not Path(c02['temporary_root']).exists()
ordinary=re.findall(r'test result:.*',(w/'native-kv-regression.log').read_text());assert sum(int(re.search(r'(\d+) passed',v)[1])for v in ordinary)==520;assert sum(int(re.search(r'(\d+) ignored',v)[1])for v in ordinary)==40
teachers=json.loads((w/'final-teacher-audit.json').read_text())['runs'];assert sum(r['files']for r in teachers)==2464 and all(r['all_bytes_equal_to_original_native_and_HF']for r in teachers);mixed=json.loads((w/'mixed-byte-audit.json').read_text());assert mixed['rows']==1024 and mixed['all_literal_equal']
a=json.loads((w/'independent-audit.json').read_text());normal=[r for r in a['arms']if r['run']in ['final-c16','final-c32']];assert len(normal)==30;startup=[]
for r in normal:
 if r['record']['mode']=='vllm':continue
 p=w/'runs'/r['run']/r['arm'];argv=json.loads((p/'argv.json').read_text());assert argv[argv.index('--owned-decode-graph')+1]=='segments-v1'
 s=(p/'server.log').read_text();pre,post=s.split('riley listening on',1);assert 'capture=true'not in post;assert 'RILEY_OWNED_BODY_WARMUP rows=1..'+str(r['record']['concurrency'])+' greedy=true complete=true'in pre
 piece=None
 if r['record']['mode']=='owned-after':
  c=r['record']['concurrency'];sealed=re.findall(r'RILEY_PIECEWISE_SEALED captures=(\d+) entries=(\d+)',pre);assert sealed and tuple(map(int,sealed[-1]))==(36*c,36*c)
  close=re.findall(r'RILEY_OWNED_SM80_MLP captures=(\d+) hits=(\d+) eager_fallbacks=(\d+) stream_resets=(\d+)',post);assert len(close)==1;captures,hits,fallback,resets=map(int,close[0]);assert captures==36*c and hits>0 and fallback==resets==0
  assert 'RILEY_PIECEWISE_WARMUP rows=1..'+str(c)+' complete=true capture_sealed=true'in pre
  piece=dict(captures=captures,hits=hits,eager_fallbacks=fallback,stream_resets=resets,additional_captures_after_listen=captures-int(sealed[-1][0]))
 startup.append(dict(arm=str(p),body_captures_before_listen=pre.count('capture=true'),body_captures_after_listen=post.count('capture=true'),piece=piece))
result=dict(time_ns=time.time_ns(),passed=True,source_files=935,changed_files=len(lineage['changed']),CPU_passed=524,CPU_ignored=40,C02_fixture_temporary_tree_removed=True,teacher_BF16_files=2464,mixed_teacher_BF16_files=1024,normal_arms=30,all_full_SSE_values_verified=a['total_full_SSE_values_verified'],normal_full_SSE_values_verified=sum(r['full_SSE_values_verified']for r in normal),Riley_normal_full_native_values_verified=sum(r['full_SSE_values_verified']for r in normal if r['record']['mode']!='vllm'),stock_normal_self_SSE_verified=sum(r['full_SSE_values_verified']for r in normal if r['record']['mode']=='vllm'),stock_source_unchanged=True,frozen_source_binary_runner_unchanged=True,normal_whole_device_peak_MiB=max(r['peak_whole_device_MiB']for r in normal),startup_and_graph_replay=startup,performance_tail_flags_preserved={str(c['concurrency']):c['tail_over_two_percent_flags']for c in json.loads((w/'final-statistics.json').read_text())['cells']},dispatch_proof=json.loads((w/'merged-dispatch-proof.json').read_text()))
(w/'final-integrity-audit.json').write_text(json.dumps(result,indent=2));(w/'finish-state.json').write_text(json.dumps(dict(phase='complete',time_ns=time.time_ns()),indent=2));print({k:v for k,v in result.items()if k not in ['startup_and_graph_replay','dispatch_proof']})
