from pathlib import Path
import zipfile,json,hashlib,difflib,time
w=Path('/mnt/efs/nlp/psyche/riley-piecewise-v13b-20261020');b=w.parent/'riley-packed-v12b-20261020';a=w.parent/'riley-piecewise-v13-20261020';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((w/'finish-state.json').read_text())['phase']=='complete';assert json.loads((w/'final-holder-audit.json').read_text())['passed']
lineage=json.loads((w/'source-lineage.json').read_text());patch=''
for f in lineage['changed']:
 before=(b/'source'/f).read_text().splitlines(True);after=(w/'source'/f).read_text().splitlines(True);patch+=''.join(difflib.unified_diff(before,after,fromfile='v12B/'+f,tofile='v13B/'+f))
(w/'v12B-to-v13B.patch').write_text(patch)
heavy=[]
for directory in [w/'final-teacher-C1-eager',w/'final-teacher-allR-Graph',w/'teacher-body-allR',w/'teacher-mixed-output',w/'runs']:
 for p in directory.rglob('*'):
  if p.is_file()and p.suffix in ['.bf16','.sqlite','.nsys-rep']:
   heavy.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
(w/'heavy-efs-evidence-index.json').write_text(json.dumps(dict(time_ns=time.time_ns(),files=heavy,scope='Full vocabulary BF16 and original Nsight traces retained on EFS; compact archive includes hashes and derived audits'),indent=2))
files={}
for p in w.iterdir():
 if p.is_file()and p.suffix in ['.py','.rs','.cpp','.sh','.json','.log','.txt','.sha256','.md','.stderr','.stdout','.jsonl','.patch','.so']:files['candidate/'+p.name]=p
for p in (w/'runs').rglob('*'):
 if p.is_file()and not any(t in p.relative_to(w/'runs').parts for t in ['cache','tmp','vllm-cache'])and p.suffix in ['.json','.log','.txt','.stdout','.stderr']:
  files['candidate/'+str(p.relative_to(w))]=p
for folder in ['c02-fixture-recheck-v2','failed-compile-1']:
 for p in (w/folder).rglob('*'):
  if p.is_file():files['candidate/'+str(p.relative_to(w))]=p
for p in (a/'research').iterdir():
 if p.is_file()and p.suffix in ['.json','.log','.stdout','.stderr','.jsonl','.cu','.cuh','.tsv']:
  files['research/'+p.name]=p
for p in a.iterdir():
 if p.is_file()and (p.name.startswith('observed-final-teacher-allR-Graph')or p.name in ['advance-state.json','qualification-binary.sha256','WORKSTATE.md']):files['failed-v13A/'+p.name]=p
# Preserve the final source of each changed file without copying prior unrelated source.
for f in lineage['changed']:files['changed-source/'+f]=w/'source'/f
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p),efs_path=str(p))for n,p in files.items()};raw=json.dumps(dict(time_ns=time.time_ns(),entries=manifest),indent=2).encode()
out=w/'piecewise-v13-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('archive-manifest.json',raw)
receipt=dict(path=str(out),bytes=out.stat().st_size,sha256=sha(out),files=len(files)+1);(w/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(receipt)
