// Research only: classify native same-SM80 M1 vs batched GEMM equality.
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <mma.h>
#include <cublas_v2.h>
#include <cublasLt.h>
#include <algorithm>
#include <openssl/sha.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <stdexcept>
#include <filesystem>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <unistd.h>
using U=uint16_t;
#define CU(x) do{if((x)!=cudaSuccess)throw std::runtime_error("CUDA API failed");}while(0)
#define BL(x) do{if((x)!=CUBLAS_STATUS_SUCCESS)throw std::runtime_error("cuBLAS API failed");}while(0)
std::string sha(const std::vector<U>&x){unsigned char d[32];SHA256((const unsigned char*)x.data(),x.size()*2,d);static const char*h="0123456789abcdef";std::string s;for(auto c:d){s+=h[c>>4];s+=h[c&15];}return s;}
std::vector<U>read(const std::string&p,size_t bytes,const std::string&digest){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f||uint64_t(f.tellg())!=bytes||bytes%2||bytes>(1ull<<30))throw std::runtime_error("input size");std::vector<U>x(bytes/2);f.seekg(0);f.read((char*)x.data(),bytes);if(!f||sha(x)!=digest)throw std::runtime_error("input SHA256");return x;}
float cv(U x){uint32_t b=uint32_t(x)<<16;float f;memcpy(&f,&b,4);return f;}
U bf(float f){uint32_t b;memcpy(&b,&f,4);return U((b+0x7fff+((b>>16)&1))>>16);}
void save(const std::string&p,const std::vector<U>&x){if(std::filesystem::exists(p))throw std::runtime_error("raw exists");std::ofstream f(p,std::ios::binary);f.write((const char*)x.data(),x.size()*2);if(!f)throw std::runtime_error("raw save");}


__device__ __forceinline__ void cp16(void*dst,const void*src,bool valid){unsigned sm=static_cast<unsigned>(__cvta_generic_to_shared(dst));asm volatile("cp.async.cg.shared.global [%0], [%1], 16, %2;"::"r"(sm),"l"(src),"r"(valid?16:0));}
template<int W,int R,int P,int S,int T>__device__ __forceinline__ void next_stage(__nv_bfloat16*dst,const __nv_bfloat16*w,const __nv_bfloat16*x,int rows,int col,int first,int split,int it){
 constexpr int N=W*16,L=T+P;int kbase=it*T;
 for(int i=threadIdx.x;i<(N+R)*(T/8);i+=W*32){int row=i/(T/8),k=(i%(T/8))*8;bool a=row<N;int xr=row-N;bool valid=it<2560/T&&(a||first+xr<rows);const __nv_bfloat16*src=valid?(a?w+(col+row)*2560+kbase+k:x+(first+xr)*2560+kbase+k):w;cp16(dst+row*L+k,src,valid);}
 asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S,int T>__global__ void gate_tile_v10(const __nv_bfloat16*w,const __nv_bfloat16*x,__nv_bfloat16*parts,int rows){
 using namespace nvcuda;constexpr int N=W*16,L=T+P,Stage=(N+R)*L,RB=R/16;
 __shared__ __align__(32)__nv_bfloat16 shared[Stage*S];int col=blockIdx.x*N,first=blockIdx.y*R,split=blockIdx.z,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;
 wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;
 wmma::fragment<wmma::accumulator,16,16,16,float>c[RB][2];
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::fill_fragment(c[rb][0],0.f);wmma::fill_fragment(c[rb][1],0.f);}
 #pragma unroll
 for(int st=0;st<S;st++)next_stage<W,R,P,S,T>(shared+st*Stage,w,x,rows,col,first,split,st);
 for(int it=0;it<2560/T;it++){
  asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+(it%S)*Stage;
  #pragma unroll
  for(int j=0;j<T/16;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
   #pragma unroll
   for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb][(j/2)%2],a,b,c[rb][(j/2)%2]);}}
  __syncthreads();next_stage<W,R,P,S,T>(t,w,x,rows,col,first,split,it+S);
 }
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){
  for(int i=0;i<c[rb][0].num_elements;i++)c[rb][0].x[i]=__fadd_rn(c[rb][0].x[i],c[rb][1].x[i]);
  float*out=reinterpret_cast<float*>(shared)+(warp*RB+rb)*256;wmma::store_matrix_sync(out,c[rb][0],16,wmma::mem_col_major);__syncwarp();
  for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows)parts[row*9728+col+warp*16+i%16]=__float2bfloat16_rn(__fmaf_rn(1.f,out[i],0.f));}
 }
}
template<int W,int R,int P,int S>__device__ __forceinline__ void gateup_stage(__nv_bfloat16*dst,const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,int rows,int col,int first,int it){
 constexpr int N=W*16,L=64+P;for(int i=threadIdx.x;i<(N+R)*8;i+=W*32){int row=i/8,k=i%8*8;bool weight=row<N,valid=it<40&&(weight||first+row-N<rows);const __nv_bfloat16*src=wg;if(valid)src=weight?((row<N/2?wg:wu)+(col+row%(N/2))*2560+it*64+k):(x+(first+row-N)*2560+it*64+k);cp16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void sm80_fused_gateup(const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,__nv_bfloat16*y,int rows){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=64+P,Stage=(N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];auto results=reinterpret_cast<float (*)[RB][256]>(shared);int col=blockIdx.x*(N/2),first=blockIdx.y*R,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB][2];
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::fill_fragment(c[rb][0],0.f);wmma::fill_fragment(c[rb][1],0.f);}
 #pragma unroll
 for(int st=0;st<S;st++)gateup_stage<W,R,P,S>(shared+st*Stage,wg,wu,x,rows,col,first,st);
 for(int it=0;it<40;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+it%S*Stage;
 #pragma unroll
 for(int j=0;j<4;j++){wmma::load_matrix_sync(a,t+warp*16*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(N+rb*16)*L+j*16,L);wmma::mma_sync(c[rb][j/2],a,b,c[rb][j/2]);}}
 __syncthreads();gateup_stage<W,R,P,S>(t,wg,wu,x,rows,col,first,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){for(int i=0;i<c[rb][0].num_elements;i++)c[rb][0].x[i]=__fadd_rn(c[rb][0].x[i],c[rb][1].x[i]);wmma::store_matrix_sync(results[warp][rb],c[rb][0],16,wmma::mem_col_major);}
 __syncthreads();if(warp<W/2){
 #pragma unroll
 for(int rb=0;rb<RB;rb++)for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows){float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp][rb][i],0.f)));float u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp+W/2][rb][i],0.f)));float activated=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[row*9728+col+warp*16+i%16]=__float2bfloat16_rn(__fmul_rn(activated,u));}}}
#endif
}
// Each warp owns Gate and Up for the same output tile. Preserve both native
// K32 accumulation chains; combine/round/SiLU in registers before one store.
template<int W,int R,int P,int S>__device__ __forceinline__ void pair_gateup_stage(__nv_bfloat16*dst,const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,int rows,int col,int first,int it){
 constexpr int N=W*16,L=128+P;for(int i=threadIdx.x;i<(2*N+R)*16;i+=W*32){int row=i/16,k=i%16*8;bool weight=row<2*N,valid=it<20&&(weight||first+row-2*N<rows);const __nv_bfloat16*src=wg;if(valid)src=weight?((row<N?wg:wu)+(col+row%N)*2560+it*128+k):(x+(first+row-2*N)*2560+it*128+k);cp16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void sm80_pair_gateup(const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,__nv_bfloat16*y,int rows){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=128+P,Stage=(2*N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];int col=blockIdx.x*N,first=blockIdx.y*R,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>ag,au;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>cg[RB][2],cu[RB][2];
 #pragma unroll
 for(int rb=0;rb<RB;rb++)for(int j=0;j<2;j++){wmma::fill_fragment(cg[rb][j],0.f);wmma::fill_fragment(cu[rb][j],0.f);}
 #pragma unroll
 for(int st=0;st<S;st++)pair_gateup_stage<W,R,P,S>(shared+st*Stage,wg,wu,x,rows,col,first,st);
 for(int it=0;it<20;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+it%S*Stage;
 #pragma unroll
 for(int j=0;j<8;j++){wmma::load_matrix_sync(ag,t+warp*16*L+j*16,L);wmma::load_matrix_sync(au,t+(N+warp*16)*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(2*N+rb*16)*L+j*16,L);wmma::mma_sync(cg[rb][(j/2)%2],ag,b,cg[rb][(j/2)%2]);wmma::mma_sync(cu[rb][(j/2)%2],au,b,cu[rb][(j/2)%2]);}}
 __syncthreads();pair_gateup_stage<W,R,P,S>(t,wg,wu,x,rows,col,first,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){for(int i=0;i<cg[rb][0].num_elements;i++){float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(cg[rb][0].x[i],cg[rb][1].x[i]),0.f)));float u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(cu[rb][0].x[i],cu[rb][1].x[i]),0.f)));float a=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));cg[rb][0].x[i]=__fmul_rn(a,u);}
 float*out=reinterpret_cast<float*>(shared)+(warp*RB+rb)*256;wmma::store_matrix_sync(out,cg[rb][0],16,wmma::mem_col_major);__syncwarp();for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows)y[row*9728+col+warp*16+i%16]=__float2bfloat16_rn(out[i]);}}
#endif
}
__global__ void product(const __nv_bfloat16*g,const __nv_bfloat16*u,__nv_bfloat16*y,int count){int i=blockIdx.x*256+threadIdx.x;if(i<count){float a=__bfloat162float(g[i]),b=__bfloat162float(u[i]);float c=__bfloat162float(__float2bfloat16_rn(a/(1.f+expf(-a))));y[i]=__float2bfloat16_rn(__fmul_rn(c,b));}}
template<int W,int R,int P,int S>void test(cublasHandle_t h,cudaStream_t s,U*wg,U*wu,U*x,U*g,U*u,U*y,const std::vector<std::vector<U>>&xs,const std::vector<std::vector<U>>&gold){
 auto candidate=[&](int rows){sm80_pair_gateup<W,R,P,S><<<dim3(9728/(W*16),(rows+R-1)/R),W*32,0,s>>>((const __nv_bfloat16*)wg,(const __nv_bfloat16*)wu,(const __nv_bfloat16*)x,(__nv_bfloat16*)y,rows);CU(cudaGetLastError());};
 auto baseline=[&](int rows){if(rows<=16)sm80_fused_gateup<4,16,16,2><<<dim3(304,(rows+15)/16),128,0,s>>>((const __nv_bfloat16*)wg,(const __nv_bfloat16*)wu,(const __nv_bfloat16*)x,(__nv_bfloat16*)y,rows);else sm80_fused_gateup<4,32,8,2><<<dim3(304,(rows+31)/32),128,0,s>>>((const __nv_bfloat16*)wg,(const __nv_bfloat16*)wu,(const __nv_bfloat16*)x,(__nv_bfloat16*)y,rows);CU(cudaGetLastError());};
 for(int st=0;st<6;st++){CU(cudaMemcpyAsync(x,xs[st].data(),xs[st].size()*2,cudaMemcpyHostToDevice,s));for(int rows=1;rows<=32;rows++){candidate(rows);CU(cudaStreamSynchronize(s));std::vector<U>a(rows*9728);CU(cudaMemcpy(a.data(),y,a.size()*2,cudaMemcpyDeviceToHost));size_t bad=0;for(size_t i=0;i<a.size();i++)bad+=a[i]!=gold[st][i];if(bad){printf("{\"W\":%d,\"R\":%d,\"state\":%d,\"rows\":%d,\"changed\":%zu}\n",W,R,st,rows,bad);fflush(stdout);return;}}}
 printf("{\"W\":%d,\"R\":%d,\"P\":%d,\"S\":%d,\"comparisons\":192,\"changed\":0}\n",W,R,P,S);fflush(stdout);CU(cudaMemcpyAsync(x,xs[0].data(),xs[0].size()*2,cudaMemcpyHostToDevice,s));
 auto time=[&](auto fn){for(int j=0;j<8;j++)fn();CU(cudaStreamSynchronize(s));cudaGraph_t g;cudaGraphExec_t e;CU(cudaStreamBeginCapture(s,cudaStreamCaptureModeThreadLocal));for(int j=0;j<64;j++)fn();CU(cudaStreamEndCapture(s,&g));CU(cudaGraphInstantiate(&e,g,nullptr,nullptr,0));cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaGraphLaunch(e,s));CU(cudaEventRecord(a,s));for(int j=0;j<8;j++)CU(cudaGraphLaunch(e,s));CU(cudaEventRecord(b,s));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));CU(cudaGraphExecDestroy(e));CU(cudaGraphDestroy(g));return ms*1000/(64*8);};
 for(int rep=0;rep<3;rep++)for(int rows:{8,12,16,24,32}){float a,b;if(rep%2){b=time([&]{candidate(rows);});a=time([&]{baseline(rows);});}else{a=time([&]{baseline(rows);});b=time([&]{candidate(rows);});}printf("{\"W\":%d,\"R\":%d,\"P\":%d,\"S\":%d,\"repeat\":%d,\"rows\":%d,\"baseline_us\":%f,\"candidate_us\":%f}\n",W,R,P,S,rep,rows,a,b);fflush(stdout);}
}
int main(int argc,char**argv){try{if(argc!=2)return 1;cudaDeviceProp prop;CU(cudaGetDeviceProperties(&prop,0));if(prop.major!=8||prop.minor!=0||prop.multiProcessorCount!=108)throw std::runtime_error("SM80");std::ifstream f(argv[1]);std::vector<std::vector<std::string>>a;std::string line,z;while(getline(f,line)){std::stringstream ss(line);std::vector<std::string>b;while(getline(ss,z,'\t'))b.push_back(z);a.push_back(b);}auto seed=read(a[0][3],128ul*2560*2,a[0][4]),w0=read(a[0][5],9728ul*2560*2,a[0][6]),w1=read(a[1][5],9728ul*2560*2,a[1][6]);U *wg,*wu,*x,*g,*u,*y;CU(cudaMalloc(&wg,w0.size()*2));CU(cudaMalloc(&wu,w1.size()*2));CU(cudaMalloc(&x,32ul*2560*2));CU(cudaMalloc(&g,32ul*9728*2));CU(cudaMalloc(&u,32ul*9728*2));CU(cudaMalloc(&y,32ul*9728*2));CU(cudaMemcpy(wg,w0.data(),w0.size()*2,cudaMemcpyHostToDevice));CU(cudaMemcpy(wu,w1.data(),w1.size()*2,cudaMemcpyHostToDevice));cudaStream_t s;CU(cudaStreamCreateWithFlags(&s,cudaStreamNonBlocking));cublasHandle_t h;BL(cublasCreate(&h));BL(cublasSetStream(h,s));int ver;BL(cublasGetVersion(h,&ver));if(ver!=120405)throw std::runtime_error("cuBLAS");BL(cublasSetMathMode(h,CUBLAS_DEFAULT_MATH));BL(cublasSetAtomicsMode(h,CUBLAS_ATOMICS_NOT_ALLOWED));std::vector<std::vector<U>>xs(6),gold(6);float alpha=1,beta=0;
 for(int st=0;st<6;st++){auto&v=xs[st];v.resize(32ul*2560);for(size_t i=0;i<v.size();i++)v[i]=st==0?seed[i]:st==1?0:st==2?bf(cv(seed[(i*13+37)%v.size()])*(i%3==0?-.5f:1.5f)):st==3?bf((int(i%17)-8)*.125f):st==4?bf((i%2?-1:1)*.0009765625f):bf(cv(seed[(i*7+19)%v.size()])*4.f);CU(cudaMemcpyAsync(x,v.data(),v.size()*2,cudaMemcpyHostToDevice,s));for(int r=0;r<32;r++)for(int which=0;which<2;which++)BL(cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,9728,1,2560,&alpha,which?wu:wg,CUDA_R_16BF,2560,x+r*2560,CUDA_R_16BF,2560,&beta,(which?u:g)+r*9728,CUDA_R_16BF,9728,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));product<<<(32*9728+255)/256,256,0,s>>>((const __nv_bfloat16*)g,(const __nv_bfloat16*)u,(__nv_bfloat16*)y,32*9728);CU(cudaStreamSynchronize(s));gold[st].resize(32ul*9728);CU(cudaMemcpy(gold[st].data(),y,gold[st].size()*2,cudaMemcpyDeviceToHost));}
 test<2,16,8,2>(h,s,wg,wu,x,g,u,y,xs,gold);test<2,32,0,2>(h,s,wg,wu,x,g,u,y,xs,gold);test<4,16,0,1>(h,s,wg,wu,x,g,u,y,xs,gold);test<4,32,0,1>(h,s,wg,wu,x,g,u,y,xs,gold);test<1,16,8,2>(h,s,wg,wu,x,g,u,y,xs,gold);return 0;}catch(const std::exception&e){fprintf(stderr,"%s\n",e.what());return 1;}}
