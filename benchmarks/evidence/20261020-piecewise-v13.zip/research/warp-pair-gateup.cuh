// Each warp owns Gate and Up for the same output tile. Preserve both native
// K32 accumulation chains; combine/round/SiLU in registers before one store.
template<int W,int R,int P,int S>__device__ __forceinline__ void pair_gateup_stage(__nv_bfloat16*dst,const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,int rows,int col,int first,int it){
 constexpr int N=W*16,L=64+P;for(int i=threadIdx.x;i<(2*N+R)*8;i+=W*32){int row=i/8,k=i%8*8;bool weight=row<2*N,valid=it<40&&(weight||first+row-2*N<rows);const __nv_bfloat16*src=wg;if(valid)src=weight?((row<N?wg:wu)+(col+row%N)*2560+it*64+k):(x+(first+row-2*N)*2560+it*64+k);sm80_down_copy16(dst+row*L+k,src,valid);}asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S>__global__ void sm80_pair_gateup(const __nv_bfloat16*wg,const __nv_bfloat16*wu,const __nv_bfloat16*x,__nv_bfloat16*y,int rows){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
 using namespace nvcuda;constexpr int N=W*16,L=64+P,Stage=(2*N+R)*L,RB=R/16;__shared__ __align__(32)__nv_bfloat16 shared[Stage*S];int col=blockIdx.x*N,first=blockIdx.y*R,warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major>ag,au;wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>cg[RB][2],cu[RB][2];
 #pragma unroll
 for(int rb=0;rb<RB;rb++)for(int j=0;j<2;j++){wmma::fill_fragment(cg[rb][j],0.f);wmma::fill_fragment(cu[rb][j],0.f);}
 #pragma unroll
 for(int st=0;st<S;st++)pair_gateup_stage<W,R,P,S>(shared+st*Stage,wg,wu,x,rows,col,first,st);
 for(int it=0;it<40;it++){asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=shared+it%S*Stage;
 #pragma unroll
 for(int j=0;j<4;j++){wmma::load_matrix_sync(ag,t+warp*16*L+j*16,L);wmma::load_matrix_sync(au,t+(N+warp*16)*L+j*16,L);
 #pragma unroll
 for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,t+(2*N+rb*16)*L+j*16,L);wmma::mma_sync(cg[rb][j/2],ag,b,cg[rb][j/2]);wmma::mma_sync(cu[rb][j/2],au,b,cu[rb][j/2]);}}
 __syncthreads();pair_gateup_stage<W,R,P,S>(t,wg,wu,x,rows,col,first,it+S);}
 asm volatile("cp.async.wait_group 0;");__syncthreads();
 #pragma unroll
 for(int rb=0;rb<RB;rb++){for(int i=0;i<cg[rb][0].num_elements;i++){float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(cg[rb][0].x[i],cg[rb][1].x[i]),0.f)));float u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,__fadd_rn(cu[rb][0].x[i],cu[rb][1].x[i]),0.f)));float a=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));cg[rb][0].x[i]=__fmul_rn(a,u);}
 float*out=reinterpret_cast<float*>(shared)+(warp*RB+rb)*256;wmma::store_matrix_sync(out,cg[rb][0],16,wmma::mem_col_major);__syncwarp();for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows)y[row*9728+col+warp*16+i%16]=__float2bfloat16_rn(out[i]);}}
#endif
}
