//! Owning, fixed-sequence CUDA execution path for the PR07 Llama reference graph.

#![cfg_attr(all(test, not(feature = "cuda")), allow(dead_code))]

use std::error;
use std::fmt;
use std::mem;

use riley_cuda::{
    AttentionBackend, AttentionBackendAvailability, AttentionMask, AttentionPreference,
    AttentionSelectionTrace, BiasGemmParams, CudaBufferSpan, CudaBufferSpanMut, CudaContext,
    CudaDType, CudaDeviceBuffer, CudaError, CudaErrorStage, CudaExecutionStream, CudaGemmConfig,
    CudaPinnedHostBuffer, CudaPreparedBiasEpilogueGemm, CudaPreparedFixed37Gemm, CudaPreparedGemm,
    CudaStream, EmbeddingError, EmbeddingParams, Fixed37GemmParams, GatedMultiplyParams,
    GemmParams, PrefillAttentionParams, PrefillAttentionRequest, PreparedPrefillAttention,
    ResidualAddParams, ResidualRmsNormParams, RmsNormParams, RopeParams, RopeTableParams,
    RowBiasAddInPlaceParams, SiluParams, embedding, fixed37_residual_rms_norm, fixed37_rms_norm,
    gated_multiply, hugging_face_smollm2_residual_rms_norm, hugging_face_smollm2_rms_norm,
    residual_add, residual_rms_norm, rms_norm, rope, rope_table, row_bias_add_in_place, silu,
};
#[cfg(feature = "cuda-cublas-gemm-probe")]
use riley_cuda::{
    CublasGemmProbeParams, CudaGemmReductionPolicy, CudaPreparedCublasGemmProbe,
    hugging_face_qwen_p2051_rms_norm, hugging_face_qwen_wide_rms_norm_row_groups,
};
use riley_model::{LoadedModel, ModelConfig};

use super::decode::PrefillKvCacheSink;
use super::gemm_policy::{
    LlamaGemmReductionPolicies, canonical_gemm_reduction_policies,
    canonical_prefill_attention_preference, is_reviewed_smollm2_rms_norm_geometry,
    is_reviewed_smollm2_rope_geometry,
};
use super::{
    ExecutionSite, LlamaDimensions, LlamaExecutionPlan, LlamaOp, LlamaPlanError,
    LlamaReductionProfile, PhysicalWeightId,
};
use crate::cuda_weights::{CudaUploadedWeights, CudaWeightUploadError};

const DEFAULT_UPLOAD_STAGING_BYTES: u64 = 4 * 1024 * 1024;
const DEFAULT_IO_STAGING_BYTES: u64 = 4 * 1024 * 1024;
const DEFAULT_GEMM_WORKSPACE_CAP_BYTES: u64 = 16 * 1024 * 1024;
const DEFAULT_ATTENTION_BUDGET_BYTES: u64 = 1_342_177_280;
const BF16_BYTES: u64 = 2;
// Token IDs + 5 hidden + 3 key/value + 4 intermediate + 2 RoPE tables +
// logits + embedding-error scratch. Attention and GEMM workspaces are optional.
const NON_ATTENTION_GRAPH_ALLOCATION_COUNT: u64 = 17;
const TRACE_POINT_COUNT: usize = 18;
const TRACE_STORAGE_POINT_COUNT: usize = 23;
const LAST_TOKEN_LAYER_STAGE_COUNT: usize = 14;

/// Result type for preparing, executing, downloading, and closing PR07 forward state.
pub type LlamaForwardResult<T> = Result<T, LlamaForwardError>;

/// Named owning resource used by cleanup and allocation diagnostics.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[non_exhaustive]
pub enum LlamaForwardResource {
    UploadedWeights,
    UploadStaging,
    IoStaging,
    HiddenGemm,
    KeyValueGemm,
    QueryBiasEpilogueGemm,
    KeyValueBiasEpilogueGemm,
    OutputProjectionDirectCublasGemm,
    MlpIntermediateDirectCublasGemm,
    MlpDownDirectCublasGemm,
    LmHeadLastTokenDirectCublasGemm,
    IntermediateGemm,
    DownGemm,
    LmHeadGemm,
    TokenIds,
    HiddenCurrent,
    HiddenNorm,
    HiddenProjection,
    HiddenRotary,
    HiddenContext,
    KeyRaw,
    ValueRaw,
    KeyRotary,
    GateRaw,
    UpRaw,
    GateActivated,
    GatedProduct,
    Attention,
    RopeCos,
    RopeSin,
    Logits,
    EmbeddingErrorScratch,
    GemmWorkspace,
    TraceCapture,
}

/// Stable diagnostic checkpoints emitted by a traced PR07 reference forward.
///
/// The order and names match the pinned Hugging Face PR07 trace artifact. A
/// production [`PreparedLlamaForward::execute`] does not capture or transfer
/// any of these tensors; callers must explicitly prepare a trace and use
/// [`PreparedLlamaForward::execute_traced`].
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(u8)]
pub enum LlamaTracePoint {
    Embedding,
    Layer0InputNorm,
    Layer0QueryProjection,
    Layer0KeyProjection,
    Layer0ValueProjection,
    Layer0AttentionProbabilities,
    Layer0AttentionContext,
    Layer0AfterAttentionResidual,
    Layer0PostAttentionNorm,
    Layer0GateProjection,
    Layer0UpProjection,
    Layer0Gated,
    Layer0DownProjection,
    Layer0Output,
    Layer14Output,
    FinalNormInput,
    FinalNormOutput,
    LastLogits,
    /// Layer-zero query after rotary positional embedding.
    Layer0QueryRotary,
    /// Layer-zero key after rotary positional embedding.
    Layer0KeyRotary,
    /// Layer-zero query projection output before its bias addition.
    Layer0QueryProjectionUnbiasedLinear,
    /// Layer-zero key projection output before its bias addition.
    Layer0KeyProjectionUnbiasedLinear,
    /// Layer-zero value projection output before its bias addition.
    Layer0ValueProjectionUnbiasedLinear,
}

impl LlamaTracePoint {
    /// Every checkpoint in canonical artifact order.
    pub const ALL: [Self; TRACE_POINT_COUNT] = [
        Self::Embedding,
        Self::Layer0InputNorm,
        Self::Layer0QueryProjection,
        Self::Layer0KeyProjection,
        Self::Layer0ValueProjection,
        Self::Layer0AttentionProbabilities,
        Self::Layer0AttentionContext,
        Self::Layer0AfterAttentionResidual,
        Self::Layer0PostAttentionNorm,
        Self::Layer0GateProjection,
        Self::Layer0UpProjection,
        Self::Layer0Gated,
        Self::Layer0DownProjection,
        Self::Layer0Output,
        Self::Layer14Output,
        Self::FinalNormInput,
        Self::FinalNormOutput,
        Self::LastLogits,
    ];

    /// Every diagnostic checkpoint supported by the trace owner.
    ///
    /// Extra diagnostic checkpoints are deliberately outside of ALL because
    /// ALL remains the immutable PR07 Hugging Face artifact contract.
    const STORAGE: [Self; TRACE_STORAGE_POINT_COUNT] = [
        Self::Embedding,
        Self::Layer0InputNorm,
        Self::Layer0QueryProjection,
        Self::Layer0KeyProjection,
        Self::Layer0ValueProjection,
        Self::Layer0AttentionProbabilities,
        Self::Layer0AttentionContext,
        Self::Layer0AfterAttentionResidual,
        Self::Layer0PostAttentionNorm,
        Self::Layer0GateProjection,
        Self::Layer0UpProjection,
        Self::Layer0Gated,
        Self::Layer0DownProjection,
        Self::Layer0Output,
        Self::Layer14Output,
        Self::FinalNormInput,
        Self::FinalNormOutput,
        Self::LastLogits,
        Self::Layer0QueryRotary,
        Self::Layer0KeyRotary,
        Self::Layer0QueryProjectionUnbiasedLinear,
        Self::Layer0KeyProjectionUnbiasedLinear,
        Self::Layer0ValueProjectionUnbiasedLinear,
    ];

    /// Stable tensor name used by trace artifacts.
    #[must_use]
    pub const fn name(self) -> &'static str {
        match self {
            Self::Embedding => "embedding",
            Self::Layer0InputNorm => "layer0.input_norm",
            Self::Layer0QueryProjection => "layer0.q_proj",
            Self::Layer0KeyProjection => "layer0.k_proj",
            Self::Layer0ValueProjection => "layer0.v_proj",
            Self::Layer0AttentionProbabilities => "layer0.attention_probs",
            Self::Layer0AttentionContext => "layer0.attention_context",
            Self::Layer0AfterAttentionResidual => "layer0.after_attention_residual",
            Self::Layer0PostAttentionNorm => "layer0.post_attention_norm",
            Self::Layer0GateProjection => "layer0.gate_proj",
            Self::Layer0UpProjection => "layer0.up_proj",
            Self::Layer0Gated => "layer0.gated",
            Self::Layer0DownProjection => "layer0.down_proj",
            Self::Layer0Output => "layer0.output",
            Self::Layer14Output => "layer14.output",
            Self::FinalNormInput => "final_norm.input",
            Self::FinalNormOutput => "final_norm.output",
            Self::LastLogits => "last_logits",
            Self::Layer0QueryRotary => "layer0.q_rope",
            Self::Layer0KeyRotary => "layer0.k_rope",
            Self::Layer0QueryProjectionUnbiasedLinear => "layer0.q_proj.unbiased_linear",
            Self::Layer0KeyProjectionUnbiasedLinear => "layer0.k_proj.unbiased_linear",
            Self::Layer0ValueProjectionUnbiasedLinear => "layer0.v_proj.unbiased_linear",
        }
    }

    const fn index(self) -> usize {
        self as usize
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct LlamaTraceContract {
    sequence_length: usize,
    layer_count: usize,
    dimensions: LlamaDimensions,
}

/// Caller-owned host storage for an explicit diagnostic forward trace.
///
/// Storage is allocated before execution and reused by every traced run. Each
/// successful checkpoint transfer sets one captured bit, so a failed run still
/// identifies the last confirmed tensor without publishing stale later data.
pub struct PreparedLlamaTrace {
    contract: LlamaTraceContract,
    tensors: Box<[Box<[u8]>]>,
    requested: u32,
    captured: u32,
}

impl fmt::Debug for PreparedLlamaTrace {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("PreparedLlamaTrace")
            .field("contract", &self.contract)
            .field("requested", &self.tensor_count())
            .field("captured", &self.captured_count())
            .finish_non_exhaustive()
    }
}

impl PreparedLlamaTrace {
    fn prepare(plan: &LlamaExecutionPlan, points: &[LlamaTracePoint]) -> LlamaForwardResult<Self> {
        let requested = points
            .iter()
            .fold(0_u32, |mask, &point| mask | trace_bit(point));
        if requested & trace_bit(LlamaTracePoint::Layer14Output) != 0 && plan.layers().len() <= 14 {
            return Err(LlamaForwardError::TraceLayerUnavailable {
                required_layers: 15,
                actual_layers: plan.layers().len(),
            });
        }
        let contract = trace_contract(plan);
        let requested_bytes = trace_total_bytes(plan, requested)?;
        let mut tensors = Vec::new();
        tensors
            .try_reserve_exact(TRACE_STORAGE_POINT_COUNT)
            .map_err(|_| LlamaForwardError::HostAllocation {
                resource: LlamaForwardResource::TraceCapture,
                requested_bytes,
            })?;
        for point in LlamaTracePoint::STORAGE {
            tensors.push(if requested & trace_bit(point) == 0 {
                Box::default()
            } else {
                allocate_host_bytes(
                    trace_byte_len(plan, point)?,
                    LlamaForwardResource::TraceCapture,
                )?
            });
        }
        Ok(Self {
            contract,
            tensors: tensors.into_boxed_slice(),
            requested,
            captured: 0,
        })
    }

    /// Number of checkpoints requested by this trace owner.
    #[must_use]
    pub fn tensor_count(&self) -> usize {
        usize::try_from(self.requested.count_ones()).unwrap_or(TRACE_STORAGE_POINT_COUNT)
    }

    /// Number of checkpoints confirmed during the latest traced execution.
    #[must_use]
    pub const fn captured_count(&self) -> u32 {
        self.captured.count_ones()
    }

    /// Returns a captured BF16 tensor, or `None` before that checkpoint ran.
    #[must_use]
    pub fn tensor(&self, point: LlamaTracePoint) -> Option<&[u8]> {
        if self.captured & trace_bit(point) == 0 {
            return None;
        }
        self.tensors.get(point.index()).map(AsRef::as_ref)
    }

    /// Exact byte length reserved for one BF16 checkpoint tensor.
    #[must_use]
    pub fn tensor_byte_len(&self, point: LlamaTracePoint) -> usize {
        self.tensors[point.index()].len()
    }

    /// Whether this owner reserved and will capture one checkpoint.
    #[must_use]
    pub const fn requests(&self, point: LlamaTracePoint) -> bool {
        self.requested & trace_bit(point) != 0
    }

    fn validate(&self, plan: &LlamaExecutionPlan) -> LlamaForwardResult<()> {
        if self.contract != trace_contract(plan) {
            return Err(LlamaForwardError::TracePlanMismatch);
        }
        Ok(())
    }

    fn reset(&mut self) {
        self.captured = 0;
    }

    fn destination(&mut self, point: LlamaTracePoint) -> &mut [u8] {
        self.tensors[point.index()].as_mut()
    }

    fn mark_captured(&mut self, point: LlamaTracePoint) {
        self.captured |= trace_bit(point);
    }
}

/// Caller-owned storage for the last BF16 residual row from selected decoder
/// layers of one diagnostic forward.
///
/// Unlike [`PreparedLlamaTrace`], this type intentionally has no stable
/// artifact-point names. It is a bounded, caller-selected layer probe used to
/// localize a numerical divergence without downloading whole `[S, H]` tensors.
/// The requested layer indices are sorted and deduplicated during preparation.
/// A production [`PreparedLlamaForward::execute`] neither allocates this owner
/// nor executes its capture path; callers must explicitly prepare it and use
/// [`PreparedLlamaForward::execute_last_token_layer_traced`].
pub struct PreparedLlamaLastTokenLayerTrace {
    contract: LlamaTraceContract,
    layer_indices: Box<[usize]>,
    residual_outputs: Box<[Box<[u8]>]>,
    captured_layers: Box<[bool]>,
    final_norm_output: Option<Box<[u8]>>,
    final_norm_output_captured: bool,
    row_byte_len: usize,
}

/// Named last-token checkpoints inside one caller-selected decoder layer.
///
/// This is a diagnostic-only API for locating a first full-forward numerical
/// divergence.  It deliberately keeps the layer index out of the enum so the
/// same trace owner can inspect any validated decoder layer without adding
/// layer-specific production trace points.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(u8)]
pub enum LlamaLastTokenLayerStage {
    InputNorm,
    QueryProjection,
    KeyProjection,
    ValueProjection,
    QueryRotary,
    KeyRotary,
    AttentionContext,
    AfterAttentionResidual,
    PostAttentionNorm,
    GateProjection,
    UpProjection,
    Gated,
    DownProjection,
    Output,
}

impl LlamaLastTokenLayerStage {
    /// Every internal boundary captured by a layer-stage trace, in execution
    /// order.
    pub const ALL: [Self; LAST_TOKEN_LAYER_STAGE_COUNT] = [
        Self::InputNorm,
        Self::QueryProjection,
        Self::KeyProjection,
        Self::ValueProjection,
        Self::QueryRotary,
        Self::KeyRotary,
        Self::AttentionContext,
        Self::AfterAttentionResidual,
        Self::PostAttentionNorm,
        Self::GateProjection,
        Self::UpProjection,
        Self::Gated,
        Self::DownProjection,
        Self::Output,
    ];

    /// Stable suffix used by source-bound external trace artifacts.
    #[must_use]
    pub const fn name(self) -> &'static str {
        match self {
            Self::InputNorm => "input_norm",
            Self::QueryProjection => "q_proj",
            Self::KeyProjection => "k_proj",
            Self::ValueProjection => "v_proj",
            Self::QueryRotary => "q_rope",
            Self::KeyRotary => "k_rope",
            Self::AttentionContext => "attention_context",
            Self::AfterAttentionResidual => "after_attention_residual",
            Self::PostAttentionNorm => "post_attention_norm",
            Self::GateProjection => "gate_proj",
            Self::UpProjection => "up_proj",
            Self::Gated => "gated",
            Self::DownProjection => "down_proj",
            Self::Output => "output",
        }
    }

    const fn index(self) -> usize {
        self as usize
    }

    const fn requires_key_value_width(self) -> bool {
        matches!(
            self,
            Self::KeyProjection | Self::ValueProjection | Self::KeyRotary
        )
    }

    const fn requires_intermediate_width(self) -> bool {
        matches!(
            self,
            Self::GateProjection | Self::UpProjection | Self::Gated
        )
    }
}

/// Caller-owned last-token rows for every numerical boundary in one selected
/// decoder layer.
///
/// It is intentionally separate from [`PreparedLlamaTrace`]'s immutable PR07
/// checkpoint set and [`PreparedLlamaLastTokenLayerTrace`]'s residual-only
/// fan-out.  Normal forward execution never creates or copies this owner.
pub struct PreparedLlamaLastTokenLayerStageTrace {
    contract: LlamaTraceContract,
    layer_index: usize,
    tensors: Box<[Box<[u8]>]>,
    captured: u16,
}

/// Caller-owned full-sequence tensors for selected boundaries in one decoder
/// layer.
///
/// This is a bounded diagnostic owner for investigating a divergence that is
/// invisible in a last-token row: later causal attention consumes every prior
/// row. Normal forward execution neither creates this owner nor transfers its
/// tensors. Callers explicitly select the layer and named stages before using
/// [`PreparedLlamaForward::execute_full_sequence_layer_stage_traced`].
pub struct PreparedLlamaFullSequenceLayerStageTrace {
    contract: LlamaTraceContract,
    layer_index: usize,
    tensors: Box<[Box<[u8]>]>,
    requested: u16,
    captured: u16,
}

/// Caller-owned eager-framework-layout BF16 copies of the cold RoPE tables.
///
/// The execution owner retains F32 `[position, head_dimension / 2]` tables.
/// This diagnostic view narrows each value exactly once to BF16 and expands the
/// duplicated half into the `[position, head_dimension]` layout that Qwen's
/// eager rotary helper receives. Normal execution never creates or copies it.
pub struct PreparedLlamaHuggingFaceRopeTableTrace {
    cosine: Box<[u8]>,
    sine: Box<[u8]>,
}

impl fmt::Debug for PreparedLlamaLastTokenLayerStageTrace {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("PreparedLlamaLastTokenLayerStageTrace")
            .field("layer_index", &self.layer_index)
            .field("captured_stage_count", &self.captured_stage_count())
            .finish_non_exhaustive()
    }
}

impl fmt::Debug for PreparedLlamaFullSequenceLayerStageTrace {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("PreparedLlamaFullSequenceLayerStageTrace")
            .field("layer_index", &self.layer_index)
            .field("requested_stage_count", &self.requested_stage_count())
            .field("captured_stage_count", &self.captured_stage_count())
            .finish_non_exhaustive()
    }
}

impl fmt::Debug for PreparedLlamaHuggingFaceRopeTableTrace {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("PreparedLlamaHuggingFaceRopeTableTrace")
            .field("cosine_byte_len", &self.cosine.len())
            .field("sine_byte_len", &self.sine.len())
            .finish()
    }
}

impl PreparedLlamaHuggingFaceRopeTableTrace {
    /// BF16 little-endian `[position, head_dimension]` cosine values.
    #[must_use]
    pub fn cosine(&self) -> &[u8] {
        &self.cosine
    }

    /// BF16 little-endian `[position, head_dimension]` sine values.
    #[must_use]
    pub fn sine(&self) -> &[u8] {
        &self.sine
    }
}

impl PreparedLlamaLastTokenLayerStageTrace {
    fn prepare(plan: &LlamaExecutionPlan, layer_index: usize) -> LlamaForwardResult<Self> {
        let layer_count = plan.layers().len();
        if layer_index >= layer_count {
            return Err(LlamaForwardError::LastTokenTraceLayerUnavailable {
                layer_index,
                actual_layers: layer_count,
            });
        }
        let total_capture_bytes =
            LlamaLastTokenLayerStage::ALL
                .into_iter()
                .try_fold(0_u64, |total, stage| {
                    total
                        .checked_add(last_token_layer_stage_row_byte_len(plan, stage)?)
                        .ok_or(LlamaForwardError::ArithmeticOverflow {
                            resource: LlamaForwardResource::TraceCapture,
                        })
                })?;
        let mut tensors = Vec::new();
        tensors
            .try_reserve_exact(LAST_TOKEN_LAYER_STAGE_COUNT)
            .map_err(|_| LlamaForwardError::HostAllocation {
                resource: LlamaForwardResource::TraceCapture,
                requested_bytes: total_capture_bytes,
            })?;
        for stage in LlamaLastTokenLayerStage::ALL {
            let bytes = last_token_layer_stage_row_byte_len(plan, stage)?;
            tensors.push(allocate_host_bytes(
                bytes,
                LlamaForwardResource::TraceCapture,
            )?);
        }
        if tensors.len() != LAST_TOKEN_LAYER_STAGE_COUNT {
            return Err(LlamaForwardError::HostAllocation {
                resource: LlamaForwardResource::TraceCapture,
                requested_bytes: total_capture_bytes,
            });
        }
        Ok(Self {
            contract: trace_contract(plan),
            layer_index,
            tensors: tensors.into_boxed_slice(),
            captured: 0,
        })
    }

    /// Decoder-layer index selected during cold diagnostic preparation.
    #[must_use]
    pub const fn layer_index(&self) -> usize {
        self.layer_index
    }

    /// Number of stage rows captured by the latest diagnostic execution.
    #[must_use]
    pub const fn captured_stage_count(&self) -> u32 {
        self.captured.count_ones()
    }

    /// Whether every selected layer boundary was captured.
    #[must_use]
    pub const fn is_complete(&self) -> bool {
        self.captured_stage_count() as usize == LAST_TOKEN_LAYER_STAGE_COUNT
    }

    /// Returns the final-token BF16 row for one completed boundary.
    #[must_use]
    pub fn tensor(&self, stage: LlamaLastTokenLayerStage) -> Option<&[u8]> {
        (self.captured & layer_stage_trace_bit(stage) != 0)
            .then(|| self.tensors[stage.index()].as_ref())
    }

    pub(super) fn validate(&self, plan: &LlamaExecutionPlan) -> LlamaForwardResult<()> {
        if self.contract != trace_contract(plan) {
            return Err(LlamaForwardError::TracePlanMismatch);
        }
        Ok(())
    }

    pub(super) fn reset(&mut self) {
        self.captured = 0;
    }

    fn destination(&mut self, stage: LlamaLastTokenLayerStage) -> &mut [u8] {
        self.tensors[stage.index()].as_mut()
    }

    fn mark_captured(&mut self, stage: LlamaLastTokenLayerStage) {
        self.captured |= layer_stage_trace_bit(stage);
    }
}

impl PreparedLlamaFullSequenceLayerStageTrace {
    fn prepare(
        plan: &LlamaExecutionPlan,
        layer_index: usize,
        stages: &[LlamaLastTokenLayerStage],
    ) -> LlamaForwardResult<Self> {
        let layer_count = plan.layers().len();
        if layer_index >= layer_count {
            return Err(
                LlamaForwardError::FullSequenceLayerStageTraceLayerUnavailable {
                    layer_index,
                    actual_layers: layer_count,
                },
            );
        }
        let requested = stages
            .iter()
            .fold(0_u16, |mask, &stage| mask | layer_stage_trace_bit(stage));
        let total_capture_bytes =
            LlamaLastTokenLayerStage::ALL
                .into_iter()
                .try_fold(0_u64, |total, stage| {
                    if requested & layer_stage_trace_bit(stage) == 0 {
                        return Ok(total);
                    }
                    total
                        .checked_add(full_sequence_layer_stage_byte_len(plan, stage)?)
                        .ok_or(LlamaForwardError::ArithmeticOverflow {
                            resource: LlamaForwardResource::TraceCapture,
                        })
                })?;
        let mut tensors = Vec::new();
        tensors
            .try_reserve_exact(LAST_TOKEN_LAYER_STAGE_COUNT)
            .map_err(|_| LlamaForwardError::HostAllocation {
                resource: LlamaForwardResource::TraceCapture,
                requested_bytes: total_capture_bytes,
            })?;
        for stage in LlamaLastTokenLayerStage::ALL {
            tensors.push(if requested & layer_stage_trace_bit(stage) == 0 {
                Box::default()
            } else {
                allocate_host_bytes(
                    full_sequence_layer_stage_byte_len(plan, stage)?,
                    LlamaForwardResource::TraceCapture,
                )?
            });
        }
        if tensors.len() != LAST_TOKEN_LAYER_STAGE_COUNT {
            return Err(LlamaForwardError::HostAllocation {
                resource: LlamaForwardResource::TraceCapture,
                requested_bytes: total_capture_bytes,
            });
        }
        Ok(Self {
            contract: trace_contract(plan),
            layer_index,
            tensors: tensors.into_boxed_slice(),
            requested,
            captured: 0,
        })
    }

    /// Decoder-layer index selected during cold diagnostic preparation.
    #[must_use]
    pub const fn layer_index(&self) -> usize {
        self.layer_index
    }

    /// Number of full-sequence boundaries selected by the caller.
    #[must_use]
    pub const fn requested_stage_count(&self) -> u32 {
        self.requested.count_ones()
    }

    /// Number of selected full-sequence boundaries captured in the latest run.
    #[must_use]
    pub const fn captured_stage_count(&self) -> u32 {
        self.captured.count_ones()
    }

    /// Whether every selected full-sequence boundary was captured.
    #[must_use]
    pub const fn is_complete(&self) -> bool {
        self.requested == self.captured
    }

    /// Returns a selected full-sequence BF16 tensor after it was captured.
    #[must_use]
    pub fn tensor(&self, stage: LlamaLastTokenLayerStage) -> Option<&[u8]> {
        (self.captured & layer_stage_trace_bit(stage) != 0)
            .then(|| self.tensors[stage.index()].as_ref())
    }

    /// Exact BF16 byte length reserved for one selected full-sequence stage.
    #[must_use]
    pub fn tensor_byte_len(&self, stage: LlamaLastTokenLayerStage) -> usize {
        self.tensors[stage.index()].len()
    }

    fn requests(&self, stage: LlamaLastTokenLayerStage) -> bool {
        self.requested & layer_stage_trace_bit(stage) != 0
    }

    fn validate(&self, plan: &LlamaExecutionPlan) -> LlamaForwardResult<()> {
        if self.contract != trace_contract(plan) {
            return Err(LlamaForwardError::TracePlanMismatch);
        }
        Ok(())
    }

    fn reset(&mut self) {
        self.captured = 0;
    }

    fn destination(&mut self, stage: LlamaLastTokenLayerStage) -> &mut [u8] {
        self.tensors[stage.index()].as_mut()
    }

    fn mark_captured(&mut self, stage: LlamaLastTokenLayerStage) {
        self.captured |= layer_stage_trace_bit(stage);
    }
}

impl fmt::Debug for PreparedLlamaLastTokenLayerTrace {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("PreparedLlamaLastTokenLayerTrace")
            .field("requested_layer_indices", &self.layer_indices)
            .field("captured_layers", &self.captured_layer_count())
            .field(
                "requests_final_norm_output",
                &self.requests_final_norm_output(),
            )
            .field(
                "final_norm_output_captured",
                &self.final_norm_output_captured,
            )
            .field("row_byte_len", &self.row_byte_len)
            .finish_non_exhaustive()
    }
}

impl PreparedLlamaLastTokenLayerTrace {
    fn prepare(
        plan: &LlamaExecutionPlan,
        layer_indices: &[usize],
        capture_final_norm_output: bool,
    ) -> LlamaForwardResult<Self> {
        let layer_indices = normalize_last_token_layer_indices(layer_indices, plan.layers().len())?;
        let row_byte_len = last_token_hidden_row_byte_len(plan)?;
        let total_capture_bytes = last_token_trace_total_bytes(
            layer_indices.len(),
            row_byte_len,
            capture_final_norm_output,
        )?;

        let mut residual_outputs = Vec::new();
        residual_outputs
            .try_reserve_exact(layer_indices.len())
            .map_err(|_| LlamaForwardError::HostAllocation {
                resource: LlamaForwardResource::TraceCapture,
                requested_bytes: total_capture_bytes,
            })?;
        for _ in &layer_indices {
            residual_outputs.push(allocate_host_bytes(
                row_byte_len,
                LlamaForwardResource::TraceCapture,
            )?);
        }

        let mut captured_layers = Vec::new();
        captured_layers
            .try_reserve_exact(layer_indices.len())
            .map_err(|_| LlamaForwardError::HostAllocation {
                resource: LlamaForwardResource::TraceCapture,
                requested_bytes: total_capture_bytes,
            })?;
        captured_layers.resize(layer_indices.len(), false);

        let final_norm_output = if capture_final_norm_output {
            Some(allocate_host_bytes(
                row_byte_len,
                LlamaForwardResource::TraceCapture,
            )?)
        } else {
            None
        };

        Ok(Self {
            contract: trace_contract(plan),
            layer_indices: layer_indices.into_boxed_slice(),
            residual_outputs: residual_outputs.into_boxed_slice(),
            captured_layers: captured_layers.into_boxed_slice(),
            final_norm_output,
            final_norm_output_captured: false,
            row_byte_len: usize::try_from(row_byte_len).map_err(|_| {
                LlamaForwardError::ArithmeticOverflow {
                    resource: LlamaForwardResource::TraceCapture,
                }
            })?,
        })
    }

    /// Sorted, duplicate-free decoder layer indices selected by the caller.
    #[must_use]
    pub fn requested_layer_indices(&self) -> &[usize] {
        &self.layer_indices
    }

    /// Number of selected decoder layers.
    #[must_use]
    pub const fn requested_layer_count(&self) -> usize {
        self.layer_indices.len()
    }

    /// Number of selected layer residual rows captured by the latest run.
    #[must_use]
    pub fn captured_layer_count(&self) -> usize {
        self.captured_layers
            .iter()
            .filter(|&&captured| captured)
            .count()
    }

    /// Exact BF16 byte length of each captured `[hidden_size]` last-token row.
    #[must_use]
    pub const fn row_byte_len(&self) -> usize {
        self.row_byte_len
    }

    /// Whether this owner reserved the final RMS-norm output row.
    #[must_use]
    pub const fn requests_final_norm_output(&self) -> bool {
        self.final_norm_output.is_some()
    }

    /// Returns a selected layer's captured MLP residual output row.
    ///
    /// The result is little-endian BF16 storage for the final token only. It
    /// returns `None` when the layer was not selected or has not completed in
    /// the latest diagnostic execution.
    #[must_use]
    pub fn layer_residual_output(&self, layer_index: usize) -> Option<&[u8]> {
        let ordinal = self.layer_ordinal(layer_index)?;
        self.captured_layers[ordinal].then(|| self.residual_outputs[ordinal].as_ref())
    }

    /// Returns the captured final RMS-norm output row for the final token.
    ///
    /// The result is little-endian BF16 storage and is absent until a
    /// successful diagnostic run reaches final normalization.
    #[must_use]
    pub fn final_norm_output(&self) -> Option<&[u8]> {
        self.final_norm_output_captured
            .then(|| self.final_norm_output.as_deref())
            .flatten()
    }

    pub(super) fn validate(&self, plan: &LlamaExecutionPlan) -> LlamaForwardResult<()> {
        if self.contract != trace_contract(plan) {
            return Err(LlamaForwardError::TracePlanMismatch);
        }
        Ok(())
    }

    pub(super) fn reset(&mut self) {
        for captured in &mut *self.captured_layers {
            *captured = false;
        }
        self.final_norm_output_captured = false;
    }

    fn layer_ordinal(&self, layer_index: usize) -> Option<usize> {
        self.layer_indices.binary_search(&layer_index).ok()
    }

    fn layer_destination(&mut self, ordinal: usize) -> &mut [u8] {
        self.residual_outputs[ordinal].as_mut()
    }

    fn mark_layer_captured(&mut self, ordinal: usize) {
        self.captured_layers[ordinal] = true;
    }

    fn final_norm_destination(&mut self) -> Option<&mut [u8]> {
        self.final_norm_output.as_deref_mut()
    }

    fn mark_final_norm_output_captured(&mut self) {
        self.final_norm_output_captured = true;
    }
}

const fn trace_bit(point: LlamaTracePoint) -> u32 {
    1_u32 << point.index()
}

const fn layer_stage_trace_bit(stage: LlamaLastTokenLayerStage) -> u16 {
    1_u16 << stage.index()
}

impl PreparedLlamaForward {
    /// Explicitly closes every prepared plan, graph allocation, pinned buffer,
    /// and uploaded weight, attempting the full set after the first failure.
    ///
    /// # Errors
    ///
    /// Returns the first close failure after all resources have been attempted.
    #[allow(clippy::too_many_lines)]
    pub fn close(self) -> LlamaForwardResult<()> {
        let Self {
            plan: _,
            weights,
            gemms,
            batch_output_lm_head,
            paged_batch_only: _,
            owned_hf_eager_bf16: _,
            attention,
            reduction_profile: _,
            projection_bias_mode: _,
            merged_gate_up: _,
            output_projection_mode: _,
            mlp_projection_mode: _,
            lm_head_mode: _,
            rms_norm_profile: _,
            rope_table_profile: _,
            gemm_reduction_policies: _,
            gemm_workspace_cap_bytes: _,
            buffers,
            io_staging,
            token_bytes: _,
            allocation_report: _,
            tokens_ready: _,
            output_ready: _,
            poisoned: _,
            captured_steps,
            captured_step_budget: _,
            owned_decode_segments,
        } = self;
        // Recorded steps reference the plans and buffers closed below.
        drop(captured_steps);
        drop(owned_decode_segments);
        let GemmPlans {
            hidden,
            key_value,
            intermediate,
            down,
            lm_head,
            merged_qkv,
            #[cfg(feature="cuda-cublas-gemm-probe")]
            hf_separate_query,
            merged_gate_up,
            output_projection,
            projection_bias_epilogue,
            #[cfg(feature="cuda-cublas-gemm-probe")]
            hf_request_bias_epilogue,
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            output_projection_direct_cublas,
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            mlp_projection_direct_cublas,
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            lm_head_last_token_direct_cublas,
        } = gemms;
        let ForwardBuffers {
            token_ids,
            hidden_current,
            hidden_norm,
            hidden_projection,
            hidden_rotary,
            hidden_context,
            key_raw,
            value_raw,
            key_rotary,
            gate_raw,
            up_raw,
            gate_activated,
            gated_product,
            attention_workspace,
            rope_cos,
            rope_sin,
            logits,
            embedding_error_scratch,
            gemm_workspace,
        } = buffers;
        let mut first = None;
        if let Some(plan) = batch_output_lm_head {
            record_close(&mut first, LlamaForwardResource::LmHeadGemm, plan.close());
        }
        record_close(&mut first, LlamaForwardResource::HiddenGemm, hidden.close());
        record_close(
            &mut first,
            LlamaForwardResource::KeyValueGemm,
            key_value.close(),
        );
        record_close(
            &mut first,
            LlamaForwardResource::IntermediateGemm,
            intermediate.close(),
        );
        record_close(&mut first, LlamaForwardResource::DownGemm, down.close());
        record_close(
            &mut first,
            LlamaForwardResource::LmHeadGemm,
            lm_head.close(),
        );
        #[cfg(feature="cuda-cublas-gemm-probe")]
        if let Some(query)=hf_separate_query {record_close(&mut first,LlamaForwardResource::HiddenGemm,query.close());}
        if let Some(merged_qkv) = merged_qkv {
            record_close(
                &mut first,
                LlamaForwardResource::HiddenGemm,
                merged_qkv.close(),
            );
        }
        if let Some(merged_gate_up) = merged_gate_up {
            record_close(
                &mut first,
                LlamaForwardResource::IntermediateGemm,
                merged_gate_up.close(),
            );
        }
        if let Some(output_projection) = output_projection {
            record_close(
                &mut first,
                LlamaForwardResource::HiddenGemm,
                output_projection.close(),
            );
        }
        if let Some(ProjectionBiasEpilogueGemmPlans { query, key_value }) = projection_bias_epilogue
        {
            record_close(
                &mut first,
                LlamaForwardResource::QueryBiasEpilogueGemm,
                query.close(),
            );
            record_close(
                &mut first,
                LlamaForwardResource::KeyValueBiasEpilogueGemm,
                key_value.close(),
            );
        }
        #[cfg(feature="cuda-cublas-gemm-probe")]
        if let Some(table)=hf_request_bias_epilogue {
          for plan in table.query {record_close(&mut first,LlamaForwardResource::QueryBiasEpilogueGemm,plan.close());}
          for plan in table.key_value {record_close(&mut first,LlamaForwardResource::KeyValueBiasEpilogueGemm,plan.close());}
          for plan in table.batch_query.into_iter().flatten() {record_close(&mut first,LlamaForwardResource::QueryBiasEpilogueGemm,plan.close());}
          for plan in table.batch_key_value.into_iter().flatten() {record_close(&mut first,LlamaForwardResource::KeyValueBiasEpilogueGemm,plan.close());}
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if let Some(plan) = output_projection_direct_cublas {
            record_close(
                &mut first,
                LlamaForwardResource::OutputProjectionDirectCublasGemm,
                plan.close(),
            );
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if let Some(MlpProjectionDirectCublasGemmPlans { intermediate, down }) =
            mlp_projection_direct_cublas
        {
            record_close(
                &mut first,
                LlamaForwardResource::MlpIntermediateDirectCublasGemm,
                intermediate.close(),
            );
            record_close(
                &mut first,
                LlamaForwardResource::MlpDownDirectCublasGemm,
                down.close(),
            );
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if let Some(plan) = lm_head_last_token_direct_cublas {
            record_close(
                &mut first,
                LlamaForwardResource::LmHeadLastTokenDirectCublasGemm,
                plan.close(),
            );
        }
        record_close(
            &mut first,
            LlamaForwardResource::Attention,
            attention.close(),
        );
        for (resource, result) in [
            (LlamaForwardResource::TokenIds, token_ids.close()),
            (LlamaForwardResource::HiddenCurrent, hidden_current.close()),
            (LlamaForwardResource::HiddenNorm, hidden_norm.close()),
            (
                LlamaForwardResource::HiddenProjection,
                hidden_projection.close(),
            ),
            (LlamaForwardResource::HiddenRotary, hidden_rotary.close()),
            (LlamaForwardResource::HiddenContext, hidden_context.close()),
            (LlamaForwardResource::KeyRaw, key_raw.close()),
            (LlamaForwardResource::ValueRaw, value_raw.close()),
            (LlamaForwardResource::KeyRotary, key_rotary.close()),
            (LlamaForwardResource::GateRaw, gate_raw.close()),
            (LlamaForwardResource::UpRaw, up_raw.close()),
            (LlamaForwardResource::GateActivated, gate_activated.close()),
            (LlamaForwardResource::GatedProduct, gated_product.close()),
            (LlamaForwardResource::RopeCos, rope_cos.close()),
            (LlamaForwardResource::RopeSin, rope_sin.close()),
            (LlamaForwardResource::Logits, logits.close()),
            (
                LlamaForwardResource::EmbeddingErrorScratch,
                embedding_error_scratch.close(),
            ),
        ] {
            record_close(&mut first, resource, result);
        }
        if let Some(workspace) = attention_workspace {
            record_close(
                &mut first,
                LlamaForwardResource::Attention,
                workspace.close(),
            );
        }
        if let Some(workspace) = gemm_workspace {
            record_close(
                &mut first,
                LlamaForwardResource::GemmWorkspace,
                workspace.close(),
            );
        }
        record_close(
            &mut first,
            LlamaForwardResource::IoStaging,
            io_staging.close(),
        );
        record_close(
            &mut first,
            LlamaForwardResource::UploadedWeights,
            weights.close(),
        );
        first.map_or(Ok(()), Err)
    }
}

fn record_close(
    first: &mut Option<LlamaForwardError>,
    resource: LlamaForwardResource,
    result: Result<(), CudaError>,
) {
    if let Err(source) = result {
        if first.is_none() {
            *first = Some(LlamaForwardError::Cleanup { resource, source });
        }
    }
}

// Reserve bounded, private actual-row keys within each fixed dense owner.
// Keep separate output-mode ranges; each includes layer segments and a body slot.
pub(super) fn owned_decode_segment_capacity(plan:&LlamaExecutionPlan,dense_rows:usize)->usize {
    let d=plan.dimensions();let legacy=plan.layers().len()*2;
    let smol=d.hidden_size()==576&&d.query_heads()==9&&d.key_value_heads()==3&&d.head_dimension()==64;
    let wide=matches!(d.hidden_size(),2560|4096)&&d.query_heads()==32&&d.key_value_heads()==8&&d.head_dimension()==128;
    legacy+if dense_rows<=32&&(smol||wide){2*dense_rows*(legacy+1)}else{0}
}

// Whole-body graphs include different logit destinations in the two output
// modes. Each dense owner therefore retains disjoint actual-row key ranges.
pub(super) fn owned_decode_segment_offset(legacy:usize,dense:usize,actual:usize,greedy:bool)->Option<usize>{
    if actual==0||actual>dense||dense>32{return None;}
    let stride=legacy.checked_add(1)?;
    let key=(if greedy{dense}else{0}).checked_add(actual-1)?;
    legacy.checked_add(key.checked_mul(stride)?)
}

/// Upper bound on recorded steps per prepared forward owner.
/// Fixed-address graph retained by one prepared shape; never shared across owners.
#[derive(Default)]
pub(super) struct OwnedDecodeSegment {
    pub(super) warmed: bool,
    pub(super) replayed: bool,
    pub(super) graph: Option<riley_cuda::CudaStepGraph>,
}

pub(super) const MAX_RECORDED_STEPS: usize = 32;

/// Prepared GEMM implementation bound to one whole-runtime reduction profile.
pub(super) enum PreparedLlamaGemm {
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    ClassicDiagnostic(CudaPreparedCublasGemmProbe),
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    ClassicRequestRows(CudaPreparedCublasGemmProbe),
    Canonical(CudaPreparedGemm),
    Fixed37(CudaPreparedFixed37Gemm),
}

impl PreparedLlamaGemm {
    #[must_use]
    pub(super) const fn config(&self) -> CudaGemmConfig {
        match self {
            Self::Canonical(plan) => plan.config(),
            Self::Fixed37(plan) => plan.config(),
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::ClassicDiagnostic(plan) | Self::ClassicRequestRows(plan) => plan.config(),
        }
    }

    #[must_use]
    pub(super) const fn workspace_bytes(&self) -> u64 {
        match self {
            Self::Canonical(plan) => plan.algorithm_metadata().workspace_bytes(),
            Self::Fixed37(plan) => plan.metadata().workspace_bytes(),
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::ClassicDiagnostic(_) | Self::ClassicRequestRows(_) => 0,
        }
    }

    #[must_use]
    pub(super) const fn is_poisoned(&self) -> bool {
        match self {
            Self::Canonical(plan) => plan.is_poisoned(),
            Self::Fixed37(plan) => plan.is_poisoned(),
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::ClassicDiagnostic(plan) | Self::ClassicRequestRows(plan) => plan.is_poisoned(),
        }
    }

    pub(super) fn close(self) -> Result<(), CudaError> {
        match self {
            Self::Canonical(plan) => plan.close(),
            Self::Fixed37(plan) => plan.close(),
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::ClassicDiagnostic(plan) | Self::ClassicRequestRows(plan) => plan.close(),
        }
    }

    fn execute<'a, S: CudaExecutionStream + ?Sized>(
        &mut self,
        input: CudaBufferSpan<'a>,
        weight: CudaBufferSpan<'a>,
        output: CudaBufferSpanMut<'a>,
        workspace: Option<CudaBufferSpanMut<'a>>,
        stream: &mut S,
    ) -> Result<(), CudaError> {
        match self {
            Self::Canonical(plan) => {
                let mut params = GemmParams {
                    input,
                    weight,
                    output,
                    workspace,
                };
                plan.execute(&mut params, stream)
            }
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::ClassicDiagnostic(plan) | Self::ClassicRequestRows(plan) => {
                debug_assert!(workspace.is_none());
                let mut params = CublasGemmProbeParams { input, weight, output };
                plan.execute(&mut params, stream)
            }
            Self::Fixed37(plan) => {
                debug_assert!(workspace.is_none());
                let mut params = Fixed37GemmParams {
                    input,
                    weight,
                    output,
                };
                plan.execute(&mut params, stream)
            }
        }
    }
}

pub(super) fn execute_gemm<S: CudaExecutionStream + ?Sized>(
    plan: &mut PreparedLlamaGemm,
    input: &CudaDeviceBuffer,
    weight: CudaBufferSpan<'_>,
    output: &mut CudaDeviceBuffer,
    workspace: &mut Option<CudaDeviceBuffer>,
    stream: &mut S,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    let config = plan.config();
    let required_workspace = plan.workspace_bytes();
    let workspace = if required_workspace == 0 {
        None
    } else {
        let buffer = workspace
            .as_mut()
            .ok_or(LlamaForwardError::InvalidConfiguration {
                field: "gemm_workspace",
                reason: "selected algorithm workspace was not allocated",
            })?;
        Some(span_mut(buffer, CudaDType::U8, required_workspace, site)?)
    };
    let input = span(input, CudaDType::BF16, config.input_bytes(), site)?;
    let output = span_mut(output, CudaDType::BF16, config.output_bytes(), site)?;
    plan.execute(input, weight, output, workspace, stream)
        .map_err(|source| LlamaForwardError::cuda(site, source))
}

#[allow(clippy::too_many_arguments)]
pub(super) fn execute_gemm_with_row_groups<S:CudaExecutionStream+?Sized>(
    plan:&mut PreparedLlamaGemm,input:&CudaDeviceBuffer,weight:CudaBufferSpan<'_>,
    output:&mut CudaDeviceBuffer,workspace:&mut Option<CudaDeviceBuffer>,stream:&mut S,
    site:ExecutionSite,host:riley_cuda::PackedBatchHostV1<'_>,output_rows:Option<usize>,grouped_decode:u8,
)->LlamaForwardResult<()> {
    execute_gemm_with_row_groups_from(plan,input,weight,output,workspace,stream,site,host,output_rows,grouped_decode,0)
}

#[allow(clippy::too_many_arguments)]
pub(super) fn execute_gemm_with_row_groups_from<S:CudaExecutionStream+?Sized>(
    plan:&mut PreparedLlamaGemm,input:&CudaDeviceBuffer,weight:CudaBufferSpan<'_>,
    output:&mut CudaDeviceBuffer,workspace:&mut Option<CudaDeviceBuffer>,stream:&mut S,
    site:ExecutionSite,host:riley_cuda::PackedBatchHostV1<'_>,output_rows:Option<usize>,grouped_decode:u8,first_row:usize,
)->LlamaForwardResult<()> {
    if first_row==host.row_sequence_slots().len(){return Ok(());}
    let slots=host.row_sequence_slots();
    #[cfg(feature="cuda-cublas-gemm-probe")]
    if let PreparedLlamaGemm::ClassicRequestRows(p)=plan {
        let c=p.config();
        let mut params=CublasGemmProbeParams {input:span(input,CudaDType::BF16,c.input_bytes(),site)?,weight,output:span_mut(output,CudaDType::BF16,c.output_bytes(),site)?};
        if let Some(groups)=host.request_row_groups(){return p.execute_row_groups_cached_from(&mut params,groups,output_rows,grouped_decode,first_row,stream).map_err(|e|LlamaForwardError::cuda(site,e));}
        if first_row!=0 {return Err(LlamaForwardError::InvalidConfiguration{field:"piecewise MLP suffix",reason:"validated request groups required"});}
        return p.execute_row_groups(&mut params,slots,output_rows,grouped_decode,stream).map_err(|e|LlamaForwardError::cuda(site,e));
    }
    #[cfg(not(feature="cuda-cublas-gemm-probe"))] let _=(slots,output_rows,grouped_decode);
    if first_row!=0{return Err(LlamaForwardError::InvalidConfiguration{field:"piecewise MLP suffix",reason:"classic request plan required"});}
    execute_gemm(plan,input,weight,output,workspace,stream,site)
}

#[allow(clippy::too_many_arguments)]
pub(super) fn execute_projection_with_row_groups<S:CudaExecutionStream+?Sized>(
    strict_plan:&mut PreparedLlamaGemm,fused_plan:Option<&mut CudaPreparedBiasEpilogueGemm>,
    weights:&CudaUploadedWeights,bias_id:Option<PhysicalWeightId>,input:&CudaDeviceBuffer,
    weight:CudaBufferSpan<'_>,output:&mut CudaDeviceBuffer,workspace:&mut Option<CudaDeviceBuffer>,
    row_count:u64,column_count:u64,stream:&mut S,site:ExecutionSite,host:riley_cuda::PackedBatchHostV1<'_>,requests:Option<&mut [CudaPreparedBiasEpilogueGemm]>,mut batches:Option<&mut [Option<CudaPreparedBiasEpilogueGemm>]>,decode_mode:u8,
)->LlamaForwardResult<()> {
    let slots=host.row_sequence_slots();
    if let Some(plans)=requests {
      let bias=weight_span(weights,bias_id.ok_or(LlamaForwardError::InvalidConfiguration{field:"hf_request_bias",reason:"bound bias missing"})?,site)?;
      let mut begin=0;
      while begin<slots.len(){let mut end=begin+1;while end<slots.len()&&slots[end]==slots[begin]{end+=1;}
        let rows=end-begin;
        let mut batched_end=end;
        if rows==1 && batches.is_some() {
          while batched_end<slots.len() && batched_end-begin<32 {
            let mut next=batched_end+1;while next<slots.len() && slots[next]==slots[batched_end]{next+=1;}
            if next-batched_end!=1 {break;}batched_end=next;
          }
        }
        let batched=if rows==1 && batched_end-begin>=2 {batches.as_deref_mut().and_then(|v|v.get_mut(batched_end-begin)).and_then(Option::as_mut)}else{None};
        let p=if let Some(p)=batched {end=batched_end;p}else{plans.get_mut(rows-1).ok_or(LlamaForwardError::InvalidConfiguration{field:"hf_request_bias",reason:"actual request rows exceed cold plans"})?};
        let c=p.config();let need=p.algorithm_metadata().workspace_bytes();
        let scratch=if need==0{None}else{Some(span_mut(workspace.as_mut().ok_or(LlamaForwardError::InvalidConfiguration{field:"hf_request_bias_workspace",reason:"cold workspace missing"})?,CudaDType::U8,need,site)?)};
        let mut params=BiasGemmParams{input:CudaBufferSpan::new(input,CudaDType::BF16,begin as u64*c.k()*2,c.input_bytes()).map_err(|e|LlamaForwardError::cuda(site,e))?,weight:weight.subspan(0,c.weight_bytes()).map_err(|e|LlamaForwardError::cuda(site,e))?,bias:bias.subspan(0,c.n()*2).map_err(|e|LlamaForwardError::cuda(site,e))?,output:CudaBufferSpanMut::new(output,CudaDType::BF16,begin as u64*c.n()*2,c.output_bytes()).map_err(|e|LlamaForwardError::cuda(site,e))?,workspace:scratch};
        p.execute(&mut params,stream).map_err(|e|LlamaForwardError::cuda(site,e))?;begin=end;
      }
      return Ok(());
    }
    match fused_plan {
        Some(p)=>execute_bias_epilogue_gemm(p,weights,bias_id,input,weight,output,workspace,stream,site),
        None=>{
            // The no-bias Q/K/V route previously forced mode0, so exact
            // singleton batch kernels were never reached. Reuse only the
            // qualified SM89 shapes and preserve all multi-token extents.
            let exact_decode_mode={
                #[cfg(feature="cuda-cublas-gemm-probe")]
                {if matches!(decode_mode,7|8|9|10) && bias_id.is_none() {
                    match &*strict_plan {
                        PreparedLlamaGemm::ClassicRequestRows(p) if p.config().k()==2560 && (p.config().n()==4096 || (decode_mode>=8 && p.config().n()==1024)) && p.supports_bounded_sm80_gateup_rows()=>decode_mode,
                        _=>0,
                    }
                } else if matches!(decode_mode,2|5) && bias_id.is_none(){match &*strict_plan{
                    PreparedLlamaGemm::ClassicRequestRows(p) if ((p.config().k()==4096 && matches!(p.config().n(),1024|4096))
                        || (p.config().k()==576 && matches!(p.config().n(),192|576)))
                        && p.supports_exact_decode_chunk()=>decode_mode,
                    _=>0,
                }}else{0}}
                #[cfg(not(feature="cuda-cublas-gemm-probe"))]
                {let _=decode_mode;0}
            };
            execute_gemm_with_row_groups(strict_plan,input,weight,output,workspace,stream,site,host,None,exact_decode_mode)?;
            execute_projection_bias(weights,bias_id,output,row_count,column_count,stream,site)}
    }
}

/// Executes the isolated direct-cuBLAS output-projection probe.
///
/// This remains behind the diagnostic feature and is only installed by the
/// P2051 Qwen full-forward qualifier after its source-bound layer-zero gate
/// passes. It has no workspace, graph, or command-batch surface.
#[cfg(feature = "cuda-cublas-gemm-probe")]
pub(super) fn execute_direct_cublas_gemm_probe<S: CudaExecutionStream + ?Sized>(
    plan: &mut CudaPreparedCublasGemmProbe,
    input: &CudaDeviceBuffer,
    weight: CudaBufferSpan<'_>,
    output: &mut CudaDeviceBuffer,
    stream: &mut S,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    let config = plan.config();
    let input = span(input, CudaDType::BF16, config.input_bytes(), site)?;
    let output = span_mut(output, CudaDType::BF16, config.output_bytes(), site)?;
    execute_direct_cublas_gemm_probe_spans(plan, input, weight, output, stream, site)
}

/// Executes the isolated direct-cuBLAS probe over validated BF16 subspans.
///
/// The P2051 final-logits qualifier uses this form to reproduce Hugging Face's
/// `logits_to_keep=1` last-row linear invocation without exposing partial
/// output through an ordinary serving path.
#[cfg(feature = "cuda-cublas-gemm-probe")]
pub(super) fn execute_direct_cublas_gemm_probe_spans<S: CudaExecutionStream + ?Sized>(
    plan: &mut CudaPreparedCublasGemmProbe,
    input: CudaBufferSpan<'_>,
    weight: CudaBufferSpan<'_>,
    output: CudaBufferSpanMut<'_>,
    stream: &mut S,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    let mut params = CublasGemmProbeParams {
        input,
        weight,
        output,
    };
    plan.execute(&mut params, stream)
        .map_err(|source| LlamaForwardError::cuda(site, source))
}

/// Executes one already-qualified Q/K/V cuBLASLt BIAS epilogue.
///
/// The caller selects this only from a cold owner that verified every decoder
/// layer has the corresponding BF16 bias. A missing bias therefore signals a
/// broken immutable plan rather than a request to fall back after dispatch.
pub(super) fn execute_bias_epilogue_gemm<S: CudaExecutionStream + ?Sized>(
    plan: &mut CudaPreparedBiasEpilogueGemm,
    weights: &CudaUploadedWeights,
    bias_id: Option<PhysicalWeightId>,
    input: &CudaDeviceBuffer,
    weight: CudaBufferSpan<'_>,
    output: &mut CudaDeviceBuffer,
    workspace: &mut Option<CudaDeviceBuffer>,
    stream: &mut S,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    let bias_id = bias_id.ok_or(LlamaForwardError::InvalidConfiguration {
        field: "projection_bias_mode",
        reason: "bias epilogue was selected for a projection without a bound bias",
    })?;
    let config = plan.config();
    let required_workspace = plan.algorithm_metadata().workspace_bytes();
    let workspace = if required_workspace == 0 {
        None
    } else {
        let buffer = workspace
            .as_mut()
            .ok_or(LlamaForwardError::InvalidConfiguration {
                field: "gemm_workspace",
                reason: "selected bias-epilogue algorithm workspace was not allocated",
            })?;
        Some(span_mut(buffer, CudaDType::U8, required_workspace, site)?)
    };
    let input = span(input, CudaDType::BF16, config.input_bytes(), site)?;
    let bias = weight_span(weights, bias_id, site)?;
    let output = span_mut(output, CudaDType::BF16, config.output_bytes(), site)?;
    let mut params = BiasGemmParams {
        input,
        weight,
        bias,
        output,
        workspace,
    };
    plan.execute(&mut params, stream)
        .map_err(|source| LlamaForwardError::cuda(site, source))
}

/// Selects the prepared fused Q/K/V plan when present, otherwise preserves
/// the strict standalone-GEMM and row-bias sequence.
#[allow(clippy::too_many_arguments)]
pub(super) fn execute_projection_with_optional_bias_epilogue<S: CudaExecutionStream + ?Sized>(
    strict_plan: &mut PreparedLlamaGemm,
    fused_plan: Option<&mut CudaPreparedBiasEpilogueGemm>,
    weights: &CudaUploadedWeights,
    bias_id: Option<PhysicalWeightId>,
    input: &CudaDeviceBuffer,
    weight: CudaBufferSpan<'_>,
    output: &mut CudaDeviceBuffer,
    workspace: &mut Option<CudaDeviceBuffer>,
    row_count: u64,
    column_count: u64,
    stream: &mut S,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    match fused_plan {
        Some(fused_plan) => execute_bias_epilogue_gemm(
            fused_plan, weights, bias_id, input, weight, output, workspace, stream, site,
        ),
        None => {
            execute_gemm(strict_plan, input, weight, output, workspace, stream, site)?;
            execute_projection_bias(
                weights,
                bias_id,
                output,
                row_count,
                column_count,
                stream,
                site,
            )
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum LlamaRmsNormProfile {
    Canonical,
    HuggingFaceSmolLm2,
    FixedContiguous37Balanced,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HuggingFaceCudaQwenP2051Probe,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HuggingFaceCudaQwenP2048CacheOnProbe,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum LlamaRopeTableProfile {
    CpuLibm,
    HuggingFaceCuda,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
enum LlamaRopeTableSelection {
    #[default]
    Automatic,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HuggingFaceCudaQwenP2051ProbeV1,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HuggingFaceCudaQwenP2048CacheOnProbeV1,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
enum LlamaRmsNormSelection {
    #[default]
    Automatic,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HuggingFaceCudaQwenP2051ProbeV1,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HuggingFaceCudaQwenP2048CacheOnProbeV1,
}

fn resolve_rms_norm_profile(
    model: &LoadedModel,
    reduction_profile: LlamaReductionProfile,
    _rms_norm_selection: LlamaRmsNormSelection,
    compute_capability: (u32, u32),
) -> LlamaRmsNormProfile {
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    if _rms_norm_selection == LlamaRmsNormSelection::HuggingFaceCudaQwenP2051ProbeV1 {
        // Geometry and epsilon are revalidated by the narrow native entry
        // point. Returning the profile unconditionally prevents selection
        // from silently falling back on a mismatched model or sequence.
        return LlamaRmsNormProfile::HuggingFaceCudaQwenP2051Probe;
    }
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    if _rms_norm_selection == LlamaRmsNormSelection::HuggingFaceCudaQwenP2048CacheOnProbeV1 {
        // The native primitive admits only the source-bound P2048/P2051
        // descriptors, so this cannot silently become a generic RMSNorm
        // selection on an unrelated model or sequence.
        return LlamaRmsNormProfile::HuggingFaceCudaQwenP2048CacheOnProbe;
    }
    match reduction_profile {
        LlamaReductionProfile::FixedContiguous37BalancedV1 => {
            LlamaRmsNormProfile::FixedContiguous37Balanced
        }
        // The Hugging Face SmolLM2 kernel picks its reduction layout from
        // the row count of the launch (it reproduces the reviewed 8.9
        // reference shape by shape), so a row's bits depend on the batch it
        // is in. Another device has no such reference and keeps the
        // row-invariant canonical kernel.
        LlamaReductionProfile::CanonicalV1
            if matches!(model.config(), ModelConfig::Llama(_))
                && is_reviewed_smollm2_rms_norm_geometry(model.spec())
                && compute_capability == (8, 9) =>
        {
            LlamaRmsNormProfile::HuggingFaceSmolLm2
        }
        LlamaReductionProfile::CanonicalV1 => LlamaRmsNormProfile::Canonical,
    }
}

fn resolve_rope_table_profile(
    model: &LoadedModel,
    reduction_profile: LlamaReductionProfile,
    _selection: LlamaRopeTableSelection,
    _sequence_length: usize,
) -> LlamaRopeTableProfile {
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    if _selection == LlamaRopeTableSelection::HuggingFaceCudaQwenP2051ProbeV1 {
        // The paired attention probe rejects every geometry other than the
        // fixed B1/S2051/QH16/KVH2/D128 RTX 4090 diagnostic. Keep table
        // selection explicit here too: normal Qwen serving remains on the
        // established cold path until this full-forward gate passes.
        if matches!(model.config(), ModelConfig::Qwen2(_)) && _sequence_length == 2_051 {
            return LlamaRopeTableProfile::HuggingFaceCuda;
        }
    }
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    if _selection == LlamaRopeTableSelection::HuggingFaceCudaQwenP2048CacheOnProbeV1 {
        // This selection is bound to cache-building prefill. M1 cache-on
        // decode will qualify a separate table/position path before reuse.
        if matches!(model.config(), ModelConfig::Qwen2(_)) && _sequence_length == 2_048 {
            return LlamaRopeTableProfile::HuggingFaceCuda;
        }
    }
    if reduction_profile == LlamaReductionProfile::CanonicalV1
        && matches!(model.config(), ModelConfig::Llama(_))
        && is_reviewed_smollm2_rope_geometry(model.spec())
    {
        LlamaRopeTableProfile::HuggingFaceCuda
    } else {
        LlamaRopeTableProfile::CpuLibm
    }
}

pub(super) fn execute_profile_rms_norm<S: CudaExecutionStream + ?Sized>(
    profile: LlamaRmsNormProfile,
    params: &mut RmsNormParams<'_>,
    stream: &mut S,
) -> Result<(), CudaError> {
    match profile {
        LlamaRmsNormProfile::Canonical => rms_norm(params, stream),
        LlamaRmsNormProfile::HuggingFaceSmolLm2 => hugging_face_smollm2_rms_norm(params, stream),
        LlamaRmsNormProfile::FixedContiguous37Balanced => fixed37_rms_norm(params, stream),
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        LlamaRmsNormProfile::HuggingFaceCudaQwenP2051Probe => {
            hugging_face_qwen_p2051_rms_norm(params, stream)
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        LlamaRmsNormProfile::HuggingFaceCudaQwenP2048CacheOnProbe => {
            hugging_face_qwen_p2051_rms_norm(params, stream)
        }
    }
}

pub(super) fn execute_profile_rms_norm_grouped<S:CudaExecutionStream+?Sized>(
 profile:LlamaRmsNormProfile,params:&mut RmsNormParams<'_>,stream:&mut S,host:riley_cuda::PackedBatchHostV1<'_>,hf_wide:bool,
)->Result<(),CudaError>{
 let slots=host.row_sequence_slots();
 #[cfg(feature="cuda-cublas-gemm-probe")]
 if hf_wide && matches!(params.hidden_size,2048|2560|4096){
   if let Some(groups)=host.request_row_groups(){return riley_cuda::hugging_face_qwen_wide_rms_norm_row_groups_cached(params,groups,stream);}
   return hugging_face_qwen_wide_rms_norm_row_groups(params,slots,stream);
 }
 #[cfg(feature="cuda-cublas-gemm-probe")]
 if hf_wide && profile==LlamaRmsNormProfile::HuggingFaceSmolLm2 {
   return riley_cuda::hugging_face_smollm2_rms_norm_row_groups(params,slots,stream);
 }
 #[cfg(not(feature="cuda-cublas-gemm-probe"))]let _=(slots,hf_wide);
 execute_profile_rms_norm(profile,params,stream)
}

pub(super) fn execute_profile_residual_rms_norm<S: CudaExecutionStream + ?Sized>(
    profile: LlamaRmsNormProfile,
    params: &mut ResidualRmsNormParams<'_>,
    stream: &mut S,
) -> Result<(), CudaError> {
    match profile {
        LlamaRmsNormProfile::Canonical => residual_rms_norm(params, stream),
        LlamaRmsNormProfile::HuggingFaceSmolLm2 => {
            hugging_face_smollm2_residual_rms_norm(params, stream)
        }
        LlamaRmsNormProfile::FixedContiguous37Balanced => fixed37_residual_rms_norm(params, stream),
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        LlamaRmsNormProfile::HuggingFaceCudaQwenP2051Probe => residual_rms_norm(params, stream),
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        LlamaRmsNormProfile::HuggingFaceCudaQwenP2048CacheOnProbe => {
            residual_rms_norm(params, stream)
        }
    }
}

pub(super) fn execute_projection_bias<S: CudaExecutionStream + ?Sized>(
    weights: &CudaUploadedWeights,
    bias_id: Option<PhysicalWeightId>,
    output: &mut CudaDeviceBuffer,
    row_count: u64,
    column_count: u64,
    stream: &mut S,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    let Some(bias_id) = bias_id else {
        return Ok(());
    };
    let bias = weight_span(weights, bias_id, site)?;
    let output_bytes = output.byte_len();
    let mut params = RowBiasAddInPlaceParams {
        matrix: span_mut(output, CudaDType::BF16, output_bytes, site)?,
        bias,
        row_count,
        column_count,
    };
    row_bias_add_in_place(&mut params, stream)
        .map_err(|source| LlamaForwardError::cuda(site, source))
}

pub(super) fn weight_span(
    weights: &CudaUploadedWeights,
    id: PhysicalWeightId,
    site: ExecutionSite,
) -> LlamaForwardResult<CudaBufferSpan<'_>> {
    weights
        .view_physical(id)
        .map(|weight| weight.span())
        .map_err(|source| LlamaForwardError::weight(site, source))
}

pub(super) fn span(
    buffer: &CudaDeviceBuffer,
    dtype: CudaDType,
    byte_len: u64,
    site: ExecutionSite,
) -> LlamaForwardResult<CudaBufferSpan<'_>> {
    CudaBufferSpan::new(buffer, dtype, 0, byte_len)
        .map_err(|source| LlamaForwardError::cuda(site, source))
}

pub(super) fn span_mut(
    buffer: &mut CudaDeviceBuffer,
    dtype: CudaDType,
    byte_len: u64,
    site: ExecutionSite,
) -> LlamaForwardResult<CudaBufferSpanMut<'_>> {
    CudaBufferSpanMut::new(buffer, dtype, 0, byte_len)
        .map_err(|source| LlamaForwardError::cuda(site, source))
}

pub(super) fn poison_for_cuda_error(poisoned: &mut bool, source: &CudaError) {
    if !matches!(source.stage(), CudaErrorStage::Validation) {
        *poisoned = true;
    }
}

pub(super) fn poison_for_forward_error(poisoned: &mut bool, error: &LlamaForwardError) {
    match error {
        LlamaForwardError::Cuda { source, .. } => poison_for_cuda_error(poisoned, source),
        LlamaForwardError::Embedding { source, .. } => {
            poison_for_cuda_error(poisoned, source.cuda_error());
        }
        LlamaForwardError::Weight { site: Some(_), .. }
        | LlamaForwardError::InvalidConfiguration { .. }
        | LlamaForwardError::ArithmeticOverflow { .. } => *poisoned = true,
        _ => {}
    }
}

fn trace_contract(plan: &LlamaExecutionPlan) -> LlamaTraceContract {
    LlamaTraceContract {
        sequence_length: plan.sequence_length(),
        layer_count: plan.layers().len(),
        dimensions: plan.dimensions(),
    }
}

fn trace_byte_len(plan: &LlamaExecutionPlan, point: LlamaTracePoint) -> LlamaForwardResult<u64> {
    let workspace = plan.workspace_spec();
    let bytes = match point {
        LlamaTracePoint::Layer0KeyProjection
        | LlamaTracePoint::Layer0ValueProjection
        | LlamaTracePoint::Layer0KeyRotary
        | LlamaTracePoint::Layer0KeyProjectionUnbiasedLinear
        | LlamaTracePoint::Layer0ValueProjectionUnbiasedLinear => {
            workspace.key_value_buffer_bytes()
        }
        LlamaTracePoint::Layer0AttentionProbabilities => workspace.attention_buffer_bytes(),
        LlamaTracePoint::Layer0GateProjection
        | LlamaTracePoint::Layer0UpProjection
        | LlamaTracePoint::Layer0Gated => workspace.intermediate_buffer_bytes(),
        LlamaTracePoint::LastLogits => {
            let sequence = u64::try_from(plan.sequence_length()).map_err(|_| {
                LlamaForwardError::ArithmeticOverflow {
                    resource: LlamaForwardResource::Logits,
                }
            })?;
            workspace.logits_bytes().checked_div(sequence).ok_or(
                LlamaForwardError::ArithmeticOverflow {
                    resource: LlamaForwardResource::Logits,
                },
            )?
        }
        LlamaTracePoint::Embedding
        | LlamaTracePoint::Layer0InputNorm
        | LlamaTracePoint::Layer0QueryProjection
        | LlamaTracePoint::Layer0QueryRotary
        | LlamaTracePoint::Layer0QueryProjectionUnbiasedLinear
        | LlamaTracePoint::Layer0AttentionContext
        | LlamaTracePoint::Layer0AfterAttentionResidual
        | LlamaTracePoint::Layer0PostAttentionNorm
        | LlamaTracePoint::Layer0DownProjection
        | LlamaTracePoint::Layer0Output
        | LlamaTracePoint::Layer14Output
        | LlamaTracePoint::FinalNormInput
        | LlamaTracePoint::FinalNormOutput => workspace.hidden_buffer_bytes(),
    };
    Ok(bytes)
}

fn trace_total_bytes(plan: &LlamaExecutionPlan, requested: u32) -> LlamaForwardResult<u64> {
    LlamaTracePoint::STORAGE
        .into_iter()
        .filter(|&point| requested & trace_bit(point) != 0)
        .try_fold(0_u64, |total, point| {
            total.checked_add(trace_byte_len(plan, point)?).ok_or(
                LlamaForwardError::ArithmeticOverflow {
                    resource: LlamaForwardResource::TraceCapture,
                },
            )
        })
}

fn normalize_last_token_layer_indices(
    layer_indices: &[usize],
    layer_count: usize,
) -> LlamaForwardResult<Vec<usize>> {
    let mut normalized = Vec::new();
    normalized
        .try_reserve_exact(layer_indices.len())
        .map_err(|_| LlamaForwardError::HostAllocation {
            resource: LlamaForwardResource::TraceCapture,
            requested_bytes: 0,
        })?;
    normalized.extend_from_slice(layer_indices);
    normalized.sort_unstable();
    normalized.dedup();
    if let Some(&layer_index) = normalized.iter().find(|&&index| index >= layer_count) {
        return Err(LlamaForwardError::LastTokenTraceLayerUnavailable {
            layer_index,
            actual_layers: layer_count,
        });
    }
    Ok(normalized)
}

fn last_token_hidden_row_byte_len(plan: &LlamaExecutionPlan) -> LlamaForwardResult<u64> {
    last_token_row_byte_len(plan.dimensions().hidden_size())
}

fn last_token_hidden_row_offset(plan: &LlamaExecutionPlan) -> LlamaForwardResult<u64> {
    last_token_row_offset(plan, plan.dimensions().hidden_size())
}

fn last_token_row_byte_len(width: usize) -> LlamaForwardResult<u64> {
    to_u64(width, LlamaForwardResource::TraceCapture)?
        .checked_mul(BF16_BYTES)
        .ok_or(LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::TraceCapture,
        })
}

fn last_token_row_offset(plan: &LlamaExecutionPlan, width: usize) -> LlamaForwardResult<u64> {
    let sequence_minus_one =
        plan.sequence_length()
            .checked_sub(1)
            .ok_or(LlamaForwardError::ArithmeticOverflow {
                resource: LlamaForwardResource::TraceCapture,
            })?;
    to_u64(sequence_minus_one, LlamaForwardResource::TraceCapture)?
        .checked_mul(to_u64(width, LlamaForwardResource::TraceCapture)?)
        .and_then(|elements| elements.checked_mul(BF16_BYTES))
        .ok_or(LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::TraceCapture,
        })
}

fn last_token_layer_stage_row_byte_len(
    plan: &LlamaExecutionPlan,
    stage: LlamaLastTokenLayerStage,
) -> LlamaForwardResult<u64> {
    let dimensions = plan.dimensions();
    let width = if stage.requires_key_value_width() {
        dimensions.key_value_width()
    } else if stage.requires_intermediate_width() {
        dimensions.intermediate_size()
    } else {
        dimensions.hidden_size()
    };
    last_token_row_byte_len(width)
}

fn full_sequence_layer_stage_byte_len(
    plan: &LlamaExecutionPlan,
    stage: LlamaLastTokenLayerStage,
) -> LlamaForwardResult<u64> {
    to_u64(plan.sequence_length(), LlamaForwardResource::TraceCapture)?
        .checked_mul(last_token_layer_stage_row_byte_len(plan, stage)?)
        .ok_or(LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::TraceCapture,
        })
}

fn last_token_trace_total_bytes(
    layer_count: usize,
    row_byte_len: u64,
    capture_final_norm_output: bool,
) -> LlamaForwardResult<u64> {
    let output_count = u64::try_from(layer_count)
        .map_err(|_| LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::TraceCapture,
        })?
        .checked_add(u64::from(capture_final_norm_output))
        .ok_or(LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::TraceCapture,
        })?;
    output_count
        .checked_mul(row_byte_len)
        .ok_or(LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::TraceCapture,
        })
}

fn capture_trace(
    trace: &mut Option<&mut PreparedLlamaTrace>,
    point: LlamaTracePoint,
    buffer: &mut CudaDeviceBuffer,
    source_offset: u64,
    io_staging: &mut CudaPinnedHostBuffer,
    stream: &mut CudaStream,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    let Some(trace) = trace.as_deref_mut() else {
        return Ok(());
    };
    if !trace.requests(point) {
        return Ok(());
    }
    {
        let destination = trace.destination(point);
        buffer
            .download_to_slice(source_offset, destination, io_staging, stream)
            .map_err(|source| LlamaForwardError::cuda(site, source))?;
    }
    trace.mark_captured(point);
    Ok(())
}

pub(super) fn capture_last_token_layer_residual(
    trace: &mut Option<&mut PreparedLlamaLastTokenLayerTrace>,
    layer_index: usize,
    buffer: &mut CudaDeviceBuffer,
    source_offset: u64,
    io_staging: &mut CudaPinnedHostBuffer,
    stream: &mut CudaStream,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    let Some(trace) = trace.as_deref_mut() else {
        return Ok(());
    };
    let Some(ordinal) = trace.layer_ordinal(layer_index) else {
        return Ok(());
    };
    {
        let destination = trace.layer_destination(ordinal);
        buffer
            .download_to_slice(source_offset, destination, io_staging, stream)
            .map_err(|source| LlamaForwardError::cuda(site, source))?;
    }
    trace.mark_layer_captured(ordinal);
    Ok(())
}

pub(super) fn capture_last_token_layer_stage(
    trace: &mut Option<&mut PreparedLlamaLastTokenLayerStageTrace>,
    layer_index: usize,
    stage: LlamaLastTokenLayerStage,
    buffer: &mut CudaDeviceBuffer,
    source_offset: u64,
    io_staging: &mut CudaPinnedHostBuffer,
    stream: &mut CudaStream,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    let Some(trace) = trace.as_deref_mut() else {
        return Ok(());
    };
    if trace.layer_index() != layer_index {
        return Ok(());
    }
    {
        let destination = trace.destination(stage);
        buffer
            .download_to_slice(source_offset, destination, io_staging, stream)
            .map_err(|source| LlamaForwardError::cuda(site, source))?;
    }
    trace.mark_captured(stage);
    Ok(())
}

fn capture_full_sequence_layer_stage(
    trace: &mut Option<&mut PreparedLlamaFullSequenceLayerStageTrace>,
    layer_index: usize,
    stage: LlamaLastTokenLayerStage,
    buffer: &mut CudaDeviceBuffer,
    io_staging: &mut CudaPinnedHostBuffer,
    stream: &mut CudaStream,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    let Some(trace) = trace.as_deref_mut() else {
        return Ok(());
    };
    if trace.layer_index() != layer_index || !trace.requests(stage) {
        return Ok(());
    }
    {
        let destination = trace.destination(stage);
        buffer
            .download_to_slice(0, destination, io_staging, stream)
            .map_err(|source| LlamaForwardError::cuda(site, source))?;
    }
    trace.mark_captured(stage);
    Ok(())
}

pub(super) fn capture_last_token_final_norm_output(
    trace: &mut Option<&mut PreparedLlamaLastTokenLayerTrace>,
    buffer: &mut CudaDeviceBuffer,
    source_offset: u64,
    io_staging: &mut CudaPinnedHostBuffer,
    stream: &mut CudaStream,
    site: ExecutionSite,
) -> LlamaForwardResult<()> {
    let Some(trace) = trace.as_deref_mut() else {
        return Ok(());
    };
    let Some(destination) = trace.final_norm_destination() else {
        return Ok(());
    };
    buffer
        .download_to_slice(source_offset, destination, io_staging, stream)
        .map_err(|source| LlamaForwardError::cuda(site, source))?;
    trace.mark_final_norm_output_captured();
    Ok(())
}

fn trace_requests_unbiased_qkv_projection(trace: &PreparedLlamaTrace) -> bool {
    [
        LlamaTracePoint::Layer0QueryProjectionUnbiasedLinear,
        LlamaTracePoint::Layer0KeyProjectionUnbiasedLinear,
        LlamaTracePoint::Layer0ValueProjectionUnbiasedLinear,
    ]
    .into_iter()
    .any(|point| trace.requests(point))
}

impl LlamaForwardResource {
    const fn name(self) -> &'static str {
        match self {
            Self::UploadedWeights => "uploaded_weights",
            Self::UploadStaging => "upload_staging",
            Self::IoStaging => "io_staging",
            Self::HiddenGemm => "hidden_gemm",
            Self::KeyValueGemm => "key_value_gemm",
            Self::QueryBiasEpilogueGemm => "query_bias_epilogue_gemm",
            Self::KeyValueBiasEpilogueGemm => "key_value_bias_epilogue_gemm",
            Self::OutputProjectionDirectCublasGemm => "output_projection_direct_cublas_gemm",
            Self::MlpIntermediateDirectCublasGemm => "mlp_intermediate_direct_cublas_gemm",
            Self::MlpDownDirectCublasGemm => "mlp_down_direct_cublas_gemm",
            Self::LmHeadLastTokenDirectCublasGemm => "lm_head_last_token_direct_cublas_gemm",
            Self::IntermediateGemm => "intermediate_gemm",
            Self::DownGemm => "down_gemm",
            Self::LmHeadGemm => "lm_head_gemm",
            Self::TokenIds => "token_ids",
            Self::HiddenCurrent => "hidden_current",
            Self::HiddenNorm => "hidden_norm",
            Self::HiddenProjection => "hidden_projection",
            Self::HiddenRotary => "hidden_rotary",
            Self::HiddenContext => "hidden_context",
            Self::KeyRaw => "key_raw",
            Self::ValueRaw => "value_raw",
            Self::KeyRotary => "key_rotary",
            Self::GateRaw => "gate_raw",
            Self::UpRaw => "up_raw",
            Self::GateActivated => "gate_activated",
            Self::GatedProduct => "gated_product",
            Self::Attention => "attention",
            Self::RopeCos => "rope_cos",
            Self::RopeSin => "rope_sin",
            Self::Logits => "logits",
            Self::EmbeddingErrorScratch => "embedding_error_scratch",
            Self::GemmWorkspace => "gemm_workspace",
            Self::TraceCapture => "trace_capture",
        }
    }
}

impl fmt::Display for LlamaForwardResource {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(self.name())
    }
}

/// Structured PR07 preparation, execution, transfer, or cleanup failure.
#[derive(Debug)]
#[non_exhaustive]
pub enum LlamaForwardError {
    Plan(LlamaPlanError),
    Weight {
        site: Option<ExecutionSite>,
        source: CudaWeightUploadError,
    },
    Cuda {
        site: ExecutionSite,
        source: CudaError,
    },
    Embedding {
        site: ExecutionSite,
        source: EmbeddingError,
    },
    InvalidConfiguration {
        field: &'static str,
        reason: &'static str,
    },
    AttentionBudgetExceeded {
        required_bytes: u64,
        maximum_bytes: u64,
    },
    HostAllocation {
        resource: LlamaForwardResource,
        requested_bytes: u64,
    },
    InvalidTokenCount {
        expected: usize,
        actual: usize,
    },
    TokenOutOfRange {
        position: usize,
        token_id: u32,
        vocabulary_size: usize,
    },
    TokensNotUploaded,
    OutputNotReady,
    Poisoned,
    InvalidDownloadLength {
        expected_bytes: usize,
        actual_bytes: usize,
    },
    TracePlanMismatch,
    TraceRequiresReferenceAttention,
    TraceLayerUnavailable {
        required_layers: usize,
        actual_layers: usize,
    },
    LastTokenTraceLayerUnavailable {
        layer_index: usize,
        actual_layers: usize,
    },
    FullSequenceLayerStageTraceLayerUnavailable {
        layer_index: usize,
        actual_layers: usize,
    },
    Cleanup {
        resource: LlamaForwardResource,
        source: CudaError,
    },
    ArithmeticOverflow {
        resource: LlamaForwardResource,
    },
}

impl LlamaForwardError {
    pub(super) fn cuda(site: ExecutionSite, source: CudaError) -> Self {
        Self::Cuda { site, source }
    }

    fn weight(site: ExecutionSite, source: CudaWeightUploadError) -> Self {
        Self::Weight {
            site: Some(site),
            source,
        }
    }
}

impl fmt::Display for LlamaForwardError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Plan(source) => source.fmt(formatter),
            Self::Weight {
                site: Some(site),
                source,
            } => write!(formatter, "{site}: {source}"),
            Self::Weight { site: None, source } => source.fmt(formatter),
            Self::Cuda { site, source } => write!(formatter, "{site}: {source}"),
            Self::Embedding { site, source } => write!(formatter, "{site}: {source}"),
            Self::InvalidConfiguration { field, reason } => {
                write!(
                    formatter,
                    "invalid Llama forward configuration {field}: {reason}"
                )
            }
            Self::AttentionBudgetExceeded {
                required_bytes,
                maximum_bytes,
            } => write!(
                formatter,
                "materialized attention requires {required_bytes} bytes, exceeding budget {maximum_bytes}"
            ),
            Self::HostAllocation {
                resource,
                requested_bytes,
            } => write!(
                formatter,
                "could not reserve {requested_bytes} host bytes for {resource}"
            ),
            Self::InvalidTokenCount { expected, actual } => {
                write!(
                    formatter,
                    "forward expects {expected} token IDs, received {actual}"
                )
            }
            Self::TokenOutOfRange {
                position,
                token_id,
                vocabulary_size,
            } => write!(
                formatter,
                "token ID {token_id} at position {position} is outside vocabulary 0..{vocabulary_size}"
            ),
            Self::TokensNotUploaded => {
                formatter.write_str("token IDs must be uploaded before executing the forward")
            }
            Self::OutputNotReady => {
                formatter.write_str("logits are unavailable before a successful forward")
            }
            Self::Poisoned => formatter
                .write_str("the Llama forward was poisoned by a native CUDA execution failure"),
            Self::InvalidDownloadLength {
                expected_bytes,
                actual_bytes,
            } => write!(
                formatter,
                "download destination has {actual_bytes} bytes, expected {expected_bytes}"
            ),
            Self::TracePlanMismatch => formatter
                .write_str("prepared trace dimensions do not match this Llama execution plan"),
            Self::TraceRequiresReferenceAttention => formatter.write_str(
                "the PR07 probability trace requires the materialized reference attention backend",
            ),
            Self::TraceLayerUnavailable {
                required_layers,
                actual_layers,
            } => write!(
                formatter,
                "PR07 trace requires at least {required_layers} decoder layers, found {actual_layers}"
            ),
            Self::LastTokenTraceLayerUnavailable {
                layer_index,
                actual_layers,
            } => write!(
                formatter,
                "last-token layer trace requested layer {layer_index}, but the forward has {actual_layers} decoder layers"
            ),
            Self::FullSequenceLayerStageTraceLayerUnavailable {
                layer_index,
                actual_layers,
            } => write!(
                formatter,
                "full-sequence layer-stage trace requested layer {layer_index}, but the forward has {actual_layers} decoder layers"
            ),
            Self::Cleanup { resource, source } => {
                write!(formatter, "could not close {resource}: {source}")
            }
            Self::ArithmeticOverflow { resource } => {
                write!(formatter, "byte arithmetic overflow for {resource}")
            }
        }
    }
}

impl error::Error for LlamaForwardError {
    fn source(&self) -> Option<&(dyn error::Error + 'static)> {
        match self {
            Self::Plan(source) => Some(source),
            Self::Weight { source, .. } => Some(source),
            Self::Cuda { source, .. } | Self::Cleanup { source, .. } => Some(source),
            Self::Embedding { source, .. } => Some(source),
            _ => None,
        }
    }
}

impl From<LlamaPlanError> for LlamaForwardError {
    fn from(source: LlamaPlanError) -> Self {
        Self::Plan(source)
    }
}

/// Q/K/V bias implementation selected during cold preparation.
///
/// The strict staged path remains the default compatibility contract. The
/// fused mode is opt-in because it intentionally adopts cuBLASLt's BF16 BIAS
/// epilogue rounding, which is qualified separately against the external
/// module output. It is eager-only until a complete CUDA-graph capture contract is
/// implemented for the same plan and pointer lifetime.
#[derive(Clone, Copy, Debug, Default, Eq, Hash, PartialEq)]
#[non_exhaustive]
pub enum LlamaProjectionBiasMode {
    /// Preserve standalone GEMM followed by the established BF16 row-bias add.
    #[default]
    StrictStagedV1,
    /// Use the qualified cuBLASLt BIAS epilogue for Q/K/V projections only.
    CublasLtBiasEpilogueExperimentalV1,
    /// Run Q, K, and V as one GEMM over concatenated weights, then split the
    /// result into the three outputs with the established staged BF16 bias
    /// add. Bias arithmetic is unchanged; only the GEMM launch (and therefore
    /// possibly its accumulation order) differs from three separate GEMMs.
    MergedQkvStrictStagedV1,
    /// Use the source-bound Hugging Face-compatible cuBLASLt BIAS profile.
    ///
    /// This diagnostic-only variant preserves the split-K reduction topology
    /// selected by the pinned P2051 `torch.addmm` discriminator. It is hidden
    /// behind the direct-cuBLAS probe feature and is deliberately unavailable
    /// to the ordinary serving selector until full-forward qualification
    /// completes.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HfCompatibleBiasEpilogueProbeV1,
}

impl LlamaProjectionBiasMode {
    /// Stable cold-selection identifier for logs and benchmark provenance.
    #[must_use]
    pub const fn id(self) -> &'static str {
        match self {
            Self::StrictStagedV1 => "strict-staged-v1",
            Self::CublasLtBiasEpilogueExperimentalV1 => "cublaslt-bias-epilogue-experimental-v1",
            Self::MergedQkvStrictStagedV1 => "merged-qkv-strict-staged-v1",
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::HfCompatibleBiasEpilogueProbeV1 => "hf-compatible-bias-epilogue-probe-v1",
        }
    }

    /// Whether Q, K, and V run as one merged GEMM.
    #[must_use]
    pub const fn merges_qkv(self) -> bool {
        matches!(self, Self::MergedQkvStrictStagedV1)
    }

    const fn requires_qkv_bias_epilogue(self) -> bool {
        matches!(self, Self::CublasLtBiasEpilogueExperimentalV1) || {
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            {
                matches!(self, Self::HfCompatibleBiasEpilogueProbeV1)
            }
            #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
            {
                false
            }
        }
    }

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    const fn is_hf_compatible_bias_epilogue_probe(self) -> bool {
        matches!(self, Self::HfCompatibleBiasEpilogueProbeV1)
    }
}

/// Cold-selected implementation for decoder attention output projections.
///
/// The default shares the established hidden-width GEMM plan. The alternate
/// mode is intentionally narrower: it exists only to qualify the exact
/// full-sequence Qwen P2051 eager-HF arithmetic contract before any serving
/// selector is allowed to opt in.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub(super) enum LlamaOutputProjectionMode {
    #[default]
    StrictHiddenGemmV1,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HfEagerQwenP2051DirectCublasProbeV1,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HfEagerQwenP2048CacheOnDirectCublasProbeV1,
}

impl LlamaOutputProjectionMode {
    const fn id(self) -> &'static str {
        match self {
            Self::StrictHiddenGemmV1 => "strict-hidden-gemm-v1",
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::HfEagerQwenP2051DirectCublasProbeV1 => {
                "hf-eager-qwen-p2051-direct-cublas-probe-v1"
            }
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::HfEagerQwenP2048CacheOnDirectCublasProbeV1 => {
                "hf-eager-qwen-p2048-cache-on-direct-cublas-probe-v1"
            }
        }
    }

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    const fn is_hf_eager_qwen_p2051_direct_cublas_probe(self) -> bool {
        matches!(self, Self::HfEagerQwenP2051DirectCublasProbeV1)
    }

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    const fn is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe(self) -> bool {
        matches!(self, Self::HfEagerQwenP2048CacheOnDirectCublasProbeV1)
    }
}

/// Cold-selected implementation for the decoder MLP Linear projections.
///
/// The alternate variant is a source-bound, cache-free P2051 diagnostic. It
/// reuses a direct-cuBLAS plan for gate/up and a second plan for down only
/// after their isolated Hugging Face eager module boundaries have qualified.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub(super) enum LlamaMlpProjectionMode {
    #[default]
    StrictStagedV1,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HfEagerQwenP2051DirectCublasProbeV1,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HfEagerQwenP2048CacheOnDirectCublasProbeV1,
}

impl LlamaMlpProjectionMode {
    const fn id(self) -> &'static str {
        match self {
            Self::StrictStagedV1 => "strict-staged-v1",
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::HfEagerQwenP2051DirectCublasProbeV1 => {
                "hf-eager-qwen-p2051-direct-cublas-probe-v1"
            }
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::HfEagerQwenP2048CacheOnDirectCublasProbeV1 => {
                "hf-eager-qwen-p2048-cache-on-direct-cublas-probe-v1"
            }
        }
    }

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    const fn is_hf_eager_qwen_p2051_direct_cublas_probe(self) -> bool {
        matches!(self, Self::HfEagerQwenP2051DirectCublasProbeV1)
    }

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    const fn is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe(self) -> bool {
        matches!(self, Self::HfEagerQwenP2048CacheOnDirectCublasProbeV1)
    }
}

/// Cold-selected implementation for the final vocabulary projection.
///
/// The diagnostic alternate is deliberately distinct from decoder output
/// projections: Hugging Face's Qwen forward applies the LM head only to the
/// final row when `logits_to_keep=1`, while the ordinary Riley owner produces
/// the full fixed-sequence logits matrix.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub(super) enum LlamaLmHeadMode {
    #[default]
    StrictFullSequenceGemmV1,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HfEagerQwenP2051LastTokenDirectCublasProbeV1,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    HfEagerQwenP2048CacheOnLastTokenDirectCublasProbeV1,
}

impl LlamaLmHeadMode {
    const fn id(self) -> &'static str {
        match self {
            Self::StrictFullSequenceGemmV1 => "strict-full-sequence-gemm-v1",
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::HfEagerQwenP2051LastTokenDirectCublasProbeV1 => {
                "hf-eager-qwen-p2051-last-token-direct-cublas-probe-v1"
            }
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            Self::HfEagerQwenP2048CacheOnLastTokenDirectCublasProbeV1 => {
                "hf-eager-qwen-p2048-cache-on-last-token-direct-cublas-probe-v1"
            }
        }
    }

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    const fn is_hf_eager_qwen_p2051_last_token_direct_cublas_probe(self) -> bool {
        matches!(self, Self::HfEagerQwenP2051LastTokenDirectCublasProbeV1)
    }

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    const fn is_hf_eager_qwen_p2048_cache_on_last_token_direct_cublas_probe(self) -> bool {
        matches!(
            self,
            Self::HfEagerQwenP2048CacheOnLastTokenDirectCublasProbeV1
        )
    }
}

/// Cold-path limits for one fixed-sequence forward owner.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[allow(clippy::struct_field_names)]
pub struct PreparedLlamaForwardConfig {
    upload_staging_bytes: u64,
    io_staging_bytes: u64,
    gemm_workspace_cap_bytes: u64,
    attention_budget_bytes: u64,
    attention_preference: AttentionPreference,
    reduction_profile: LlamaReductionProfile,
    projection_bias_mode: LlamaProjectionBiasMode,
    merged_gate_up: bool,
    output_projection_mode: LlamaOutputProjectionMode,
    mlp_projection_mode: LlamaMlpProjectionMode,
    lm_head_mode: LlamaLmHeadMode,
    rope_table_selection: LlamaRopeTableSelection,
    rms_norm_selection: LlamaRmsNormSelection,
    first_heuristic_gemm_reductions: bool,
    bit_equivalent_gemm_selection: bool,
    owned_hf_eager_bf16: bool,
}

impl PreparedLlamaForwardConfig {
    #[must_use]
    pub const fn new(
        upload_staging_bytes: u64,
        io_staging_bytes: u64,
        gemm_workspace_cap_bytes: u64,
        attention_budget_bytes: u64,
    ) -> Self {
        Self {
            upload_staging_bytes,
            io_staging_bytes,
            gemm_workspace_cap_bytes,
            attention_budget_bytes,
            attention_preference: AttentionPreference::Optimized,
            reduction_profile: LlamaReductionProfile::CanonicalV1,
            projection_bias_mode: LlamaProjectionBiasMode::StrictStagedV1,
            merged_gate_up: false,
            output_projection_mode: LlamaOutputProjectionMode::StrictHiddenGemmV1,
            mlp_projection_mode: LlamaMlpProjectionMode::StrictStagedV1,
            lm_head_mode: LlamaLmHeadMode::StrictFullSequenceGemmV1,
            rope_table_selection: LlamaRopeTableSelection::Automatic,
            rms_norm_selection: LlamaRmsNormSelection::Automatic,
            first_heuristic_gemm_reductions: false,
            bit_equivalent_gemm_selection: false,
            owned_hf_eager_bf16: false,
        }
    }

    /// Selects the owned BF16 eager arithmetic profile for batch preparation.
    /// It requires the matching batch attention selector; the batch owner
    /// validates completion policy and unsupported component combinations.
    #[must_use]
    pub const fn with_owned_hf_eager_bf16(mut self) -> Self {
        self.owned_hf_eager_bf16 = true;
        self
    }

    #[must_use]
    pub const fn owned_hf_eager_bf16(self) -> bool { self.owned_hf_eager_bf16 }

    /// Selects the allocation-free online prefill backend when supported,
    /// falling back to the native materialized reference during preparation.
    #[must_use]
    pub const fn with_optimized_attention(mut self) -> Self {
        self.attention_preference = AttentionPreference::Optimized;
        self
    }

    /// Requires the native materialized reference backend. This mode is used
    /// by the pinned PR07 probability trace and its exact staged-BF16 golden.
    #[must_use]
    pub const fn with_reference_attention(mut self) -> Self {
        self.attention_preference = AttentionPreference::Reference;
        self
    }

    /// Requires the reviewed Hugging Face eager-compatible attention backend.
    /// Unsupported model, device, or sequence geometry fails during cold
    /// preparation instead of falling back.
    #[must_use]
    pub const fn with_hugging_face_eager_attention(mut self) -> Self {
        self.attention_preference = AttentionPreference::HuggingFaceEager;
        self
    }

    /// Requires the P2051 Qwen Hugging Face eager attention diagnostic
    /// candidate. This is feature-gated and is never chosen by an ordinary
    /// serving selection policy.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    #[must_use]
    pub const fn with_hugging_face_eager_qwen_p2051_probe_attention(mut self) -> Self {
        self.attention_preference = AttentionPreference::HuggingFaceEagerQwenP2051Probe;
        self
    }

    /// Selects one whole-runtime reduction contract for GEMM, `RMSNorm`, and
    /// prefill attention. Preparation never falls back across profiles.
    #[must_use]
    pub const fn with_reduction_profile(mut self, profile: LlamaReductionProfile) -> Self {
        self.reduction_profile = profile;
        self
    }

    /// Restores the established canonical reduction contract.
    #[must_use]
    pub const fn with_canonical_reductions(mut self) -> Self {
        self.reduction_profile = LlamaReductionProfile::CanonicalV1;
        self
    }

    /// Lets every canonical-profile projection keep cuBLASLt's first heuristic
    /// reduction instead of the model's default policy. Deterministic for a
    /// fixed device, library and shape, but a different arithmetic from the
    /// default, so it is opt-in.
    #[must_use]
    pub const fn with_first_heuristic_gemm_reductions(mut self) -> Self {
        self.first_heuristic_gemm_reductions = true;
        self
    }

    /// With the first-heuristic reductions, lets each row bucket use a listed
    /// algorithm that the native layer verified to be bit-identical to the
    /// anchor algorithm for that exact shape. Outputs do not change.
    #[must_use]
    pub const fn with_bit_equivalent_gemm_selection(mut self) -> Self {
        self.bit_equivalent_gemm_selection = true;
        self
    }

    /// Selects fixed contiguous groups of 37 followed by balanced reductions.
    #[must_use]
    pub const fn with_fixed37_reductions(mut self) -> Self {
        self.reduction_profile = LlamaReductionProfile::FixedContiguous37BalancedV1;
        self
    }

    /// Selects the Q/K/V bias implementation used by one prepared owner.
    ///
    /// `CublasLtBiasEpilogueExperimentalV1` remains explicit because its
    /// arithmetic is the qualified fused-Hugging-Face contract, rather than
    /// the established staged BF16 compatibility contract.
    #[must_use]
    /// Selects one merged Q|K|V GEMM followed by the staged bias split.
    #[must_use]
    pub const fn with_merged_qkv_projection(mut self) -> Self {
        self.projection_bias_mode = LlamaProjectionBiasMode::MergedQkvStrictStagedV1;
        self
    }

    /// Selects one GEMM over the concatenated gate|up weights of each MLP
    /// (batch executor only; needs the fused SiLU multiply). The merged weight
    /// is a second device copy of the two projections.
    #[must_use]
    pub const fn with_merged_gate_up_projection(mut self) -> Self {
        self.merged_gate_up = true;
        self
    }

    /// Selects the projection bias mode explicitly.
    #[must_use]
    pub const fn with_projection_bias_mode(mut self, mode: LlamaProjectionBiasMode) -> Self {
        self.projection_bias_mode = mode;
        self
    }

    /// Selects the established standalone-GEMM plus row-bias contract.
    #[must_use]
    pub const fn with_strict_staged_projection_bias(mut self) -> Self {
        self.projection_bias_mode = LlamaProjectionBiasMode::StrictStagedV1;
        self
    }

    /// Selects the qualified eager-only cuBLASLt Q/K/V BIAS epilogue.
    #[must_use]
    pub const fn with_cublaslt_bias_epilogue_projection_bias(mut self) -> Self {
        self.projection_bias_mode = LlamaProjectionBiasMode::CublasLtBiasEpilogueExperimentalV1;
        self
    }

    /// Selects the P2051-qualified Hugging Face-compatible cuBLASLt Q/K/V
    /// BIAS profile for an isolated full-forward diagnostic.
    ///
    /// This API is feature-gated so ordinary CUDA builds and serving selectors
    /// cannot accidentally select the still-unqualified profile.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    #[must_use]
    pub const fn with_hf_compatible_bias_epilogue_projection_probe(mut self) -> Self {
        self.projection_bias_mode = LlamaProjectionBiasMode::HfCompatibleBiasEpilogueProbeV1;
        self
    }

    /// Selects the P2051-qualified direct-cuBLAS output projection for an
    /// isolated cache-free full-forward diagnostic.
    ///
    /// The method is feature-gated and has no ordinary serving selector. Cold
    /// preparation requires the matching Q/K/V and attention probe modes plus
    /// the exact reviewed Qwen geometry.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    #[must_use]
    pub const fn with_hf_eager_qwen_p2051_direct_cublas_output_projection_probe(mut self) -> Self {
        self.output_projection_mode =
            LlamaOutputProjectionMode::HfEagerQwenP2051DirectCublasProbeV1;
        self
    }

    /// Selects the P2051-qualified direct-cuBLAS MLP projections for one
    /// isolated cache-free full-forward diagnostic.
    ///
    /// This API is feature-gated and cannot be reached through an ordinary
    /// serving selector. It requires the paired direct O-projection and the
    /// pre-existing P2051 Q/K/V and attention diagnostic modes.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    #[must_use]
    pub const fn with_hf_eager_qwen_p2051_direct_cublas_mlp_projection_probe(mut self) -> Self {
        self.mlp_projection_mode = LlamaMlpProjectionMode::HfEagerQwenP2051DirectCublasProbeV1;
        self
    }

    /// Selects the last-token-only direct-cuBLAS LM head used by the P2051
    /// cache-free eager-HF qualifier. The mode mirrors Hugging Face's
    /// `logits_to_keep=1` shape and is diagnostic-only: it cannot be reached
    /// through an ordinary serving selector and does not make full logits
    /// available for download.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    #[must_use]
    pub const fn with_hf_eager_qwen_p2051_last_token_direct_cublas_lm_head_probe(mut self) -> Self {
        self.lm_head_mode = LlamaLmHeadMode::HfEagerQwenP2051LastTokenDirectCublasProbeV1;
        self
    }

    /// Selects GPU-generated RoPE tables for the paired P2051 Qwen eager
    /// diagnostic. This is feature-gated and cannot be reached by a serving
    /// selector; it exists solely to reproduce the framework's cold table
    /// construction before the cache-free quality gate is complete.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    #[must_use]
    pub const fn with_hugging_face_cuda_qwen_p2051_rope_table_probe(mut self) -> Self {
        self.rope_table_selection = LlamaRopeTableSelection::HuggingFaceCudaQwenP2051ProbeV1;
        self
    }

    /// Selects the P2051-native RMSNorm candidate that reproduces the pinned
    /// Hugging Face FP32 `pow(2).mean` reduction topology. This is
    /// feature-gated and diagnostic-only; no serving selector can use it.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    #[must_use]
    pub const fn with_hugging_face_cuda_qwen_p2051_rms_norm_probe(mut self) -> Self {
        self.rms_norm_selection = LlamaRmsNormSelection::HuggingFaceCudaQwenP2051ProbeV1;
        self
    }

    /// Selects the whole P2048 Qwen cache-on *prefill* diagnostic profile.
    ///
    /// The profile is deliberately one atomic opt-in rather than a collection
    /// of serving toggles: Q/K/V bias epilogues, attention, O/MLP/LM direct
    /// cuBLAS, GPU RoPE tables, and RMSNorm must all match the same offline
    /// HF cache-on stage receipt. It has no serving selector route. A separate
    /// source-bound M1 trace owner may reuse this atomic profile solely to
    /// diagnose cache-on decode arithmetic.
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    #[must_use]
    pub const fn with_hf_eager_qwen_p2048_cache_on_prefill_probe(mut self) -> Self {
        self.attention_preference = AttentionPreference::HuggingFaceEagerQwenP2048CacheOnProbe;
        self.projection_bias_mode = LlamaProjectionBiasMode::HfCompatibleBiasEpilogueProbeV1;
        self.output_projection_mode =
            LlamaOutputProjectionMode::HfEagerQwenP2048CacheOnDirectCublasProbeV1;
        self.mlp_projection_mode =
            LlamaMlpProjectionMode::HfEagerQwenP2048CacheOnDirectCublasProbeV1;
        self.lm_head_mode = LlamaLmHeadMode::HfEagerQwenP2048CacheOnLastTokenDirectCublasProbeV1;
        self.rope_table_selection = LlamaRopeTableSelection::HuggingFaceCudaQwenP2048CacheOnProbeV1;
        self.rms_norm_selection = LlamaRmsNormSelection::HuggingFaceCudaQwenP2048CacheOnProbeV1;
        self
    }

    #[must_use]
    pub const fn upload_staging_bytes(self) -> u64 {
        self.upload_staging_bytes
    }

    #[must_use]
    pub const fn io_staging_bytes(self) -> u64 {
        self.io_staging_bytes
    }

    #[must_use]
    pub const fn gemm_workspace_cap_bytes(self) -> u64 {
        self.gemm_workspace_cap_bytes
    }

    #[must_use]
    pub const fn attention_budget_bytes(self) -> u64 {
        self.attention_budget_bytes
    }

    #[must_use]
    pub const fn attention_preference(self) -> AttentionPreference {
        self.attention_preference
    }

    /// Whole-runtime reduction contract selected for preparation.
    #[must_use]
    pub const fn reduction_profile(self) -> LlamaReductionProfile {
        self.reduction_profile
    }

    /// Q/K/V bias implementation selected for cold preparation.
    #[must_use]
    pub const fn projection_bias_mode(self) -> LlamaProjectionBiasMode {
        self.projection_bias_mode
    }

    /// MLP Linear implementation selected during cold preparation.
    #[must_use]
    pub(super) const fn mlp_projection_mode(self) -> LlamaMlpProjectionMode {
        self.mlp_projection_mode
    }

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    pub(super) fn has_hf_eager_qwen_p2048_cache_on_component(self) -> bool {
        self.attention_preference == AttentionPreference::HuggingFaceEagerQwenP2048CacheOnProbe
            || self
                .output_projection_mode
                .is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe()
            || self
                .mlp_projection_mode
                .is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe()
            || self
                .lm_head_mode
                .is_hf_eager_qwen_p2048_cache_on_last_token_direct_cublas_probe()
            || self.rope_table_selection
                == LlamaRopeTableSelection::HuggingFaceCudaQwenP2048CacheOnProbeV1
            || self.rms_norm_selection
                == LlamaRmsNormSelection::HuggingFaceCudaQwenP2048CacheOnProbeV1
    }

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    pub(super) fn is_hf_eager_qwen_p2048_cache_on_prefill_profile(self) -> bool {
        self.attention_preference == AttentionPreference::HuggingFaceEagerQwenP2048CacheOnProbe
            && self.projection_bias_mode == LlamaProjectionBiasMode::HfCompatibleBiasEpilogueProbeV1
            && self
                .output_projection_mode
                .is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe()
            && self
                .mlp_projection_mode
                .is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe()
            && self
                .lm_head_mode
                .is_hf_eager_qwen_p2048_cache_on_last_token_direct_cublas_probe()
            && self.rope_table_selection
                == LlamaRopeTableSelection::HuggingFaceCudaQwenP2048CacheOnProbeV1
            && self.rms_norm_selection
                == LlamaRmsNormSelection::HuggingFaceCudaQwenP2048CacheOnProbeV1
            && self.reduction_profile == LlamaReductionProfile::CanonicalV1
    }

    fn validate(self) -> LlamaForwardResult<()> {
        if self.owned_hf_eager_bf16 {
            if !cfg!(feature="cuda-cublas-gemm-probe") {
                return Err(LlamaForwardError::InvalidConfiguration {field:"owned-hf-eager-bf16-v1",reason:"the owned eager CUDA feature is not linked"});
            }
            if self.reduction_profile != LlamaReductionProfile::CanonicalV1 || self.merged_gate_up
                || self.first_heuristic_gemm_reductions || self.bit_equivalent_gemm_selection {
                return Err(LlamaForwardError::InvalidConfiguration {field:"owned-hf-eager-bf16-v1",reason:"unqualified reduction/merged-MLP overrides are unsupported"});
            }
        }
        if self.upload_staging_bytes == 0 {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "upload_staging_bytes",
                reason: "must be non-zero",
            });
        }
        if self.io_staging_bytes == 0 {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "io_staging_bytes",
                reason: "must be non-zero",
            });
        }
        if self.projection_bias_mode.requires_qkv_bias_epilogue()
            && self.reduction_profile != LlamaReductionProfile::CanonicalV1
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "projection_bias_mode",
                reason: "cuBLASLt bias epilogue requires canonical-v1 reductions",
            });
        }
        if self.projection_bias_mode.merges_qkv()
            && self.reduction_profile != LlamaReductionProfile::CanonicalV1
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "projection_bias_mode",
                reason: "merged QKV projection requires canonical-v1 reductions",
            });
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if self.has_hf_eager_qwen_p2048_cache_on_component()
            && !self.is_hf_eager_qwen_p2048_cache_on_prefill_profile()
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "p2048_cache_on_prefill_profile",
                reason: "every paired P2048 cache-on Q/K/V, attention, O-projection, MLP, LM-head, RoPE-table, RMSNorm, and canonical reduction mode must be selected together",
            });
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if self
            .output_projection_mode
            .is_hf_eager_qwen_p2051_direct_cublas_probe()
            && (self.projection_bias_mode
                != LlamaProjectionBiasMode::HfCompatibleBiasEpilogueProbeV1
                || self.attention_preference != AttentionPreference::HuggingFaceEagerQwenP2051Probe
                || self.reduction_profile != LlamaReductionProfile::CanonicalV1)
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "output_projection_mode",
                reason: "the direct-cuBLAS O-projection probe requires the paired P2051 Q/K/V, attention, and canonical reduction probes",
            });
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if self
            .mlp_projection_mode
            .is_hf_eager_qwen_p2051_direct_cublas_probe()
            && (self.output_projection_mode
                != LlamaOutputProjectionMode::HfEagerQwenP2051DirectCublasProbeV1
                || self.projection_bias_mode
                    != LlamaProjectionBiasMode::HfCompatibleBiasEpilogueProbeV1
                || self.attention_preference != AttentionPreference::HuggingFaceEagerQwenP2051Probe
                || self.reduction_profile != LlamaReductionProfile::CanonicalV1)
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "mlp_projection_mode",
                reason: "the direct-cuBLAS MLP projection probe requires the paired P2051 Q/K/V, attention, O-projection, and canonical reduction probes",
            });
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if self.rope_table_selection == LlamaRopeTableSelection::HuggingFaceCudaQwenP2051ProbeV1
            && (self.mlp_projection_mode
                != LlamaMlpProjectionMode::HfEagerQwenP2051DirectCublasProbeV1
                || self.output_projection_mode
                    != LlamaOutputProjectionMode::HfEagerQwenP2051DirectCublasProbeV1
                || self.projection_bias_mode
                    != LlamaProjectionBiasMode::HfCompatibleBiasEpilogueProbeV1
                || self.attention_preference != AttentionPreference::HuggingFaceEagerQwenP2051Probe
                || self.reduction_profile != LlamaReductionProfile::CanonicalV1)
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "rope_table_selection",
                reason: "the Qwen GPU RoPE-table probe requires the paired P2051 Q/K/V, attention, O-projection, MLP, and canonical reduction probes",
            });
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if self.rms_norm_selection == LlamaRmsNormSelection::HuggingFaceCudaQwenP2051ProbeV1
            && (self.mlp_projection_mode
                != LlamaMlpProjectionMode::HfEagerQwenP2051DirectCublasProbeV1
                || self.output_projection_mode
                    != LlamaOutputProjectionMode::HfEagerQwenP2051DirectCublasProbeV1
                || self.projection_bias_mode
                    != LlamaProjectionBiasMode::HfCompatibleBiasEpilogueProbeV1
                || self.attention_preference != AttentionPreference::HuggingFaceEagerQwenP2051Probe
                || self.reduction_profile != LlamaReductionProfile::CanonicalV1)
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "rms_norm_selection",
                reason: "the Qwen P2051 RMSNorm probe requires the paired P2051 Q/K/V, attention, O-projection, MLP, and canonical reduction probes",
            });
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if self
            .lm_head_mode
            .is_hf_eager_qwen_p2051_last_token_direct_cublas_probe()
            && (self.rms_norm_selection != LlamaRmsNormSelection::HuggingFaceCudaQwenP2051ProbeV1
                || self.rope_table_selection
                    != LlamaRopeTableSelection::HuggingFaceCudaQwenP2051ProbeV1
                || self.mlp_projection_mode
                    != LlamaMlpProjectionMode::HfEagerQwenP2051DirectCublasProbeV1
                || self.output_projection_mode
                    != LlamaOutputProjectionMode::HfEagerQwenP2051DirectCublasProbeV1
                || self.projection_bias_mode
                    != LlamaProjectionBiasMode::HfCompatibleBiasEpilogueProbeV1
                || self.attention_preference != AttentionPreference::HuggingFaceEagerQwenP2051Probe
                || self.reduction_profile != LlamaReductionProfile::CanonicalV1)
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "lm_head_mode",
                reason: "the last-token direct-cuBLAS LM-head probe requires the paired P2051 Q/K/V, attention, O-projection, MLP, RoPE-table, RMSNorm, and canonical reduction probes",
            });
        }
        Ok(())
    }
}

impl Default for PreparedLlamaForwardConfig {
    fn default() -> Self {
        Self::new(
            DEFAULT_UPLOAD_STAGING_BYTES,
            DEFAULT_IO_STAGING_BYTES,
            DEFAULT_GEMM_WORKSPACE_CAP_BYTES,
            DEFAULT_ATTENTION_BUDGET_BYTES,
        )
    }
}

/// Exact owned CUDA allocation totals after cold preparation.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PreparedLlamaAllocationReport {
    weight_bytes: u64,
    graph_bytes: u64,
    gemm_workspace_bytes: u64,
    total_device_bytes: u64,
    device_allocation_count: u64,
    pinned_host_bytes: u64,
    pinned_host_allocation_count: u64,
}

impl PreparedLlamaAllocationReport {
    #[must_use]
    pub const fn weight_bytes(self) -> u64 {
        self.weight_bytes
    }
    #[must_use]
    pub const fn graph_bytes(self) -> u64 {
        self.graph_bytes
    }
    #[must_use]
    pub const fn gemm_workspace_bytes(self) -> u64 {
        self.gemm_workspace_bytes
    }
    #[must_use]
    pub const fn total_device_bytes(self) -> u64 {
        self.total_device_bytes
    }
    #[must_use]
    pub const fn device_allocation_count(self) -> u64 {
        self.device_allocation_count
    }
    #[must_use]
    pub const fn pinned_host_bytes(self) -> u64 {
        self.pinned_host_bytes
    }
    #[must_use]
    pub const fn pinned_host_allocation_count(self) -> u64 {
        self.pinned_host_allocation_count
    }

    fn replace_gemm_workspace_bytes(&mut self, replacement_bytes: u64) -> LlamaForwardResult<()> {
        let previous_bytes = self.gemm_workspace_bytes;
        let total_device_bytes = self
            .total_device_bytes
            .checked_sub(previous_bytes)
            .and_then(|bytes| bytes.checked_add(replacement_bytes))
            .ok_or(LlamaForwardError::ArithmeticOverflow {
                resource: LlamaForwardResource::GemmWorkspace,
            })?;
        let device_allocation_count = if previous_bytes == 0 && replacement_bytes != 0 {
            self.device_allocation_count.checked_add(1).ok_or(
                LlamaForwardError::ArithmeticOverflow {
                    resource: LlamaForwardResource::GemmWorkspace,
                },
            )?
        } else {
            self.device_allocation_count
        };
        self.total_device_bytes = total_device_bytes;
        self.device_allocation_count = device_allocation_count;
        self.gemm_workspace_bytes = replacement_bytes;
        Ok(())
    }
}

/// Qualified eager-only Q/K/V BIAS-epilogue plans.
///
/// Query and key/value have distinct output widths. K and V share one
/// geometry and therefore one immutable cuBLASLt plan; the runtime bias
/// pointer remains an explicit hot-path input.
pub(super) struct ProjectionBiasEpilogueGemmPlans {
    query: CudaPreparedBiasEpilogueGemm,
    key_value: CudaPreparedBiasEpilogueGemm,
}

/// Qualified eager-only direct-cuBLAS plans for Qwen P2051 MLP Linears.
///
/// Gate and up share one immutable `[S, I, H]` geometry. Down has the
/// transposed `[S, H, I]` geometry and therefore owns a separate plan.
#[cfg(feature = "cuda-cublas-gemm-probe")]
pub(super) struct MlpProjectionDirectCublasGemmPlans {
    intermediate: CudaPreparedCublasGemmProbe,
    down: CudaPreparedCublasGemmProbe,
}

#[cfg(feature="cuda-cublas-gemm-probe")]
pub(super) struct HfRequestBiasEpilogueGemmPlans {
 query:Vec<CudaPreparedBiasEpilogueGemm>,key_value:Vec<CudaPreparedBiasEpilogueGemm>,
 batch_query:Vec<Option<CudaPreparedBiasEpilogueGemm>>,batch_key_value:Vec<Option<CudaPreparedBiasEpilogueGemm>>,
}

pub(super) struct GemmPlans {
    pub(super) hidden: PreparedLlamaGemm,
    pub(super) key_value: PreparedLlamaGemm,
    pub(super) intermediate: PreparedLlamaGemm,
    pub(super) down: PreparedLlamaGemm,
    pub(super) lm_head: PreparedLlamaGemm,
    merged_qkv: Option<PreparedLlamaGemm>,
    #[cfg(feature="cuda-cublas-gemm-probe")]
    hf_separate_query:Option<PreparedLlamaGemm>,
    merged_gate_up: Option<PreparedLlamaGemm>,
    /// Output projection `query_width -> hidden` of a model whose query
    /// projection is wider than its residual stream; `hidden` otherwise.
    output_projection: Option<PreparedLlamaGemm>,
    projection_bias_epilogue: Option<ProjectionBiasEpilogueGemmPlans>,
    #[cfg(feature="cuda-cublas-gemm-probe")]
    hf_request_bias_epilogue:Option<HfRequestBiasEpilogueGemmPlans>,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    output_projection_direct_cublas: Option<CudaPreparedCublasGemmProbe>,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    mlp_projection_direct_cublas: Option<MlpProjectionDirectCublasGemmPlans>,
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    lm_head_last_token_direct_cublas: Option<CudaPreparedCublasGemmProbe>,
}

impl GemmPlans {
    #[cfg(feature="cuda-cublas-gemm-probe")]
    pub(super) fn prepare_sm80_merged_decode(&mut self,context:&CudaContext)->LlamaForwardResult<()> {
        let site=ExecutionSite::global(LlamaOp::GateProjection);
        let mut p=context.prepare_owned_hf_gemm(CudaGemmConfig::new(32,19456,2560,0).map_err(|e|LlamaForwardError::cuda(site,e))?)
            .map_err(|e|LlamaForwardError::cuda(site,e))?;
        p.prepare_sm80_prefill().map_err(|e|LlamaForwardError::cuda(site,e))?;
        self.merged_gate_up=Some(PreparedLlamaGemm::ClassicRequestRows(p));
        Ok(())
    }
    #[cfg(feature="cuda-cublas-gemm-probe")]
    pub(super) fn prepare_sm80_prefill(&mut self)->LlamaForwardResult<()> {
        let site=ExecutionSite::global(LlamaOp::IterationCompletion);
        for gemm in [&mut self.key_value,&mut self.intermediate,&mut self.down].into_iter().chain(self.hf_separate_query.iter_mut()).chain(self.output_projection.iter_mut()) {
            if let PreparedLlamaGemm::ClassicRequestRows(p)=gemm {p.prepare_sm80_prefill().map_err(|e|LlamaForwardError::cuda(site,e))?;}
        }
        Ok(())
    }
    #[cfg(feature="cuda-cublas-gemm-probe")]
    pub(super) fn prepare_bounded_sm80_projections(&mut self)->LlamaForwardResult<()> {
        let site=ExecutionSite::global(LlamaOp::IterationCompletion);
        for gemm in [&mut self.hidden,&mut self.down].into_iter().chain(self.output_projection.iter_mut()) {
            if let PreparedLlamaGemm::ClassicRequestRows(p)=gemm {p.prepare_bounded_sm80_projections().map_err(|e|LlamaForwardError::cuda(site,e))?;}
        }
        Ok(())
    }

    pub(super) fn any_poisoned(&self) -> bool {
        self.hidden.is_poisoned()
            || self.key_value.is_poisoned()
            || self.intermediate.is_poisoned()
            || self.down.is_poisoned()
            || self.lm_head.is_poisoned()
            || self
                .merged_qkv
                .as_ref()
                .is_some_and(PreparedLlamaGemm::is_poisoned)
            || self
                .merged_gate_up
                .as_ref()
                .is_some_and(PreparedLlamaGemm::is_poisoned)
            || self
                .output_projection
                .as_ref()
                .is_some_and(PreparedLlamaGemm::is_poisoned)
            || self
                .projection_bias_epilogue
                .as_ref()
                .is_some_and(|plans| plans.query.is_poisoned() || plans.key_value.is_poisoned())
            || {
                #[cfg(feature = "cuda-cublas-gemm-probe")]
                {
                    self.hf_separate_query.as_ref().is_some_and(PreparedLlamaGemm::is_poisoned) ||
                    self.hf_request_bias_epilogue.as_ref().is_some_and(|t|t.query.iter().chain(t.key_value.iter()).chain(t.batch_query.iter().flatten()).chain(t.batch_key_value.iter().flatten()).any(CudaPreparedBiasEpilogueGemm::is_poisoned)) ||
                    self.output_projection_direct_cublas
                        .as_ref()
                        .is_some_and(CudaPreparedCublasGemmProbe::is_poisoned)
                        || self
                            .mlp_projection_direct_cublas
                            .as_ref()
                            .is_some_and(|plans| {
                                plans.intermediate.is_poisoned() || plans.down.is_poisoned()
                            })
                        || self
                            .lm_head_last_token_direct_cublas
                            .as_ref()
                            .is_some_and(CudaPreparedCublasGemmProbe::is_poisoned)
                }
                #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
                {
                    false
                }
            }
    }

    pub(super) fn maximum_workspace_bytes(&self) -> u64 {
        let projection_bias_workspace = self.projection_bias_epilogue.as_ref().map_or(0, |plans| {
            plans
                .query
                .algorithm_metadata()
                .workspace_bytes()
                .max(plans.key_value.algorithm_metadata().workspace_bytes())
        });
        #[cfg(feature="cuda-cublas-gemm-probe")]
        let request_bias_workspace=self.hf_request_bias_epilogue.as_ref().map_or(0,|t|t.query.iter().chain(t.key_value.iter()).map(|p|p.algorithm_metadata().workspace_bytes()).max().unwrap_or(0));
        #[cfg(not(feature="cuda-cublas-gemm-probe"))]let request_bias_workspace=0;
        [
            self.hidden.workspace_bytes(),
            self.key_value.workspace_bytes(),
            self.intermediate.workspace_bytes(),
            self.down.workspace_bytes(),
            self.lm_head.workspace_bytes(),
            self.merged_qkv
                .as_ref()
                .map_or(0, PreparedLlamaGemm::workspace_bytes),
            self.merged_gate_up
                .as_ref()
                .map_or(0, PreparedLlamaGemm::workspace_bytes),
            self.output_projection
                .as_ref()
                .map_or(0, PreparedLlamaGemm::workspace_bytes),
            projection_bias_workspace,
            request_bias_workspace,
        ]
        .into_iter()
        .max()
        .unwrap_or(0)
    }

    /// The attention output projection plan.
    pub(super) fn output_projection_plan(&mut self) -> &mut PreparedLlamaGemm {
        self.output_projection.as_mut().unwrap_or(&mut self.hidden)
    }

    /// The merged gate|up plan, when the merged MLP projection is selected.
    pub(super) fn merged_gate_up_plan(&mut self) -> Option<&mut PreparedLlamaGemm> {
        self.merged_gate_up.as_mut()
    }

    /// The merged Q|K|V plan, when the merged projection mode is selected.
    #[cfg(feature="cuda-cublas-gemm-probe")]
    pub(super) fn hf_separate_projection_plans(&mut self)->Option<(&mut PreparedLlamaGemm,&mut PreparedLlamaGemm)>{self.hf_separate_query.as_mut().map(|q|(q,&mut self.key_value))}
    pub(super) fn merged_qkv_plan(&mut self) -> Option<&mut PreparedLlamaGemm> {
        self.merged_qkv.as_mut()
    }

    pub(super) fn query_projection_plans_with_requests(&mut self)->(&mut PreparedLlamaGemm,Option<&mut CudaPreparedBiasEpilogueGemm>,Option<&mut [CudaPreparedBiasEpilogueGemm]>,Option<&mut [Option<CudaPreparedBiasEpilogueGemm>]>){
      let Self{hidden,projection_bias_epilogue,#[cfg(feature="cuda-cublas-gemm-probe")]hf_request_bias_epilogue,..}=self;
      #[cfg(feature="cuda-cublas-gemm-probe")]
      let (requests,batches)=if let Some(t)=hf_request_bias_epilogue.as_mut(){(Some(t.query.as_mut_slice()),Some(t.batch_query.as_mut_slice()))}else{(None,None)};
      #[cfg(not(feature="cuda-cublas-gemm-probe"))]let (requests,batches)=(None,None);
      (hidden,projection_bias_epilogue.as_mut().map(|p|&mut p.query),requests,batches)
    }

    pub(super) fn key_value_projection_plans_with_requests(&mut self)->(&mut PreparedLlamaGemm,Option<&mut CudaPreparedBiasEpilogueGemm>,Option<&mut [CudaPreparedBiasEpilogueGemm]>,Option<&mut [Option<CudaPreparedBiasEpilogueGemm>]>){
      let Self{key_value,projection_bias_epilogue,#[cfg(feature="cuda-cublas-gemm-probe")]hf_request_bias_epilogue,..}=self;
      #[cfg(feature="cuda-cublas-gemm-probe")]
      let (requests,batches)=if let Some(t)=hf_request_bias_epilogue.as_mut(){(Some(t.key_value.as_mut_slice()),Some(t.batch_key_value.as_mut_slice()))}else{(None,None)};
      #[cfg(not(feature="cuda-cublas-gemm-probe"))]let (requests,batches)=(None,None);
      (key_value,projection_bias_epilogue.as_mut().map(|p|&mut p.key_value),requests,batches)
    }

    pub(super) fn query_projection_plans(
        &mut self,
    ) -> (
        &mut PreparedLlamaGemm,
        Option<&mut CudaPreparedBiasEpilogueGemm>,
    ) {
        let Self {
            hidden,
            projection_bias_epilogue,
            ..
        } = self;
        (
            hidden,
            projection_bias_epilogue
                .as_mut()
                .map(|plans| &mut plans.query),
        )
    }

    pub(super) fn key_value_projection_plans(
        &mut self,
    ) -> (
        &mut PreparedLlamaGemm,
        Option<&mut CudaPreparedBiasEpilogueGemm>,
    ) {
        let Self {
            key_value,
            projection_bias_epilogue,
            ..
        } = self;
        (
            key_value,
            projection_bias_epilogue
                .as_mut()
                .map(|plans| &mut plans.key_value),
        )
    }

    pub(super) fn close(self) -> LlamaForwardResult<()> {
        let Self {
            hidden,
            key_value,
            intermediate,
            down,
            lm_head,
            merged_qkv,
            #[cfg(feature="cuda-cublas-gemm-probe")]
            hf_separate_query,
            merged_gate_up,
            output_projection,
            projection_bias_epilogue,
            #[cfg(feature="cuda-cublas-gemm-probe")]
            hf_request_bias_epilogue,
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            output_projection_direct_cublas,
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            mlp_projection_direct_cublas,
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            lm_head_last_token_direct_cublas,
        } = self;
        let mut first = None;
        if let Some(merged_gate_up) = merged_gate_up {
            record_close(
                &mut first,
                LlamaForwardResource::IntermediateGemm,
                merged_gate_up.close(),
            );
        }
        if let Some(output_projection) = output_projection {
            record_close(
                &mut first,
                LlamaForwardResource::HiddenGemm,
                output_projection.close(),
            );
        }
        record_close(&mut first, LlamaForwardResource::HiddenGemm, hidden.close());
        record_close(
            &mut first,
            LlamaForwardResource::KeyValueGemm,
            key_value.close(),
        );
        record_close(
            &mut first,
            LlamaForwardResource::IntermediateGemm,
            intermediate.close(),
        );
        record_close(&mut first, LlamaForwardResource::DownGemm, down.close());
        record_close(
            &mut first,
            LlamaForwardResource::LmHeadGemm,
            lm_head.close(),
        );
        #[cfg(feature="cuda-cublas-gemm-probe")]
        if let Some(query)=hf_separate_query {record_close(&mut first,LlamaForwardResource::HiddenGemm,query.close());}
        if let Some(merged_qkv) = merged_qkv {
            record_close(
                &mut first,
                LlamaForwardResource::HiddenGemm,
                merged_qkv.close(),
            );
        }
        if let Some(ProjectionBiasEpilogueGemmPlans { query, key_value }) = projection_bias_epilogue
        {
            record_close(
                &mut first,
                LlamaForwardResource::QueryBiasEpilogueGemm,
                query.close(),
            );
            record_close(
                &mut first,
                LlamaForwardResource::KeyValueBiasEpilogueGemm,
                key_value.close(),
            );
        }
        #[cfg(feature="cuda-cublas-gemm-probe")]
        if let Some(table)=hf_request_bias_epilogue {
          for plan in table.query {record_close(&mut first,LlamaForwardResource::QueryBiasEpilogueGemm,plan.close());}
          for plan in table.key_value {record_close(&mut first,LlamaForwardResource::KeyValueBiasEpilogueGemm,plan.close());}
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if let Some(plan) = output_projection_direct_cublas {
            record_close(
                &mut first,
                LlamaForwardResource::OutputProjectionDirectCublasGemm,
                plan.close(),
            );
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if let Some(MlpProjectionDirectCublasGemmPlans { intermediate, down }) =
            mlp_projection_direct_cublas
        {
            record_close(
                &mut first,
                LlamaForwardResource::MlpIntermediateDirectCublasGemm,
                intermediate.close(),
            );
            record_close(
                &mut first,
                LlamaForwardResource::MlpDownDirectCublasGemm,
                down.close(),
            );
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if let Some(plan) = lm_head_last_token_direct_cublas {
            record_close(
                &mut first,
                LlamaForwardResource::LmHeadLastTokenDirectCublasGemm,
                plan.close(),
            );
        }
        first.map_or(Ok(()), Err)
    }
}

pub(super) struct ForwardBuffers {
    pub(super) token_ids: CudaDeviceBuffer,
    pub(super) hidden_current: CudaDeviceBuffer,
    pub(super) hidden_norm: CudaDeviceBuffer,
    pub(super) hidden_projection: CudaDeviceBuffer,
    pub(super) hidden_rotary: CudaDeviceBuffer,
    pub(super) hidden_context: CudaDeviceBuffer,
    pub(super) key_raw: CudaDeviceBuffer,
    pub(super) value_raw: CudaDeviceBuffer,
    pub(super) key_rotary: CudaDeviceBuffer,
    pub(super) gate_raw: CudaDeviceBuffer,
    pub(super) up_raw: CudaDeviceBuffer,
    pub(super) gate_activated: CudaDeviceBuffer,
    pub(super) gated_product: CudaDeviceBuffer,
    pub(super) attention_workspace: Option<CudaDeviceBuffer>,
    pub(super) rope_cos: CudaDeviceBuffer,
    pub(super) rope_sin: CudaDeviceBuffer,
    pub(super) logits: CudaDeviceBuffer,
    pub(super) embedding_error_scratch: CudaDeviceBuffer,
    pub(super) gemm_workspace: Option<CudaDeviceBuffer>,
}

/// Owning fixed-S reference forward. All hot execution state is direct-indexed.
pub struct PreparedLlamaForward {
    pub(super) plan: LlamaExecutionPlan,
    pub(super) weights: CudaUploadedWeights,
    pub(super) gemms: GemmPlans,
    // Separate cold output-row plan avoids aliasing the selected shape's GEMMs.
    pub(super) batch_output_lm_head: Option<PreparedLlamaGemm>,
    paged_batch_only: bool,
    pub(super) owned_hf_eager_bf16: bool,
    attention: PreparedPrefillAttention,
    reduction_profile: LlamaReductionProfile,
    projection_bias_mode: LlamaProjectionBiasMode,
    merged_gate_up: bool,
    output_projection_mode: LlamaOutputProjectionMode,
    mlp_projection_mode: LlamaMlpProjectionMode,
    lm_head_mode: LlamaLmHeadMode,
    rms_norm_profile: LlamaRmsNormProfile,
    rope_table_profile: LlamaRopeTableProfile,
    gemm_reduction_policies: LlamaGemmReductionPolicies,
    gemm_workspace_cap_bytes: u64,
    pub(super) buffers: ForwardBuffers,
    pub(super) io_staging: CudaPinnedHostBuffer,
    pub(super) token_bytes: Box<[u8]>,
    allocation_report: PreparedLlamaAllocationReport,
    pub(super) tokens_ready: bool,
    pub(super) output_ready: bool,
    pub(super) poisoned: bool,
    /// Recorded steps of the maximum dense shape (see the batch executor's
    /// shape variants, which hold their own). Destroyed before the plans.
    pub(super) captured_steps: Vec<(usize, riley_cuda::CudaStepGraph)>,
    pub(super) owned_decode_segments: Vec<OwnedDecodeSegment>,
    /// How many more steps may be recorded across every dense shape. Each
    /// recorded step keeps several MiB of host and device memory, so the
    /// total is bounded; shapes met after the budget is spent run eagerly.
    pub(super) captured_step_budget: usize,
}

impl fmt::Debug for PreparedLlamaForward {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("PreparedLlamaForward")
            .field("plan", &self.plan)
            .field("attention_selection", &self.attention.selection_trace())
            .field("reduction_profile", &self.reduction_profile)
            .field("projection_bias_mode", &self.projection_bias_mode)
            .field("output_projection_mode", &self.output_projection_mode)
            .field("mlp_projection_mode", &self.mlp_projection_mode)
            .field("lm_head_mode", &self.lm_head_mode)
            .field("rms_norm_profile", &self.rms_norm_profile)
            .field("rope_table_profile", &self.rope_table_profile)
            .field("gemm_reduction_policies", &self.gemm_reduction_policies)
            .field("gemm_workspace_cap_bytes", &self.gemm_workspace_cap_bytes)
            .field("allocation_report", &self.allocation_report)
            .field("tokens_ready", &self.tokens_ready)
            .field("output_ready", &self.output_ready)
            .field("poisoned", &self.poisoned)
            .finish_non_exhaustive()
    }
}

impl PreparedLlamaForward {
    /// Uploads the verified checkpoint and prepares one immutable fixed-S graph.
    ///
    /// The model is used only during this cold call. The returned owner contains
    /// all CUDA weights, algorithms, tables, graph buffers, and reusable I/O
    /// staging required by subsequent allocation-free execution.
    ///
    /// # Errors
    ///
    /// Returns for an invalid plan/configuration, failed weight upload, attention
    /// budget violation, host reservation, GEMM preparation, CUDA allocation, or
    /// RoPE-table upload failure.
    #[allow(clippy::too_many_lines)]
    pub fn prepare(
        model: &LoadedModel,
        context: &CudaContext,
        stream: &mut CudaStream,
        sequence_length: usize,
        config: PreparedLlamaForwardConfig,
    ) -> LlamaForwardResult<Self> {
        Self::prepare_storage(model, context, stream, sequence_length, config, None)
    }

    /// Reserves batch-only storage; standalone dense execution is rejected.
    pub(super) fn prepare_paged_batch(
        model: &LoadedModel, context: &CudaContext, stream: &mut CudaStream,
        sequence_length: usize, config: PreparedLlamaForwardConfig, output_capacity: usize,
    ) -> LlamaForwardResult<Self> {
        Self::prepare_storage(model, context, stream, sequence_length, config, Some(output_capacity))
    }

    fn prepare_storage(
        model: &LoadedModel, context: &CudaContext, stream: &mut CudaStream,
        sequence_length: usize, config: PreparedLlamaForwardConfig,
        batch_output_capacity: Option<usize>,
    ) -> LlamaForwardResult<Self> {
        let paged_batch_only = batch_output_capacity.is_some();
        #[cfg(not(feature="cuda-cublas-gemm-probe"))]
        if paged_batch_only {
            return Err(LlamaForwardError::InvalidConfiguration {field:"paged_batch_storage",reason:"owned HF batch storage requires cuda-cublas-gemm-probe"});
        }
        config.validate()?;
        if config.owned_hf_eager_bf16 && (!paged_batch_only || !matches!(context.compute_capability(), (8,0)|(8,9))) {
            return Err(LlamaForwardError::InvalidConfiguration {field:"owned-hf-eager-bf16-v1",reason:"requires the owned batch path and compute capability 8.0 or 8.9"});
        }
        if sequence_length == 0 || sequence_length > model.spec().max_sequence_length() {
            return Err(LlamaForwardError::Plan(
                LlamaPlanError::InvalidSequenceLength {
                    requested: sequence_length,
                    maximum: model.spec().max_sequence_length(),
                },
            ));
        }

        if config.owned_hf_eager_bf16 {
            let supported = model.spec().dtype().name()=="bf16" && model.spec().blocks().iter().all(|b| {
                let a=b.attention();
                matches!((a.hidden_size(),a.query_heads(),a.key_value_heads(),a.head_dimension(),a.has_bias(),a.query_key_norm().is_some()),
                    (576,9,3,64,false,false)|(2048,16,2,128,true,false)|
                    (2048,16,8,128,false,true)|(2560,32,8,128,false,true)|
                    (4096,32,8,128,false,false))
            });
            let wide_query=model.spec().blocks().first().is_some_and(|b|b.attention().query_heads()*b.attention().head_dimension()>b.attention().hidden_size());
            let expected_projection=if wide_query {LlamaProjectionBiasMode::MergedQkvStrictStagedV1} else {LlamaProjectionBiasMode::StrictStagedV1};
            if !supported || config.projection_bias_mode != expected_projection {
                return Err(LlamaForwardError::InvalidConfiguration {field:"owned-hf-eager-bf16-v1",reason:"unqualified model geometry or QKV override"});
            }
        }

        let gemm_reduction_policies = resolve_gemm_reduction_policies(
            model,
            config.reduction_profile,
            config.first_heuristic_gemm_reductions,
        )
        .with_bit_equivalent_selection(
            config.first_heuristic_gemm_reductions && config.bit_equivalent_gemm_selection,
        );
        let rms_norm_profile = if config.owned_hf_eager_bf16
            && matches!(model.config(), ModelConfig::Llama(_))
            && is_reviewed_smollm2_rms_norm_geometry(model.spec())
        {
            // The owned A100/4090 profile uses the independently qualified
            // HF row reduction, rather than the default device-specific path.
            LlamaRmsNormProfile::HuggingFaceSmolLm2
        } else {
            resolve_rms_norm_profile(model, config.reduction_profile,
                config.rms_norm_selection, context.compute_capability())
        };
        let rope_table_profile = resolve_rope_table_profile(
            model,
            config.reduction_profile,
            config.rope_table_selection,
            sequence_length,
        );

        let mut weights = CudaUploadedWeights::upload(
            model.weights(),
            context,
            stream,
            config.upload_staging_bytes,
        )
        .map_err(|source| LlamaForwardError::Weight { site: None, source })?;
        let plan = LlamaExecutionPlan::prepare(model.spec(), &weights, sequence_length)?;
        // The owned wide-query path packs separate Q/K/V outputs, never merged weights.
        if config.projection_bias_mode.merges_qkv() && !config.owned_hf_eager_bf16 {
            weights
                .upload_merged_qkv(
                    model.weights(),
                    plan.layers().len(),
                    context,
                    stream,
                    config.upload_staging_bytes,
                    // With both merged copies the batch route reads no
                    // separate projection; a 14B checkpoint does not fit a
                    // 40 GB card with the Q/K/V weights held twice.
                    config.merged_gate_up,
                )
                .map_err(|source| LlamaForwardError::Weight { site: None, source })?;
        }
        // A model without Q/K/V biases and without a per-head query/key norm
        // (Llama 3) takes the merged projection through the split-with-bias
        // kernel with a bias of negative zeros, which adds nothing.
        if config.projection_bias_mode.merges_qkv()
            && plan.layers().iter().all(|layer| {
                layer.query_bias().is_none()
                    && layer.key_bias().is_none()
                    && layer.value_bias().is_none()
                    && layer.query_key_norm().is_none()
            })
        {
            let dimensions = plan.dimensions();
            weights
                .upload_negative_zero_bias(
                    dimensions.query_width().max(dimensions.key_value_width()),
                    context,
                    stream,
                )
                .map_err(|source| LlamaForwardError::Weight { site: None, source })?;
        }
        if config.merged_gate_up {
            weights
                .upload_merged_gate_up(
                    model.weights(),
                    plan.layers().len(),
                    context,
                    stream,
                    config.upload_staging_bytes,
                    true,
                )
                .map_err(|source| LlamaForwardError::Weight { site: None, source })?;
            // The merged copy replaces the two separate device tensors.
            weights
                .release_separate_gate_up(plan.layers().len())
                .map_err(|source| LlamaForwardError::Weight {
                    site: None,
                    source: source.into(),
                })?;
        }
        let workspace = plan.workspace_spec();
        let attention_preference = canonical_prefill_attention_preference(
            model.config(),
            model.spec(),
            sequence_length,
            config.attention_preference,
            config.reduction_profile,
        );
        // The reviewed HF-eager prefill backend exists for compute capability
        // 8.9 only; on another device the reviewed geometry keeps the
        // configured preference, as every other geometry does.
        let attention_preference = if attention_preference == AttentionPreference::HuggingFaceEager
            && config.attention_preference != AttentionPreference::HuggingFaceEager
            && context.compute_capability() != (8, 9)
        {
            config.attention_preference
        } else {
            attention_preference
        };
        let attention = prepare_attention(
            context,
            &plan,
            if paged_batch_only { AttentionPreference::Reference } else { attention_preference },
            config.reduction_profile,
            paged_batch_only,
        )?;
        let attention_workspace_bytes = if paged_batch_only { 0 } else { attention.workspace_bytes() };
        if attention_workspace_bytes > config.attention_budget_bytes {
            return Err(LlamaForwardError::AttentionBudgetExceeded {
                required_bytes: attention_workspace_bytes,
                maximum_bytes: config.attention_budget_bytes,
            });
        }

        let gemms = prepare_gemms(
            context,
            &weights,
            &plan,
            config.gemm_workspace_cap_bytes,
            config.reduction_profile,
            gemm_reduction_policies,
            config.projection_bias_mode,
            config.merged_gate_up,
            config.output_projection_mode,
            config.mlp_projection_mode,
            config.lm_head_mode,
            config.owned_hf_eager_bf16,
            None,
        )?;
        let gemm_workspace_bytes = gemms.maximum_workspace_bytes();
        let mut buffers = allocate_buffers(
            context,
            &plan,
            attention_workspace_bytes,
            gemm_workspace_bytes,
            config.merged_gate_up,
            paged_batch_only,
        )?;
        let mut io_staging = context
            .allocate_pinned_host_buffer(config.io_staging_bytes)
            .map_err(|source| {
                LlamaForwardError::cuda(ExecutionSite::global(LlamaOp::Embedding), source)
            })?;

        let rope_site = ExecutionSite::layer(0, LlamaOp::QueryRope);
        let rope_table_bytes = plan.workspace_spec().rope_cos_bytes();
        if rope_table_profile == LlamaRopeTableProfile::HuggingFaceCuda {
            let rope_angles = build_rope_angles(&plan)?;
            buffers
                .rope_cos
                .upload_from_slice(0, &rope_angles, &mut io_staging, stream)
                .map_err(|source| LlamaForwardError::cuda(rope_site, source))?;
            let mut rope_table_params = RopeTableParams {
                angles_cos: span_mut(
                    &mut buffers.rope_cos,
                    CudaDType::F32,
                    rope_table_bytes,
                    rope_site,
                )?,
                sin: span_mut(
                    &mut buffers.rope_sin,
                    CudaDType::F32,
                    rope_table_bytes,
                    rope_site,
                )?,
                element_count: rope_table_bytes / mem::size_of::<f32>() as u64,
            };
            rope_table(&mut rope_table_params, stream)
                .map_err(|source| LlamaForwardError::cuda(rope_site, source))?;
        } else {
            let (rope_cos, rope_sin) = build_cpu_rope_tables(&plan)?;
            buffers
                .rope_cos
                .upload_from_slice(0, &rope_cos, &mut io_staging, stream)
                .map_err(|source| LlamaForwardError::cuda(rope_site, source))?;
            buffers
                .rope_sin
                .upload_from_slice(0, &rope_sin, &mut io_staging, stream)
                .map_err(|source| LlamaForwardError::cuda(rope_site, source))?;
        }

        let token_bytes =
            allocate_host_bytes(workspace.token_ids_bytes(), LlamaForwardResource::TokenIds)?;
        let allocation_report = build_allocation_report(
            &weights,
            &plan,
            attention_workspace_bytes,
            gemm_workspace_bytes,
            config.io_staging_bytes,
            if paged_batch_only { Some(&buffers) } else { None },
        )?;
        #[cfg(feature="cuda-cublas-gemm-probe")]
        let batch_output_lm_head = if let Some(capacity) = batch_output_capacity {
            let m = capacity.min(sequence_length).max(1) as u64;
            let cfg = CudaGemmConfig::new(m, plan.dimensions().vocabulary_size() as u64,
                plan.dimensions().hidden_size() as u64, 0)
                .map_err(|e| LlamaForwardError::cuda(ExecutionSite::global(LlamaOp::LmHead), e))?;
            Some(PreparedLlamaGemm::ClassicRequestRows(context.prepare_owned_hf_gemm(cfg)
                .map_err(|e| LlamaForwardError::cuda(ExecutionSite::global(LlamaOp::LmHead), e))?))
        } else { None };
        #[cfg(not(feature="cuda-cublas-gemm-probe"))]
        let batch_output_lm_head = None;

        let owned_decode_segments = (0..owned_decode_segment_capacity(&plan,plan.sequence_length()))
            .map(|_| OwnedDecodeSegment::default()).collect();
        Ok(Self {
            plan,
            weights,
            gemms,
            batch_output_lm_head,
            paged_batch_only,
            owned_hf_eager_bf16: config.owned_hf_eager_bf16,
            attention,
            reduction_profile: config.reduction_profile,
            projection_bias_mode: config.projection_bias_mode,
            merged_gate_up: config.merged_gate_up,
            output_projection_mode: config.output_projection_mode,
            mlp_projection_mode: config.mlp_projection_mode,
            lm_head_mode: config.lm_head_mode,
            rms_norm_profile,
            rope_table_profile,
            gemm_reduction_policies,
            gemm_workspace_cap_bytes: config.gemm_workspace_cap_bytes,
            buffers,
            io_staging,
            token_bytes,
            allocation_report,
            tokens_ready: false,
            output_ready: false,
            poisoned: false,
            owned_decode_segments,
            captured_steps: Vec::new(),
            captured_step_budget: MAX_RECORDED_STEPS,
        })
    }

    /// Immutable fixed-S topology and dimensions.
    #[must_use]
    pub const fn plan(&self) -> &LlamaExecutionPlan {
        &self.plan
    }

    /// Prepares one exact dense-row plan and its GEMM variants against this
    /// owner's uploaded weights and maximum-size shared workspace.
    ///
    /// The returned value owns algorithms only. It borrows no model data and
    /// allocates no duplicate weights, KV storage, or graph buffers.
    pub(super) fn prepare_batch_shape_variant(
        &self,
        model: &LoadedModel,
        context: &CudaContext,
        dense_rows: usize,
    ) -> LlamaForwardResult<(LlamaExecutionPlan, GemmPlans)> {
        if dense_rows == 0 || dense_rows >= self.plan.sequence_length() {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "dense_rows",
                reason: "batch shape variants must be non-zero and smaller than the maximum plan",
            });
        }
        let plan = LlamaExecutionPlan::prepare(model.spec(), &self.weights, dense_rows)?;
        if plan.dimensions() != self.plan.dimensions()
            || plan.layers().len() != self.plan.layers().len()
            || plan.rope_theta().to_bits() != self.plan.rope_theta().to_bits()
            || plan.rope_frequencies() != self.plan.rope_frequencies()
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "batch_shape_plan",
                reason: "shape variant changed immutable model topology",
            });
        }
        let gemms = prepare_gemms(
            context,
            &self.weights,
            &plan,
            self.gemm_workspace_cap_bytes,
            self.reduction_profile,
            self.gemm_reduction_policies,
            self.projection_bias_mode,
            self.merged_gate_up,
            self.output_projection_mode,
            self.mlp_projection_mode,
            self.lm_head_mode,
            self.owned_hf_eager_bf16,
            Some(&self.gemms),
        )?;
        Ok((plan, gemms))
    }

    /// Grows the one shared GEMM workspace to the largest requirement selected
    /// across the maximum plan and every cold-prepared batch-shape variant.
    /// This cold-path operation never reallocates after preparation returns.
    ///
    /// # Errors
    ///
    /// Returns when the selected requirement exceeds the configured cap, the
    /// replacement allocation or old-buffer close fails, or report arithmetic
    /// cannot represent the replacement.
    pub(super) fn ensure_batch_shape_gemm_workspace(
        &mut self,
        context: &CudaContext,
        required_bytes: u64,
    ) -> LlamaForwardResult<()> {
        if required_bytes > self.gemm_workspace_cap_bytes {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "gemm_workspace_bytes",
                reason: "a prepared batch shape exceeded the configured GEMM workspace cap",
            });
        }
        let current_bytes = self
            .buffers
            .gemm_workspace
            .as_ref()
            .map_or(0, CudaDeviceBuffer::byte_len);
        if required_bytes <= current_bytes {
            return Ok(());
        }

        let mut replacement_report = self.allocation_report;
        replacement_report.replace_gemm_workspace_bytes(required_bytes)?;
        let replacement = context
            .allocate_device_buffer(required_bytes)
            .map_err(|source| {
                LlamaForwardError::cuda(ExecutionSite::layer(0, LlamaOp::QueryProjection), source)
            })?;
        // Allocate before replacing the live owner so an allocation failure
        // leaves the previous workspace and allocation report untouched. Once
        // the replacement is installed, a failed old-buffer close poisons this
        // forward owner rather than exposing a partially reconciled workspace
        // to a later execution attempt.
        let previous = self.buffers.gemm_workspace.replace(replacement);
        self.allocation_report = replacement_report;
        if let Some(previous) = previous {
            if let Err(source) = previous.close() {
                self.poisoned = true;
                return Err(LlamaForwardError::cuda(
                    ExecutionSite::layer(0, LlamaOp::QueryProjection),
                    source,
                ));
            }
        }
        Ok(())
    }

    /// Exact owned allocations expected after successful preparation.
    #[must_use]
    pub const fn allocation_report(&self) -> PreparedLlamaAllocationReport {
        self.allocation_report
    }

    /// Cold-path attention selection and its allocation/materialization facts.
    #[must_use]
    pub fn attention_selection(&self) -> AttentionSelectionTrace {
        self.attention.selection_trace()
    }

    /// Whole-runtime reduction contract selected during cold preparation.
    #[must_use]
    pub const fn reduction_profile(&self) -> LlamaReductionProfile {
        self.reduction_profile
    }

    /// Q/K/V bias implementation selected during this owner's cold preparation.
    #[must_use]
    pub const fn projection_bias_mode(&self) -> LlamaProjectionBiasMode {
        self.projection_bias_mode
    }

    pub(super) const fn actual_projection_bias_backend_id(&self) -> &'static str {
        if self.owned_hf_eager_bf16 {
            #[cfg(feature="cuda-cublas-gemm-probe")]
            {
                if self.gemms.hf_separate_query.is_some() { return "owned-hf-separate-qkv-bitpack-v1"; }
                if self.gemms.hf_request_bias_epilogue.is_some() { return "owned-hf-lt-bias-first-1m-v1"; }
            }
            return "owned-hf-classic-request-rows-v1";
        }
        self.projection_bias_mode.id()
    }

    /// Stable cold-selection identifier for the decoder attention output
    /// projection implementation.
    #[must_use]
    pub const fn output_projection_backend_id(&self) -> &'static str {
        if self.owned_hf_eager_bf16 { "owned-hf-classic-request-rows-v1" } else { self.output_projection_mode.id() }
    }

    /// Stable cold-selection identifier for the decoder MLP Linear
    /// implementation.
    #[must_use]
    pub const fn mlp_projection_backend_id(&self) -> &'static str {
        if self.owned_hf_eager_bf16 { "owned-hf-classic-request-rows-v1" } else { self.mlp_projection_mode.id() }
    }

    /// Stable cold-selection identifier for the final vocabulary projection.
    ///
    /// The P2051 last-token mode is diagnostic-only and intentionally does
    /// not expose the uncomputed earlier logits rows.
    #[must_use]
    pub const fn lm_head_backend_id(&self) -> &'static str {
        if self.owned_hf_eager_bf16 { "owned-hf-classic-output-rows-v1" } else { self.lm_head_mode.id() }
    }

    pub(super) const fn rms_norm_profile(&self) -> LlamaRmsNormProfile {
        self.rms_norm_profile
    }

    /// Stable identifier for the RMSNorm numerical path selected at cold
    /// preparation. The P2051 identifier remains diagnostic-only and is not a
    /// serving selector value.
    #[must_use]
    pub const fn rms_norm_backend_id(&self) -> &'static str {
        if self.owned_hf_eager_bf16 && self.plan.dimensions().hidden_size()==576 {
            return "owned-hf-smollm2-request-rmsnorm-v1";
        }
        if self.owned_hf_eager_bf16 && matches!(self.plan.dimensions().hidden_size(),2048|2560|4096) {
            return "owned-hf-float4-request-rmsnorm-v1";
        }
        match self.rms_norm_profile {
            LlamaRmsNormProfile::Canonical => "canonical-rmsnorm-v1",
            LlamaRmsNormProfile::HuggingFaceSmolLm2 => "hf-smollm2-rmsnorm-v1",
            LlamaRmsNormProfile::FixedContiguous37Balanced => "fixed37-balanced-rmsnorm-v1",
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            LlamaRmsNormProfile::HuggingFaceCudaQwenP2051Probe => {
                "hf-cuda-qwen-p2051-rmsnorm-probe-v1"
            }
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            LlamaRmsNormProfile::HuggingFaceCudaQwenP2048CacheOnProbe => {
                "hf-cuda-qwen-p2048-cache-on-rmsnorm-probe-v1"
            }
        }
    }

    pub(super) const fn rope_table_profile(&self) -> LlamaRopeTableProfile {
        self.rope_table_profile
    }

    /// Allocates reusable caller-owned host storage for the canonical PR07
    /// diagnostic checkpoints without executing CUDA work.
    ///
    /// # Errors
    ///
    /// Returns if the plan has fewer than the layer-14 checkpoint or host byte
    /// arithmetic/reservation fails. Online attention has no probability
    /// matrix to capture, so callers must prepare a reference-attention owner.
    pub fn prepare_trace(&self) -> LlamaForwardResult<PreparedLlamaTrace> {
        if !attention_probabilities_available(self.attention.backend()) {
            return Err(LlamaForwardError::TraceRequiresReferenceAttention);
        }
        if self.projection_bias_mode.requires_qkv_bias_epilogue() {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "trace",
                reason: "fused Q/K/V bias epilogue has no unbiased-linear trace checkpoint",
            });
        }
        PreparedLlamaTrace::prepare(&self.plan, &LlamaTracePoint::ALL)
    }

    /// Allocates host storage only for caller-selected diagnostic checkpoints.
    ///
    /// Unlike [`Self::prepare_trace`], this API does not require materialized
    /// reference attention unless `Layer0AttentionProbabilities` is requested.
    /// It is therefore suitable for bounded calibration capture on optimized
    /// attention paths. Duplicate points are coalesced and an empty selection
    /// is valid, although it performs no transfers.
    ///
    /// # Errors
    ///
    /// Returns when attention probabilities are unavailable, layer 14 was
    /// requested from a shallower model, or host byte arithmetic/reservation
    /// fails.
    pub fn prepare_trace_points(
        &self,
        points: &[LlamaTracePoint],
    ) -> LlamaForwardResult<PreparedLlamaTrace> {
        if points.contains(&LlamaTracePoint::Layer0AttentionProbabilities)
            && !attention_probabilities_available(self.attention.backend())
        {
            return Err(LlamaForwardError::TraceRequiresReferenceAttention);
        }
        if self.projection_bias_mode.requires_qkv_bias_epilogue()
            && [
                LlamaTracePoint::Layer0QueryProjectionUnbiasedLinear,
                LlamaTracePoint::Layer0KeyProjectionUnbiasedLinear,
                LlamaTracePoint::Layer0ValueProjectionUnbiasedLinear,
            ]
            .into_iter()
            .any(|point| points.contains(&point))
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "trace",
                reason: "fused Q/K/V bias epilogue has no unbiased-linear trace checkpoint",
            });
        }
        PreparedLlamaTrace::prepare(&self.plan, points)
    }

    /// Allocates reusable host rows for selected decoder-layer residuals at
    /// the final token position.
    ///
    /// This diagnostic owner is deliberately independent from the immutable
    /// PR07 artifact checkpoints. Indices must name existing decoder layers;
    /// duplicates are coalesced and the retained order is ascending. When
    /// `capture_final_norm_output` is true, one additional BF16
    /// `[hidden_size]` row is reserved for the final RMS-norm output.
    ///
    /// # Errors
    ///
    /// Returns when an index is outside `0..layer_count`, or host byte
    /// arithmetic/reservation fails.
    pub fn prepare_last_token_layer_trace(
        &self,
        layer_indices: &[usize],
        capture_final_norm_output: bool,
    ) -> LlamaForwardResult<PreparedLlamaLastTokenLayerTrace> {
        PreparedLlamaLastTokenLayerTrace::prepare(
            &self.plan,
            layer_indices,
            capture_final_norm_output,
        )
    }

    /// Allocates final-token rows for every internal boundary in one selected
    /// decoder layer.
    ///
    /// This owner is diagnostic-only. It lets an external, source-bound oracle
    /// distinguish input norm, projection, attention, and MLP divergence
    /// without changing the normal full-forward trace contract.
    ///
    /// # Errors
    ///
    /// Returns when the requested layer does not exist or its row storage
    /// cannot be reserved.
    pub fn prepare_last_token_layer_stage_trace(
        &self,
        layer_index: usize,
    ) -> LlamaForwardResult<PreparedLlamaLastTokenLayerStageTrace> {
        PreparedLlamaLastTokenLayerStageTrace::prepare(&self.plan, layer_index)
    }

    /// Allocates selected full-sequence BF16 boundaries in one decoder layer.
    ///
    /// This owner is diagnostic-only. It exists for cases where a final-token
    /// boundary is exact while earlier causal rows still affect a later layer.
    /// Normal serving execution does not allocate or copy these tensors.
    ///
    /// # Errors
    ///
    /// Returns when the layer does not exist or the caller-selected full
    /// sequence tensors cannot be reserved.
    pub fn prepare_full_sequence_layer_stage_trace(
        &self,
        layer_index: usize,
        stages: &[LlamaLastTokenLayerStage],
    ) -> LlamaForwardResult<PreparedLlamaFullSequenceLayerStageTrace> {
        PreparedLlamaFullSequenceLayerStageTrace::prepare(&self.plan, layer_index, stages)
    }

    /// Downloads an eager-framework-layout BF16 view of the cold RoPE tables.
    ///
    /// This diagnostic copy is deliberately explicit. The execution owner
    /// keeps its F32 half-tables and normal forward execution neither creates
    /// host storage nor performs this D2H transfer.
    ///
    /// # Errors
    ///
    /// Returns when the owner is poisoned, table host storage cannot be
    /// reserved, or a staged CUDA copy fails.
    pub fn download_hugging_face_bf16_rope_table_trace(
        &mut self,
        stream: &mut CudaStream,
    ) -> LlamaForwardResult<PreparedLlamaHuggingFaceRopeTableTrace> {
        if self.poisoned {
            return Err(LlamaForwardError::Poisoned);
        }
        let table_bytes = self.plan.workspace_spec().rope_cos_bytes();
        let mut cosine = allocate_host_bytes(table_bytes, LlamaForwardResource::TraceCapture)?;
        let mut sine = allocate_host_bytes(table_bytes, LlamaForwardResource::TraceCapture)?;
        let site = ExecutionSite::layer(0, LlamaOp::QueryRope);
        self.buffers
            .rope_cos
            .download_to_slice(0, &mut cosine, &mut self.io_staging, stream)
            .map_err(|source| LlamaForwardError::cuda(site, source))?;
        self.buffers
            .rope_sin
            .download_to_slice(0, &mut sine, &mut self.io_staging, stream)
            .map_err(|source| LlamaForwardError::cuda(site, source))?;
        Ok(PreparedLlamaHuggingFaceRopeTableTrace {
            cosine: hf_eager_bf16_rope_table_view(
                &self.plan,
                &cosine,
                LlamaForwardResource::TraceCapture,
            )?,
            sine: hf_eager_bf16_rope_table_view(
                &self.plan,
                &sine,
                LlamaForwardResource::TraceCapture,
            )?,
        })
    }

    /// Whether one valid exact-length token vector has been uploaded.
    #[must_use]
    pub const fn tokens_ready(&self) -> bool {
        self.tokens_ready
    }

    /// Whether logits belong to the most recent successful execution.
    #[must_use]
    pub const fn output_ready(&self) -> bool {
        self.output_ready
    }

    /// Whether a native execution failure or nested owner poison disabled reuse.
    #[must_use]
    pub const fn is_poisoned(&self) -> bool {
        self.poisoned
    }

    pub(super) fn validate_token_ids(&self, token_ids: &[u32]) -> LlamaForwardResult<()> {
        if token_ids.len() != self.plan.sequence_length() {
            return Err(LlamaForwardError::InvalidTokenCount {
                expected: self.plan.sequence_length(),
                actual: token_ids.len(),
            });
        }
        let vocabulary_size = self.plan.dimensions().vocabulary_size();
        for (position, &token_id) in token_ids.iter().enumerate() {
            let in_range = usize::try_from(token_id)
                .ok()
                .is_some_and(|token| token < vocabulary_size);
            if !in_range {
                return Err(LlamaForwardError::TokenOutOfRange {
                    position,
                    token_id,
                    vocabulary_size,
                });
            }
        }
        Ok(())
    }

    /// Validates and uploads exactly the plan's fixed token vector.
    ///
    /// Host conversion, pinned staging, and the device allocation are all
    /// prepared already, so this method performs no allocation.
    ///
    /// # Errors
    ///
    /// Returns for a poisoned owner, wrong token count, out-of-range token, or
    /// CUDA copy/synchronization failure.
    pub fn upload_tokens(
        &mut self,
        token_ids: &[u32],
        stream: &mut CudaStream,
    ) -> LlamaForwardResult<()> {
        if self.poisoned {
            return Err(LlamaForwardError::Poisoned);
        }
        self.validate_token_ids(token_ids)?;
        for (destination, &token_id) in self.token_bytes.chunks_exact_mut(4).zip(token_ids) {
            destination.copy_from_slice(&token_id.to_ne_bytes());
        }

        self.tokens_ready = false;
        self.output_ready = false;
        let result = self.buffers.token_ids.upload_from_slice(
            0,
            &self.token_bytes,
            &mut self.io_staging,
            stream,
        );
        match result {
            Ok(()) => {
                self.tokens_ready = true;
                Ok(())
            }
            Err(source) => {
                poison_for_cuda_error(&mut self.poisoned, &source);
                Err(LlamaForwardError::cuda(
                    ExecutionSite::global(LlamaOp::Embedding),
                    source,
                ))
            }
        }
    }

    /// Executes the prepared cache-free full-sequence graph and writes logits.
    ///
    /// The successful path performs no host or device allocation, name lookup,
    /// JSON parsing, or map lookup. Every native operation synchronizes the
    /// explicit stream before returning.
    ///
    /// # Errors
    ///
    /// Returns for missing tokens, poisoned state, an impossible bound-weight
    /// invariant, or a layer/op-qualified CUDA failure.
    pub fn execute(&mut self, stream: &mut CudaStream) -> LlamaForwardResult<()> {
        if self.poisoned {
            return Err(LlamaForwardError::Poisoned);
        }
        if !self.tokens_ready {
            return Err(LlamaForwardError::TokensNotUploaded);
        }
        self.output_ready = false;
        let result =
            self.execute_inner::<false, false, false>(stream, None, None, None, None, None);
        match result {
            Ok(()) => {
                self.output_ready = true;
                Ok(())
            }
            Err(error) => {
                poison_for_forward_error(&mut self.poisoned, &error);
                self.poisoned |= self.gemms.any_poisoned();
                Err(error)
            }
        }
    }

    /// Executes the fixed prompt graph while copying each layer's rotated K
    /// and raw V tensors into the caller-selected decode cache.
    ///
    /// This is a crate-private PR09/PR10 entry point. The public cache-free
    /// [`Self::execute`] path continues to pass no cache sink and therefore
    /// launches exactly the PR08 graph.
    pub(super) fn execute_prefill_into_cache(
        &mut self,
        cache: PrefillKvCacheSink<'_>,
        stream: &mut CudaStream,
    ) -> LlamaForwardResult<()> {
        if self.poisoned {
            return Err(LlamaForwardError::Poisoned);
        }
        if !self.tokens_ready {
            return Err(LlamaForwardError::TokensNotUploaded);
        }
        self.output_ready = false;
        let result =
            self.execute_inner::<false, false, false>(stream, None, None, None, None, Some(cache));
        match result {
            Ok(()) => {
                self.output_ready = true;
                Ok(())
            }
            Err(error) => {
                poison_for_forward_error(&mut self.poisoned, &error);
                self.poisoned |= self.gemms.any_poisoned();
                Err(error)
            }
        }
    }

    /// Executes the same graph while downloading the fixed diagnostic
    /// checkpoints into a compatible preallocated trace owner.
    ///
    /// This path is intentionally diagnostic and synchronizes for each trace
    /// transfer. The production [`Self::execute`] path performs no transfers.
    ///
    /// # Errors
    ///
    /// Returns for missing tokens, poisoned state, an incompatible trace, or
    /// any layer/op-qualified execution or trace-copy failure.
    pub fn execute_traced(
        &mut self,
        stream: &mut CudaStream,
        trace: &mut PreparedLlamaTrace,
    ) -> LlamaForwardResult<()> {
        if self.poisoned {
            return Err(LlamaForwardError::Poisoned);
        }
        if !self.tokens_ready {
            return Err(LlamaForwardError::TokensNotUploaded);
        }
        if trace.requests(LlamaTracePoint::Layer0AttentionProbabilities)
            && !attention_probabilities_available(self.attention.backend())
        {
            return Err(LlamaForwardError::TraceRequiresReferenceAttention);
        }
        if self.projection_bias_mode.requires_qkv_bias_epilogue()
            && trace_requests_unbiased_qkv_projection(trace)
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "trace",
                reason: "fused Q/K/V bias epilogue has no unbiased-linear trace checkpoint",
            });
        }
        trace.validate(&self.plan)?;
        trace.reset();
        self.output_ready = false;
        let result =
            self.execute_inner::<false, false, false>(stream, Some(trace), None, None, None, None);
        match result {
            Ok(()) => {
                self.output_ready = true;
                Ok(())
            }
            Err(error) => {
                poison_for_forward_error(&mut self.poisoned, &error);
                self.poisoned |= self.gemms.any_poisoned();
                Err(error)
            }
        }
    }

    /// Executes the graph while downloading the final BF16 row after each
    /// caller-selected MLP residual and, optionally, final RMS normalization.
    ///
    /// The capture happens after the residual kernel and before the next
    /// layer's hidden-buffer swap. It is intentionally diagnostic: each
    /// selected row transfer synchronizes the stream. The normal
    /// [`Self::execute`] instantiation does not execute this capture branch.
    ///
    /// # Errors
    ///
    /// Returns for missing tokens, poisoned state, an incompatible trace, or
    /// any layer/op-qualified execution or trace-copy failure.
    pub fn execute_last_token_layer_traced(
        &mut self,
        stream: &mut CudaStream,
        trace: &mut PreparedLlamaLastTokenLayerTrace,
    ) -> LlamaForwardResult<()> {
        if self.poisoned {
            return Err(LlamaForwardError::Poisoned);
        }
        if !self.tokens_ready {
            return Err(LlamaForwardError::TokensNotUploaded);
        }
        trace.validate(&self.plan)?;
        trace.reset();
        self.output_ready = false;
        let result =
            self.execute_inner::<true, false, false>(stream, None, Some(trace), None, None, None);
        match result {
            Ok(()) => {
                self.output_ready = true;
                Ok(())
            }
            Err(error) => {
                poison_for_forward_error(&mut self.poisoned, &error);
                self.poisoned |= self.gemms.any_poisoned();
                Err(error)
            }
        }
    }

    /// Executes the graph while capturing every final-token boundary in one
    /// selected decoder layer.
    ///
    /// This is a diagnostic-only path. Each capture synchronizes the explicit
    /// stream; normal serving execution neither allocates this owner nor emits
    /// any of its copies.
    ///
    /// # Errors
    ///
    /// Returns for missing tokens, a poisoned owner, an incompatible trace, or
    /// a layer/op-qualified CUDA transfer or execution failure.
    pub fn execute_last_token_layer_stage_traced(
        &mut self,
        stream: &mut CudaStream,
        trace: &mut PreparedLlamaLastTokenLayerStageTrace,
    ) -> LlamaForwardResult<()> {
        if self.poisoned {
            return Err(LlamaForwardError::Poisoned);
        }
        if !self.tokens_ready {
            return Err(LlamaForwardError::TokensNotUploaded);
        }
        trace.validate(&self.plan)?;
        trace.reset();
        self.output_ready = false;
        let result =
            self.execute_inner::<false, true, false>(stream, None, None, Some(trace), None, None);
        match result {
            Ok(()) => {
                self.output_ready = true;
                Ok(())
            }
            Err(error) => {
                poison_for_forward_error(&mut self.poisoned, &error);
                self.poisoned |= self.gemms.any_poisoned();
                Err(error)
            }
        }
    }

    /// Executes the graph while capturing caller-selected full-sequence
    /// boundaries in one decoder layer.
    ///
    /// This is a diagnostic-only path. Each selected transfer synchronizes the
    /// explicit stream; the normal serving path has no allocation or transfer
    /// branch for this owner.
    ///
    /// # Errors
    ///
    /// Returns for missing tokens, a poisoned owner, an incompatible trace, or
    /// a layer/op-qualified CUDA transfer or execution failure.
    pub fn execute_full_sequence_layer_stage_traced(
        &mut self,
        stream: &mut CudaStream,
        trace: &mut PreparedLlamaFullSequenceLayerStageTrace,
    ) -> LlamaForwardResult<()> {
        if self.poisoned {
            return Err(LlamaForwardError::Poisoned);
        }
        if !self.tokens_ready {
            return Err(LlamaForwardError::TokensNotUploaded);
        }
        trace.validate(&self.plan)?;
        trace.reset();
        self.output_ready = false;
        let result =
            self.execute_inner::<false, false, true>(stream, None, None, None, Some(trace), None);
        match result {
            Ok(()) => {
                self.output_ready = true;
                Ok(())
            }
            Err(error) => {
                poison_for_forward_error(&mut self.poisoned, &error);
                self.poisoned |= self.gemms.any_poisoned();
                Err(error)
            }
        }
    }

    /// Uploads one exact-length token vector and executes the graph.
    ///
    /// # Errors
    ///
    /// Returns any validation, copy, or execution failure from the two stages.
    pub fn forward(
        &mut self,
        token_ids: &[u32],
        stream: &mut CudaStream,
    ) -> LlamaForwardResult<()> {
        self.upload_tokens(token_ids, stream)?;
        self.execute(stream)
    }

    /// Downloads all BF16 logits `[S,V]` into caller-owned bytes.
    ///
    /// # Errors
    ///
    /// Returns when no successful output exists, the destination size differs,
    /// or the staged CUDA copy fails.
    pub fn download_logits(
        &mut self,
        destination: &mut [u8],
        stream: &mut CudaStream,
    ) -> LlamaForwardResult<()> {
        if self.poisoned {
            return Err(LlamaForwardError::Poisoned);
        }
        if !self.output_ready {
            return Err(LlamaForwardError::OutputNotReady);
        }
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if self
            .lm_head_mode
            .is_hf_eager_qwen_p2051_last_token_direct_cublas_probe()
            || self
                .lm_head_mode
                .is_hf_eager_qwen_p2048_cache_on_last_token_direct_cublas_probe()
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "lm_head_mode",
                reason: "the diagnostic last-token LM-head probe does not produce a full logits matrix",
            });
        }
        let expected =
            usize::try_from(self.plan.workspace_spec().logits_bytes()).map_err(|_| {
                LlamaForwardError::ArithmeticOverflow {
                    resource: LlamaForwardResource::Logits,
                }
            })?;
        if destination.len() != expected {
            return Err(LlamaForwardError::InvalidDownloadLength {
                expected_bytes: expected,
                actual_bytes: destination.len(),
            });
        }
        self.download_logits_range(0, destination, stream)
    }

    /// Downloads the last-position BF16 vocabulary logits `[V]`.
    ///
    /// # Errors
    ///
    /// Returns when no successful output exists, the destination size differs,
    /// offset arithmetic overflows, or the staged CUDA copy fails.
    pub fn download_last_logits(
        &mut self,
        destination: &mut [u8],
        stream: &mut CudaStream,
    ) -> LlamaForwardResult<()> {
        if self.poisoned {
            return Err(LlamaForwardError::Poisoned);
        }
        if !self.output_ready {
            return Err(LlamaForwardError::OutputNotReady);
        }
        let row_bytes = to_u64(
            self.plan.dimensions().vocabulary_size(),
            LlamaForwardResource::Logits,
        )?
        .checked_mul(BF16_BYTES)
        .ok_or(LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::Logits,
        })?;
        let expected =
            usize::try_from(row_bytes).map_err(|_| LlamaForwardError::ArithmeticOverflow {
                resource: LlamaForwardResource::Logits,
            })?;
        if destination.len() != expected {
            return Err(LlamaForwardError::InvalidDownloadLength {
                expected_bytes: expected,
                actual_bytes: destination.len(),
            });
        }
        let row = to_u64(
            self.plan.sequence_length() - 1,
            LlamaForwardResource::Logits,
        )?;
        let offset = row
            .checked_mul(row_bytes)
            .ok_or(LlamaForwardError::ArithmeticOverflow {
                resource: LlamaForwardResource::Logits,
            })?;
        self.download_logits_range(offset, destination, stream)
    }

    pub(super) fn download_logits_range(
        &mut self,
        offset: u64,
        destination: &mut [u8],
        stream: &mut CudaStream,
    ) -> LlamaForwardResult<()> {
        if self.paged_batch_only {
            return Err(LlamaForwardError::InvalidConfiguration {field:"paged_batch_storage",reason:"batch-only logits are owned by the batch output buffer"});
        }
        let result = self.buffers.logits.download_to_slice(
            offset,
            destination,
            &mut self.io_staging,
            stream,
        );
        match result {
            Ok(()) => Ok(()),
            Err(source) => {
                poison_for_cuda_error(&mut self.poisoned, &source);
                Err(LlamaForwardError::cuda(
                    ExecutionSite::global(LlamaOp::LmHead),
                    source,
                ))
            }
        }
    }

    // HOT_EXECUTE_BEGIN
    #[allow(
        clippy::too_many_lines,
        clippy::cast_precision_loss,
        clippy::similar_names
    )]
    fn execute_inner<
        const LAST_TOKEN_TRACE: bool,
        const LAYER_STAGE_TRACE: bool,
        const FULL_SEQUENCE_LAYER_STAGE_TRACE: bool,
    >(
        &mut self,
        stream: &mut CudaStream,
        mut trace: Option<&mut PreparedLlamaTrace>,
        mut last_token_layer_trace: Option<&mut PreparedLlamaLastTokenLayerTrace>,
        mut last_token_layer_stage_trace: Option<&mut PreparedLlamaLastTokenLayerStageTrace>,
        mut full_sequence_layer_stage_trace: Option<&mut PreparedLlamaFullSequenceLayerStageTrace>,
        mut cache: Option<PrefillKvCacheSink<'_>>,
    ) -> LlamaForwardResult<()> {
        if self.paged_batch_only {
            return Err(LlamaForwardError::InvalidConfiguration {field:"paged_batch_storage",reason:"batch-only buffers cannot execute the standalone dense graph"});
        }
        // The per-head query/key norm (Qwen3) is implemented by the batch
        // executor only; this single-sequence route would silently skip it.
        if self
            .plan
            .layers()
            .iter()
            .any(|layer| layer.query_key_norm().is_some())
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "model",
                reason: "a per-head query/key norm is supported by the batch executor only",
            });
        }
        if self.plan.dimensions().query_width() != self.plan.dimensions().hidden_size() {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "model",
                reason: "a query projection wider than the hidden size is supported by the batch executor only",
            });
        }
        let plan = &self.plan;
        let weights = &self.weights;
        let gemms = &mut self.gemms;
        let attention = &self.attention;
        let rms_norm_profile = self.rms_norm_profile;
        let buffers = &mut self.buffers;
        let io_staging = &mut self.io_staging;
        let sequence = to_u64(plan.sequence_length(), LlamaForwardResource::HiddenCurrent)?;
        let dimensions = plan.dimensions();
        let hidden = to_u64(
            dimensions.hidden_size(),
            LlamaForwardResource::HiddenCurrent,
        )?;
        let last_token_hidden_offset = last_token_hidden_row_offset(plan)?;
        let key_value_width = to_u64(dimensions.key_value_width(), LlamaForwardResource::KeyRaw)?;
        let last_token_key_value_offset = if LAYER_STAGE_TRACE {
            last_token_row_offset(plan, dimensions.key_value_width())?
        } else {
            0
        };
        let last_token_intermediate_offset = if LAYER_STAGE_TRACE {
            last_token_row_offset(plan, dimensions.intermediate_size())?
        } else {
            0
        };
        let query_heads = to_u64(dimensions.query_heads(), LlamaForwardResource::Attention)?;
        let key_value_heads = to_u64(dimensions.key_value_heads(), LlamaForwardResource::KeyRaw)?;
        let head_size = to_u64(
            dimensions.head_dimension(),
            LlamaForwardResource::HiddenRotary,
        )?;
        let hidden_elements = plan.workspace_spec().hidden_buffer_bytes() / BF16_BYTES;
        let intermediate_elements = plan.workspace_spec().intermediate_buffer_bytes() / BF16_BYTES;

        let embedding_site = ExecutionSite::global(LlamaOp::Embedding);
        let embedding_weight = weight_span(weights, plan.embedding_weight(), embedding_site)?;
        {
            let mut params = EmbeddingParams {
                table: embedding_weight,
                token_ids: span(
                    &buffers.token_ids,
                    CudaDType::U32,
                    plan.workspace_spec().token_ids_bytes(),
                    embedding_site,
                )?,
                output: span_mut(
                    &mut buffers.hidden_current,
                    CudaDType::BF16,
                    plan.workspace_spec().hidden_buffer_bytes(),
                    embedding_site,
                )?,
                error_scratch: span_mut(
                    &mut buffers.embedding_error_scratch,
                    CudaDType::U8,
                    plan.workspace_spec().embedding_error_scratch_bytes(),
                    embedding_site,
                )?,
                token_count: sequence,
                vocabulary_size: to_u64(
                    dimensions.vocabulary_size(),
                    LlamaForwardResource::Logits,
                )?,
                hidden_size: hidden,
            };
            embedding(&mut params, stream).map_err(|source| LlamaForwardError::Embedding {
                site: embedding_site,
                source,
            })?;
        }
        capture_trace(
            &mut trace,
            LlamaTracePoint::Embedding,
            &mut buffers.hidden_current,
            0,
            io_staging,
            stream,
            embedding_site,
        )?;

        for layer in plan.layers() {
            let layer_index = layer.index();
            let input_norm_site = ExecutionSite::layer(layer_index, LlamaOp::InputNorm);
            let input_norm_weight =
                weight_span(weights, layer.input_norm_weight(), input_norm_site)?;
            {
                let mut params = RmsNormParams {
                    input: span(
                        &buffers.hidden_current,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        input_norm_site,
                    )?,
                    weight: input_norm_weight,
                    output: span_mut(
                        &mut buffers.hidden_norm,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        input_norm_site,
                    )?,
                    row_count: sequence,
                    hidden_size: hidden,
                    epsilon: layer.input_norm_epsilon(),
                };
                execute_profile_rms_norm(rms_norm_profile, &mut params, stream)
                    .map_err(|source| LlamaForwardError::cuda(input_norm_site, source))?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0InputNorm,
                    &mut buffers.hidden_norm,
                    0,
                    io_staging,
                    stream,
                    input_norm_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::InputNorm,
                    &mut buffers.hidden_norm,
                    last_token_hidden_offset,
                    io_staging,
                    stream,
                    input_norm_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::InputNorm,
                    &mut buffers.hidden_norm,
                    io_staging,
                    stream,
                    input_norm_site,
                )?;
            }

            let query_site = ExecutionSite::layer(layer_index, LlamaOp::QueryProjection);
            let query_weight = weight_span(weights, layer.query_weight(), query_site)?;
            let (strict, fused) = gemms.query_projection_plans();
            if let Some(fused) = fused {
                execute_bias_epilogue_gemm(
                    fused,
                    weights,
                    layer.query_bias(),
                    &buffers.hidden_norm,
                    query_weight,
                    &mut buffers.hidden_projection,
                    &mut buffers.gemm_workspace,
                    stream,
                    query_site,
                )?;
            } else {
                execute_gemm(
                    strict,
                    &buffers.hidden_norm,
                    query_weight,
                    &mut buffers.hidden_projection,
                    &mut buffers.gemm_workspace,
                    stream,
                    query_site,
                )?;
                if layer_index == 0 {
                    capture_trace(
                        &mut trace,
                        LlamaTracePoint::Layer0QueryProjectionUnbiasedLinear,
                        &mut buffers.hidden_projection,
                        0,
                        io_staging,
                        stream,
                        query_site,
                    )?;
                }
                execute_projection_bias(
                    weights,
                    layer.query_bias(),
                    &mut buffers.hidden_projection,
                    sequence,
                    hidden,
                    stream,
                    query_site,
                )?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0QueryProjection,
                    &mut buffers.hidden_projection,
                    0,
                    io_staging,
                    stream,
                    query_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::QueryProjection,
                    &mut buffers.hidden_projection,
                    last_token_hidden_offset,
                    io_staging,
                    stream,
                    query_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::QueryProjection,
                    &mut buffers.hidden_projection,
                    io_staging,
                    stream,
                    query_site,
                )?;
            }
            let key_site = ExecutionSite::layer(layer_index, LlamaOp::KeyProjection);
            let key_weight = weight_span(weights, layer.key_weight(), key_site)?;
            let (strict, fused) = gemms.key_value_projection_plans();
            if let Some(fused) = fused {
                execute_bias_epilogue_gemm(
                    fused,
                    weights,
                    layer.key_bias(),
                    &buffers.hidden_norm,
                    key_weight,
                    &mut buffers.key_raw,
                    &mut buffers.gemm_workspace,
                    stream,
                    key_site,
                )?;
            } else {
                execute_gemm(
                    strict,
                    &buffers.hidden_norm,
                    key_weight,
                    &mut buffers.key_raw,
                    &mut buffers.gemm_workspace,
                    stream,
                    key_site,
                )?;
                if layer_index == 0 {
                    capture_trace(
                        &mut trace,
                        LlamaTracePoint::Layer0KeyProjectionUnbiasedLinear,
                        &mut buffers.key_raw,
                        0,
                        io_staging,
                        stream,
                        key_site,
                    )?;
                }
                execute_projection_bias(
                    weights,
                    layer.key_bias(),
                    &mut buffers.key_raw,
                    sequence,
                    key_value_width,
                    stream,
                    key_site,
                )?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0KeyProjection,
                    &mut buffers.key_raw,
                    0,
                    io_staging,
                    stream,
                    key_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::KeyProjection,
                    &mut buffers.key_raw,
                    last_token_key_value_offset,
                    io_staging,
                    stream,
                    key_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::KeyProjection,
                    &mut buffers.key_raw,
                    io_staging,
                    stream,
                    key_site,
                )?;
            }
            let value_site = ExecutionSite::layer(layer_index, LlamaOp::ValueProjection);
            let value_weight = weight_span(weights, layer.value_weight(), value_site)?;
            let (strict, fused) = gemms.key_value_projection_plans();
            if let Some(fused) = fused {
                execute_bias_epilogue_gemm(
                    fused,
                    weights,
                    layer.value_bias(),
                    &buffers.hidden_norm,
                    value_weight,
                    &mut buffers.value_raw,
                    &mut buffers.gemm_workspace,
                    stream,
                    value_site,
                )?;
            } else {
                execute_gemm(
                    strict,
                    &buffers.hidden_norm,
                    value_weight,
                    &mut buffers.value_raw,
                    &mut buffers.gemm_workspace,
                    stream,
                    value_site,
                )?;
                if layer_index == 0 {
                    capture_trace(
                        &mut trace,
                        LlamaTracePoint::Layer0ValueProjectionUnbiasedLinear,
                        &mut buffers.value_raw,
                        0,
                        io_staging,
                        stream,
                        value_site,
                    )?;
                }
                execute_projection_bias(
                    weights,
                    layer.value_bias(),
                    &mut buffers.value_raw,
                    sequence,
                    key_value_width,
                    stream,
                    value_site,
                )?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0ValueProjection,
                    &mut buffers.value_raw,
                    0,
                    io_staging,
                    stream,
                    value_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::ValueProjection,
                    &mut buffers.value_raw,
                    last_token_key_value_offset,
                    io_staging,
                    stream,
                    value_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::ValueProjection,
                    &mut buffers.value_raw,
                    io_staging,
                    stream,
                    value_site,
                )?;
            }

            let query_rope_site = ExecutionSite::layer(layer_index, LlamaOp::QueryRope);
            {
                let mut params = RopeParams {
                    input: span(
                        &buffers.hidden_projection,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        query_rope_site,
                    )?,
                    cos: span(
                        &buffers.rope_cos,
                        CudaDType::F32,
                        plan.workspace_spec().rope_cos_bytes(),
                        query_rope_site,
                    )?,
                    sin: span(
                        &buffers.rope_sin,
                        CudaDType::F32,
                        plan.workspace_spec().rope_sin_bytes(),
                        query_rope_site,
                    )?,
                    output: span_mut(
                        &mut buffers.hidden_rotary,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        query_rope_site,
                    )?,
                    token_count: sequence,
                    head_count: query_heads,
                    head_size,
                    rotary_dimension: head_size,
                    table_position_count: sequence,
                    position_offset: 0,
                };
                rope(&mut params, stream)
                    .map_err(|source| LlamaForwardError::cuda(query_rope_site, source))?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0QueryRotary,
                    &mut buffers.hidden_rotary,
                    0,
                    io_staging,
                    stream,
                    query_rope_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::QueryRotary,
                    &mut buffers.hidden_rotary,
                    last_token_hidden_offset,
                    io_staging,
                    stream,
                    query_rope_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::QueryRotary,
                    &mut buffers.hidden_rotary,
                    io_staging,
                    stream,
                    query_rope_site,
                )?;
            }
            let key_rope_site = ExecutionSite::layer(layer_index, LlamaOp::KeyRope);
            {
                let mut params = RopeParams {
                    input: span(
                        &buffers.key_raw,
                        CudaDType::BF16,
                        plan.workspace_spec().key_value_buffer_bytes(),
                        key_rope_site,
                    )?,
                    cos: span(
                        &buffers.rope_cos,
                        CudaDType::F32,
                        plan.workspace_spec().rope_cos_bytes(),
                        key_rope_site,
                    )?,
                    sin: span(
                        &buffers.rope_sin,
                        CudaDType::F32,
                        plan.workspace_spec().rope_sin_bytes(),
                        key_rope_site,
                    )?,
                    output: span_mut(
                        &mut buffers.key_rotary,
                        CudaDType::BF16,
                        plan.workspace_spec().key_value_buffer_bytes(),
                        key_rope_site,
                    )?,
                    token_count: sequence,
                    head_count: key_value_heads,
                    head_size,
                    rotary_dimension: head_size,
                    table_position_count: sequence,
                    position_offset: 0,
                };
                rope(&mut params, stream)
                    .map_err(|source| LlamaForwardError::cuda(key_rope_site, source))?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0KeyRotary,
                    &mut buffers.key_rotary,
                    0,
                    io_staging,
                    stream,
                    key_rope_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::KeyRotary,
                    &mut buffers.key_rotary,
                    last_token_key_value_offset,
                    io_staging,
                    stream,
                    key_rope_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::KeyRotary,
                    &mut buffers.key_rotary,
                    io_staging,
                    stream,
                    key_rope_site,
                )?;
            }

            if let Some(cache) = cache.as_mut() {
                let cache_site = ExecutionSite::layer(layer_index, LlamaOp::KvCacheWrite);
                cache
                    .append_layer(
                        layer_index,
                        &buffers.key_rotary,
                        &buffers.value_raw,
                        sequence,
                        0,
                        stream,
                    )
                    .map_err(|error| error.into_forward_cache_error(cache_site))?;
            }

            let prefill_site = ExecutionSite::layer(layer_index, LlamaOp::PrefillAttention);
            {
                let ForwardBuffers {
                    hidden_rotary,
                    hidden_context,
                    value_raw,
                    key_rotary,
                    attention_workspace,
                    ..
                } = buffers;
                let workspace = attention_workspace
                    .as_mut()
                    .map(|buffer| {
                        span_mut(
                            buffer,
                            CudaDType::BF16,
                            attention.workspace_bytes(),
                            prefill_site,
                        )
                    })
                    .transpose()?;
                let mut params = PrefillAttentionParams {
                    query: span(
                        hidden_rotary,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        prefill_site,
                    )?,
                    key: span(
                        key_rotary,
                        CudaDType::BF16,
                        plan.workspace_spec().key_value_buffer_bytes(),
                        prefill_site,
                    )?,
                    value: span(
                        value_raw,
                        CudaDType::BF16,
                        plan.workspace_spec().key_value_buffer_bytes(),
                        prefill_site,
                    )?,
                    output: span_mut(
                        hidden_context,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        prefill_site,
                    )?,
                    workspace,
                };
                attention
                    .execute(&mut params, stream)
                    .map_err(|source| LlamaForwardError::cuda(prefill_site, source))?;
            }
            if layer_index == 0
                && trace.as_deref().is_some_and(|trace| {
                    trace.requests(LlamaTracePoint::Layer0AttentionProbabilities)
                })
            {
                let workspace = buffers
                    .attention_workspace
                    .as_mut()
                    .ok_or(LlamaForwardError::TraceRequiresReferenceAttention)?;
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0AttentionProbabilities,
                    workspace,
                    0,
                    io_staging,
                    stream,
                    prefill_site,
                )?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0AttentionContext,
                    &mut buffers.hidden_context,
                    0,
                    io_staging,
                    stream,
                    prefill_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::AttentionContext,
                    &mut buffers.hidden_context,
                    last_token_hidden_offset,
                    io_staging,
                    stream,
                    prefill_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::AttentionContext,
                    &mut buffers.hidden_context,
                    io_staging,
                    stream,
                    prefill_site,
                )?;
            }

            let output_site = ExecutionSite::layer(layer_index, LlamaOp::OutputProjection);
            let output_weight = weight_span(weights, layer.output_weight(), output_site)?;
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            {
                if let Some(plan) = gemms.output_projection_direct_cublas.as_mut() {
                    execute_direct_cublas_gemm_probe(
                        plan,
                        &buffers.hidden_context,
                        output_weight,
                        &mut buffers.hidden_projection,
                        stream,
                        output_site,
                    )?;
                } else {
                    execute_gemm(
                        &mut gemms.hidden,
                        &buffers.hidden_context,
                        output_weight,
                        &mut buffers.hidden_projection,
                        &mut buffers.gemm_workspace,
                        stream,
                        output_site,
                    )?;
                }
            }
            #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
            execute_gemm(
                &mut gemms.hidden,
                &buffers.hidden_context,
                output_weight,
                &mut buffers.hidden_projection,
                &mut buffers.gemm_workspace,
                stream,
                output_site,
            )?;
            execute_projection_bias(
                weights,
                layer.output_bias(),
                &mut buffers.hidden_projection,
                sequence,
                hidden,
                stream,
                output_site,
            )?;
            let attention_residual_site =
                ExecutionSite::layer(layer_index, LlamaOp::AttentionResidual);
            {
                let mut params = ResidualAddParams {
                    left: span(
                        &buffers.hidden_current,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        attention_residual_site,
                    )?,
                    right: span(
                        &buffers.hidden_projection,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        attention_residual_site,
                    )?,
                    output: span_mut(
                        &mut buffers.hidden_rotary,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        attention_residual_site,
                    )?,
                    element_count: hidden_elements,
                };
                residual_add(&mut params, stream)
                    .map_err(|source| LlamaForwardError::cuda(attention_residual_site, source))?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0AfterAttentionResidual,
                    &mut buffers.hidden_rotary,
                    0,
                    io_staging,
                    stream,
                    attention_residual_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::AfterAttentionResidual,
                    &mut buffers.hidden_rotary,
                    last_token_hidden_offset,
                    io_staging,
                    stream,
                    attention_residual_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::AfterAttentionResidual,
                    &mut buffers.hidden_rotary,
                    io_staging,
                    stream,
                    attention_residual_site,
                )?;
            }

            let post_norm_site = ExecutionSite::layer(layer_index, LlamaOp::PostAttentionNorm);
            let post_norm_weight =
                weight_span(weights, layer.post_attention_norm_weight(), post_norm_site)?;
            {
                let mut params = RmsNormParams {
                    input: span(
                        &buffers.hidden_rotary,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        post_norm_site,
                    )?,
                    weight: post_norm_weight,
                    output: span_mut(
                        &mut buffers.hidden_norm,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        post_norm_site,
                    )?,
                    row_count: sequence,
                    hidden_size: hidden,
                    epsilon: layer.post_attention_norm_epsilon(),
                };
                execute_profile_rms_norm(rms_norm_profile, &mut params, stream)
                    .map_err(|source| LlamaForwardError::cuda(post_norm_site, source))?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0PostAttentionNorm,
                    &mut buffers.hidden_norm,
                    0,
                    io_staging,
                    stream,
                    post_norm_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::PostAttentionNorm,
                    &mut buffers.hidden_norm,
                    last_token_hidden_offset,
                    io_staging,
                    stream,
                    post_norm_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::PostAttentionNorm,
                    &mut buffers.hidden_norm,
                    io_staging,
                    stream,
                    post_norm_site,
                )?;
            }

            let gate_site = ExecutionSite::layer(layer_index, LlamaOp::GateProjection);
            let gate_weight = weight_span(weights, layer.gate_weight(), gate_site)?;
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            {
                if let Some(plans) = gemms.mlp_projection_direct_cublas.as_mut() {
                    execute_direct_cublas_gemm_probe(
                        &mut plans.intermediate,
                        &buffers.hidden_norm,
                        gate_weight,
                        &mut buffers.gate_raw,
                        stream,
                        gate_site,
                    )?;
                } else {
                    execute_gemm(
                        &mut gemms.intermediate,
                        &buffers.hidden_norm,
                        gate_weight,
                        &mut buffers.gate_raw,
                        &mut buffers.gemm_workspace,
                        stream,
                        gate_site,
                    )?;
                }
            }
            #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
            execute_gemm(
                &mut gemms.intermediate,
                &buffers.hidden_norm,
                gate_weight,
                &mut buffers.gate_raw,
                &mut buffers.gemm_workspace,
                stream,
                gate_site,
            )?;
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0GateProjection,
                    &mut buffers.gate_raw,
                    0,
                    io_staging,
                    stream,
                    gate_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::GateProjection,
                    &mut buffers.gate_raw,
                    last_token_intermediate_offset,
                    io_staging,
                    stream,
                    gate_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::GateProjection,
                    &mut buffers.gate_raw,
                    io_staging,
                    stream,
                    gate_site,
                )?;
            }
            let up_site = ExecutionSite::layer(layer_index, LlamaOp::UpProjection);
            let up_weight = weight_span(weights, layer.up_weight(), up_site)?;
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            {
                if let Some(plans) = gemms.mlp_projection_direct_cublas.as_mut() {
                    execute_direct_cublas_gemm_probe(
                        &mut plans.intermediate,
                        &buffers.hidden_norm,
                        up_weight,
                        &mut buffers.up_raw,
                        stream,
                        up_site,
                    )?;
                } else {
                    execute_gemm(
                        &mut gemms.intermediate,
                        &buffers.hidden_norm,
                        up_weight,
                        &mut buffers.up_raw,
                        &mut buffers.gemm_workspace,
                        stream,
                        up_site,
                    )?;
                }
            }
            #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
            execute_gemm(
                &mut gemms.intermediate,
                &buffers.hidden_norm,
                up_weight,
                &mut buffers.up_raw,
                &mut buffers.gemm_workspace,
                stream,
                up_site,
            )?;
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0UpProjection,
                    &mut buffers.up_raw,
                    0,
                    io_staging,
                    stream,
                    up_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::UpProjection,
                    &mut buffers.up_raw,
                    last_token_intermediate_offset,
                    io_staging,
                    stream,
                    up_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::UpProjection,
                    &mut buffers.up_raw,
                    io_staging,
                    stream,
                    up_site,
                )?;
            }
            let silu_site = ExecutionSite::layer(layer_index, LlamaOp::Silu);
            {
                let mut params = SiluParams {
                    input: span(
                        &buffers.gate_raw,
                        CudaDType::BF16,
                        plan.workspace_spec().intermediate_buffer_bytes(),
                        silu_site,
                    )?,
                    output: span_mut(
                        &mut buffers.gate_activated,
                        CudaDType::BF16,
                        plan.workspace_spec().intermediate_buffer_bytes(),
                        silu_site,
                    )?,
                    element_count: intermediate_elements,
                };
                silu(&mut params, stream)
                    .map_err(|source| LlamaForwardError::cuda(silu_site, source))?;
            }
            let gated_site = ExecutionSite::layer(layer_index, LlamaOp::GatedMultiply);
            {
                let mut params = GatedMultiplyParams {
                    activated_gate: span(
                        &buffers.gate_activated,
                        CudaDType::BF16,
                        plan.workspace_spec().intermediate_buffer_bytes(),
                        gated_site,
                    )?,
                    up: span(
                        &buffers.up_raw,
                        CudaDType::BF16,
                        plan.workspace_spec().intermediate_buffer_bytes(),
                        gated_site,
                    )?,
                    output: span_mut(
                        &mut buffers.gated_product,
                        CudaDType::BF16,
                        plan.workspace_spec().intermediate_buffer_bytes(),
                        gated_site,
                    )?,
                    element_count: intermediate_elements,
                };
                gated_multiply(&mut params, stream)
                    .map_err(|source| LlamaForwardError::cuda(gated_site, source))?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0Gated,
                    &mut buffers.gated_product,
                    0,
                    io_staging,
                    stream,
                    gated_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::Gated,
                    &mut buffers.gated_product,
                    last_token_intermediate_offset,
                    io_staging,
                    stream,
                    gated_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::Gated,
                    &mut buffers.gated_product,
                    io_staging,
                    stream,
                    gated_site,
                )?;
            }
            let down_site = ExecutionSite::layer(layer_index, LlamaOp::DownProjection);
            let down_weight = weight_span(weights, layer.down_weight(), down_site)?;
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            {
                if let Some(plans) = gemms.mlp_projection_direct_cublas.as_mut() {
                    execute_direct_cublas_gemm_probe(
                        &mut plans.down,
                        &buffers.gated_product,
                        down_weight,
                        &mut buffers.hidden_current,
                        stream,
                        down_site,
                    )?;
                } else {
                    execute_gemm(
                        &mut gemms.down,
                        &buffers.gated_product,
                        down_weight,
                        &mut buffers.hidden_current,
                        &mut buffers.gemm_workspace,
                        stream,
                        down_site,
                    )?;
                }
            }
            #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
            execute_gemm(
                &mut gemms.down,
                &buffers.gated_product,
                down_weight,
                &mut buffers.hidden_current,
                &mut buffers.gemm_workspace,
                stream,
                down_site,
            )?;
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0DownProjection,
                    &mut buffers.hidden_current,
                    0,
                    io_staging,
                    stream,
                    down_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::DownProjection,
                    &mut buffers.hidden_current,
                    last_token_hidden_offset,
                    io_staging,
                    stream,
                    down_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::DownProjection,
                    &mut buffers.hidden_current,
                    io_staging,
                    stream,
                    down_site,
                )?;
            }
            let mlp_residual_site = ExecutionSite::layer(layer_index, LlamaOp::MlpResidual);
            {
                let mut params = ResidualAddParams {
                    left: span(
                        &buffers.hidden_rotary,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        mlp_residual_site,
                    )?,
                    right: span(
                        &buffers.hidden_current,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        mlp_residual_site,
                    )?,
                    output: span_mut(
                        &mut buffers.hidden_projection,
                        CudaDType::BF16,
                        plan.workspace_spec().hidden_buffer_bytes(),
                        mlp_residual_site,
                    )?,
                    element_count: hidden_elements,
                };
                residual_add(&mut params, stream)
                    .map_err(|source| LlamaForwardError::cuda(mlp_residual_site, source))?;
            }
            if layer_index == 0 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer0Output,
                    &mut buffers.hidden_projection,
                    0,
                    io_staging,
                    stream,
                    mlp_residual_site,
                )?;
            } else if layer_index == 14 {
                capture_trace(
                    &mut trace,
                    LlamaTracePoint::Layer14Output,
                    &mut buffers.hidden_projection,
                    0,
                    io_staging,
                    stream,
                    mlp_residual_site,
                )?;
            }
            if LAYER_STAGE_TRACE {
                capture_last_token_layer_stage(
                    &mut last_token_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::Output,
                    &mut buffers.hidden_projection,
                    last_token_hidden_offset,
                    io_staging,
                    stream,
                    mlp_residual_site,
                )?;
            }
            if FULL_SEQUENCE_LAYER_STAGE_TRACE {
                capture_full_sequence_layer_stage(
                    &mut full_sequence_layer_stage_trace,
                    layer_index,
                    LlamaLastTokenLayerStage::Output,
                    &mut buffers.hidden_projection,
                    io_staging,
                    stream,
                    mlp_residual_site,
                )?;
            }
            if LAST_TOKEN_TRACE {
                capture_last_token_layer_residual(
                    &mut last_token_layer_trace,
                    layer_index,
                    &mut buffers.hidden_projection,
                    last_token_hidden_offset,
                    io_staging,
                    stream,
                    mlp_residual_site,
                )?;
            }
            mem::swap(&mut buffers.hidden_current, &mut buffers.hidden_projection);
        }

        let final_norm_site = ExecutionSite::global(LlamaOp::FinalNorm);
        capture_trace(
            &mut trace,
            LlamaTracePoint::FinalNormInput,
            &mut buffers.hidden_current,
            0,
            io_staging,
            stream,
            final_norm_site,
        )?;
        let final_norm_weight = weight_span(weights, plan.final_norm_weight(), final_norm_site)?;
        {
            let mut params = RmsNormParams {
                input: span(
                    &buffers.hidden_current,
                    CudaDType::BF16,
                    plan.workspace_spec().hidden_buffer_bytes(),
                    final_norm_site,
                )?,
                weight: final_norm_weight,
                output: span_mut(
                    &mut buffers.hidden_norm,
                    CudaDType::BF16,
                    plan.workspace_spec().hidden_buffer_bytes(),
                    final_norm_site,
                )?,
                row_count: sequence,
                hidden_size: hidden,
                epsilon: plan.final_norm_epsilon(),
            };
            execute_profile_rms_norm(rms_norm_profile, &mut params, stream)
                .map_err(|source| LlamaForwardError::cuda(final_norm_site, source))?;
        }
        capture_trace(
            &mut trace,
            LlamaTracePoint::FinalNormOutput,
            &mut buffers.hidden_norm,
            0,
            io_staging,
            stream,
            final_norm_site,
        )?;
        if LAST_TOKEN_TRACE {
            capture_last_token_final_norm_output(
                &mut last_token_layer_trace,
                &mut buffers.hidden_norm,
                last_token_hidden_offset,
                io_staging,
                stream,
                final_norm_site,
            )?;
        }
        let lm_head_site = ExecutionSite::global(LlamaOp::LmHead);
        let lm_head_weight = weight_span(weights, plan.lm_head_weight(), lm_head_site)?;
        let last_logits_bytes = trace_byte_len(plan, LlamaTracePoint::LastLogits)?;
        let last_logits_offset = plan
            .workspace_spec()
            .logits_bytes()
            .checked_sub(last_logits_bytes)
            .ok_or(LlamaForwardError::ArithmeticOverflow {
                resource: LlamaForwardResource::Logits,
            })?;
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        {
            if let Some(lm_head_plan) = gemms.lm_head_last_token_direct_cublas.as_mut() {
                let input = CudaBufferSpan::new(
                    &buffers.hidden_norm,
                    CudaDType::BF16,
                    last_token_hidden_offset,
                    last_token_hidden_row_byte_len(plan)?,
                )
                .map_err(|source| LlamaForwardError::cuda(lm_head_site, source))?;
                let output = CudaBufferSpanMut::new(
                    &mut buffers.logits,
                    CudaDType::BF16,
                    last_logits_offset,
                    last_logits_bytes,
                )
                .map_err(|source| LlamaForwardError::cuda(lm_head_site, source))?;
                execute_direct_cublas_gemm_probe_spans(
                    lm_head_plan,
                    input,
                    lm_head_weight,
                    output,
                    stream,
                    lm_head_site,
                )?;
            } else {
                execute_gemm(
                    &mut gemms.lm_head,
                    &buffers.hidden_norm,
                    lm_head_weight,
                    &mut buffers.logits,
                    &mut buffers.gemm_workspace,
                    stream,
                    lm_head_site,
                )?;
            }
        }
        #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
        execute_gemm(
            &mut gemms.lm_head,
            &buffers.hidden_norm,
            lm_head_weight,
            &mut buffers.logits,
            &mut buffers.gemm_workspace,
            stream,
            lm_head_site,
        )?;
        capture_trace(
            &mut trace,
            LlamaTracePoint::LastLogits,
            &mut buffers.logits,
            last_logits_offset,
            io_staging,
            stream,
            lm_head_site,
        )?;
        Ok(())
    }
    // HOT_EXECUTE_END
}

const fn attention_probabilities_available(backend: AttentionBackend) -> bool {
    matches!(
        backend,
        AttentionBackend::MaterializedReference
            | AttentionBackend::HuggingFaceEager
            | AttentionBackend::HuggingFaceEagerQwenP2051Probe
            | AttentionBackend::HuggingFaceEagerQwenP2048CacheOnProbe
    )
}

#[allow(clippy::cast_precision_loss)]
fn prepare_attention(
    context: &CudaContext,
    plan: &LlamaExecutionPlan,
    preference: AttentionPreference,
    reduction_profile: LlamaReductionProfile,
    paged_batch_only: bool,
) -> LlamaForwardResult<PreparedPrefillAttention> {
    let site = ExecutionSite::layer(0, LlamaOp::PrefillAttention);
    let dimensions = plan.dimensions();
    let head_size = to_u64(
        dimensions.head_dimension(),
        LlamaForwardResource::HiddenRotary,
    )?;
    let request = PrefillAttentionRequest::new(
        1,
        to_u64(if paged_batch_only { 1 } else { plan.sequence_length() }, LlamaForwardResource::Attention)?,
        to_u64(dimensions.query_heads(), LlamaForwardResource::Attention)?,
        to_u64(dimensions.key_value_heads(), LlamaForwardResource::KeyRaw)?,
        head_size,
        1.0 / (head_size as f32).sqrt(),
        AttentionMask::Causal,
    );
    PreparedPrefillAttention::select_with_reduction_profile(
        context,
        request,
        preference,
        reduction_profile.attention_profile(),
        AttentionBackendAvailability::linked(),
    )
    .map_err(|source| LlamaForwardError::cuda(site, source))
}

fn build_allocation_report(
    weights: &CudaUploadedWeights,
    plan: &LlamaExecutionPlan,
    attention_workspace_bytes: u64,
    gemm_workspace_bytes: u64,
    pinned_host_bytes: u64,
    actual_buffers: Option<&ForwardBuffers>,
) -> LlamaForwardResult<PreparedLlamaAllocationReport> {
    let graph_bytes = if let Some(b) = actual_buffers {
        let fixed = [&b.token_ids,&b.hidden_current,&b.hidden_norm,&b.hidden_projection,
            &b.hidden_rotary,&b.hidden_context,&b.key_raw,&b.value_raw,&b.key_rotary,
            &b.gate_raw,&b.up_raw,&b.gate_activated,&b.gated_product,&b.rope_cos,
            &b.rope_sin,&b.logits,&b.embedding_error_scratch];
        fixed.iter().try_fold(attention_workspace_bytes, |sum, buffer| sum.checked_add(buffer.byte_len()))
            .ok_or(LlamaForwardError::ArithmeticOverflow {resource:LlamaForwardResource::Attention})?
    } else { plan
        .workspace_spec()
        .non_attention_planned_bytes()
        .checked_add(attention_workspace_bytes)
        .ok_or(LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::Attention,
        })? };
    let total_device_bytes = weights
        .total_physical_bytes()
        .checked_add(graph_bytes)
        .and_then(|bytes| bytes.checked_add(gemm_workspace_bytes))
        .ok_or(LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::GemmWorkspace,
        })?;
    let graph_allocations = NON_ATTENTION_GRAPH_ALLOCATION_COUNT
        .checked_add(u64::from(attention_workspace_bytes != 0))
        .and_then(|count| count.checked_add(u64::from(gemm_workspace_bytes != 0)))
        .ok_or(LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::Attention,
        })?;
    let physical_allocations = u64::try_from(weights.physical_tensor_count()).map_err(|_| {
        LlamaForwardError::ArithmeticOverflow {
            resource: LlamaForwardResource::UploadedWeights,
        }
    })?;
    Ok(PreparedLlamaAllocationReport {
        weight_bytes: weights.total_physical_bytes(),
        graph_bytes,
        gemm_workspace_bytes,
        total_device_bytes,
        device_allocation_count: physical_allocations.checked_add(graph_allocations).ok_or(
            LlamaForwardError::ArithmeticOverflow {
                resource: LlamaForwardResource::UploadedWeights,
            },
        )?,
        pinned_host_bytes,
        pinned_host_allocation_count: 1,
    })
}

pub(super) fn prepare_gemms(
    context: &CudaContext,
    weights: &CudaUploadedWeights,
    plan: &LlamaExecutionPlan,
    workspace_cap: u64,
    reduction_profile: LlamaReductionProfile,
    policies: LlamaGemmReductionPolicies,
    projection_bias_mode: LlamaProjectionBiasMode,
    merged_gate_up: bool,
    output_projection_mode: LlamaOutputProjectionMode,
    mlp_projection_mode: LlamaMlpProjectionMode,
    lm_head_mode: LlamaLmHeadMode,
    owned_hf_eager_bf16: bool,
    anchors: Option<&GemmPlans>,
) -> LlamaForwardResult<GemmPlans> {
    #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
    let _ = (output_projection_mode, mlp_projection_mode, lm_head_mode);
    let sequence = to_u64(plan.sequence_length(), LlamaForwardResource::HiddenCurrent)?;
    let dimensions = plan.dimensions();
    let hidden = to_u64(
        dimensions.hidden_size(),
        LlamaForwardResource::HiddenCurrent,
    )?;
    let key_value = to_u64(dimensions.key_value_width(), LlamaForwardResource::KeyRaw)?;
    let query_width = to_u64(
        dimensions.query_width(),
        LlamaForwardResource::HiddenCurrent,
    )?;
    let intermediate = to_u64(
        dimensions.intermediate_size(),
        LlamaForwardResource::GateRaw,
    )?;
    let vocabulary = to_u64(dimensions.vocabulary_size(), LlamaForwardResource::Logits)?;

    // In the fixed profile these five plans validate both reduction widths
    // used by the graph: `hidden` (also the RMSNorm axis) and `intermediate`.
    // Unsupported fixed37 shapes therefore fail here during cold preparation.
    let prepare = |m,
                   n,
                   k,
                   policy,
                   site,
                   anchor: Option<&PreparedLlamaGemm>|
     -> LlamaForwardResult<PreparedLlamaGemm> {
        let config = CudaGemmConfig::new(m, n, k, workspace_cap)
            .map_err(|source| LlamaForwardError::cuda(site, source))?;
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        if owned_hf_eager_bf16 {
            return context.prepare_owned_hf_gemm(config)
                .map(PreparedLlamaGemm::ClassicRequestRows)
                .map_err(|source| LlamaForwardError::cuda(site, source));
        }
        let config = match reduction_profile {
            LlamaReductionProfile::CanonicalV1 => config
                .with_reduction_policy(policy)
                .with_bit_equivalent_selection(policies.bit_equivalent_selection()),
            LlamaReductionProfile::FixedContiguous37BalancedV1 => config,
        };
        match reduction_profile {
            LlamaReductionProfile::CanonicalV1 => match anchor {
                None => match policies.heuristic_anchor_rows() {
                    Some(rows) if m > rows => {
                        // Select at the anchor row count, then bind this
                        // shape to that algorithm without a heuristic fallback.
                        let selection = CudaGemmConfig::new(rows, n, k, workspace_cap)
                            .map_err(|source| LlamaForwardError::cuda(site, source))?
                            .with_reduction_policy(policy)
                            .with_bit_equivalent_selection(
                                policies.bit_equivalent_selection(),
                            );
                        let selection = context
                            .prepare_gemm(selection)
                            .map_err(|source| LlamaForwardError::cuda(site, source))?;
                        let prepared = context.prepare_gemm_anchored(config, &selection);
                        let closed = selection.close();
                        prepared
                            .and_then(|prepared| closed.map(|()| prepared))
                            .map(PreparedLlamaGemm::Canonical)
                    }
                    _ => context.prepare_gemm(config).map(PreparedLlamaGemm::Canonical),
                },
                Some(PreparedLlamaGemm::Canonical(anchor)) => context
                    .prepare_gemm_anchored(config, anchor)
                    .map(PreparedLlamaGemm::Canonical),
                #[cfg(feature = "cuda-cublas-gemm-probe")]
                Some(PreparedLlamaGemm::ClassicDiagnostic(_)) | Some(PreparedLlamaGemm::ClassicRequestRows(_)) => {
                    return Err(LlamaForwardError::InvalidConfiguration {
                        field: "gemm_anchor", reason: "classic diagnostic anchors require explicit diagnostic selection",
                    });
                }
                Some(PreparedLlamaGemm::Fixed37(_)) => {
                    return Err(LlamaForwardError::InvalidConfiguration {
                        field: "gemm_anchor",
                        reason: "canonical shape variants require canonical maximum-shape GEMM anchors",
                    });
                }
            },
            LlamaReductionProfile::FixedContiguous37BalancedV1 => context
                .prepare_fixed37_gemm(config)
                .map(PreparedLlamaGemm::Fixed37),
        }
        .map_err(|source| LlamaForwardError::cuda(site, source))
    };
    let hidden_plan = prepare(
        sequence,
        hidden,
        hidden,
        policies.hidden(),
        ExecutionSite::layer(0, LlamaOp::QueryProjection),
        anchors.map(|value| &value.hidden),
    )?;
    let key_value_plan = prepare(
        sequence,
        key_value,
        hidden,
        policies.key_value(),
        ExecutionSite::layer(0, LlamaOp::KeyProjection),
        anchors.map(|value| &value.key_value),
    )?;
    let intermediate_plan = prepare(
        sequence,
        intermediate,
        hidden,
        policies.intermediate(),
        ExecutionSite::layer(0, LlamaOp::GateProjection),
        anchors.map(|value| &value.intermediate),
    )?;
    let down_plan = prepare(
        sequence,
        hidden,
        intermediate,
        policies.down(),
        ExecutionSite::layer(0, LlamaOp::DownProjection),
        anchors.map(|value| &value.down),
    )?;
    let lm_head_plan = prepare(
        sequence,
        vocabulary,
        hidden,
        policies.lm_head(),
        ExecutionSite::global(LlamaOp::LmHead),
        anchors.map(|value| &value.lm_head),
    )?;

    let merged_qkv_plan = if projection_bias_mode.merges_qkv() {
        // Every layer has all three biases (Qwen2), none of them with a
        // per-head query/key norm (Qwen3: the head-norm split), or none at all
        // (Llama 3: the split adds a negative-zero bias).
        if plan.layers().iter().any(|layer| {
            let biases = [layer.query_bias(), layer.key_bias(), layer.value_bias()];
            let all = biases.iter().all(Option::is_some);
            let none = biases.iter().all(Option::is_none);
            !(all && layer.query_key_norm().is_none() || none)
        }) {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "projection_bias_mode",
                reason: "merged QKV projection requires all three Q/K/V biases or none of them in every decoder layer",
            });
        }
        let anchor = match anchors {
            None => None,
            Some(value) => Some(value.merged_qkv.as_ref().ok_or(
                LlamaForwardError::InvalidConfiguration {
                    field: "gemm_anchor",
                    reason: "merged QKV shape variants require a merged maximum-shape anchor",
                },
            )?),
        };
        Some(prepare(
            sequence,
            query_width + 2 * key_value,
            hidden,
            policies.hidden(),
            ExecutionSite::layer(0, LlamaOp::QueryProjection),
            anchor,
        )?)
    } else {
        None
    };

    #[cfg(feature="cuda-cublas-gemm-probe")]
    let hf_separate_query=if owned_hf_eager_bf16 && query_width!=hidden {
      if sequence>8192||hidden!=2560||query_width!=4096||key_value!=1024||!projection_bias_mode.merges_qkv()||plan.layers().iter().any(|l|l.query_bias().is_some()||l.key_bias().is_some()||l.value_bias().is_some()) {
       return Err(LlamaForwardError::InvalidConfiguration{field:"hf_separate_qkv",reason:"private no-bias H2560/Q4096/KV1024 M<=8192 required"});
      }
      Some(prepare(sequence,query_width,hidden,policies.hidden(),ExecutionSite::layer(0,LlamaOp::QueryProjection),None)?)
    }else{None};
    let output_projection_plan = if query_width == hidden {
        None
    } else {
        let anchor = match anchors {
            None => None,
            Some(value) => Some(value.output_projection.as_ref().ok_or(
                LlamaForwardError::InvalidConfiguration {
                    field: "gemm_anchor",
                    reason: "output projection shape variants require a maximum-shape anchor",
                },
            )?),
        };
        Some(prepare(
            sequence,
            hidden,
            query_width,
            policies.hidden(),
            ExecutionSite::layer(0, LlamaOp::OutputProjection),
            anchor,
        )?)
    };

    let merged_gate_up_plan = if merged_gate_up {
        let anchor = match anchors {
            None => None,
            Some(value) => Some(value.merged_gate_up.as_ref().ok_or(
                LlamaForwardError::InvalidConfiguration {
                    field: "gemm_anchor",
                    reason: "merged gate|up shape variants require a merged maximum-shape anchor",
                },
            )?),
        };
        Some(prepare(
            sequence,
            2 * intermediate,
            hidden,
            policies.intermediate(),
            ExecutionSite::layer(0, LlamaOp::GateProjection),
            anchor,
        )?)
    } else {
        None
    };

    #[cfg(feature="cuda-cublas-gemm-probe")]
    let hf_request_bias_epilogue=if owned_hf_eager_bf16 && plan.layers().iter().any(|l|l.query_bias().is_some()) {
      if sequence>8192 || hidden!=2048 || query_width!=hidden || key_value!=256 || !plan.layers().iter().all(|l|l.query_bias().is_some()&&l.key_bias().is_some()&&l.value_bias().is_some()) {
        return Err(LlamaForwardError::InvalidConfiguration{field:"hf_request_bias",reason:"private biased H2048/KV256, M<=8192 with all QKV biases required"});
      }
      let first=plan.layers().first().expect("all-biased nonempty plan");let site=ExecutionSite::layer(0,LlamaOp::QueryProjection);
      let mut query=Vec::with_capacity(sequence as usize);let mut key_value_plans=Vec::with_capacity(sequence as usize);
      for rows in 1..=sequence {
        let q=CudaGemmConfig::new(rows,hidden,hidden,1048576).map_err(|e|LlamaForwardError::cuda(site,e))?.with_reduction_policy(CudaGemmReductionPolicy::HfCompatibleBiasSplitKV1);
        let kv=CudaGemmConfig::new(rows,key_value,hidden,1048576).map_err(|e|LlamaForwardError::cuda(site,e))?.with_reduction_policy(CudaGemmReductionPolicy::HfCompatibleBiasSplitKV1);
        query.push(context.prepare_hf_compatible_bias_epilogue_probe(q,weight_span(weights,first.query_bias().expect("validated bias"),site)?).map_err(|e|LlamaForwardError::cuda(site,e))?);
        key_value_plans.push(context.prepare_hf_compatible_bias_epilogue_probe(kv,weight_span(weights,first.key_bias().expect("validated bias"),site)?).map_err(|e|LlamaForwardError::cuda(site,e))?);
      }
      eprintln!("private-hf-request-bias: cold all M=1..{sequence}, Lt cap1048576, first heuristic, owned plans");
      {
        let mut batch_query=(0..=32).map(|_|None).collect::<Vec<_>>();
        let mut batch_key_value=(0..=32).map(|_|None).collect::<Vec<_>>();
        for rows in 2..=sequence.min(32) {
          for (n,bias_id,plans) in [(hidden,first.query_bias().expect("bias"),&mut batch_query),(key_value,first.key_bias().expect("bias"),&mut batch_key_value)] {
            let config=CudaGemmConfig::new(rows,n,hidden,1048576).map_err(|e|LlamaForwardError::cuda(site,e))?.with_reduction_policy(CudaGemmReductionPolicy::HfCompatibleBiasSplitKV1);
            match context.prepare_hf_bias_singleton_batch(config,weight_span(weights,bias_id,site)?) {
              Ok(plan)=>plans[rows as usize]=Some(plan),
              Err(e) if e.kind()==riley_cuda::CudaErrorKind::NotSupported=>{},
              Err(e)=>return Err(LlamaForwardError::cuda(site,e)),
            }
          }
        }
        eprintln!("private-hf-singleton-bias: Q={} KV={} checked batch extents",batch_query.iter().flatten().count(),batch_key_value.iter().flatten().count());
        Some(HfRequestBiasEpilogueGemmPlans{query,key_value:key_value_plans,batch_query,batch_key_value})
      }
    } else {None};

    let projection_bias_epilogue = if projection_bias_mode.requires_qkv_bias_epilogue() {
        let first_layer = plan
            .layers()
            .first()
            .ok_or(LlamaForwardError::InvalidConfiguration {
                field: "projection_bias_mode",
                reason: "cuBLASLt bias epilogue requires at least one decoder layer",
            })?;
        if plan.layers().iter().any(|layer| {
            layer.query_bias().is_none()
                || layer.key_bias().is_none()
                || layer.value_bias().is_none()
        }) {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "projection_bias_mode",
                reason: "cuBLASLt bias epilogue requires Q/K/V biases in every decoder layer",
            });
        }
        let query_site = ExecutionSite::layer(0, LlamaOp::QueryProjection);
        let key_site = ExecutionSite::layer(0, LlamaOp::KeyProjection);
        let query_bias_id =
            first_layer
                .query_bias()
                .ok_or(LlamaForwardError::InvalidConfiguration {
                    field: "projection_bias_mode",
                    reason: "cuBLASLt bias epilogue requires a layer-zero query bias",
                })?;
        let key_bias_id =
            first_layer
                .key_bias()
                .ok_or(LlamaForwardError::InvalidConfiguration {
                    field: "projection_bias_mode",
                    reason: "cuBLASLt bias epilogue requires a layer-zero key bias",
                })?;
        let query_bias = weight_span(weights, query_bias_id, query_site)?;
        let key_bias = weight_span(weights, key_bias_id, key_site)?;
        let query_config = CudaGemmConfig::new(sequence, hidden, hidden, workspace_cap)
            .map_err(|source| LlamaForwardError::cuda(query_site, source))?;
        let key_value_config = CudaGemmConfig::new(sequence, key_value, hidden, workspace_cap)
            .map_err(|source| LlamaForwardError::cuda(key_site, source))?;
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        let hf_compatible_probe = projection_bias_mode.is_hf_compatible_bias_epilogue_probe();
        #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
        let hf_compatible_probe = false;
        let query = if hf_compatible_probe {
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            {
                context.prepare_hf_compatible_bias_epilogue_probe(
                    query_config.with_reduction_policy(
                        CudaGemmReductionPolicy::AllowInPlaceAndOutputTypeSplitKV1,
                    ),
                    query_bias,
                )
            }
            #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
            {
                unreachable!("feature-gated HF-compatible probe cannot be selected")
            }
        } else {
            context.prepare_bias_epilogue_gemm(query_config, query_bias)
        }
        .map_err(|source| LlamaForwardError::cuda(query_site, source))?;
        let key_value = if hf_compatible_probe {
            #[cfg(feature = "cuda-cublas-gemm-probe")]
            {
                context.prepare_hf_compatible_bias_epilogue_probe(
                    key_value_config.with_reduction_policy(
                        CudaGemmReductionPolicy::AllowInPlaceAndOutputTypeSplitKV1,
                    ),
                    key_bias,
                )
            }
            #[cfg(not(feature = "cuda-cublas-gemm-probe"))]
            {
                unreachable!("feature-gated HF-compatible probe cannot be selected")
            }
        } else {
            context.prepare_bias_epilogue_gemm(key_value_config, key_bias)
        }
        .map_err(|source| LlamaForwardError::cuda(key_site, source))?;
        Some(ProjectionBiasEpilogueGemmPlans { query, key_value })
    } else {
        None
    };

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    let output_projection_direct_cublas = if output_projection_mode
        .is_hf_eager_qwen_p2051_direct_cublas_probe()
        || output_projection_mode.is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe()
    {
        const P2051_SEQUENCE: u64 = 2_051;
        const P2048_CACHE_ON_SEQUENCE: u64 = 2_048;
        const QWEN_HIDDEN: u64 = 2_048;
        const QWEN_KEY_VALUE: u64 = 256;
        const QWEN_INTERMEDIATE: u64 = 11_008;
        const QWEN_LAYER_COUNT: usize = 36;
        let expected_sequence =
            if output_projection_mode.is_hf_eager_qwen_p2051_direct_cublas_probe() {
                P2051_SEQUENCE
            } else {
                P2048_CACHE_ON_SEQUENCE
            };
        if anchors.is_some()
            || sequence != expected_sequence
            || hidden != QWEN_HIDDEN
            || key_value != QWEN_KEY_VALUE
            || intermediate != QWEN_INTERMEDIATE
            || plan.layers().len() != QWEN_LAYER_COUNT
            || plan
                .layers()
                .iter()
                .any(|layer| layer.output_bias().is_some())
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "output_projection_mode",
                reason: "the direct-cuBLAS O-projection probe requires source-bound Qwen P2051 cache-free or P2048 cache-on geometry, no output biases, and no batch-shape variants",
            });
        }
        let output_site = ExecutionSite::layer(0, LlamaOp::OutputProjection);
        let output_config = CudaGemmConfig::new(sequence, hidden, hidden, workspace_cap)
            .map_err(|source| LlamaForwardError::cuda(output_site, source))?;
        Some(
            context
                .prepare_cublas_gemm_probe(output_config)
                .map_err(|source| LlamaForwardError::cuda(output_site, source))?,
        )
    } else {
        None
    };

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    let mlp_projection_direct_cublas = if mlp_projection_mode
        .is_hf_eager_qwen_p2051_direct_cublas_probe()
        || mlp_projection_mode.is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe()
    {
        const P2051_SEQUENCE: u64 = 2_051;
        const P2048_CACHE_ON_SEQUENCE: u64 = 2_048;
        const QWEN_HIDDEN: u64 = 2_048;
        const QWEN_KEY_VALUE: u64 = 256;
        const QWEN_INTERMEDIATE: u64 = 11_008;
        const QWEN_LAYER_COUNT: usize = 36;
        let p2051 = mlp_projection_mode.is_hf_eager_qwen_p2051_direct_cublas_probe();
        let expected_sequence = if p2051 {
            P2051_SEQUENCE
        } else {
            P2048_CACHE_ON_SEQUENCE
        };
        let paired_output = if p2051 {
            output_projection_mode.is_hf_eager_qwen_p2051_direct_cublas_probe()
        } else {
            output_projection_mode.is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe()
        };
        if anchors.is_some()
            || !paired_output
            || sequence != expected_sequence
            || hidden != QWEN_HIDDEN
            || key_value != QWEN_KEY_VALUE
            || intermediate != QWEN_INTERMEDIATE
            || plan.layers().len() != QWEN_LAYER_COUNT
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "mlp_projection_mode",
                reason: "the direct-cuBLAS MLP projection probe requires the matching source-bound Qwen P2051/P2048 O-projection geometry and no batch-shape variants",
            });
        }
        let gate_site = ExecutionSite::layer(0, LlamaOp::GateProjection);
        let down_site = ExecutionSite::layer(0, LlamaOp::DownProjection);
        let intermediate_config =
            CudaGemmConfig::new(sequence, intermediate, hidden, workspace_cap)
                .map_err(|source| LlamaForwardError::cuda(gate_site, source))?;
        let down_config = CudaGemmConfig::new(sequence, hidden, intermediate, workspace_cap)
            .map_err(|source| LlamaForwardError::cuda(down_site, source))?;
        Some(MlpProjectionDirectCublasGemmPlans {
            intermediate: context
                .prepare_cublas_gemm_probe(intermediate_config)
                .map_err(|source| LlamaForwardError::cuda(gate_site, source))?,
            down: context
                .prepare_cublas_gemm_probe(down_config)
                .map_err(|source| LlamaForwardError::cuda(down_site, source))?,
        })
    } else {
        None
    };

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    let lm_head_last_token_direct_cublas = if lm_head_mode
        .is_hf_eager_qwen_p2051_last_token_direct_cublas_probe()
        || lm_head_mode.is_hf_eager_qwen_p2048_cache_on_last_token_direct_cublas_probe()
    {
        const P2051_SEQUENCE: u64 = 2_051;
        const P2048_CACHE_ON_SEQUENCE: u64 = 2_048;
        const QWEN_HIDDEN: u64 = 2_048;
        const QWEN_KEY_VALUE: u64 = 256;
        const QWEN_INTERMEDIATE: u64 = 11_008;
        const QWEN_VOCABULARY: u64 = 151_936;
        const QWEN_LAYER_COUNT: usize = 36;
        let p2051 = lm_head_mode.is_hf_eager_qwen_p2051_last_token_direct_cublas_probe();
        let expected_sequence = if p2051 {
            P2051_SEQUENCE
        } else {
            P2048_CACHE_ON_SEQUENCE
        };
        let paired_mlp = if p2051 {
            mlp_projection_mode.is_hf_eager_qwen_p2051_direct_cublas_probe()
        } else {
            mlp_projection_mode.is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe()
        };
        let paired_output = if p2051 {
            output_projection_mode.is_hf_eager_qwen_p2051_direct_cublas_probe()
        } else {
            output_projection_mode.is_hf_eager_qwen_p2048_cache_on_direct_cublas_probe()
        };
        if anchors.is_some()
            || !paired_mlp
            || !paired_output
            || sequence != expected_sequence
            || hidden != QWEN_HIDDEN
            || key_value != QWEN_KEY_VALUE
            || intermediate != QWEN_INTERMEDIATE
            || vocabulary != QWEN_VOCABULARY
            || plan.layers().len() != QWEN_LAYER_COUNT
        {
            return Err(LlamaForwardError::InvalidConfiguration {
                field: "lm_head_mode",
                reason: "the last-token direct-cuBLAS LM-head probe requires source-bound Qwen P2051 cache-free or P2048 cache-on geometry and no batch-shape variants",
            });
        }
        let lm_head_site = ExecutionSite::global(LlamaOp::LmHead);
        let lm_head_config = CudaGemmConfig::new(1, vocabulary, hidden, workspace_cap)
            .map_err(|source| LlamaForwardError::cuda(lm_head_site, source))?;
        Some(
            context
                .prepare_cublas_gemm_probe(lm_head_config)
                .map_err(|source| LlamaForwardError::cuda(lm_head_site, source))?,
        )
    } else {
        None
    };

    Ok(GemmPlans {
        hidden: hidden_plan,
        key_value: key_value_plan,
        intermediate: intermediate_plan,
        down: down_plan,
        lm_head: lm_head_plan,
        merged_qkv: merged_qkv_plan,
        #[cfg(feature="cuda-cublas-gemm-probe")]
        hf_separate_query,
        merged_gate_up: merged_gate_up_plan,
        output_projection: output_projection_plan,
        projection_bias_epilogue,
        #[cfg(feature="cuda-cublas-gemm-probe")]
        hf_request_bias_epilogue,
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        output_projection_direct_cublas,
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        mlp_projection_direct_cublas,
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        lm_head_last_token_direct_cublas,
    })
}

fn resolve_gemm_reduction_policies(
    model: &LoadedModel,
    profile: LlamaReductionProfile,
    first_heuristic: bool,
) -> LlamaGemmReductionPolicies {
    match profile {
        LlamaReductionProfile::CanonicalV1 if first_heuristic => {
            LlamaGemmReductionPolicies::first_heuristic()
        }
        LlamaReductionProfile::CanonicalV1 => {
            canonical_gemm_reduction_policies(model.config(), model.spec())
        }
        LlamaReductionProfile::FixedContiguous37BalancedV1 => LlamaGemmReductionPolicies::strict(),
    }
}

fn allocate_buffers(
    context: &CudaContext,
    plan: &LlamaExecutionPlan,
    attention_workspace_bytes: u64,
    gemm_workspace_bytes: u64,
    merged_gate_up: bool,
    paged_batch_only: bool,
) -> LlamaForwardResult<ForwardBuffers> {
    let spec = plan.workspace_spec();
    let allocate = |bytes, site| {
        context
            .allocate_device_buffer(bytes)
            .map_err(|source| LlamaForwardError::cuda(site, source))
    };
    let hidden_site = ExecutionSite::layer(0, LlamaOp::InputNorm);
    let kv_site = ExecutionSite::layer(0, LlamaOp::KeyProjection);
    let intermediate_site = ExecutionSite::layer(0, LlamaOp::GateProjection);
    Ok(ForwardBuffers {
        token_ids: allocate(
            spec.token_ids_bytes(),
            ExecutionSite::global(LlamaOp::Embedding),
        )?,
        hidden_current: allocate(spec.hidden_buffer_bytes(), hidden_site)?,
        hidden_norm: allocate(spec.hidden_buffer_bytes(), hidden_site)?,
        hidden_projection: allocate(spec.hidden_buffer_bytes(), hidden_site)?,
        // The rotated query and the attention output are query-width.
        hidden_rotary: allocate(
            spec.hidden_buffer_bytes().max(spec.query_buffer_bytes()),
            hidden_site,
        )?,
        hidden_context: allocate(
            spec.hidden_buffer_bytes().max(spec.query_buffer_bytes()),
            hidden_site,
        )?,
        key_raw: allocate(spec.key_value_buffer_bytes(), kv_site)?,
        value_raw: allocate(spec.key_value_buffer_bytes(), kv_site)?,
        key_rotary: allocate(spec.key_value_buffer_bytes(), kv_site)?,
        // A merged gate|up GEMM writes both projections of a row side by side.
        // It is also the scratch of the merged Q|K|V GEMM, which is wider
        // than the intermediate size for a few small models.
        gate_raw: allocate(
            if merged_gate_up {
                spec.intermediate_buffer_bytes().checked_mul(2).ok_or(
                    LlamaForwardError::InvalidConfiguration {
                        field: "merged_gate_up",
                        reason: "merged gate|up output size overflows",
                    },
                )?
            } else {
                spec.intermediate_buffer_bytes()
            }
            .max(
                spec.key_value_buffer_bytes()
                    .checked_mul(2)
                    .and_then(|bytes| bytes.checked_add(spec.query_buffer_bytes()))
                    .ok_or(LlamaForwardError::InvalidConfiguration {
                        field: "merged_qkv",
                        reason: "merged Q|K|V output size overflows",
                    })?,
            ),
            intermediate_site,
        )?,
        up_raw: allocate(spec.intermediate_buffer_bytes(), intermediate_site)?,
        gate_activated: allocate(spec.intermediate_buffer_bytes(), intermediate_site)?,
        gated_product: allocate(spec.intermediate_buffer_bytes(), intermediate_site)?,
        attention_workspace: if attention_workspace_bytes == 0 {
            None
        } else {
            Some(allocate(
                attention_workspace_bytes,
                ExecutionSite::layer(0, LlamaOp::PrefillAttention),
            )?)
        },
        rope_cos: allocate(
            spec.rope_cos_bytes(),
            ExecutionSite::layer(0, LlamaOp::QueryRope),
        )?,
        rope_sin: allocate(
            spec.rope_sin_bytes(),
            ExecutionSite::layer(0, LlamaOp::QueryRope),
        )?,
        logits: allocate(if paged_batch_only { 0 } else { spec.logits_bytes() }, ExecutionSite::global(LlamaOp::LmHead))?,
        embedding_error_scratch: allocate(
            spec.embedding_error_scratch_bytes(),
            ExecutionSite::global(LlamaOp::Embedding),
        )?,
        gemm_workspace: if gemm_workspace_bytes == 0 {
            None
        } else {
            Some(allocate(
                gemm_workspace_bytes,
                ExecutionSite::layer(0, LlamaOp::QueryProjection),
            )?)
        },
    })
}

fn allocate_host_bytes(
    byte_len: u64,
    resource: LlamaForwardResource,
) -> LlamaForwardResult<Box<[u8]>> {
    let length = usize::try_from(byte_len)
        .map_err(|_| LlamaForwardError::ArithmeticOverflow { resource })?;
    let mut bytes = Vec::new();
    bytes
        .try_reserve_exact(length)
        .map_err(|_| LlamaForwardError::HostAllocation {
            resource,
            requested_bytes: byte_len,
        })?;
    bytes.resize(length, 0);
    Ok(bytes.into_boxed_slice())
}

#[allow(clippy::cast_precision_loss)]
fn build_rope_angles(plan: &LlamaExecutionPlan) -> LlamaForwardResult<Box<[u8]>> {
    let dimensions = plan.dimensions();
    let head_dimension = dimensions.head_dimension();
    let half = head_dimension / 2;
    let mut angles = allocate_host_bytes(
        plan.workspace_spec().rope_cos_bytes(),
        LlamaForwardResource::RopeCos,
    )?;
    let frequencies = plan.rope_frequencies();
    for position in 0..plan.sequence_length() {
        for pair in 0..half {
            let inverse_frequency = frequencies.inverse_frequency(pair, head_dimension);
            let angle = position as f32 * inverse_frequency;
            let element = position
                .checked_mul(half)
                .and_then(|value| value.checked_add(pair))
                .and_then(|value| value.checked_mul(4))
                .ok_or(LlamaForwardError::ArithmeticOverflow {
                    resource: LlamaForwardResource::RopeCos,
                })?;
            angles[element..element + 4].copy_from_slice(&angle.to_ne_bytes());
        }
    }
    Ok(angles)
}

type RopeTableBytes = (Box<[u8]>, Box<[u8]>);

#[allow(clippy::cast_precision_loss)]
fn build_cpu_rope_tables(plan: &LlamaExecutionPlan) -> LlamaForwardResult<RopeTableBytes> {
    let dimensions = plan.dimensions();
    let head_dimension = dimensions.head_dimension();
    let half = head_dimension / 2;
    let mut cos = allocate_host_bytes(
        plan.workspace_spec().rope_cos_bytes(),
        LlamaForwardResource::RopeCos,
    )?;
    let mut sin = allocate_host_bytes(
        plan.workspace_spec().rope_sin_bytes(),
        LlamaForwardResource::RopeSin,
    )?;
    let frequencies = plan.rope_frequencies();
    for position in 0..plan.sequence_length() {
        for pair in 0..half {
            let inverse_frequency = frequencies.inverse_frequency(pair, head_dimension);
            let angle = position as f32 * inverse_frequency;
            let (sine, cosine) = angle.sin_cos();
            let element = position
                .checked_mul(half)
                .and_then(|value| value.checked_add(pair))
                .and_then(|value| value.checked_mul(4))
                .ok_or(LlamaForwardError::ArithmeticOverflow {
                    resource: LlamaForwardResource::RopeCos,
                })?;
            cos[element..element + 4].copy_from_slice(&cosine.to_ne_bytes());
            sin[element..element + 4].copy_from_slice(&sine.to_ne_bytes());
        }
    }
    Ok((cos, sin))
}

fn f32_to_bf16_bits(value: f32) -> u16 {
    // CUDA's `cvt.rn.bf16.f32` uses round-to-nearest-even. The tables are
    // finite by construction, so this bit-level conversion has no NaN payload
    // contract to preserve.
    let bits = value.to_bits();
    let round = 0x7fff_u32 + ((bits >> 16) & 1);
    (bits.wrapping_add(round) >> 16) as u16
}

fn hf_eager_bf16_rope_table_view(
    plan: &LlamaExecutionPlan,
    values: &[u8],
    resource: LlamaForwardResource,
) -> LlamaForwardResult<Box<[u8]>> {
    if values.len() % mem::size_of::<f32>() != 0 {
        return Err(LlamaForwardError::InvalidConfiguration {
            field: "rope_table",
            reason: "F32 table storage is not aligned to elements",
        });
    }
    let sequence = plan.sequence_length();
    let head_dimension = plan.dimensions().head_dimension();
    let half = head_dimension / 2;
    let table_elements = sequence
        .checked_mul(half)
        .ok_or(LlamaForwardError::ArithmeticOverflow { resource })?;
    if values.len() / mem::size_of::<f32>() != table_elements {
        return Err(LlamaForwardError::InvalidConfiguration {
            field: "rope_table",
            reason: "F32 table storage differs from the prepared RoPE geometry",
        });
    }
    let output_elements = sequence
        .checked_mul(head_dimension)
        .ok_or(LlamaForwardError::ArithmeticOverflow { resource })?;
    let output_bytes = u64::try_from(output_elements)
        .map_err(|_| LlamaForwardError::ArithmeticOverflow { resource })?
        .checked_mul(BF16_BYTES)
        .ok_or(LlamaForwardError::ArithmeticOverflow { resource })?;
    let mut output = allocate_host_bytes(output_bytes, resource)?;
    for position in 0..sequence {
        for pair in 0..half {
            let source_index = position
                .checked_mul(half)
                .and_then(|value| value.checked_add(pair))
                .ok_or(LlamaForwardError::ArithmeticOverflow { resource })?;
            let source_offset = source_index
                .checked_mul(mem::size_of::<f32>())
                .ok_or(LlamaForwardError::ArithmeticOverflow { resource })?;
            let value = f32::from_ne_bytes(
                values[source_offset..source_offset + mem::size_of::<f32>()]
                    .try_into()
                    .expect("validated F32 table source range"),
            );
            let destination_index = position
                .checked_mul(head_dimension)
                .and_then(|value| value.checked_add(pair))
                .ok_or(LlamaForwardError::ArithmeticOverflow { resource })?;
            for index in [destination_index, destination_index + half] {
                let destination_offset = index
                    .checked_mul(BF16_BYTES as usize)
                    .ok_or(LlamaForwardError::ArithmeticOverflow { resource })?;
                output[destination_offset..destination_offset + BF16_BYTES as usize]
                    .copy_from_slice(&f32_to_bf16_bits(value).to_le_bytes());
            }
        }
    }
    Ok(output)
}

fn to_u64(value: usize, resource: LlamaForwardResource) -> LlamaForwardResult<u64> {
    u64::try_from(value).map_err(|_| LlamaForwardError::ArithmeticOverflow { resource })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn last_token_layer_trace_normalizes_indices_and_rejects_out_of_range_layers() {
        assert_eq!(
            normalize_last_token_layer_indices(&[5, 0, 5, 3, 0, 1], 6)
                .expect("all requested layers are in range"),
            vec![0, 1, 3, 5]
        );
        assert_eq!(
            normalize_last_token_layer_indices(&[], 0)
                .expect("empty last-token layer selection is valid"),
            Vec::<usize>::new()
        );
        assert!(matches!(
            normalize_last_token_layer_indices(&[0, 6, 6], 6),
            Err(LlamaForwardError::LastTokenTraceLayerUnavailable {
                layer_index: 6,
                actual_layers: 6,
            })
        ));
    }

    #[test]
    fn projection_bias_mode_is_strict_by_default_and_fused_is_canonical_only() {
        let defaults = PreparedLlamaForwardConfig::default();
        assert_eq!(
            defaults.projection_bias_mode(),
            LlamaProjectionBiasMode::StrictStagedV1
        );
        let fused = defaults.with_cublaslt_bias_epilogue_projection_bias();
        assert_eq!(
            fused.projection_bias_mode(),
            LlamaProjectionBiasMode::CublasLtBiasEpilogueExperimentalV1
        );
        fused
            .validate()
            .expect("fused Q/K/V bias epilogue accepts canonical reductions");
        assert!(matches!(
            fused.with_fixed37_reductions().validate(),
            Err(LlamaForwardError::InvalidConfiguration {
                field: "projection_bias_mode",
                ..
            })
        ));
        assert_eq!(
            fused
                .with_strict_staged_projection_bias()
                .projection_bias_mode(),
            LlamaProjectionBiasMode::StrictStagedV1
        );
        #[cfg(feature = "cuda-cublas-gemm-probe")]
        {
            let probe = defaults.with_hf_compatible_bias_epilogue_projection_probe();
            assert_eq!(
                probe.projection_bias_mode(),
                LlamaProjectionBiasMode::HfCompatibleBiasEpilogueProbeV1
            );
            assert_eq!(
                probe.projection_bias_mode().id(),
                "hf-compatible-bias-epilogue-probe-v1"
            );
            probe
                .validate()
                .expect("HF-compatible probe accepts canonical reductions");
            assert!(matches!(
                probe.with_fixed37_reductions().validate(),
                Err(LlamaForwardError::InvalidConfiguration {
                    field: "projection_bias_mode",
                    ..
                })
            ));

            let attention_probe = defaults.with_hugging_face_eager_qwen_p2051_probe_attention();
            assert_eq!(
                attention_probe.attention_preference(),
                AttentionPreference::HuggingFaceEagerQwenP2051Probe
            );

            let output_probe =
                defaults.with_hf_eager_qwen_p2051_direct_cublas_output_projection_probe();
            assert_eq!(
                output_probe.output_projection_mode.id(),
                "hf-eager-qwen-p2051-direct-cublas-probe-v1"
            );
            assert!(matches!(
                output_probe.validate(),
                Err(LlamaForwardError::InvalidConfiguration {
                    field: "output_projection_mode",
                    ..
                })
            ));
            let paired_probe = defaults
                .with_hf_compatible_bias_epilogue_projection_probe()
                .with_hugging_face_eager_qwen_p2051_probe_attention()
                .with_hf_eager_qwen_p2051_direct_cublas_output_projection_probe();
            paired_probe
                .validate()
                .expect("paired P2051 direct-cuBLAS output probe is canonical-only");
            assert!(matches!(
                paired_probe.with_reference_attention().validate(),
                Err(LlamaForwardError::InvalidConfiguration {
                    field: "output_projection_mode",
                    ..
                })
            ));

            let mlp_probe = defaults.with_hf_eager_qwen_p2051_direct_cublas_mlp_projection_probe();
            assert_eq!(
                mlp_probe.mlp_projection_mode().id(),
                "hf-eager-qwen-p2051-direct-cublas-probe-v1"
            );
            assert!(matches!(
                mlp_probe.validate(),
                Err(LlamaForwardError::InvalidConfiguration {
                    field: "mlp_projection_mode",
                    ..
                })
            ));
            let paired_mlp_probe =
                paired_probe.with_hf_eager_qwen_p2051_direct_cublas_mlp_projection_probe();
            paired_mlp_probe
                .validate()
                .expect("paired P2051 direct-cuBLAS MLP probe is canonical-only");
            // The Q/K/V canonical-reduction guard rejects this combination
            // before the downstream O-projection/MLP guards are reached.
            assert!(matches!(
                paired_mlp_probe.with_fixed37_reductions().validate(),
                Err(LlamaForwardError::InvalidConfiguration {
                    field: "projection_bias_mode",
                    ..
                })
            ));

            let rope_table_probe =
                paired_mlp_probe.with_hugging_face_cuda_qwen_p2051_rope_table_probe();
            rope_table_probe
                .validate()
                .expect("paired Qwen GPU RoPE-table probe is canonical-only");
            assert!(matches!(
                defaults
                    .with_hugging_face_cuda_qwen_p2051_rope_table_probe()
                    .validate(),
                Err(LlamaForwardError::InvalidConfiguration {
                    field: "rope_table_selection",
                    ..
                })
            ));

            let rms_norm_probe =
                paired_mlp_probe.with_hugging_face_cuda_qwen_p2051_rms_norm_probe();
            rms_norm_probe
                .validate()
                .expect("paired Qwen P2051 RMSNorm probe is canonical-only");
            assert!(matches!(
                defaults
                    .with_hugging_face_cuda_qwen_p2051_rms_norm_probe()
                    .validate(),
                Err(LlamaForwardError::InvalidConfiguration {
                    field: "rms_norm_selection",
                    ..
                })
            ));

            let lm_head_probe = rope_table_probe
                .with_hugging_face_cuda_qwen_p2051_rms_norm_probe()
                .with_hf_eager_qwen_p2051_last_token_direct_cublas_lm_head_probe();
            lm_head_probe
                .validate()
                .expect("paired Qwen P2051 last-token LM-head probe is canonical-only");
            assert!(matches!(
                defaults
                    .with_hf_eager_qwen_p2051_last_token_direct_cublas_lm_head_probe()
                    .validate(),
                Err(LlamaForwardError::InvalidConfiguration {
                    field: "lm_head_mode",
                    ..
                })
            ));

            let p2048_cache_on = defaults.with_hf_eager_qwen_p2048_cache_on_prefill_probe();
            assert_eq!(
                p2048_cache_on.attention_preference(),
                AttentionPreference::HuggingFaceEagerQwenP2048CacheOnProbe
            );
            assert_eq!(
                p2048_cache_on.output_projection_mode.id(),
                "hf-eager-qwen-p2048-cache-on-direct-cublas-probe-v1"
            );
            assert_eq!(
                p2048_cache_on.mlp_projection_mode().id(),
                "hf-eager-qwen-p2048-cache-on-direct-cublas-probe-v1"
            );
            assert_eq!(
                p2048_cache_on.lm_head_mode.id(),
                "hf-eager-qwen-p2048-cache-on-last-token-direct-cublas-probe-v1"
            );
            p2048_cache_on
                .validate()
                .expect("P2048 cache-on prefill profile must be atomic and canonical");
            assert!(matches!(
                p2048_cache_on.with_reference_attention().validate(),
                Err(LlamaForwardError::InvalidConfiguration {
                    field: "p2048_cache_on_prefill_profile",
                    ..
                })
            ));
            assert!(matches!(
                p2048_cache_on.with_fixed37_reductions().validate(),
                Err(LlamaForwardError::InvalidConfiguration {
                    field: "projection_bias_mode",
                    ..
                })
            ));
        }
    }

    #[test]
    fn eager_rope_table_view_uses_bf16_round_to_nearest_even() {
        assert_eq!(f32_to_bf16_bits(1.0), 0x3f80);
        // Halfway between BF16 1.0 (even mantissa) and its next representable
        // value must retain the even low mantissa bit.
        assert_eq!(f32_to_bf16_bits(1.003_906_2), 0x3f80);
        assert_eq!(f32_to_bf16_bits(1.003_906_4), 0x3f81);
    }

    #[test]
    fn workspace_growth_updates_exact_allocation_totals_once() {
        let mut report = PreparedLlamaAllocationReport {
            weight_bytes: 100,
            graph_bytes: 200,
            gemm_workspace_bytes: 0,
            total_device_bytes: 300,
            device_allocation_count: 7,
            pinned_host_bytes: 64,
            pinned_host_allocation_count: 1,
        };

        report
            .replace_gemm_workspace_bytes(32)
            .expect("zero-to-nonzero workspace growth is representable");
        assert_eq!(report.gemm_workspace_bytes(), 32);
        assert_eq!(report.total_device_bytes(), 332);
        assert_eq!(report.device_allocation_count(), 8);

        report
            .replace_gemm_workspace_bytes(96)
            .expect("nonzero workspace replacement is representable");
        assert_eq!(report.gemm_workspace_bytes(), 96);
        assert_eq!(report.total_device_bytes(), 396);
        assert_eq!(report.device_allocation_count(), 8);
    }

    #[test]
    fn workspace_report_growth_is_atomic_on_overflow() {
        let mut report = PreparedLlamaAllocationReport {
            weight_bytes: u64::MAX,
            graph_bytes: 0,
            gemm_workspace_bytes: 0,
            total_device_bytes: u64::MAX,
            device_allocation_count: 1,
            pinned_host_bytes: 0,
            pinned_host_allocation_count: 1,
        };
        let before = report;

        assert!(matches!(
            report.replace_gemm_workspace_bytes(1),
            Err(LlamaForwardError::ArithmeticOverflow {
                resource: LlamaForwardResource::GemmWorkspace,
            })
        ));
        assert_eq!(report, before);
    }
}

#[cfg(test)]
mod owned_decode_output_mode_keys {
    #[test]
    fn dense_actual_and_output_modes_have_disjoint_bounded_ranges(){
        for dense in 1..=32 {let legacy=72;let capacity=legacy+2*dense*(legacy+1);let mut spans=Vec::new();
            for greedy in [false,true]{for actual in 1..=dense{
                let start=super::owned_decode_segment_offset(legacy,dense,actual,greedy).unwrap();
                assert!(start>=legacy&&start+legacy+1<=capacity);
                for &(a,b)in &spans{assert!(start>=b||start+legacy+1<=a);}
                spans.push((start,start+legacy+1));
            }}
        }
        assert!(super::owned_decode_segment_offset(72,16,0,false).is_none());
        assert!(super::owned_decode_segment_offset(72,16,17,false).is_none());
        assert!(super::owned_decode_segment_offset(usize::MAX,16,1,false).is_none());
    }
}
