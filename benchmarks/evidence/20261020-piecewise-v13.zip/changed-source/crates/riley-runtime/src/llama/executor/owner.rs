//! Cold-owned CUDA resources for the Llama continuous-batch executor.
//!
//! This module is the sole lifetime boundary for the uploaded forward owner,
//! optional shape GEMM variants, paged KV storage, absolute `RoPE` tables,
//! metadata input, and output workspaces.  It deliberately does not import
//! scheduler or server policy.  The batch-executor facade retains logical
//! iteration state and borrows these resources for dispatch.

use riley_cuda::{
    CudaContext, CudaDType, CudaDeviceBuffer, CudaStream,
    NativeBf16RaggedPagedSplitGqaD128TwoStageWorkspaceLayout, RopeTableParams, rope_table,
};
use riley_model::LoadedModel;

use super::super::batch::{LlamaBatchMetadataConfig, PreparedLlamaBatchMetadata};
use super::super::forward::{LlamaRopeTableProfile, PreparedLlamaForward, span_mut};
use super::super::{ExecutionSite, LlamaOp};
use super::buffers::{
    BatchDeviceInput, BatchHostInput, allocate_packed_device_input, allocate_packed_host_input,
    allocate_synchronous_device_input, allocate_synchronous_host_input, close_device_input,
    close_host_input,
};
use super::config::{BatchMetadataTransport, PreparedLlamaBatchExecutorConfig};
use super::error::{
    LlamaBatchExecutorError, LlamaBatchExecutorResource, LlamaBatchExecutorResult,
    cuda_error as owner_cuda, record_close, usize_u64,
};
use super::gemm_plan::{PreparedLlamaBatchShape, prepare_shape_variants};
use super::host::allocate_zeroed_host_bytes;
use super::metadata::PackedIterationLayout;
use super::output::{GREEDY_RESULT_BYTES, greedy_result_capacity_bytes, output_logits_bytes};
use super::rope::{build_absolute_cpu_rope_tables, build_absolute_rope_angles};
use crate::paged_kv::{KV_BLOCK_SIZE, KvLayout};

const F32_BYTES: u64 = 4;
pub(in crate::llama) const SUPPORTED_HEAD_DIMENSION: usize = 64;
const NATIVE_D128_TWO_STAGE_MAX_DENSE_ROWS: usize = 256;
const NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS: usize = 32_768;

/// Cold-owned workspace for the explicit eager native D128 two-stage ragged
/// attention backend. It is reused layer by layer and never exists on the
/// established D64 path.

#[cfg(feature = "cuda-cublas-gemm-probe")]
pub(in crate::llama) struct HfAttentionDiagnosticWorkspace {
    pub(in crate::llama) plan: riley_cuda::CudaPreparedCublasGemmProbe,
    pub(in crate::llama) scratch: [CudaDeviceBuffer;8],
    pub(in crate::llama) decode_chunk: Option<[CudaDeviceBuffer;3]>,
}

pub(in crate::llama) struct MaterializedBf16ReferenceWorkspace {
    #[cfg(feature = "cuda-cublas-gemm-probe")]
    pub(in crate::llama) hf: Option<HfAttentionDiagnosticWorkspace>,
    pub(in crate::llama) reference: riley_cuda::PreparedPagedDecodeAttention,
    pub(in crate::llama) scores: CudaDeviceBuffer,
    pub(in crate::llama) valid: CudaDeviceBuffer,
    pub(in crate::llama) staging: riley_cuda::CudaPinnedHostBuffer,
    pub(in crate::llama) valid_host: Box<[u16]>,
    pub(in crate::llama) encoded_valid: Box<[u8]>,
    pub(in crate::llama) duplicate_scratch: Box<[u8]>,
    pub(in crate::llama) zero_host: Box<[u8]>,
}

impl MaterializedBf16ReferenceWorkspace {
    fn diagnostic_bytes(&self)->u64 {
        #[cfg(feature="cuda-cublas-gemm-probe")]
        { self.hf.as_ref().map_or(0,|h|h.scratch.iter().chain(h.decode_chunk.iter().flat_map(|b|b.iter())).map(CudaDeviceBuffer::byte_len).sum()) }
        #[cfg(not(feature="cuda-cublas-gemm-probe"))] {0}
    }
}

pub(in crate::llama) struct NativeD128TwoStageWorkspace {

    pub(in crate::llama) materialized: Option<MaterializedBf16ReferenceWorkspace>,

    pub(in crate::llama) partial_states: CudaDeviceBuffer,
    pub(in crate::llama) reduction_steps: CudaDeviceBuffer,
    pub(in crate::llama) reduction_normalizers: CudaDeviceBuffer,
    pub(in crate::llama) partial_state_capacity: u64,
    byte_len: u64,
}

impl NativeD128TwoStageWorkspace {
    #[must_use]
    pub(in crate::llama) const fn byte_len(&self) -> u64 {
        self.byte_len
    }
}

/// Host workspace coupled to the prepared device input and greedy result
/// storage.  This remains private to the Llama executor boundary even though
/// dispatch borrows it while an iteration is executing.
pub(in crate::llama) struct BatchHostWorkspace {
    pub(in crate::llama) input: BatchHostInput,
    pub(in crate::llama) greedy_results: Box<[u8]>,
}

/// One cold-prepared owner of all reusable CUDA-side batch resources.
///
/// Shape variants hold only their plan/GEMM descriptors; they share this
/// owner's uploaded weights, paged KV arena, `RoPE`, metadata, and output
/// workspaces rather than allocating duplicates.
pub(in crate::llama) struct PreparedLlamaBatchOwner {
    #[cfg(feature="cuda-cublas-gemm-probe")]
    pub(in crate::llama) owned_mlp_graphs: Option<riley_cuda::CudaOwnedHfMlpGraph>,
    pub(in crate::llama) metadata: PreparedLlamaBatchMetadata,
    pub(in crate::llama) forward: PreparedLlamaForward,
    pub(in crate::llama) shape_variants: Box<[PreparedLlamaBatchShape]>,
    pub(in crate::llama) layout: KvLayout,
    pub(in crate::llama) key_cache: CudaDeviceBuffer,
    pub(in crate::llama) value_cache: CudaDeviceBuffer,
    pub(in crate::llama) absolute_rope_cos: CudaDeviceBuffer,
    pub(in crate::llama) absolute_rope_sin: CudaDeviceBuffer,
    pub(in crate::llama) device_input: BatchDeviceInput,
    pub(in crate::llama) gathered_logits: Option<CudaDeviceBuffer>,
    pub(in crate::llama) greedy_results: Option<CudaDeviceBuffer>,
    pub(in crate::llama) native_d128_two_stage_workspace: Option<NativeD128TwoStageWorkspace>,
    pub(in crate::llama) host: BatchHostWorkspace,
    pub(in crate::llama) poisoned: bool,
}

impl PreparedLlamaBatchOwner {
    /// Cold opt-in bridge for the existing per-operation metadata transport.
    /// The returned graph borrows actual executor storage, including both full
    /// KV parents. Packed-slab metadata and inventory promotion remain blocked.
    #[allow(dead_code)] // Admission remains disabled until complete C07 evidence.
    pub(in crate::llama) fn prepare_parent_attention_graph<'a>(
        &'a mut self,
        stream: &'a mut CudaStream,
        layer_index: usize,
        batch: riley_cuda::PackedBatchHostV1<'_>,
        query_heads: u64,
        output_rows: u64,
    ) -> LlamaBatchExecutorResult<riley_cuda::ParentAttentionGraph<'a>> {
        let site = ExecutionSite::layer(layer_index, LlamaOp::RaggedPagedAttention);
        if self.poisoned || self.layout.head_dimension() != 64 {
            return Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "attention graph parent binding",
                reason: "owner is poisoned or not D64",
            });
        }
        let layer = riley_cuda::AttentionParentLayer::new(
            self.layout.layer_count() as u64,
            layer_index as u64,
            self.layout.physical_block_count() as u64,
            self.layout.key_value_head_count() as u64,
        )
        .map_err(|source| owner_cuda(site, source))?;
        if self.layout.layer_byte_offset(layer_index) != Some(layer.byte_offset())
            || self.layout.layer_stride_bytes() != layer.byte_len()
            || self.layout.bytes_per_kind() != layer.parent_byte_len()
        {
            return Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "attention graph parent binding",
                reason: "KV layout differs from native layer geometry",
            });
        }
        let BatchDeviceInput::PerOperation(metadata) = &mut self.device_input else {
            return Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "attention graph parent binding",
                reason: "packed metadata slab binding is not admitted",
            });
        };
        riley_cuda::ParentAttentionGraph::prepare(
            riley_cuda::ParentAttentionResources {
                stream,
                query: &mut self.forward.buffers.hidden_rotary,
                key_parent: &mut self.key_cache,
                value_parent: &mut self.value_cache,
                output: &mut self.forward.buffers.hidden_context,
                sequence_block_offsets: &mut metadata.sequence_block_offsets,
                block_ids: &mut metadata.physical_block_ids,
                valid_tokens: &mut metadata.valid_tokens,
                row_sequence_slots: &mut metadata.row_sequence_slots,
                row_positions: &mut metadata.row_positions,
            },
            layer,
            batch,
            query_heads,
            output_rows,
            0.125,
        )
        .map_err(|source| owner_cuda(site, source))
    }

    /// Captures canonical C07 metadata using actual model-owned query and KV.
    /// This cold API measures same-owner parity before exposing any evidence.
    #[cfg(feature = "cuda")]
    #[allow(dead_code, clippy::too_many_arguments)]
    pub(in crate::llama) fn prepare_c07_attention_graph<'a>(
        &'a mut self,
        stream: &'a mut CudaStream,
        device: &'a mut crate::llama::graph_decode_exact_device_slab::PureDecodeGraphV1ExactDeviceSlab,
        staging: &mut riley_cuda::CudaPinnedHostBuffer,
        source: crate::llama::graph_decode_exact_host_slab::PureDecodeGraphV1ExactHostSlabLease<'_>,
        expected: crate::llama::graph_decode_layout::PureDecodeGraphMetadataLayout,
        layer_index: usize,
        batch: riley_cuda::PackedBatchHostV1<'_>,
    ) -> LlamaBatchExecutorResult<
        crate::llama::graph_decode_attention_owner::C07AttentionGraphOwner<'a>,
    > {
        if self.poisoned {
            return Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "C07 attention owner",
                reason: "executor is poisoned",
            });
        }
        let query_heads = self.forward.plan.dimensions().query_heads() as u64;
        crate::llama::graph_decode_attention_owner::C07AttentionGraphOwner::prepare(
            stream,
            &mut self.forward.buffers.hidden_rotary,
            &mut self.key_cache,
            &mut self.value_cache,
            &mut self.forward.buffers.hidden_context,
            device,
            staging,
            source,
            expected,
            self.layout,
            layer_index,
            batch,
            query_heads,
            &mut self.poisoned,
        )
    }

    /// G02C cold M=1 capture of the actual final norm workspace and weight.
    /// Profile rejection happens before CUDA work; per-layer Norm evidence is
    /// never substituted for this final normalization operation.
    #[cfg(feature = "cuda")]
    #[allow(dead_code)]
    pub(in crate::llama) fn prepare_c07_final_norm_graph<'a>(
        &'a mut self,
        stream: &'a mut CudaStream,
    ) -> LlamaBatchExecutorResult<
        crate::llama::graph_decode_final_norm_owner::C07FinalNormGraphOwner<'a>,
    > {
        use crate::llama::graph_decode_final_norm_owner::{
            C07FinalNormGraphOwner, FinalNormBinding,
        };
        let rejected = |reason| LlamaBatchExecutorError::InvalidConfiguration {
            field: "C07 final norm owner",
            reason,
        };
        if self.poisoned || self.forward.is_poisoned() {
            return Err(rejected("executor is poisoned"));
        }
        let plan = &self.forward.plan;
        if plan.sequence_length() != 1 {
            return Err(rejected("initial final norm owner requires exact M=1"));
        }
        let hidden = plan.dimensions().hidden_size();
        let weight_id = plan.final_norm_weight();
        let binding = FinalNormBinding::new(
            self.forward.rms_norm_profile(),
            1,
            hidden as u64,
            plan.final_norm_epsilon(),
            weight_id,
        )
        .map_err(|_| rejected("final norm profile or geometry has no exact capture evidence"))?;
        let metadata = self
            .forward
            .weights
            .physical_metadata(weight_id)
            .ok_or_else(|| rejected("final norm weight belongs to a different uploaded owner"))?;
        if metadata.dtype != riley_tensor::DType::BF16
            || metadata.shape != [hidden]
            || metadata.byte_len != hidden as u64 * 2
        {
            return Err(rejected("final norm weight dtype or shape differs"));
        }
        let weight = self
            .forward
            .weights
            .borrow_graph_weight(weight_id)
            .map_err(|_| rejected("final norm weight cannot be borrowed"))?;
        C07FinalNormGraphOwner::prepare(
            stream,
            &mut self.forward.buffers.hidden_current,
            weight,
            &mut self.forward.buffers.hidden_norm,
            &mut self.forward.io_staging,
            binding,
            &mut self.poisoned,
        )
    }

    /// Uploads weights and reserves every CUDA and host resource reused by a
    /// prepared continuous-batch executor.
    ///
    /// The caller has already normalized and validated the host-only config.
    /// This method preserves the established cold allocation and rollback
    /// order: forward first, then optional shape plans, KV/`RoPE`, metadata,
    /// outputs, and host workspace.
    #[allow(clippy::too_many_lines)]
    pub(in crate::llama) fn prepare(
        model: &LoadedModel,
        context: &CudaContext,
        stream: &mut CudaStream,
        config: PreparedLlamaBatchExecutorConfig,
    ) -> LlamaBatchExecutorResult<Self> {
        let spec = model.spec();
        if config.owned_hf_eager_bf16()
            && config.execution_completion_implementation()
                == super::config::ExecutionCompletionImplementation::IterationBatch
            && spec.blocks().iter().any(|block| block.mlp().has_bias())
        {
            return Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "owned-hf-eager-bf16-v1",
                reason: "iteration completion does not support owned MLP biases",
            });
        }
        // Owned Q/K/V bias projections use the same prepared cuBLASLt
        // algorithms and actual-request row groups in either completion mode.
        // Native ExclusiveGemmUses retains the plan, bias, operands and
        // workspace in the enclosing command batch until confirmed completion;
        // no projection arithmetic or split-K policy changes here. The forward
        // owner still rejects unqualified biased model geometries.
        let attention = spec
            .blocks()
            .first()
            .ok_or(LlamaBatchExecutorError::InvalidConfiguration {
                field: "model.blocks",
                reason: "the validated model must contain at least one decoder layer",
            })?
            .attention();
        let bounds = config.metadata();
        if matches!(config.owned_decode_batch(),6|7|8|9|10) && (bounds.max_rows()>32 || bounds.max_output_slots()>32) {
            return Err(LlamaBatchExecutorError::InvalidConfiguration{field:"bounded_sm80_gateup",reason:"requires at most32 simultaneous sequences"});
        }
        if config.owned_decode_batch()==5 && (bounds.max_rows()>32 || bounds.max_output_slots()>32) {
            return Err(LlamaBatchExecutorError::InvalidConfiguration{field:"exact_smallrows_decode",reason:"mode5 requires at most32 simultaneous sequences"});
        }
        if config.owned_decode_batch()==4 && (bounds.max_rows()>2 || bounds.max_output_slots()>2) {
            return Err(LlamaBatchExecutorError::InvalidConfiguration{field:"exact_r2_global_decode",reason:"mode4 is performance-qualified only for at most2 simultaneous sequences; use the existing mode3 for larger batches"});
        }

        validate_batch_attention_geometry(
            config,
            attention.query_heads(),
            attention.key_value_heads(),
            attention.head_dimension(),
            serving_sequence_tokens(config, spec.max_sequence_length()),
            bounds,
        )?;
        if config.vllm_smol_p128_graph()
            && (bounds.max_rows() != 1
                || !matches!(bounds.max_input_tokens(), 1 | 128)
                || config.shape_policy() != super::shape::LlamaBatchShapePolicy::FixedMaximum)
        {
            return Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "vllm-smol-p128-v1 metadata",
                reason: "owned profile requires fixed maximum, one sequence and a 1 or 128 token budget",
            });
        }
        if bounds.max_input_tokens() > spec.max_sequence_length() {
            return Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "max_input_tokens",
                reason: "maximum dense rows must not exceed the model sequence length",
            });
        }

        let metadata = PreparedLlamaBatchMetadata::prepare(bounds)?;
        // The batch dispatcher uses paged attention exclusively; the dense
        // forward owner's prefill plan is never dispatched. For M=1 reserve
        // the native reference plan explicitly, avoiding an unused cuBLASLt
        // prefill dependency (and its separate CUDA-version qualification).
        // This does not change the paged attention reduction implementation.
        let forward_rows = if config.vllm_smol_p128_batched_prefill() {
            1
        } else {
            bounds.max_input_tokens()
        };
        let forward_config = if forward_rows == 1 {
            config.forward().with_reference_attention()
        } else {
            config.forward()
        };
        #[cfg(feature="cuda-cublas-gemm-probe")]
        let hf_batch_only = config.owned_hf_eager_bf16();
        #[cfg(not(feature="cuda-cublas-gemm-probe"))]
        let hf_batch_only = false;
        let mut forward = if hf_batch_only {
            PreparedLlamaForward::prepare_paged_batch(model, context, stream, forward_rows,
                forward_config, bounds.max_output_slots())?
        } else {
            PreparedLlamaForward::prepare(model, context, stream, forward_rows, forward_config)?
        };
        let mut shape_variants = match prepare_shape_variants(
            model,
            context,
            &forward,
            config.shape_policy(),
            config.configured_shape_buckets(),
        ) {
            Ok(variants) => variants,
            Err(error) => {
                let _ = forward.close();
                return Err(error);
            }
        };
        #[cfg(feature="cuda-cublas-gemm-probe")]
        if matches!(config.owned_decode_batch(),7|8|9|10) {
            let d=forward.plan.dimensions();
            if (d.hidden_size(),d.query_heads(),d.key_value_heads(),d.head_dimension(),d.intermediate_size())!=(2560,32,8,128,9728) {
                return Err(LlamaBatchExecutorError::InvalidConfiguration{field:"bounded_sm80_projections",reason:"requires qualified Qwen3-4B geometry"});
            }
            forward.gemms.prepare_bounded_sm80_projections()?;
            for shape in shape_variants.iter_mut(){shape.gemms.prepare_bounded_sm80_projections()?;}
        }
        #[cfg(feature="cuda-cublas-gemm-probe")]
        if config.owned_decode_batch()==10 {
            forward.gemms.prepare_sm80_prefill()?;
            for shape in shape_variants.iter_mut(){shape.gemms.prepare_sm80_prefill()?;}
        }
        #[cfg(feature="cuda-cublas-gemm-probe")]
        if config.owned_decode_batch()==10 && config.owned_decode_graph() && bounds.max_rows()>=2 && bounds.max_input_tokens()>=128 {
            forward.weights.upload_merged_gate_up(model.weights(),forward.plan.layers().len(),context,stream,
                config.forward().upload_staging_bytes(),false)
                .map_err(|source|crate::llama::LlamaForwardError::Weight{site:None,source})?;
            forward.gemms.prepare_sm80_merged_decode(context)?;
            for shape in shape_variants.iter_mut(){shape.gemms.prepare_sm80_merged_decode(context)?;}
        }
        let required_gemm_workspace_bytes = shape_variants.iter().fold(
            forward.gemms.maximum_workspace_bytes(),
            |required, shape| required.max(shape.gemms.maximum_workspace_bytes()),
        );
        if let Err(error) =
            forward.ensure_batch_shape_gemm_workspace(context, required_gemm_workspace_bytes)
        {
            for shape in shape_variants {
                let _ = shape.close();
            }
            let _ = forward.close();
            return Err(LlamaBatchExecutorError::Forward(error));
        }
        let dimensions = forward.plan.dimensions();
        validate_batch_attention_geometry(
            config,
            dimensions.query_heads(),
            dimensions.key_value_heads(),
            dimensions.head_dimension(),
            serving_sequence_tokens(config, spec.max_sequence_length()),
            bounds,
        )?;
        let layout = KvLayout::checked(
            forward.plan.layers().len(),
            bounds.physical_block_count(),
            dimensions.key_value_heads(),
            dimensions.head_dimension(),
        )?;

        let key_cache = allocate_device(
            context,
            layout.bytes_per_kind(),
            ExecutionSite::layer(0, LlamaOp::KvCacheWrite),
        )?;
        let value_cache = allocate_device(
            context,
            layout.bytes_per_kind(),
            ExecutionSite::layer(0, LlamaOp::KvCacheWrite),
        )?;
        let native_d128_two_stage_workspace = if config.uses_paged_attention_workspace()
        {
            // A row never has more pages than the longest sequence the
            // scheduler admits; without a declared bound, fall back to the
            // checkpoint context.
            let workspace_sequence_tokens = config
                .serving_sequence_token_bound()
                .map_or(spec.max_sequence_length(), |bound| {
                    bound.clamp(1, spec.max_sequence_length())
                });
            let partial_state_capacity =
                native_d128_partial_state_capacity(workspace_sequence_tokens)?;
            let workspace_layout =
                NativeBf16RaggedPagedSplitGqaD128TwoStageWorkspaceLayout::with_query_heads(
                    usize_u64(
                        bounds.max_input_tokens(),
                        LlamaBatchExecutorResource::NativeD128PartialStates,
                    )?,
                    partial_state_capacity,
                    usize_u64(
                        dimensions.query_heads(),
                        LlamaBatchExecutorResource::NativeD128PartialStates,
                    )?,
                )
                .map_err(|source| {
                    owner_cuda(
                        ExecutionSite::layer(0, LlamaOp::RaggedPagedAttention),
                        source,
                    )
                })?;
            let attention_site = ExecutionSite::layer(0, LlamaOp::RaggedPagedAttention);

            let materialized = if config.materialized_bf16_reference_d128() || config.materialized_bf16_reference_d64() || config.owned_hf_eager_bf16() {
                let reference = riley_cuda::PreparedPagedDecodeAttention::select(context,
                    riley_cuda::PagedDecodeAttentionRequest::new(workspace_sequence_tokens as u64,
                        layout.physical_block_count() as u64, dimensions.query_heads() as u64,
                        dimensions.key_value_heads() as u64, dimensions.head_dimension() as u64,
                        1.0/(dimensions.head_dimension() as f32).sqrt()),
                    riley_cuda::DecodeAttentionPreference::Reference,
                    riley_cuda::DecodeAttentionBackendAvailability::linked())
                    .map_err(|e| owner_cuda(attention_site,e))?;
                let scores=allocate_device(context,reference.workspace_bytes(),attention_site)?;
                let valid_bytes=partial_state_capacity*2*bounds.max_input_tokens() as u64;
                let valid=allocate_device(context,valid_bytes,attention_site)?;
                let zero_bytes=bounds.max_input_tokens()*dimensions.query_width()*2;
                let staging=context.allocate_pinned_host_buffer(valid_bytes.max(zero_bytes as u64))
                    .map_err(|e| owner_cuda(attention_site,e))?;
                #[cfg(feature="cuda-cublas-gemm-probe")]
                let hf=if config.owned_hf_eager_bf16() {
                    if dimensions.query_heads()==0 || dimensions.query_heads()>64 || dimensions.key_value_heads()==0 || dimensions.query_heads()%dimensions.key_value_heads()!=0 || dimensions.query_heads()/dimensions.key_value_heads()>8 || !matches!(dimensions.head_dimension(),64|128) || bounds.max_input_tokens()>8192 || workspace_sequence_tokens>9216 {
                        return Err(LlamaBatchExecutorError::InvalidConfiguration {field:"hf_attention_diagnostic",reason:"owned D64/D128 GQA<=8 M<=8192 T<=9216 geometry only"});
                    }
                    let m=bounds.max_input_tokens() as u64;let t=workspace_sequence_tokens as u64;let h=dimensions.query_heads() as u64;let d=dimensions.head_dimension() as u64;let q=m*h*d*2;let kv=t*h*d*2;let sc=h*m*t;let tiled=h*m.min(128)*t;
                    let mut plan=context.prepare_owned_hf_gemm(riley_cuda::CudaGemmConfig::new(m,t,d,16777216).map_err(|e|owner_cuda(attention_site,e))?).map_err(|e|owner_cuda(attention_site,e))?;
                    if matches!(config.owned_decode_batch(),9|10) {plan.prepare_sm80_attention().map_err(|e|owner_cuda(attention_site,e))?;}
                    if config.owned_decode_batch()==10 {plan.prepare_sm80_paged_attention().map_err(|e|owner_cuda(attention_site,e))?;}
                    let mut allocated=Vec::with_capacity(8);
                    for len in [q,kv,kv,sc*2,tiled*4,tiled*4,q,16777216] {allocated.push(allocate_device(context,len,attention_site)?);}
                    let scratch=match allocated.try_into() {Ok(a)=>a,Err(_)=>unreachable!("eight cold buffers")};
                    eprintln!("owned-hf-eager-bf16-v1: owned scratch, completion={:?}, M={m}, T={t}",config.execution_completion_implementation());
                    let decode_chunk=if config.owned_decode_batch()>=2 && bounds.max_rows()>=2 && matches!((dimensions.query_heads(),dimensions.key_value_heads()),(16,2)|(32,8)) && d==128 && plan.supports_exact_decode_chunk(){
                        let maximum=if dimensions.query_heads()==32{32}else{8};let r=bounds.max_rows().min(maximum) as u64;let t=t.min(512);let p=r*h*t*2;let kv=if plan.uses_sm80_paged_attention(){p}else{r*h*t*128*2};
                        Some([allocate_device(context,kv,attention_site)?,allocate_device(context,kv,attention_site)?,allocate_device(context,p,attention_site)?])
                    }else if config.owned_decode_batch()>=2 && bounds.max_rows()>=2 && dimensions.query_heads()==9 && dimensions.key_value_heads()==3 && d==64 && plan.supports_exact_smol_attention(16) {
                        let r=bounds.max_rows().min(32) as u64;let kv=r*3*1024*64*2;let p=r*9*1024*2;
                        Some([allocate_device(context,kv,attention_site)?,allocate_device(context,kv,attention_site)?,allocate_device(context,p,attention_site)?])
                    }else{None};
                    Some(HfAttentionDiagnosticWorkspace {plan,scratch,decode_chunk})
                } else {None};
                Some(MaterializedBf16ReferenceWorkspace {
                    #[cfg(feature="cuda-cublas-gemm-probe")] hf,
                    reference,scores,valid,staging,
                    valid_host:vec![0;partial_state_capacity as usize].into_boxed_slice(),
                    encoded_valid:vec![0;valid_bytes as usize].into_boxed_slice(),
                    duplicate_scratch:vec![0;layout.physical_block_count()].into_boxed_slice(),
                    zero_host:vec![0;zero_bytes].into_boxed_slice()})
            } else { None };
            let materialized_extra_bytes = materialized.as_ref().map_or(0,|w|w.scores.byte_len()+w.valid.byte_len()+w.diagnostic_bytes());
            // The owned HF path returns directly from dispatch; it never uses
            // native split-page partials. Retain zero-capacity owned buffers
            // instead of a second, unused M*pages*heads*D allocation.
            #[cfg(feature="cuda-cublas-gemm-probe")]
            let hf_only = materialized.as_ref().is_some_and(|w| w.hf.is_some());
            #[cfg(not(feature="cuda-cublas-gemm-probe"))]
            let hf_only = false;
            let legacy_lengths = if hf_only { [0; 3] } else {
                [workspace_layout.partial_state_bytes(), workspace_layout.reduction_step_bytes(),
                 workspace_layout.reduction_normalizer_bytes()]
            };
            Some(NativeD128TwoStageWorkspace {

                materialized,

                partial_states: allocate_device(
                    context,
                    legacy_lengths[0],
                    attention_site,
                )?,
                reduction_steps: allocate_device(
                    context,
                    legacy_lengths[1],
                    attention_site,
                )?,
                reduction_normalizers: allocate_device(
                    context,
                    legacy_lengths[2],
                    attention_site,
                )?,
                partial_state_capacity,
                byte_len: legacy_lengths.iter().sum::<u64>() + materialized_extra_bytes,
            })
        } else {
            None
        };
        let rope_bytes_per_kind = checked_product_u64(
            &[
                usize_u64(
                    spec.max_sequence_length(),
                    LlamaBatchExecutorResource::RopeCos,
                )?,
                usize_u64(
                    dimensions.head_dimension() / 2,
                    LlamaBatchExecutorResource::RopeCos,
                )?,
                F32_BYTES,
            ],
            LlamaBatchExecutorResource::RopeCos,
        )?;
        let mut absolute_rope_cos = allocate_device(
            context,
            rope_bytes_per_kind,
            ExecutionSite::layer(0, LlamaOp::QueryRope),
        )?;
        let mut absolute_rope_sin = allocate_device(
            context,
            rope_bytes_per_kind,
            ExecutionSite::layer(0, LlamaOp::QueryRope),
        )?;
        let rope_site = ExecutionSite::layer(0, LlamaOp::QueryRope);
        if forward.rope_table_profile() == LlamaRopeTableProfile::HuggingFaceCuda {
            let rope_angles = build_absolute_rope_angles(
                spec.max_sequence_length(),
                dimensions.head_dimension(),
                forward.plan.rope_frequencies(),
            )?;
            absolute_rope_cos
                .upload_from_slice(0, &rope_angles, &mut forward.io_staging, stream)
                .map_err(|source| owner_cuda(rope_site, source))?;
            let mut rope_table_params = RopeTableParams {
                angles_cos: span_mut(
                    &mut absolute_rope_cos,
                    CudaDType::F32,
                    rope_bytes_per_kind,
                    rope_site,
                )?,
                sin: span_mut(
                    &mut absolute_rope_sin,
                    CudaDType::F32,
                    rope_bytes_per_kind,
                    rope_site,
                )?,
                element_count: rope_bytes_per_kind / F32_BYTES,
            };
            rope_table(&mut rope_table_params, stream)
                .map_err(|source| owner_cuda(rope_site, source))?;
        } else {
            let (rope_cos, rope_sin) = build_absolute_cpu_rope_tables(
                spec.max_sequence_length(),
                dimensions.head_dimension(),
                forward.plan.rope_frequencies(),
            )?;
            absolute_rope_cos
                .upload_from_slice(0, &rope_cos, &mut forward.io_staging, stream)
                .map_err(|source| owner_cuda(rope_site, source))?;
            absolute_rope_sin
                .upload_from_slice(0, &rope_sin, &mut forward.io_staging, stream)
                .map_err(|source| owner_cuda(rope_site, source))?;
        }

        let device_input = allocate_device_input(
            context,
            bounds,
            config.metadata_transport(),
            config.staged_step_uploads(),
        )?;
        let gathered_logits_capacity_bytes =
            output_logits_bytes(bounds.max_output_slots(), dimensions.vocabulary_size())?;
        let gathered_logits = if bounds.max_output_slots() == 0 {
            None
        } else {
            Some(allocate_device(
                context,
                gathered_logits_capacity_bytes,
                ExecutionSite::global(LlamaOp::OutputGather),
            )?)
        };
        let greedy_result_capacity_bytes = greedy_result_capacity_bytes(bounds.max_output_slots())?;
        let greedy_results = if bounds.max_output_slots() == 0 {
            None
        } else {
            Some(allocate_device(
                context,
                greedy_result_capacity_bytes,
                ExecutionSite::global(LlamaOp::OutputGather),
            )?)
        };
        let host = allocate_host_workspace(
            context,
            bounds,
            config.metadata_transport(),
            config.staged_step_uploads(),
        )?;

        #[cfg(feature="cuda-cublas-gemm-probe")]
        if matches!(config.owned_decode_batch(),3|4) && ((dimensions.hidden_size(),dimensions.query_heads(),dimensions.key_value_heads(),dimensions.head_dimension(),dimensions.intermediate_size())!=(2560,32,8,128,9728)
            ||!native_d128_two_stage_workspace.as_ref().and_then(|w|w.materialized.as_ref()).and_then(|w|w.hf.as_ref()).is_some_and(|w|w.plan.supports_exact_decode_chunk())
            ||["CUBLAS_WORKSPACE_CONFIG","CUDA_MPS_ACTIVE_THREAD_PERCENTAGE"].iter().any(|k|std::env::var_os(k).is_some_and(|v|!v.is_empty()))) {
            return Err(LlamaBatchExecutorError::InvalidConfiguration{field:"exact_r2_decode",reason:"requires qualified Q4 SM89/CUDA12.8 geometry and unmodified cuBLAS workspace/SM configuration"});
        }
        #[cfg(feature="cuda-cublas-gemm-probe")]
        if config.owned_decode_batch()==5 && (!matches!((dimensions.hidden_size(),dimensions.query_heads(),dimensions.key_value_heads(),dimensions.head_dimension(),dimensions.intermediate_size()),(2560,32,8,128,9728)|(4096,32,8,128,14336))
            ||!native_d128_two_stage_workspace.as_ref().and_then(|w|w.materialized.as_ref()).and_then(|w|w.hf.as_ref()).is_some_and(|w|w.plan.supports_exact_decode_chunk())
            ||["CUBLAS_WORKSPACE_CONFIG","CUDA_MPS_ACTIVE_THREAD_PERCENTAGE"].iter().any(|k|std::env::var_os(k).is_some_and(|v|!v.is_empty()))) {
            return Err(LlamaBatchExecutorError::InvalidConfiguration{field:"exact_smallrows_decode",reason:"requires qualified Q4/Mistral SM89/CUDA12.8 geometry and unmodified cuBLAS workspace/SM configuration"});
        }
        #[cfg(feature="cuda-cublas-gemm-probe")]
        if matches!(config.owned_decode_batch(),6|7|8|9|10) && (!matches!((dimensions.hidden_size(),dimensions.query_heads(),dimensions.key_value_heads(),dimensions.head_dimension(),dimensions.intermediate_size()),(2560,32,8,128,9728)|(4096,32,8,128,14336))
            ||!native_d128_two_stage_workspace.as_ref().and_then(|w|w.materialized.as_ref()).and_then(|w|w.hf.as_ref()).is_some_and(|w|w.plan.supports_bounded_sm80_gateup_rows())
            ||["CUBLAS_WORKSPACE_CONFIG","CUDA_MPS_ACTIVE_THREAD_PERCENTAGE"].iter().any(|k|std::env::var_os(k).is_some_and(|v|!v.is_empty()))) {
            return Err(LlamaBatchExecutorError::InvalidConfiguration{field:"bounded_sm80_gateup",reason:"requires Q4/Mistral SM80/108SM/CUDA12.4 and unmodified cuBLAS workspace/SM configuration"});
        }
        #[cfg(feature="cuda-cublas-gemm-probe")]
        let owned_mlp_graphs=if config.owned_mlp_graphs() || (config.owned_decode_graph() && config.owned_decode_batch()==10 && bounds.max_rows()>=2) {
            if spec.blocks().iter().any(|b|b.mlp().has_bias()) {return Err(LlamaBatchExecutorError::InvalidConfiguration{field:"owned_mlp_graphs",reason:"MLP biases are not supported by graph MLP"});}
            let sm80=matches!(config.owned_decode_batch(),9|10);
            let mut graphs=riley_cuda::CudaOwnedHfMlpGraph::prepare(context,bounds.max_input_tokens().min(32) as u32,
                dimensions.hidden_size() as u64,dimensions.intermediate_size() as u64,if sm80 {2048}else{1024})
                .map_err(|e|owner_cuda(ExecutionSite::layer(0,LlamaOp::GateProjection),e))?;
            if config.owned_decode_graph() && config.owned_decode_batch()==10 {graphs.enable_piecewise_sm80(context).map_err(|e|owner_cuda(ExecutionSite::layer(0,LlamaOp::GateProjection),e))?;}
            else if sm80 {graphs.enable_bounded_sm80_projections().map_err(|e|owner_cuda(ExecutionSite::layer(0,LlamaOp::GateProjection),e))?;}
            Some(graphs)
        }else{None};

        Ok(Self {
            #[cfg(feature="cuda-cublas-gemm-probe")]
            owned_mlp_graphs,
            metadata,
            forward,
            shape_variants,
            layout,
            key_cache,
            value_cache,
            absolute_rope_cos,
            absolute_rope_sin,
            device_input,
            gathered_logits,
            greedy_results,
            native_d128_two_stage_workspace,
            host,
            poisoned: false,
        })
    }

    /// Explicitly closes every resource in the original observable order.
    ///
    /// All cleanup attempts run even after an error.  The first batch-resource
    /// failure wins over a shape-plan failure, which wins over the reused
    /// forward owner's failure.  `Drop` remains best-effort only.
    #[allow(clippy::too_many_lines)]
    pub(in crate::llama) fn close(self) -> LlamaBatchExecutorResult<()> {
        let Self {
            #[cfg(feature="cuda-cublas-gemm-probe")]
            owned_mlp_graphs,
            metadata: _,
            forward,
            shape_variants,
            layout: _,
            key_cache,
            value_cache,
            absolute_rope_cos,
            absolute_rope_sin,
            device_input,
            gathered_logits,
            greedy_results,
            native_d128_two_stage_workspace,
            host,
            poisoned: _,
        } = self;
        let mut first = None;
        #[cfg(feature="cuda-cublas-gemm-probe")]
        if let Some(graphs)=owned_mlp_graphs {record_close(&mut first,LlamaBatchExecutorResource::HostWorkspace,graphs.close());}
        record_close(
            &mut first,
            LlamaBatchExecutorResource::KeyCache,
            key_cache.close(),
        );
        record_close(
            &mut first,
            LlamaBatchExecutorResource::ValueCache,
            value_cache.close(),
        );
        if let Some(workspace) = native_d128_two_stage_workspace {

            if let Some(materialized) = workspace.materialized {
                record_close(&mut first,LlamaBatchExecutorResource::NativeD128PartialStates,materialized.scores.close());
                record_close(&mut first,LlamaBatchExecutorResource::NativeD128ReductionSteps,materialized.valid.close());
                record_close(&mut first,LlamaBatchExecutorResource::NativeD128ReductionNormalizers,materialized.staging.close());
                #[cfg(feature="cuda-cublas-gemm-probe")]
                if let Some(hf)=materialized.hf {
                    record_close(&mut first,LlamaBatchExecutorResource::NativeD128PartialStates,hf.plan.close());
                    for buffer in hf.scratch {record_close(&mut first,LlamaBatchExecutorResource::NativeD128PartialStates,buffer.close());}
                    if let Some(chunk)=hf.decode_chunk {for buffer in chunk {record_close(&mut first,LlamaBatchExecutorResource::NativeD128PartialStates,buffer.close());}}
                }
                drop(materialized.reference);
            }
            record_close(
                &mut first,
                LlamaBatchExecutorResource::NativeD128PartialStates,
                workspace.partial_states.close(),
            );
            record_close(
                &mut first,
                LlamaBatchExecutorResource::NativeD128ReductionSteps,
                workspace.reduction_steps.close(),
            );
            record_close(
                &mut first,
                LlamaBatchExecutorResource::NativeD128ReductionNormalizers,
                workspace.reduction_normalizers.close(),
            );
        }
        record_close(
            &mut first,
            LlamaBatchExecutorResource::RopeCos,
            absolute_rope_cos.close(),
        );
        record_close(
            &mut first,
            LlamaBatchExecutorResource::RopeSin,
            absolute_rope_sin.close(),
        );
        record_first_error(&mut first, close_device_input(device_input));
        if let Some(buffer) = gathered_logits {
            record_close(
                &mut first,
                LlamaBatchExecutorResource::GatheredLogits,
                buffer.close(),
            );
        }
        if let Some(buffer) = greedy_results {
            record_close(
                &mut first,
                LlamaBatchExecutorResource::GreedyResults,
                buffer.close(),
            );
        }
        record_first_error(&mut first, close_host_input(host.input));

        let mut shape_error = None;
        for shape in shape_variants {
            record_first_error(&mut shape_error, shape.close().err());
        }
        let forward_error = forward
            .close()
            .map_err(LlamaBatchExecutorError::Forward)
            .err();
        finish_close_errors(first, shape_error, forward_error)
    }
}

fn allocate_device_input(
    context: &CudaContext,
    bounds: LlamaBatchMetadataConfig,
    transport: BatchMetadataTransport,
    staged: bool,
) -> LlamaBatchExecutorResult<BatchDeviceInput> {
    match transport {
        BatchMetadataTransport::Synchronous => {
            allocate_synchronous_device_input(context, bounds, staged)
        }
        BatchMetadataTransport::PackedAsync => {
            let capacity = PackedIterationLayout::capacity(bounds)?.total_bytes;
            allocate_packed_device_input(context, capacity)
        }
    }
}

fn allocate_host_workspace(
    context: &CudaContext,
    bounds: LlamaBatchMetadataConfig,
    transport: BatchMetadataTransport,
    staged: bool,
) -> LlamaBatchExecutorResult<BatchHostWorkspace> {
    let input = match transport {
        BatchMetadataTransport::Synchronous => {
            allocate_synchronous_host_input(context, bounds, staged)?
        }
        BatchMetadataTransport::PackedAsync => {
            let capacity = PackedIterationLayout::capacity(bounds)?.total_bytes;
            allocate_packed_host_input(context, capacity)?
        }
    };
    Ok(BatchHostWorkspace {
        input,
        greedy_results: allocate_zeroed_host_bytes(bounds.max_output_slots(), GREEDY_RESULT_BYTES)?,
    })
}

fn allocate_device(
    context: &CudaContext,
    byte_len: u64,
    site: ExecutionSite,
) -> LlamaBatchExecutorResult<CudaDeviceBuffer> {
    context
        .allocate_device_buffer(byte_len)
        .map_err(|source| owner_cuda(site, source))
}

/// The longest sequence the scheduler admits: the declared serving bound when
/// one was given, else the checkpoint context.
fn serving_sequence_tokens(
    config: PreparedLlamaBatchExecutorConfig,
    model_sequence_tokens: usize,
) -> usize {
    config
        .serving_sequence_token_bound()
        .map_or(model_sequence_tokens, |bound| {
            bound.clamp(1, model_sequence_tokens)
        })
}

fn validate_batch_attention_geometry(
    config: PreparedLlamaBatchExecutorConfig,
    query_heads: usize,
    key_value_heads: usize,
    head_dimension: usize,
    maximum_sequence_tokens: usize,
    bounds: LlamaBatchMetadataConfig,
) -> LlamaBatchExecutorResult<()> {
    #[cfg(feature="cuda-cublas-gemm-probe")]
    if config.owned_hf_eager_bf16() {
        if config.vllm_smol_p128_graph() {
            return Err(LlamaBatchExecutorError::InvalidConfiguration {field:"hf_attention_diagnostic",reason:"owned materialized reference attention does not support graphs"});
        }
        if !matches!(head_dimension,64|128) || query_heads==0 || query_heads>64 || key_value_heads==0 || query_heads%key_value_heads!=0 || query_heads/key_value_heads>8 || bounds.max_input_tokens()>8192 || maximum_sequence_tokens>9216 {
            return Err(LlamaBatchExecutorError::InvalidConfiguration {field:"hf_attention_diagnostic_geometry",reason:"bounded D64/D128 GQA diagnostic only"});
        }
        return Ok(());
    }
    if config.materialized_bf16_reference_d64() {
        // Private full-prefill diagnostic; reference executes one row at a time.
        let maximum_materialized_d64_rows = 512;
        if head_dimension != 64 || query_heads == 0 || key_value_heads == 0 || query_heads % key_value_heads != 0 || query_heads / key_value_heads > 8 || bounds.max_input_tokens() > maximum_materialized_d64_rows || maximum_sequence_tokens > NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS {
            return Err(LlamaBatchExecutorError::InvalidConfiguration {field:"materialized_d64_reference_geometry",reason:"requires D64 GQA ratio<=8, batch<=512, sequence<=32768"});
        }
        return Ok(());
    }
    if !config.uses_d128_paged_attention() {
        if head_dimension != SUPPORTED_HEAD_DIMENSION {
            return Err(LlamaBatchExecutorError::UnsupportedHeadDimension {
                expected: SUPPORTED_HEAD_DIMENSION,
                actual: head_dimension,
            });
        }
        return Ok(());
    }

    if query_heads == 0
        || key_value_heads == 0
        || query_heads % key_value_heads != 0
        || query_heads / key_value_heads
            > riley_cuda::NATIVE_BF16_RAGGED_PAGED_SPLIT_GQA_D128_MAX_GROUP_HEADS as usize
        || (head_dimension
            != riley_cuda::NATIVE_BF16_RAGGED_PAGED_SPLIT_GQA_D128_HEAD_SIZE as usize
            && head_dimension
                != riley_cuda::NATIVE_BF16_RAGGED_PAGED_SPLIT_GQA_D64_HEAD_SIZE as usize)
    {
        return Err(LlamaBatchExecutorError::InvalidConfiguration {
            field: "native_d128_two_stage_geometry",
            reason: "requires head_dimension=128 or 64 and at most eight query heads per key/value head",
        });
    }
    // A 64-wide head exists for the tensor-core producer with the global-max
    // merge only.
    if head_dimension == riley_cuda::NATIVE_BF16_RAGGED_PAGED_SPLIT_GQA_D64_HEAD_SIZE as usize
        && !(config.d128_tensor_core_producer() && config.d128_global_merge())
    {
        return Err(LlamaBatchExecutorError::InvalidConfiguration {
            field: "native_d128_two_stage_geometry",
            reason: "head_dimension=64 requires the tensor-core producer and the global-max merge",
        });
    }
    if bounds.max_input_tokens() > NATIVE_D128_TWO_STAGE_MAX_DENSE_ROWS {
        return Err(LlamaBatchExecutorError::InvalidConfiguration {
            field: "max_input_tokens",
            reason: "native D128 two-stage requires a batch token budget at most 256",
        });
    }
    if maximum_sequence_tokens > NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS {
        return Err(LlamaBatchExecutorError::InvalidConfiguration {
            field: "max_sequence_tokens",
            reason: "native D128 two-stage workspace is qualified through 32768 tokens",
        });
    }
    Ok(())
}

fn native_d128_partial_state_capacity(
    maximum_sequence_tokens: usize,
) -> LlamaBatchExecutorResult<u64> {
    let rounded = maximum_sequence_tokens
        .checked_add(KV_BLOCK_SIZE - 1)
        .ok_or(LlamaBatchExecutorError::ArithmeticOverflow {
            resource: LlamaBatchExecutorResource::NativeD128PartialStates,
        })?;
    usize_u64(
        rounded / KV_BLOCK_SIZE,
        LlamaBatchExecutorResource::NativeD128PartialStates,
    )
}

fn checked_product_u64(
    values: &[u64],
    resource: LlamaBatchExecutorResource,
) -> LlamaBatchExecutorResult<u64> {
    values.iter().try_fold(1_u64, |product, &value| {
        product
            .checked_mul(value)
            .ok_or(LlamaBatchExecutorError::ArithmeticOverflow { resource })
    })
}

fn record_first_error(
    first: &mut Option<LlamaBatchExecutorError>,
    candidate: Option<LlamaBatchExecutorError>,
) {
    if first.is_none() {
        *first = candidate;
    }
}

fn finish_close_errors(
    first: Option<LlamaBatchExecutorError>,
    shape_error: Option<LlamaBatchExecutorError>,
    forward_error: Option<LlamaBatchExecutorError>,
) -> LlamaBatchExecutorResult<()> {
    match (first, shape_error, forward_error) {
        (Some(error), _, _) | (None, Some(error), _) | (None, None, Some(error)) => Err(error),
        (None, None, None) => Ok(()),
    }
}

#[cfg(test)]
mod tests {
    use super::{
        NATIVE_D128_TWO_STAGE_MAX_DENSE_ROWS, NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS,
        finish_close_errors, native_d128_partial_state_capacity, record_first_error,
        validate_batch_attention_geometry,
    };
    use crate::llama::batch::LlamaBatchMetadataConfig;
    use crate::llama::executor::config::PreparedLlamaBatchExecutorConfig;
    use crate::llama::executor::error::{LlamaBatchExecutorError, LlamaBatchExecutorResource};
    use crate::llama::forward::PreparedLlamaForwardConfig;

    fn failure(field: &'static str) -> LlamaBatchExecutorError {
        LlamaBatchExecutorError::InvalidConfiguration {
            field,
            reason: "test cleanup precedence",
        }
    }

    #[test]
    fn cleanup_precedence_keeps_the_first_resource_error() {
        let mut first = None;
        record_first_error(&mut first, Some(failure("key_cache")));
        record_first_error(&mut first, Some(failure("value_cache")));

        let error = finish_close_errors(first, Some(failure("shape")), Some(failure("forward")))
            .expect_err("the first resource close failure must win");
        assert!(matches!(
            error,
            LlamaBatchExecutorError::InvalidConfiguration {
                field: "key_cache",
                ..
            }
        ));
    }

    #[test]
    fn cleanup_precedence_keeps_shape_before_forward_error() {
        let error = finish_close_errors(None, Some(failure("shape")), Some(failure("forward")))
            .expect_err("a shape close failure must win before forward close");
        assert!(matches!(
            error,
            LlamaBatchExecutorError::InvalidConfiguration { field: "shape", .. }
        ));
    }

    #[test]
    fn cleanup_succeeds_when_every_close_succeeds() {
        finish_close_errors(None, None, None).expect("all successful close results must succeed");
    }

    fn native_config(
        max_input_tokens: usize,
    ) -> (PreparedLlamaBatchExecutorConfig, LlamaBatchMetadataConfig) {
        let bounds = LlamaBatchMetadataConfig::new(
            1,
            max_input_tokens,
            max_input_tokens,
            1,
            max_input_tokens,
        )
        .expect("small test metadata bounds are valid");
        (
            PreparedLlamaBatchExecutorConfig::new(bounds, PreparedLlamaForwardConfig::default())
                .with_native_bf16_paged_split_gqa_d128_two_stage(),
            bounds,
        )
    }

    #[test]
    fn d64_reference_geometry_rejects_wrong_heads_and_bounds() {
        let (base,bounds)=native_config(128);
        let config=base.with_materialized_bf16_reference_d64();
        assert!(validate_batch_attention_geometry(config,9,3,64,1024,bounds).is_ok());
        for (qh,kh,d,seq) in [(9,3,128,1024),(9,0,64,1024),(10,3,64,1024),(27,3,64,1024),(9,3,64,32769)] {assert!(validate_batch_attention_geometry(config,qh,kh,d,seq,bounds).is_err());}
    }

    #[cfg(feature = "cuda-cublas-gemm-probe")]
    #[test]
    fn owned_geometry_admits_both_completion_modes_without_relaxing_bounds() {
        let (base, bounds) = native_config(8192);
        let owned = base.with_owned_hf_eager_bf16();
        for config in [owned, owned.with_iteration_batch_completion()] {
            assert!(validate_batch_attention_geometry(config,32,8,128,9216,bounds).is_ok());
            for (qh,kvh,d,t) in [(32,0,128,9216),(32,8,256,9216),(32,8,128,9217),(32,2,128,9216)] {
                assert!(validate_batch_attention_geometry(config,qh,kvh,d,t,bounds).is_err());
            }
            assert!(validate_batch_attention_geometry(config.with_vllm_smol_p128_graph(),32,8,128,9216,bounds).is_err());
        }
    }

    #[test]
    fn native_d128_geometry_admission_is_exact_and_bounded() {
        let (config, bounds) = native_config(NATIVE_D128_TWO_STAGE_MAX_DENSE_ROWS);
        validate_batch_attention_geometry(
            config,
            16,
            2,
            128,
            NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS,
            bounds,
        )
        .expect("the qualified Qwen D128 geometry must be admitted");

        assert!(matches!(
            validate_batch_attention_geometry(
                config,
                15,
                2,
                128,
                NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS,
                bounds,
            ),
            Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "native_d128_two_stage_geometry",
                ..
            })
        ));
        for (query_heads, key_value_heads) in [(12, 2), (28, 4), (40, 8), (16, 8), (32, 8)] {
            validate_batch_attention_geometry(
                config,
                query_heads,
                key_value_heads,
                128,
                NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS,
                bounds,
            )
            .expect("every head-dimension-128 geometry with a group of at most eight is admitted");
        }
        assert!(matches!(
            validate_batch_attention_geometry(
                config,
                18,
                2,
                128,
                NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS,
                bounds,
            ),
            Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "native_d128_two_stage_geometry",
                ..
            })
        ));

        let (over_rows, over_rows_bounds) = native_config(NATIVE_D128_TWO_STAGE_MAX_DENSE_ROWS + 1);
        assert!(matches!(
            validate_batch_attention_geometry(
                over_rows,
                16,
                2,
                128,
                NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS,
                over_rows_bounds,
            ),
            Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "max_input_tokens",
                ..
            })
        ));
        assert!(matches!(
            validate_batch_attention_geometry(
                config,
                16,
                2,
                128,
                NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS + 1,
                bounds,
            ),
            Err(LlamaBatchExecutorError::InvalidConfiguration {
                field: "max_sequence_tokens",
                ..
            })
        ));
    }

    #[test]
    fn native_d128_workspace_capacity_tracks_per_row_page_count() {
        assert_eq!(native_d128_partial_state_capacity(1).unwrap(), 1);
        assert_eq!(native_d128_partial_state_capacity(16).unwrap(), 1);
        assert_eq!(native_d128_partial_state_capacity(17).unwrap(), 2);
        assert_eq!(
            native_d128_partial_state_capacity(NATIVE_D128_TWO_STAGE_MAX_SEQUENCE_TOKENS).unwrap(),
            2_048
        );
        assert!(matches!(
            native_d128_partial_state_capacity(usize::MAX),
            Err(LlamaBatchExecutorError::ArithmeticOverflow {
                resource: LlamaBatchExecutorResource::NativeD128PartialStates,
            })
        ));
    }
}
