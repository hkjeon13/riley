"""Measure a fully occupied cache owner when its peer streams have more output remaining."""

import concurrent.futures
import json
import sys
import threading
from pathlib import Path

import fleet_phase04
from agent_workflow import stream
from fixed_agent_decode import freeze
from probe_replica_wait import request


def diagnostic(folder, endpoints, cfg, arm, policy):
    peer = freeze(
        json.loads((folder.parent / "frozen-sustained.json").read_text())[0], "m"
    )
    peer["max_tokens"] = 192
    results = []
    for busy in range(2):
        pair = [endpoints[busy], endpoints[1 - busy]]
        (warm_addr, warm_key), _ = pair
        stream(warm_addr, peer, {}, bearer=warm_key)
        for repeat in range(2):
            probe = request(
                f"Boundary {busy}-{repeat}. Review these records. "
                + "Observation of routine latency was recorded. " * 450,
                1,
            )
            priming = {}
            stream(warm_addr, probe, priming, bearer=warm_key)
            with concurrent.futures.ThreadPoolExecutor(10) as threads:
                ready = [threading.Event() for _ in range(8)]
                active = [{} for _ in ready]
                peers = [
                    threads.submit(stream, warm_addr, peer, row, ev, bearer=warm_key)
                    for row, ev in zip(active, ready, strict=True)
                ]
                if not all(ev.wait(35) for ev in ready):
                    raise ValueError("peer stream readiness incomplete")
                gate = threading.Barrier(2, timeout=5)

                def send(endpoint, gate=gate, probe=probe):
                    address, key = endpoint
                    row = {}
                    gate.wait()
                    stream(address, probe, row, bearer=key)
                    return row

                arrivals = list(threads.map(send, pair))
                for completed in peers:
                    completed.result()
            results.append(
                {
                    "warm_gpu": cfg["devices"][busy],
                    "repeat": repeat,
                    "prime": priming,
                    "warm": arrivals[0],
                    "cold": arrivals[1],
                    "peers": active,
                }
            )
            fleet_phase04.write(folder / "sustained-probes.json", results)


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    cfg = json.loads((root / "phase04-registration.json").read_text())
    fleet_phase04.workload = diagnostic
    fleet_phase04.pair_run(root, Path(sys.argv[1]), cfg, 6, "sustained")
