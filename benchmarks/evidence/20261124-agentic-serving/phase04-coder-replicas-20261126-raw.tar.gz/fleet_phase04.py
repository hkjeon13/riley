"""Run the Coder-7B replica policy crossover and separate-pool isolation checks."""

import concurrent.futures
import json
import secrets
import sys
import tempfile
import time
from functools import partial
from pathlib import Path
from urllib.request import urlopen

import probe_replica_wait
from agent_workflow import replay, stream
from coder_catalog_trial import tool_output
from replica_process import serve
from replica_workflow import Router, check_isolation, tenant_burst


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def metrics(endpoint):
    with urlopen(f"http://{endpoint[0]}/metrics", timeout=5) as response:
        return json.load(response)


def wave(router, size, base, spacing_ns):
    before = time.monotonic_ns()
    origin = before + 100_000_000

    def job(index):
        reader = index % 4 == 0
        seed = base + index
        scheduled = origin + spacing_ns * index
        time.sleep(max(0, scheduled - time.monotonic_ns()) / 1e9)
        receipts = []
        work = replay(
            "",
            "m",
            seed,
            2,
            0 if reader else 0.5,
            f"job-{seed}",
            history=0 if reader else 200,
            dispatch_fixed_tools=not reader,
            execute_tool=partial(tool_output, "selected", reader, seed, receipts),
            send=router.sender(index),
        )
        return {
            "index": index,
            "role": "reader" if reader else "target",
            "scheduled_ns": scheduled,
            "work": work,
            "tool_result_receipts": receipts,
        }

    with concurrent.futures.ThreadPoolExecutor(size) as threads:
        jobs = list(threads.map(job, range(size)))
    elapsed = time.monotonic_ns()
    return {
        "size": size,
        "base": base,
        "origin_ns": origin,
        "drained_ns": elapsed,
        "before": {"clock_ns": before},
        "after": {"clock_ns": time.monotonic_ns()},
        "jobs": jobs,
    }


def workload(path, endpoints, cfg, arm, policy):
    busy = 0 if arm < 3 else 1
    pair = endpoints if busy == 0 else list(reversed(endpoints))
    write(
        path / "tenant-orientation.json",
        {"busy_gpu": cfg["devices"][busy], "peer_gpu": cfg["devices"][1 - busy]},
    )
    write(path / "isolation.json", check_isolation(pair))
    router = Router(endpoints, policy)
    waves = []
    for size, base in cfg["waves"]:
        waves.append(wave(router, size, base, cfg["arrival_spacing_ms"] * 1_000_000))
        write(path / "waves.json", waves)
    assert router.active == [0, 0]

    peer_addr, peer_key = pair[1]
    protected = partial(
        replay,
        peer_addr,
        "m",
        761,
        2,
        0,
        "unloaded-peer",
        history=100,
        send=partial(stream, bearer=peer_key),
    )
    protected()
    write(path / "unloaded-peer.json", protected())
    write(path / "tenant-burst.json", tenant_burst(pair))
    if arm in cfg["boundary_boots"]:
        (a, ka), (b, kb) = pair
        write(path / "cache-queue-crossover.json", probe_replica_wait.run(a, b, ka, kb))
        before = metrics(pair[0])
        overload = probe_replica_wait.overload(a, b, ka, kb)
        write(
            path / "overload.json",
            {"before": before, "waves": overload, "after": metrics(pair[0])},
        )


def pair_run(root, holder, cfg, arm, policy):
    path = root / f"arm-{arm}-{policy}"
    path.mkdir()
    started = time.monotonic_ns()
    with tempfile.TemporaryDirectory(prefix="riley-phase04-keys-") as directory:
        keys = Path(directory)
        for i in cfg["devices"]:
            keyfile = keys / str(i)
            keyfile.write_text(secrets.token_hex(32))
            keyfile.chmod(0o600)
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            children = [
                pool.submit(
                    serve, root, holder, path, gpu, keys, launcher="serve-phase04.sh"
                )
                for gpu in cfg["devices"]
            ]
            try:
                deadline = time.monotonic() + 395
                while not all(
                    (path / f"gpu{i}" / "address").is_file() for i in cfg["devices"]
                ):
                    for child in children:
                        if child.done():
                            child.result()
                            raise RuntimeError("replica exited before readiness")
                    if time.monotonic() >= deadline:
                        raise TimeoutError("two replicas did not become ready")
                    time.sleep(0.5)
                endpoints = [
                    (
                        (path / f"gpu{i}" / "address").read_text().strip(),
                        (keys / str(i)).read_text().strip(),
                    )
                    for i in cfg["devices"]
                ]
                print(f"{path.name} ready", flush=True)
                workload(path, endpoints, cfg, arm, policy)
            finally:
                (path / "finished").touch()
            for child in children:
                child.result()
    write(
        path / "interval.json", {"started_ns": started, "ended_ns": time.monotonic_ns()}
    )


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    cfg = json.loads((root / "phase04-registration.json").read_text())
    holder = Path(sys.argv[1])
    arms = (
        map(int, sys.argv[2:]) if len(sys.argv) > 2 else range(len(cfg["policy_order"]))
    )
    for arm in arms:
        policy = cfg["policy_order"][arm]
        print(f"arm-{arm}-{policy} starting", flush=True)
        pair_run(root, holder, cfg, arm, policy)
        print(f"arm-{arm}-{policy} complete", flush=True)
