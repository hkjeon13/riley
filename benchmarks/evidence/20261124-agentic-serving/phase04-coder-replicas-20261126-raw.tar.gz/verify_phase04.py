"""Verify the phase-04 route crossover, tenant boundaries, cancellation and resource release."""

import argparse
import itertools
import json
import math
from collections import Counter
from hashlib import sha256
from pathlib import Path

from agent_workflow import fingerprint, percentile
from fixed_agent_decode import freeze
from verify_catalog_engines import application, summarize
from verify_model_decode import natural
from verify_named_burst import prompt_ids


def read(path):
    return json.loads(path.read_text())


def quantile(values, fraction=0.95):
    return percentile(list(values), fraction)


def cache_tokens(row):
    return (row["usage"].get("prompt_tokens_details") or {}).get("cached_tokens", 0)


def idle(snapshot):
    return all(
        snapshot[k] == 0
        for k in ("active_requests", "waiting_requests", "kv_allocated_blocks")
    )


def peer(work, cfg, history=100):
    result = natural(work, 761, 2, history, delay=0)
    final = work["turns"][-1]
    events = final.get("content_ns", [])
    start, finish = result["first_final_ms"], result["last_final_ms"]
    gap = quantile((b - a) / 1e6 for a, b in itertools.pairwise(events))
    goal = cfg["tenant_slo"]
    slo = bool(
        result["valid"]
        and start is not None
        and finish is not None
        and gap is not None
        and start <= goal["first_ms"]
        and finish <= goal["last_ms"]
        and gap <= goal["gap_p95_ms"]
    )
    return {
        "correct": result["valid"],
        "first_ms": start,
        "last_ms": finish,
        "gap_p95_ms": gap,
        "slo": slo,
        "error": work.get("error"),
        "answer_sha256": fingerprint(final.get("answer", "")),
    }


def statuses(records):
    return dict(Counter(str(r.get("status", "transport_error")) for r in records))


def isolation(path, cfg):
    auth = read(path / "isolation.json")
    assert [(r["replica"], r["principal"]) for r in auth] == [
        (0, 0),
        (0, 0),
        (1, 0),
        (1, 1),
        (1, 1),
    ]
    assert len({r["input_sha256"] for r in auth}) == 1
    codes = [r["status"] for r in auth]
    hits = [cache_tokens(r) for r in auth if r["status"] == 200]
    assert (
        codes == [200, 200, 401, 200, 200]
        and hits[::2] == [0, 0]
        and min(hits[1::2]) > 0
    )
    assert codes[2] == 401 and "usage" not in auth[2] and not auth[2]["content_ns"]
    burst = read(path / "tenant-burst.json")
    assert burst["submitted"] == len(burst["requests"]) == 17
    assert {r["request"] for r in burst["requests"]} == set(range(17))
    drops = [r for r in burst["requests"] if "client_cancel_ns" in r]
    after, before = burst["after"], burst["before"]
    protected = peer(burst["protected"], cfg)
    control = peer(read(path / "unloaded-peer.json"), cfg)
    events = burst["protected"]["turns"][-1]["content_ns"]
    overlap = bool(events and events[0] < burst["burst_start_ns"] < events[-1])
    delta = {k: v - before["counters"][k] for k, v in after["counters"].items()}
    isolation_pass = (
        overlap
        and protected["slo"]
        and len(drops) == 1
        and drops[0]["status"] == 200
        and delta["cancellations"] == delta["disconnects"] == 1
        and idle(after)
    )
    return {
        "status_codes": codes,
        "cache_hits": hits,
        "unloaded_peer": control,
        "protected_peer": protected,
        "peer_body_unchanged": protected["answer_sha256"] == control["answer_sha256"],
        "concurrent_with_protected_stream": overlap,
        "burst_statuses": statuses(burst["requests"]),
        "intentional_disconnects": len(drops),
        "counter_delta": delta,
        "idle_after": idle(after),
        "passes": isolation_pass,
    }


def boundary(path, cfg):
    probes = read(path / "cache-queue-crossover.json")
    assert [(p["repeat"], p["streams"]) for p in probes] == [
        (repeat, n) for repeat in range(2) for n in cfg["boundary_occupancy"]
    ]
    estimates = []
    for probe in probes:
        a, b = probe["warm"], probe["cold"]
        assert a["input_sha256"] == b["input_sha256"]
        assert a["usage"]["prompt_tokens"] == b["usage"]["prompt_tokens"]
        assert all(
            r["status"] == 200 and r["done_ns"] and r["usage"]["completion_tokens"] == 1
            for r in (a, b)
        )
        assert len(probe["peers"]) == probe["streams"]
        active = sum(
            r["content_ns"][0] < a["sent_ns"] < r["content_ns"][-1]
            for r in probe["peers"]
        )
        estimates.append(
            {
                "repeat": probe["repeat"],
                "occupancy_requested": probe["streams"],
                "actual_ongoing_streams": active,
                "peer_output_tokens": [
                    p["usage"]["completion_tokens"] for p in probe["peers"]
                ],
                "prompt_tokens": a["usage"]["prompt_tokens"],
                "warm_cached_tokens": cache_tokens(a),
                "cold_cached_tokens": cache_tokens(b),
                **{
                    k + "_first_ms": (r["content_ns"][0] - r["sent_ns"]) / 1e6
                    for k, r in (("warm", a), ("cold", b))
                },
            }
        )
    inputs = read(path / "overload.json")
    assert [cell["submitted"] for cell in inputs["waves"]] == cfg["overload_arrivals"]
    response = []
    for cell in inputs["waves"]:
        jobs = cell["requests"]
        assert {r["index"] for r in jobs} == set(range(cell["submitted"]))
        p = cell["protected"]
        visible = p["turns"][-1]["content_ns"]
        know_sends = [r["sent_ns"] for r in jobs if "sent_ns" in r]
        overlap = bool(
            visible and know_sends and visible[0] < min(know_sends) < visible[-1]
        )
        warm = cell["post_wave"]
        recovery = warm["status"] == 200 and bool(warm.get("done_ns"))
        response.append(
            {
                "submitted": cell["submitted"],
                "statuses": statuses(jobs),
                "complete": sum(bool(r.get("done_ns")) for r in jobs),
                "peer": peer(p, cfg, history=20),
                "overlaps_peer": overlap,
                "arrivals_during_peer": sum(
                    visible[0] < t < visible[-1] for t in know_sends
                )
                if visible
                else 0,
                "arrival_span_ms": (max(know_sends) - min(know_sends)) / 1e6
                if know_sends
                else None,
                "recovered": recovery,
            }
        )
    a, b = inputs["after"], inputs["before"]
    return {
        "probes": estimates,
        "overload": response,
        "overloads_delta": a["counters"]["overloads"] - b["counters"]["overloads"],
        "idle_after": idle(a),
    }


def route_points(waves, policy):
    route_records = []
    for raw in waves:
        for job in raw["jobs"]:
            for turn in job["work"]["turns"]:
                if turn.get("dispatch") == "application":
                    assert "route" not in turn and "status" not in turn
                    continue
                route = turn["route"]
                slot = route["replica"]
                assert slot in (0, 1) and route["decision_ms"] >= 0
                assert all(
                    math.isclose(
                        score,
                        60 * active + 0.09 * max(0, route["estimated_tokens"] - credit),
                    )
                    for score, active, credit in zip(
                        route["score_ms"],
                        route["active"],
                        route["eligible_estimate"],
                        strict=True,
                    )
                )
                if policy == "session":
                    assert slot == job["index"] % 2
                if policy == "cost":
                    assert route["score_ms"][slot] == min(route["score_ms"])
                route_records.append((turn, route, raw["size"]))
    counts = Counter(str(r["replica"]) for _, r, _ in route_records)
    if policy == "round-robin":
        assert abs(counts["0"] - counts["1"]) <= 1
    c16 = Counter(str(r["replica"]) for _, r, size in route_records if size == 16)
    matches = [t for t, _, _ in route_records if "usage" in t]
    errors = [
        abs(cache_tokens(t) - r["eligible_estimate"][r["replica"]])
        for t, r, _ in route_records
        if "usage" in t
    ]
    return {
        "request_statuses": statuses([t for t, _, _ in route_records]),
        "placements": dict(counts),
        "placements_c16": dict(c16),
        "decision_p50_ms": quantile(
            (r["decision_ms"] for _, r, _ in route_records), 0.5
        ),
        "decision_p95_ms": quantile(r["decision_ms"] for _, r, _ in route_records),
        "actual_cached_tokens": sum(cache_tokens(t) for t in matches),
        "cache_estimate_abs_error_p95_tokens": quantile(errors),
    }


def comparison(arms):
    eligible = all(a["isolation"]["passes"] for a in arms)
    results = []
    for group in (arms[:3], arms[3:]):
        by_policy = {a["policy"]: a["c16"] for a in group}
        cost = by_policy["cost"]
        for name in ("round-robin", "session"):
            base = by_policy[name]
            results.append(
                {
                    "half": group[0]["arm"] // 3,
                    "against": name,
                    "preserves_correctness": set(cost["failed_basic"])
                    <= set(base["failed_basic"]),
                    "reader_first_protected": cost["reader_first_p95_ms"]
                    <= 1.05 * base["reader_first_p95_ms"],
                    "reader_gap_protected": cost["reader_sse_gap_p95_ms"]
                    <= 1.05 * base["reader_sse_gap_p95_ms"],
                    "more_slo_or_lower_p95": cost["slo"] > base["slo"]
                    or cost["last_p95_ms"] < base["last_p95_ms"],
                    "cost_completion_change_ms": cost["last_p95_ms"]
                    - base["last_p95_ms"],
                    "cost_slo_change": cost["slo"] - base["slo"],
                }
            )
    passed = eligible and all(
        all(
            r[k]
            for k in (
                "preserves_correctness",
                "reader_first_protected",
                "reader_gap_protected",
                "more_slo_or_lower_p95",
            )
        )
        for r in results
    )
    return {"pairs": results, "cost_passes_registered_gates": passed}


def sustained(root, cfg, starts, common_cli):
    assert (root / "sustained-exit.log").read_text().strip() == "0"
    for line in (root / "sustained-inputs.sha256").read_text().splitlines():
        digest, name = line.split(maxsplit=1)
        assert sha256((root / name).read_bytes()).hexdigest() == digest
    folder = root / "arm-6-sustained"
    interval = read(folder / "interval.json")
    for gpu in cfg["devices"]:
        directory = folder / f"gpu{gpu}"
        assert (directory / "arguments.txt").read_text() == common_cli
        assert (directory / "binary.sha256").read_text().split()[0] == cfg[
            "binary_sha256"
        ]
        assert (directory / "device.csv").read_text().splitlines()[1].split(",")[
            0
        ] == starts[gpu]["gpu"]
        shutdown = read(directory / "shutdown.json")
        assert idle(shutdown) and not any(shutdown["allocation"].values())
        final = read(root / f"sustained-gpu{gpu}.after.json")
        assert (final["pid"], final["phase"], final["other_processes"]) == (
            starts[gpu]["pid"],
            "idle",
            [],
        )
        records = [
            e
            for line in (root / f"sustained-gpu{gpu}.processes.jsonl")
            .read_text()
            .splitlines()
            if interval["started_ns"]
            <= (e := json.loads(line))["monotonic_ns"]
            <= interval["ended_ns"]
        ]
        own = {a["pid"] for e in records for a in e["apps"] if a["runner_descendant"]}
        other = (
            {a["pid"] for e in records for a in e["apps"]} - own - {starts[gpu]["pid"]}
        )
        assert len(own) == 1 and not other
    trace = read(folder / "sustained-probes.json")
    assert [(r["warm_gpu"], r["repeat"]) for r in trace] == [
        (i, n) for i in cfg["devices"] for n in range(2)
    ]
    requested_peer = freeze(read(root / "frozen-sustained.json")[0], "m")
    requested_peer["max_tokens"] = 192
    peer_fingerprint = fingerprint(requested_peer)
    result = []
    for pair in trace:
        peers = pair["peers"]
        assert len(peers) == 8 and all(
            r["input_sha256"] == peer_fingerprint for r in peers
        )
        a, b = pair["warm"], pair["cold"]
        assert pair["prime"]["input_sha256"] == a["input_sha256"] == b["input_sha256"]
        assert all(r["status"] == 200 and r["done_ns"] for r in (a, b, *peers))
        before = a["sent_ns"]
        ongoing = sum(p["content_ns"][0] < before < p["content_ns"][-1] for p in peers)
        remaining = (min(p["content_ns"][-1] for p in peers) - before) / 1e6
        lengths = [p["usage"]["completion_tokens"] for p in peers]
        delay = {
            k: (r["content_ns"][0] - r["sent_ns"]) / 1e6
            for k, r in (("warm", a), ("cold", b))
        }
        assert a["usage"]["prompt_tokens"] == b["usage"]["prompt_tokens"]
        result.append(
            {
                "warm_gpu": pair["warm_gpu"],
                "repeat": pair["repeat"],
                "peers_overlapped": ongoing,
                "peer_output_tokens": lengths,
                "minimum_time_until_peer_last_ms": remaining,
                "cache_tokens": {"warm": cache_tokens(a), "cold": cache_tokens(b)},
                "first_ms": delay,
                "qualified": ongoing == 8
                and min(lengths) >= 64
                and remaining > delay["cold"],
            }
        )
    return result


def verify(root, profiler, tokenizer, count=None):
    cfg = read(root / "phase04-registration.json")
    full = count is None
    count = len(cfg["policy_order"]) if full else count
    if full:
        assert (root / "exit.log").read_text().strip() == "0"
        assert (root / "model-before.txt").read_bytes() == (
            root / "model-after.txt"
        ).read_bytes()
    for line in (root / "inputs.sha256").read_text().splitlines():
        digest, name = line.split(maxsplit=1)
        assert sha256((root / name).read_bytes()).hexdigest() == digest
    for name in ("tokenizer.json", "tokenizer_config.json"):
        assert (
            f"{sha256((tokenizer / name).read_bytes()).hexdigest()}  {name}"
            in (root / "model-before.txt").read_text()
        )
    assert tuple(cfg["devices"]) == (6, 7)
    starts = {i: read(root / f"gpu{i}.before.json") for i in cfg["devices"]}
    monitors = {
        i: [
            json.loads(line)
            for line in (root / f"gpu{i}.processes.jsonl").read_text().splitlines()
        ]
        for i in cfg["devices"]
    }
    arms, common_tokens, common_cli = [], None, None
    for arm, policy in enumerate(cfg["policy_order"][:count]):
        path = root / f"arm-{arm}-{policy}"
        interval = read(path / "interval.json")
        allocation = 0
        devices = {}
        for gpu in cfg["devices"]:
            d = path / f"gpu{gpu}"
            assert (d / "binary.sha256").read_text().split()[0] == cfg["binary_sha256"]
            assert (d / "device.csv").read_text().splitlines()[1].split(",")[
                0
            ] == starts[gpu]["gpu"]
            matches = [
                e
                for e in monitors[gpu]
                if interval["started_ns"] <= e["monotonic_ns"] <= interval["ended_ns"]
            ]
            owned = {
                app["pid"]
                for e in matches
                for app in e["apps"]
                if app["runner_descendant"]
            }
            other = (
                {app["pid"] for e in matches for app in e["apps"]}
                - owned
                - {starts[gpu]["pid"]}
            )
            assert len(owned) == 1 and not other, (arm, gpu, owned, other)
            devices[gpu] = {
                "samples": len(matches),
                "server_pid": next(iter(owned)),
                "foreign_pids": [],
            }
            assert read(d / "ready.json")["ready"]
            after_lease = read(d / "lease-after.json")
            assert (
                after_lease["pid"],
                after_lease["phase"],
                after_lease["other_processes"],
            ) == (starts[gpu]["pid"], "idle", [])
            shutdown = read(d / "shutdown.json")
            assert idle(shutdown) and not any(shutdown["allocation"].values())
            receipt = read(path / f"allocation-{gpu}.json")
            assert receipt["returncode"] == 0
            allocation += receipt["elapsed_s"]
            cli = (d / "arguments.txt").read_text()
            common_cli = common_cli or cli
            assert cli == common_cli
        raw = read(path / "waves.json")
        waves = application(raw, cfg, application_targets=True)
        points = route_points(raw, policy)
        sig = prompt_ids(profiler, tokenizer, raw)
        common_tokens = common_tokens or sig
        assert sig == common_tokens and len(sig) == sum(n for n, _ in cfg["waves"])
        high = summarize(waves[-2:])
        high["reader_first_p95_ms"] = quantile(
            r["first_ms"]
            for w in waves[-2:]
            for r in w["rows"]
            if r["reader"] and "first_ms" in r
        )
        available = sum(w["duration_s"] for w in waves[-2:]) * len(cfg["devices"])
        high["warm_slo_per_gpu_hour"] = high["slo"] * 3600 / available
        waves_summary = []
        for w in waves:
            summary = summarize([w])
            summary["warm_slo_per_gpu_hour"] /= len(cfg["devices"])
            waves_summary.append(summary)
        arms.append(
            {
                "arm": arm,
                "policy": policy,
                "gpu_monitor": devices,
                "c16": high,
                "waves": waves_summary,
                "allocation_gpu_seconds": allocation,
                "slo_per_allocated_gpu_hour": 3600
                * sum(w["slo"] for w in waves_summary)
                / allocation,
                "routes": points,
                "tenant_orientation": read(path / "tenant-orientation.json"),
                "isolation": isolation(path, cfg),
                **(
                    {"saturation": boundary(path, cfg)}
                    if arm in cfg["boundary_boots"]
                    else {}
                ),
            }
        )
    if full:
        for i, start in starts.items():
            after = read(root / f"gpu{i}.after.json")
            assert (after["pid"], after["phase"], after["other_processes"]) == (
                start["pid"],
                "idle",
                [],
            )
    return {
        "date": "2026-11-26",
        "same_final_input_token_ids": len(common_tokens or {}),
        "arms": arms,
        **({"comparison": comparison(arms)} if full else {}),
        **(
            {"sustained_occupancy": sustained(root, cfg, starts, common_cli)}
            if full and (root / "sustained-exit.log").is_file()
            else {}
        ),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("root", "profiler", "tokenizer"):
        parser.add_argument(name, type=Path)
    parser.add_argument("--completed", type=int)
    a = parser.parse_args()
    print(
        json.dumps(
            verify(a.root, a.profiler, a.tokenizer, a.completed),
            indent=2,
            allow_nan=False,
        )
    )
