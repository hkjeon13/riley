#!/usr/bin/env bash
set -euo pipefail
: "${RILEY_GPU_HOLDER_LEASE_DIR:?}" "${CUDA_VISIBLE_DEVICES:?}"
out=$1
pair=$2
mkdir "$out"
root=$(realpath ../../..)
model="$root/models/Qwen2.5-Coder-7B-Instruct"
binary="$(dirname "$PWD")/prefix-range-20261125.bn73vRNe/server-candidate"
sha256sum "$binary" > "$out/binary.sha256"
test "$(cut -d' ' -f1 "$out/binary.sha256")" = 13b589df5c19a33c685ca1388398905f46a6cc566cbd1bed68f06b798080ca9f
RILEY_TRIAL_KEY=$(cat "$3")
export RILEY_TRIAL_KEY RILEY_SHUTDOWN_METRICS_PATH="$out/shutdown.json"
export LD_LIBRARY_PATH="/usr/local/cuda-12.4/lib64:${LD_LIBRARY_PATH:-}"
args=(serve --bind 127.0.0.1:0 --model "$model" --model-id m --inference-profile native-bf16-varlen-v1
  --max-weight-bytes 68719476736 --max-sequence-tokens 8192 --max-output-tokens 384
  --max-active-sequences 8 --max-waiting-requests 2 --kv-blocks 4096 --prefix-cache-blocks 1536
  --batch-token-budget 1024 --prefill-chunk-tokens 1024
  --batch-shape-buckets 1,2,4,8,16,24,32,48,64,80,96,112,128,144,160,176,192,208,224,240,256,512,1024
  --prefill-burst-steady-budget 256 --prefill-burst-max-decode-rows 0
  --prefill-burst-min-prompt-tokens 512 --api-key-env RILEY_TRIAL_KEY)
printf '%s\n' "${args[@]}" > "$out/arguments.txt"
nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-gpu=uuid,name,driver_version --format=csv > "$out/device.csv"
"$binary" "${args[@]}" > "$out/server.log" 2>&1 &
pid=$!
trap 'if kill -0 "$pid" 2>/dev/null; then kill -TERM "$pid"; fi; wait "$pid"' EXIT
deadline=$((SECONDS+360))
until address=$(sed -nE 's/.*listening on http:\/\/(127\.0\.0\.1:[0-9]+).*/\1/p' "$out/server.log") && [[ -n $address ]]; do
    kill -0 "$pid" && ((SECONDS < deadline)) || exit 1
    sleep .5
done
curl -fsS --max-time 3 "http://$address/readyz" > "$out/ready.json"
printf '%s\n' "$address" > "$out/address.new"
mv "$out/address.new" "$out/address"
deadline=$((SECONDS+850))
until [[ -e $pair/finished ]]; do
    kill -0 "$pid" && ((SECONDS < deadline)) || exit 1
    sleep .25
done
curl -fsS --max-time 5 "http://$address/metrics" > "$out/metrics.json"
