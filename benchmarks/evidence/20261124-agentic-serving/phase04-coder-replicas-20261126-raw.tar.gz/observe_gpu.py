import json
import subprocess
import sys
import time
from pathlib import Path

index, runner = sys.argv[1:]
runner = int(runner)
while Path(f"/proc/{runner}").exists():
    out = subprocess.check_output(["nvidia-smi", "-i", index, "--query-compute-apps=pid,used_memory", "--format=csv,noheader,nounits"], text=True)
    apps = []
    for line in out.splitlines():
        pid, memory = line.split(",")
        pid = int(pid)
        parent = pid
        for _ in range(64):
            if parent in (runner, 0, 1):
                break
            try:
                parent = int(Path(f"/proc/{parent}/stat").read_text().rsplit(")", 1)[1].split()[1])
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                break
        apps.append({"pid": pid, "memory_mib": float(memory), "runner_descendant": parent == runner})
    print(json.dumps({"time_ns": time.time_ns(), "monotonic_ns": time.monotonic_ns(), "apps": apps}), flush=True)
    time.sleep(2)
