"""Run the phase-05 synthetic soak and share an isolated process harness."""
import concurrent.futures
import contextlib
import json
import os
import secrets
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from urllib.request import urlopen

from agent_workflow import fingerprint, replay, stream
from balanced_plan import workload_template
from replica_process import serve
from verify_agent_citations import with_citations

GPU = (6, 7)
ROOT = Path(__file__).resolve().parent
HOLDER = Path("/mnt/efs/nlp/psyche/riley-gap-20261102/evidence/w2-sm17-20261118.6UMfeHh2")
CFG = json.loads((ROOT / "phase05-registration.json").read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def append(sink, value):
    sink.write(json.dumps(value, separators=(",", ":")) + "\n")
    sink.flush()


def status(gpu):
    return json.loads(subprocess.check_output([
        sys.executable, str(HOLDER / "control.py"), "--lease-dir",
        str(HOLDER / "leases"), "--index", str(gpu), "status",
    ]))


def metrics(address):
    with urlopen(f"http://{address}/metrics", timeout=5) as response:
        return json.load(response)


class Pair:
    def __init__(self, path):
        self.path = path
        self.generations = {}
        self.active = {}
        self.in_flight = {}
        self.routes = []
        self.sequence = 0
        self.lock = threading.Lock()

    def __enter__(self):
        self.path.mkdir()
        self.resources = contextlib.ExitStack()
        self.keys = Path(self.resources.enter_context(tempfile.TemporaryDirectory(prefix="riley-phase05-keys-")))
        self.pool = self.resources.enter_context(concurrent.futures.ThreadPoolExecutor(4))
        for gpu in GPU:
            key = self.keys / str(gpu)
            key.write_text(secrets.token_hex(32))
            key.chmod(0o600)
        write(self.path / "holders-before.json", {gpu: status(gpu) for gpu in GPU})
        return self

    def __exit__(self, *_):
        (self.path / "finished").touch()
        try:
            for generation in self.generations.values():
                generation["task"].result(timeout=100)
        finally:
            write(self.path / "routes.json", self.routes)
            write(self.path / "holders-after.json", {gpu: status(gpu) for gpu in GPU})
            self.resources.close()

    def start(self, gpu, name):
        generation = self.generations[name] = {
            "gpu": gpu, "start_ns": time.monotonic_ns(), "key": (self.keys / str(gpu)).read_text(),
        }
        generation["task"] = self.pool.submit(serve, ROOT, HOLDER, self.path, gpu, self.keys, name, "serve-phase05.sh")

    def ready(self, name):
        generation = self.generations[name]
        path = self.path / name
        limit = time.monotonic() + 360
        while not (path / "address").is_file():
            if generation["task"].done():
                generation["task"].result()
                raise RuntimeError(f"{name} exited before ready")
            if time.monotonic() >= limit:
                raise TimeoutError(f"{name} readiness")
            time.sleep(0.05)
        readiness = json.loads((path / "ready.json").read_text())
        if not readiness["ready"] or not readiness["accepting"]:
            raise RuntimeError(f"{name} not accepting: {readiness}")
        generation["address"] = (path / "address").read_text().strip()
        generation["pid"] = int((path / "pid").read_text())
        generation["ready_ns"] = time.monotonic_ns()
        return generation

    def admit(self, name):
        generation = self.generations[name]
        with self.lock:
            assert generation["ready_ns"]
            self.active[generation["gpu"]] = name
            self.in_flight[name] = 0
            t = time.monotonic_ns()
            self.routes.append({"event": "admit", "generation": name, "ns": t})
            return t

    def withdraw(self, name):
        generation = self.generations[name]
        with self.lock:
            del self.active[generation["gpu"]]
            t = time.monotonic_ns()
            self.routes.append({"event": "withdraw", "generation": name, "ns": t, "in_flight": self.in_flight[name]})
            return t

    def retire(self, name):
        with self.lock:
            assert self.in_flight[name] == 0 and name not in self.active.values()
        (self.path / name / "retire").touch()
        self.generations[name]["task"].result(timeout=100)

    def sender(self, workflow, *, on_content=None, on_connect=None):
        def send(_, body, row, visible):
            with self.lock:
                eligible = [self.active[gpu] for gpu in GPU if gpu in self.active]
                if not eligible:
                    raise ConnectionError("no admitted replica")
                name = eligible[self.sequence % len(eligible)]
                row["route"] = {"sequence": self.sequence, "generation": name, "gpu": self.generations[name]["gpu"], "ns": time.monotonic_ns(), "eligible": eligible}
                self.routes.append({"event": "route", "workflow": workflow, "turn": row["turn"], **row["route"]})
                self.sequence += 1
                self.in_flight[name] += 1
            generation = self.generations[name]

            def receive(n):
                if on_content:
                    on_content(n, row)

            try:
                options = on_connect(row) if on_connect else {}
                return stream(generation["address"], body, row, visible, bearer=generation["key"], on_content=receive, **options)
            finally:
                with self.lock:
                    self.in_flight[name] -= 1
        return send


def compact_metrics(address):
    m = metrics(address)
    keys = ("active_requests", "waiting_requests", "kv_allocated_blocks", "prefix_cache", "allocation", "counters")
    return {key: m[key] for key in keys}


def sample(pair, names, stage):
    readings = {}
    for name in names:
        generation = pair.generations[name]
        pid = generation["pid"]
        system = Path(f"/proc/{pid}/status").read_text()
        rss = int(next(line.split()[1] for line in system.splitlines() if line.startswith("VmRSS:")))
        observed = subprocess.check_output(
            ["nvidia-smi", "-i", str(generation["gpu"]), "--query-compute-apps=pid,used_memory", "--format=csv,noheader,nounits"],
            text=True,
        )
        readings[name] = {
            "gpu": generation["gpu"], "rss_kib": rss, "pid": pid,
            "apps": [[int(part) for part in line.split(",")] for line in observed.splitlines()],
            "metrics": compact_metrics(generation["address"]),
        }
    return {"stage": stage, "ns": time.monotonic_ns(), "replicas": readings}


def soak_job(pair, i, scheduled):
    template = workload_template(i)
    kind = "cancel" if template % 19 == 11 else "slow" if template % 17 == 12 else "normal"
    name = f"soak-{i}"
    direct = template % 4 != 0

    def receive(n, row):
        if row["turn"] != 2:
            return
        if kind == "cancel" and n == 4:
            row["client_cancel_ns"] = time.monotonic_ns()
            raise ValueError("scheduled client cancellation")
        if kind == "slow":
            time.sleep(0.03)

    route = pair.sender(name, on_content=receive)

    def send(address, request, row, visible):
        if row["turn"] == 2:
            row["original_request_sha256"] = fingerprint(request)
            request = with_citations(request)
        return route(address, request, row, visible)

    job = replay(
        "", "m", CFG["soak"]["seed_first"] + template,
        96 if template % 3 == 1 else 2,
        (0.5 if template % 4 in (1, 2) else 0.01) if direct else (0.2 if template % 8 == 0 else 0.01),
        name, history=(0, 200, 50)[template % 3], dispatch_fixed_tools=direct,
        send=send,
    )
    return {"index": i, "template": template, "kind": kind, "tenant": "primary" if template * 7 % 5 else "secondary", "scheduled_ns": scheduled, "app_direct": direct, "work": job}


def wait_scheduled(ns):
    time.sleep(max(0, ns - time.monotonic_ns()) / 1e9)


def soak(out):
    with Pair(out) as pair:
        names = [f"soak-gpu{gpu}" for gpu in GPU]
        for gpu, name in zip(GPU, names):
            pair.start(gpu, name)
        for name in names:
            pair.ready(name)
            pair.admit(name)
        write(out / "ready.json", {name: {key: pair.generations[name][key] for key in ("gpu", "start_ns", "ready_ns", "pid")} for name in names})
        cfg = CFG["soak"]
        origin = time.monotonic_ns() + 1_000_000_000
        write(out / "origin.json", {"scheduled_ns": origin, "epoch_offset_ns": time.time_ns() - time.monotonic_ns()})
        stop = threading.Event()

        def observe(sink):
            write(out / "measurement-start.json", sample(pair, names, "before"))
            tick = origin
            while not stop.wait(max(0, tick - time.monotonic_ns()) / 1e9):
                append(sink, sample(pair, names, "running"))
                tick += cfg["sample_seconds"] * 1_000_000_000

        with (out / "rows.jsonl").open("x") as rows, (out / "samples.jsonl").open("x") as samples, concurrent.futures.ThreadPoolExecutor(49) as pool:
            observer = pool.submit(observe, samples)
            pending = []
            offset = 0
            i = 0
            try:
                while offset < cfg["seconds"]:
                    scheduled = origin + round(offset * 1e9)
                    wait_scheduled(scheduled)
                    pending.append(pool.submit(soak_job, pair, i, scheduled))
                    completed = [work for work in pending if work.done()]
                    pending = [work for work in pending if work not in completed]
                    for work in completed:
                        append(rows, work.result())
                    phase = offset % cfg["period_s"]
                    in_peak = cfg["peak_start_s"] <= phase < cfg["peak_start_s"] + cfg["peak_duration_s"]
                    offset += 1 / (cfg["peak_workflows_per_s"] if in_peak else cfg["base_workflows_per_s"])
                    i += 1
                wait_scheduled(origin + cfg["seconds"] * 1_000_000_000)
                for work in concurrent.futures.as_completed(pending):
                    append(rows, work.result())
            finally:
                stop.set()
                observer.result()
        deadline = time.monotonic() + 10
        while True:
            after = sample(pair, names, "drained")
            if all(not any(row["metrics"][key] for key in ("active_requests", "waiting_requests", "kv_allocated_blocks")) for row in after["replicas"].values()):
                break
            if time.monotonic() >= deadline:
                break
            time.sleep(0.1)
        write(out / "measurement-end.json", after)


if __name__ == "__main__":
    soak(Path(sys.argv[1]))
