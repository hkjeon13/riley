"""Apply benchmark-only timestamps to the isolated copy of the pinned server."""
import sys
from pathlib import Path


def replace_one(source, old, new):
    if source.count(old) != 1:
        raise ValueError(f"expected a single source anchor: {old[:100]!r}")
    return source.replace(old, new, 1)


def engine(source):
    source = replace_one(source, "struct RequestControl {", """// Benchmark-only timestamps on Linux CLOCK_MONOTONIC, shared with the client.
#[allow(unsafe_code)]
pub(crate) fn phase05_clock() -> u128 {
    let mut now = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    // SAFETY: the writable timespec lives until clock_gettime returns.
    let result = unsafe { libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut now) };
    assert_eq!(result, 0);
    now.tv_sec as u128 * 1_000_000_000 + now.tv_nsec as u128
}

pub(crate) fn phase05_visible(event: &GenerationEvent) -> bool {
    matches!(event, GenerationEvent::TokenDelta { text } | GenerationEvent::CommittedToken { text, .. } if !text.is_empty())
}

#[derive(Default)]
pub(crate) struct Phase05Timing {
    first: u128,
    last: u128,
    count: u64,
}

impl Phase05Timing {
    pub(crate) fn mark(&mut self, at: u128) {
        if self.count == 0 {
            self.first = at;
        }
        self.last = at;
        self.count += 1;
    }

    pub(crate) fn log(&self, stage: &str, request_id: impl std::fmt::Display) {
        eprintln!("PHASE05_{} {} {} {} {} {}", stage, request_id, self.first,
            self.last, self.count, phase05_clock());
    }
}

struct RequestControl {
    phase05_timing: Phase05Timing,""")
    source = replace_one(source,
        "    fn publish_terminal(&self, event: GenerationEvent) {",
        """    fn publish_terminal(&self, request_id: EngineRequestId, event: GenerationEvent) {
        self.phase05_timing.log("ENGINE", format_args!("cmpl-{:016x}", request_id.get()));""")
    assert source.count("control.publish_terminal(event);") == 2
    source = source.replace("control.publish_terminal(event);", "control.publish_terminal(request_id, event);")
    source = replace_one(source,
        "            } else if let Some(control) = requests.get(&request_id) {\n                outbox.staged.push(StagedEvent {",
        """            } else if let Some(control) = requests.get_mut(&request_id) {
                if phase05_visible(&event) {
                    control.phase05_timing.mark(phase05_clock());
                }
                outbox.staged.push(StagedEvent {""")
    source = replace_one(source,
        "        let Some(control) = requests.get(&request_id) else {\n            continue;\n        };\n        if matches!(\n            control.cancellation",
        """        let Some(control) = requests.get_mut(&request_id) else {
            continue;
        };
        if matches!(
            control.cancellation""")
    source = replace_one(source,
        "        let sent = if matches!(&event, GenerationEvent::TokenDelta { text } if text.is_empty()) {",
        """        if phase05_visible(&event) {
            control.phase05_timing.mark(phase05_clock());
        }
        let sent = if matches!(&event, GenerationEvent::TokenDelta { text } if text.is_empty()) {""")
    assert source.count("                RequestControl {\n") == 1
    source = source.replace("                RequestControl {\n", "                RequestControl {\n                    phase05_timing: Phase05Timing::default(),\n")
    source = source.replace("                super::RequestControl {\n", "                super::RequestControl {\n                    phase05_timing: super::Phase05Timing::default(),\n")
    # The public ID's formatting is part of the join contract.
    assert 'format!("cmpl-{raw_id:016x}")' in source
    return source


def service(source):
    source = replace_one(source, "struct RequestTracker {", """struct RequestTracker {
    phase05_timing: crate::engine::Phase05Timing,""")
    source = replace_one(source, "        Self {\n            metadata,\n            queue_wait,", """        Self {
            phase05_timing: crate::engine::Phase05Timing::default(),
            metadata,
            queue_wait,""")
    source = replace_one(source, "        self.metrics.record_terminal(status, error_class);", """        self.phase05_timing.log("HTTP", &self.metadata.request_id);
        self.metrics.record_terminal(status, error_class);""")
    source = replace_one(source, "                if stream.write_all(frame.as_bytes()).is_err() {", """                if !frame.is_empty() && crate::engine::phase05_visible(&event) {
                    tracker.phase05_timing.mark(crate::engine::phase05_clock());
                }
                if stream.write_all(frame.as_bytes()).is_err() {""")
    return source


if __name__ == "__main__":
    folder = Path(sys.argv[1]) / "crates" / "riley-server" / "src"
    for name, change in (("engine.rs", engine), ("service.rs", service)):
        path = folder / name
        path.write_text(change(path.read_text()))
