"""Verify matched workload pairs, phase boundaries and infrastructure receipts."""
import collections
import json
import statistics
import sys
from pathlib import Path

from verify_citation_soak import verify_requests
from verify_phase05 import lines, percentile, read, result_is_correct, verify_soak

NS_PER_MS = 1_000_000
REPLICAS = ("soak-gpu6", "soak-gpu7")
PHASES = ("scheduled_to_engine_first_ms", "engine_text_span_ms",
          "engine_last_to_http_write_ms", "http_last_write_to_client_last_ms")


def timing_log(path):
    timings = {}
    for line in path.read_text().splitlines():
        if not line.startswith(("PHASE05_ENGINE ", "PHASE05_HTTP ")):
            continue
        phase, response, first, last, count, terminal = line.split()
        key = phase, response
        assert key not in timings, (path, key)
        timings[key] = dict(first=int(first), last=int(last), count=int(count), terminal=int(terminal))
    return timings


def join(rows, folder):
    traces = {name: timing_log(folder / name / "server.log") for name in REPLICAS}
    metrics, errors = {}, []
    for row in rows:
        work = row["work"]
        if not result_is_correct(work):
            continue
        turn = work["turns"][-1]
        replica = turn["route"]["generation"]
        wire_id = turn["response_id"]
        visible = turn["content_ns"]
        engine = traces[replica].get(("PHASE05_ENGINE", wire_id))
        http = traces[replica].get(("PHASE05_HTTP", wire_id))
        if not (engine and http):
            errors.append({"index": row["index"], "id": wire_id, "missing_side": "engine" if not engine else "http"})
            continue
        check_counts = engine["count"] == http["count"] == len(visible)
        check_clocks = (
            row["scheduled_ns"] <= turn["sent_ns"] <= engine["first"] <= http["first"] <= visible[0]
            and engine["first"] <= engine["last"] <= engine["terminal"]
            and engine["last"] <= http["last"] <= visible[-1] <= turn["done_ns"]
            and http["first"] <= http["last"] <= http["terminal"]
        )
        if not check_counts or not check_clocks:
            errors.append({"index": row["index"], "id": wire_id,
                           "engine": engine, "http": http, "client_chunks": len(visible),
                           "checks": {"counts": check_counts, "ordered_clocks": check_clocks}})
            continue
        metrics[row["index"]] = {
            "index": row["index"], "gpu": turn["route"]["gpu"], "client": row["kind"],
            "response_id": wire_id, "chunks": len(visible),
            "scheduled_to_engine_first_ms": (engine["first"] - row["scheduled_ns"]) / NS_PER_MS,
            "engine_text_span_ms": (engine["last"] - engine["first"]) / NS_PER_MS,
            "engine_last_to_http_write_ms": (http["last"] - engine["last"]) / NS_PER_MS,
            "http_last_write_to_client_last_ms": (visible[-1] - http["last"]) / NS_PER_MS,
            "total_last_ms": (visible[-1] - row["scheduled_ns"]) / NS_PER_MS,
            "prompt_tokens": turn["usage"]["prompt_tokens"],
            "cached_tokens": turn["usage"]["prompt_tokens_details"]["cached_tokens"],
            "output_tokens": turn["usage"]["completion_tokens"],
        }
    return metrics, errors, {
        name: dict(collections.Counter(phase for phase, _ in events))
        for name, events in traces.items()
    }


def latency(rows, metrics):
    completion = []
    for row in rows:
        if result_is_correct(row["work"]):
            end = row["work"]["turns"][-1]["content_ns"][-1]
            completion.append((row["index"], (end - row["scheduled_ns"]) / NS_PER_MS))
    p95 = percentile([delay for _, delay in completion], .95)
    observed = [metrics[row["index"]] for row in rows if row["index"] in metrics]
    return {
        "submissions": len(rows),
        "correct": len(completion),
        "client_last_p95_ms": p95,
        "measured_phases": len(observed),
        "phase_p95_ms": {key: percentile([r[key] for r in observed], .95) for key in PHASES},
        "p95_requests": [metrics.get(index, {"index": index}) for index, delay in completion if delay == p95],
    }


def paired(rows, metrics, reg, origin):
    n, start = reg["jobs_per_matched_window"], reg["matched_late_start_index"]
    both = [rows[:n], rows[start:start + n]]
    offset_ns = (reg["window_starts_s"][1] - reg["window_starts_s"][0]) * 1_000_000_000
    pair_receipts = []
    for a, b in zip(*both, strict=True):
        for key in ("tenant", "kind", "app_direct", "template"):
            assert a[key] == b[key]
        for key in ("seed", "fixture_sha256", "history_entries", "document_pairs", "tool_delay_s"):
            assert a["work"][key] == b["work"][key]
        assert b["scheduled_ns"] - a["scheduled_ns"] == offset_ns
        if a["index"] in metrics and b["index"] in metrics:
            early, late = metrics[a["index"]], metrics[b["index"]]
            pair_receipts.append({
                "indices": [a["index"], b["index"]],
                "tenant": a["tenant"], "client": a["kind"],
                "same_gpu": early["gpu"] == late["gpu"],
                "prompt_match": early["prompt_tokens"] == late["prompt_tokens"],
                "cached_token_delta": late["cached_tokens"] - early["cached_tokens"],
                "output_token_delta": late["output_tokens"] - early["output_tokens"],
                "last_ms_delta": late["total_last_ms"] - early["total_last_ms"],
            })
    assert both[0][0]["scheduled_ns"] == origin
    both_profile = {}
    for tenant in ("all", "primary", "secondary"):
        data = {}
        for client in ("all", "normal", "slow"):
            windows = [
                [r for r in period if (tenant == "all" or r["tenant"] == tenant)
                 and (client == "all" or r["kind"] == client)]
                for period in both
            ]
            a, b = [latency(period, metrics) for period in windows]
            data[client] = {"early": a, "late": b, "late_over_early": b["client_last_p95_ms"] / a["client_last_p95_ms"]}
        details = [r for r in pair_receipts if tenant == "all" or r["tenant"] == tenant]
        data["pair_summary"] = {
            "measured_pairs": len(details),
            "same_gpu": sum(r["same_gpu"] for r in details),
            "prompt_match": sum(r["prompt_match"] for r in details),
            "late_more_cached": sum(r["cached_token_delta"] > 0 for r in details),
            "late_less_cached": sum(r["cached_token_delta"] < 0 for r in details),
            "cache_token_delta_range": [min(r["cached_token_delta"] for r in details), max(r["cached_token_delta"] for r in details)],
            "output_token_delta_range": [min(r["output_token_delta"] for r in details), max(r["output_token_delta"] for r in details)],
            "late_last_ms_minus_early_median": statistics.median(r["last_ms_delta"] for r in details),
        }
        both_profile[tenant] = data
    return both_profile, pair_receipts


def verify(path):
    reg = read(path / "balanced-registration.json")
    cfg = read(path / "phase05-registration.json")
    assert cfg["soak"]["seconds"] == reg["duration_s"]
    assert cfg["soak"]["criteria"]["late_completion_p95_over_early_max_ratio_each_tenant"] == reg["ratio_limit"]
    cfg["binary_sha256"] = (path / "trace-server.sha256").read_text().split()[0]
    checkpoint = read(path / "phase04-checkpoint-receipt.json")
    assert (path / "model-checks.txt").read_text().splitlines() == [
        file["path"] + ": OK" for file in checkpoint["files"]
    ]
    assert (path / "model-before.txt").read_bytes() == (path / "model-at-launch.txt").read_bytes()
    out = path / "soak"
    stats = verify_soak(out, cfg)
    request_checks = verify_requests(path)
    rows = sorted(lines(out / "rows.jsonl"), key=lambda row: row["index"])
    origin = read(out / "origin.json")["scheduled_ns"]
    measured, errors, receipt = join(rows, out)
    profiles, pairs = paired(rows, measured, reg, origin)
    matched_window_pass = all(
        profiles[tenant]["all"]["late_over_early"] <= reg["ratio_limit"]
        for tenant in ("primary", "secondary")
    )
    totals = stats["outcomes"]["all"]["all"]
    gates = {
        "existing_gates_except_unmatched_windows": all(
            met for name, met in stats["checks"].items() if name != "late_tenant_completion_p95_within_limit"
        ),
        "matched_window_each_tenant": matched_window_pass,
        "all_successful_finals_join_engine_to_http_to_client": not errors and len(measured) == totals["correct"],
        "each_final_instruction_and_expected_workflow_count": (
            request_checks["final_requests_with_exact_instruction"] == totals["submitted"] == reg["registered_expected_submitted"]
            and totals["cancelled"] == reg["registered_expected_cancellations"]
            and request_checks["unchanged_model_tool_requests"] == 600
            and request_checks["unchanged_app_tool_workflows"] == 900
        ),
    }
    return {
        "registration": reg, "trace_binary_sha256": cfg["binary_sha256"],
        "prior_reanalysis": read(path / "prior-reanalysis.json"),
        "matched_checks": gates, "matched_run_passed": all(gates.values()),
        "historical_unmatched_window_pass": stats["checks"]["late_tenant_completion_p95_within_limit"],
        "soak": stats, "request_checks": request_checks, "traced_final_count": len(measured),
        "trace_count_by_gpu_and_stage": receipt, "trace_errors": errors,
        "matched_window_profiles": profiles, "pair_details": pairs,
    }


if __name__ == "__main__":
    print(json.dumps(verify(Path(sys.argv[1])), indent=2))
