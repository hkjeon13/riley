"""Reanalyze the original phase-05 raw records using a common workload mix."""
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
import json
import sys

from verify_phase05 import lines, percentile, read, result_is_correct


def workload(row, origin):
    work = row["work"]
    if row["tenant"] != "secondary" or not result_is_correct(work):
        return None
    turn = work["turns"][-1]
    offset = (row["scheduled_ns"] - origin) / 1e9
    first, last = turn["content_ns"][0], turn["content_ns"][-1]
    return {
        "index": row["index"], "kind": row["kind"], "app_direct": row["app_direct"],
        "history": work["history_entries"], "pairs": work["document_pairs"],
        "burst": 120 <= offset % 180 < 140, "offset": offset,
        "prompt_tokens": turn["usage"]["prompt_tokens"],
        "output_tokens": turn["usage"]["completion_tokens"],
        "last_ms": (last - row["scheduled_ns"]) / 1e6,
        "sent_to_first_ms": (first - turn["sent_ns"]) / 1e6,
        "first_to_last_ms": (last - first) / 1e6,
        "client_chunks": len(turn["content_ns"]),
    }


def windows(rows, width):
    return ([r for r in rows if r["offset"] < width],
            [r for r in rows if r["offset"] >= 1800 - width])


def key(row):
    return tuple(row[k] for k in ("kind", "history", "pairs", "burst", "app_direct"))


def grouped(rows):
    result = defaultdict(list)
    for row in rows:
        result[key(row)].append(row)
    return result


def weighted_p95(groups, weights):
    samples = sorted(
        (r["last_ms"], Fraction(n, len(groups[k])))
        for k, n in weights.items() for r in groups[k]
    )
    rank = Fraction(95, 100) * sum(weights.values())
    accumulated = Fraction(0)
    for value, weight in samples:
        accumulated += weight
        if accumulated >= rank:
            return value
    raise ValueError("no comparable latency samples")


def profile(rows):
    last = [r["last_ms"] for r in rows]
    observed = percentile(last, .95)
    return {
        "n": len(rows),
        "last_p95_ms": observed,
        "first_to_last_p95_ms": percentile([r["first_to_last_ms"] for r in rows], .95),
        "sent_to_first_p95_ms": percentile([r["sent_to_first_ms"] for r in rows], .95),
        "p95_rows": [r for r in rows if r["last_ms"] == observed],
    }


def matched(early, late):
    a, b = grouped(early), grouped(late)
    weights = {k: min(len(a[k]), len(b[k])) for k in a.keys() & b.keys()}
    cells = []
    for k in sorted(a.keys() | b.keys()):
        if k not in weights:
            continue
        cells.append({
            "stratum": list(k),
            "early_n": len(a[k]), "late_n": len(b[k]), "common_weight": weights[k],
            "early_last_ms_p95": percentile([r["last_ms"] for r in a[k]], .95),
            "late_last_ms_p95": percentile([r["last_ms"] for r in b[k]], .95),
        })
    ep95, lp95 = weighted_p95(a, weights), weighted_p95(b, weights)
    return {
        "weights_per_side": sum(weights.values()),
        "early_n_supported": sum(len(a[k]) for k in weights), "late_n_supported": sum(len(b[k]) for k in weights),
        "early_last_p95_ms": ep95, "late_last_p95_ms": lp95, "late_over_early": lp95 / ep95,
        "strata": cells,
    }


def analysis(path):
    path = path / "soak"
    origin = read(path / "origin.json")["scheduled_ns"]
    rows = [reg for raw in lines(path / "rows.jsonl") if (reg := workload(raw, origin)) is not None]
    report = {}
    for width in (600, 540):
        a, b = windows(rows, width)
        report[width] = {
            "by_class": {
                label: [
                    profile([r for r in period if label == "all" or r["kind"] == label])
                    for period in (a, b)
                ] for label in ("all", "normal", "slow")
            },
            "common_mix": matched(a, b),
        }
    return report


if __name__ == "__main__":
    original, explicit = map(Path, sys.argv[1:])
    print(json.dumps({"original": analysis(original), "explicit": analysis(explicit)}, indent=2))
