#!/usr/bin/env bash
set -euo pipefail
until [[ -f build-exit ]]; do sleep 5; done
test "$(cat build-exit)" = 0
sha256sum -c inputs.sha256 trace-server.sha256
root=$(realpath ../../..)
model="$root/models/Qwen2.5-Coder-7B-Instruct"
(cd "$model" && stat --printf '%n %s %i %Y\n' ./model-*.safetensors && sha256sum config.json tokenizer.json tokenizer_config.json model.safetensors.index.json riley-checkpoint.json) > model-at-launch.txt
cmp model-before.txt model-at-launch.txt
nvidia-smi -i 6,7 --query-gpu=index,uuid,name,driver_version --format=csv > devices.csv
date -Is > run-start-time
rc=0
python3 -u run_phase05_soak.py "$PWD/soak" > soak.log 2>&1 || rc=$?
date -Is > run-end-time
printf '%s\n' "$rc" > soak-exit.new
mv soak-exit.new soak-exit
if [[ $rc = 0 ]]; then
  checksum_rc=0
  manifest="$PWD/model-registered.sha256"
  (cd "$model" && sha256sum -c "$manifest") > model-checks.txt 2>&1 || checksum_rc=$?
  printf '%s\n' "$checksum_rc" > checkpoint-exit.new
  mv checkpoint-exit.new checkpoint-exit
fi
