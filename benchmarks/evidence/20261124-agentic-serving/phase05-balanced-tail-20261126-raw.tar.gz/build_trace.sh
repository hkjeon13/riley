#!/usr/bin/env bash
set -euo pipefail
trap 'rc=$?; printf "%s\n" "$rc" > build-exit.new; mv build-exit.new build-exit' EXIT
root=$(realpath ../../..)
prior="$(dirname "$PWD")/prefix-range-20261125.bn73vRNe"
sha256sum "$prior/server-candidate" > stock-binary.sha256
test "$(cut -d ' ' -f1 stock-binary.sha256)" = 13b589df5c19a33c685ca1388398905f46a6cc566cbd1bed68f06b798080ca9f
test -d "$prior/src/crates/riley-server/src"
cp -a "$prior/src" trace-src
(cd "$prior/src"; find . -type f -print0 | sort -z | xargs -0 sha256sum) > stock-source-files.sha256
python3 -B apply_phase05_trace.py trace-src
rc=0
diff -u --label a/crates/riley-server/src/engine.rs --label b/crates/riley-server/src/engine.rs "$prior/src/crates/riley-server/src/engine.rs" trace-src/crates/riley-server/src/engine.rs > phase05-trace.patch || rc=$?
test "$rc" = 1
rc=0
diff -u --label a/crates/riley-server/src/service.rs --label b/crates/riley-server/src/service.rs "$prior/src/crates/riley-server/src/service.rs" trace-src/crates/riley-server/src/service.rs >> phase05-trace.patch || rc=$?
test "$rc" = 1
export PATH="$root/tools/rustup/toolchains/1.85.0-x86_64-unknown-linux-gnu/bin:/usr/local/cuda-12.4/bin:$PATH"
export CARGO_HOME="$root/tools/cargo" CUDA_HOME=/usr/local/cuda-12.4 CUDAToolkit_ROOT=/usr/local/cuda-12.4
export LD_LIBRARY_PATH=/usr/local/cuda-12.4/lib64 RILEY_CUDA_ARCHITECTURES=80
export CMAKE_BUILD_PARALLEL_LEVEL=2 CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CUDA_VISIBLE_DEVICES=
export CARGO_TARGET_DIR="$PWD/trace-target"
(cd trace-src; cargo build --offline --locked --release -p riley-server --features server,cuda --bin riley)
cp trace-target/release/riley trace-server
sha256sum trace-server > trace-server.sha256
