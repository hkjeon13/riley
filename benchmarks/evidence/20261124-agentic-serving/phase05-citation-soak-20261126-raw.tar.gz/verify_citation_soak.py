"""Verify the citation-only replay with the unchanged phase-05 acceptance gate."""
import hashlib
import re
import sys
from pathlib import Path

from agent_workflow import append_tool_result, fingerprint, fixture, history_messages, percentile, turn_request
from verify_agent_citations import INSTRUCTION, with_citations
from verify_phase05 import lines, read, result_is_correct, verify_soak


def verify_requests(folder):
    sent = finals = formatted = 0
    by_path = {"app": {"submitted": 0, "correct": 0}, "model": {"submitted": 0, "correct": 0}}
    locations = []
    for row in lines(folder / "soak" / "rows.jsonl"):
        work = row["work"]
        direct = row["app_direct"]
        counts = by_path["app" if direct else "model"]
        counts["submitted"] += 1
        ok = result_is_correct(work)
        counts["correct"] += int(ok)
        tools, prompt, docs = fixture(work["seed"], work["document_pairs"])
        assert work["fixture_sha256"] == fingerprint([prompt, docs])
        messages = history_messages(work["seed"], work["history_entries"]) + [
            {"role": "user", "content": prompt}
        ]
        for turn, name in zip(work["turns"], ("list_reports", "read_reports", None)):
            base = turn_request("m", messages, tools, name)
            if name is None:
                finals += 1
                assert turn["original_request_sha256"] == fingerprint(base)
                assert turn["input_sha256"] == fingerprint(with_citations(base))
                if ok:
                    answer = turn["answer"].lower().replace("*", "").replace("`", "")
                    paired = all(
                        re.search(rf"\b{doc['p95_ms']}\s*ms\s*\(\s*{re.escape(doc['id'].lower())}\s*\)", answer)
                        for doc in docs
                    )
                    formatted += int(paired)
                    if work["seed"] == 6143:
                        locations.append({
                            "seed": work["seed"], "correct": ok, "both_ids_after_measurements": paired,
                            "gpu": turn["route"]["gpu"], "answer": turn["answer"],
                        })
                continue
            if direct:
                assert turn["planned_request_sha256"] == fingerprint(base)
                assert "input_sha256" not in turn
            else:
                assert turn["input_sha256"] == fingerprint(base)
                sent += 1
            if "tool_ready_ns" in turn:
                append_tool_result(messages, [turn["call"]], docs, turn["turn"])
    return {
        "final_requests_with_exact_instruction": finals,
        "unchanged_model_tool_requests": sent,
        "unchanged_app_tool_workflows": by_path["app"]["submitted"],
        "right_before_and_after_ids_in_parentheses_adjacent_to_measurements": formatted,
        "workflow_results_by_tool_path": by_path,
        "prior_failure_seed_rule": locations,
    }


def secondary_window_tail(folder, seconds):
    soak = folder / "soak"
    origin = read(soak / "origin.json")["scheduled_ns"]
    windows = {"early": [], "late": []}
    for row in lines(soak / "rows.jsonl"):
        work = row["work"]
        if row["tenant"] != "secondary" or not result_is_correct(work):
            continue
        offset = (row["scheduled_ns"] - origin) / 1e9
        if seconds / 3 <= offset < seconds * 2 / 3:
            continue
        end = work["turns"][-1]["content_ns"][-1]
        windows["early" if offset < seconds / 3 else "late"].append({
            "index": row["index"], "client": row["kind"],
            "last_ms": (end - row["scheduled_ns"]) / 1e6,
        })
    result = {}
    for label, window in windows.items():
        p95_ms = percentile([row["last_ms"] for row in window], .95)
        result[label] = {
            "valid": len(window),
            "slow_reads": sum(row["client"] == "slow" for row in window),
            "p95_requests": [row for row in window if row["last_ms"] == p95_ms],
        }
    return result


def summarize(folder):
    reg = read(folder / "citation-soak-registration.json")
    assert INSTRUCTION == reg["final_instruction"]
    config = read(folder / "phase05-registration.json")
    assert config["soak"]["seconds"] == reg["arrival_seconds"]
    before = folder / "baseline-verified.json"
    assert hashlib.sha256(before.read_bytes()).hexdigest() == reg["baseline_verified_sha256"]
    baseline = read(before)
    checkpoint = read(folder / "phase04-checkpoint-receipt.json")
    assert (folder / "model-checks.txt").read_text().splitlines() == [
        item["path"] + ": OK" for item in checkpoint["files"]
    ]
    candidate = verify_soak(folder / "soak", config)
    checked = verify_requests(folder)
    totals = candidate["outcomes"]["all"]["all"]
    baseline_totals = baseline["soak"]["outcomes"]["all"]["all"]
    assert totals["submitted"] == reg["workflow_count"]
    assert totals["cancelled"] == reg["expected_cancellations"]
    request_coverage = (
        checked["final_requests_with_exact_instruction"] == reg["workflow_count"]
        and checked["unchanged_model_tool_requests"] == 600
        and checked["unchanged_app_tool_workflows"] == 900
    )
    return {
        "registration": reg,
        "provenance": baseline["provenance"],
        "matched_request_checks": checked,
        "request_coverage_passed": request_coverage,
        "baseline_outcomes": baseline["soak"]["outcomes"],
        "baseline_slo_failure_seeds": [r["seed"] for r in baseline["soak"]["non_slo_noncancel_jobs"]],
        "soak": candidate,
        "secondary_p95_observations": secondary_window_tail(folder, reg["arrival_seconds"]),
        "change": {
            "slo_completed_count": totals["slo"] - baseline_totals["slo"],
            "first_p95_ms": totals["first_ms"] - baseline_totals["first_ms"],
            "last_p95_ms": totals["last_ms"] - baseline_totals["last_ms"],
            "gap_p95_ms": totals["gap_ms"] - baseline_totals["gap_ms"],
        },
        "passed": candidate["passed"] and request_coverage and totals["slo"] == reg["expected_correct_and_slo"],
    }


if __name__ == "__main__":
    import json

    print(json.dumps(summarize(Path(sys.argv[1])), indent=2))
