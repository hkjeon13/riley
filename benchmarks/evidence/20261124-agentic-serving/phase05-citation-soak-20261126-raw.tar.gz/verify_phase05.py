"""Recompute phase-05 gates from raw client, routing, allocator and process receipts."""
import collections
import json
import re
import sqlite3
import statistics
import sys
from pathlib import Path

from agent_workflow import fingerprint, fixture, fixture_tool_result, percentile

NS = 1_000_000_000
GPU = (6, 7)
GAUGES = ("active_requests", "waiting_requests", "kv_allocated_blocks")


def read(path):
    return json.loads(path.read_text())


def lines(path):
    with path.open() as records:
        return [json.loads(line) for line in records]


def plan(cfg):
    offsets = []
    offset = 0
    while offset < cfg["seconds"]:
        offsets.append(offset)
        phase = offset % cfg["period_s"]
        peak = cfg["peak_start_s"] <= phase < cfg["peak_start_s"] + cfg["peak_duration_s"]
        offset += 1 / (cfg["peak_workflows_per_s"] if peak else cfg["base_workflows_per_s"])
    return offsets


def result_is_correct(work):
    if len(work["turns"]) != 3:
        return False
    *tool_turns, last = work["turns"]
    _, _, docs = fixture(work["seed"], work["document_pairs"])
    ids = [doc["id"] for doc in docs]
    for index, (turn, name, args) in enumerate(zip(
        tool_turns, ("list_reports", "read_reports"),
        ({}, {"first": ids[0], "second": ids[1]}),
    )):
        call = turn.get("call", {})
        function = call.get("function", {})
        if (
            not call.get("id") or function.get("name") != name
            or json.loads(function["arguments"]) != args
            or not turn["tool_start_ns"] <= turn["tool_ready_ns"]
        ):
            return False
        if turn.get("dispatch") != "application" and (
            turn.get("status") != 200 or turn.get("finish") not in ("tool_calls", "stop")
            or "done_ns" not in turn or turn.get("observed_calls") != [call]
        ):
            return False
    if (
        last.get("status") != 200 or last.get("finish") != "stop"
        or last.get("usage", {}).get("completion_tokens", 0) < 64
        or not last.get("content_ns") or last.get("done_ns", 0) < last["content_ns"][-1]
    ):
        return False
    before, after = (doc["p95_ms"] for doc in docs)
    plain = last.get("answer", "").replace("*", "").lower()
    return all(
        re.search(rf"\b{label}\s*:\s*{value}\s*ms\b", plain)
        for label, value in zip(("before", "after", "reduction"), (before, after, before - after))
    ) and all(doc.lower() in plain for doc in ids)


def verify_routes(path, works, ready):
    events = read(path / "routes.json")
    active = {}
    decisions = []
    route_map = {}
    for event in events:
        name, ns = event["generation"], event["ns"]
        gpu = ready[name]["gpu"]
        if event["event"] == "admit":
            assert name not in active.values() and gpu not in active and ns >= ready[name]["ready_ns"]
            active[gpu] = name
        elif event["event"] == "withdraw":
            assert active.pop(gpu) == name
        else:
            eligible = [active[gpu] for gpu in GPU if gpu in active]
            assert event["sequence"] == len(decisions)
            assert event["eligible"] == eligible and name == eligible[len(decisions) % len(eligible)]
            assert event["gpu"] == gpu
            decisions.append(event)
            route_map[event["sequence"]] = event
    request_count = 0
    for work in works:
        for turn in work["turns"]:
            if "route" not in turn:
                continue
            record = route_map.pop(turn["route"]["sequence"])
            assert record["workflow"] == work["workflow_id"] and record["turn"] == turn["turn"]
            assert all(record[key] == val for key, val in turn["route"].items())
            assert turn.get("sent_ns", record["ns"]) >= record["ns"]
            request_count += 1
    assert not route_map
    return {
        "model_requests": request_count,
        "requests_by_gpu": dict(collections.Counter(row["gpu"] for row in decisions)),
        "admissions_by_generation": dict(collections.Counter(row["generation"] for row in decisions)),
        "withdrawn_or_unready_admissions": 0,
    }


def zero(metrics):
    return all(metrics[key] == 0 for key in GAUGES)


def clean_lease(lease):
    return lease["phase"] == "idle" and lease["allocation_bytes"] == 20 * 1024**3 and not lease["other_processes"]


def releases(path, cfg, generations):
    holders_before = read(path / "holders-before.json")
    holders_after = read(path / "holders-after.json")
    assert holders_before.keys() == holders_after.keys() == {"6", "7"}
    shutdown, lease_after, allocation_s = {}, {}, {}
    for name in generations:
        folder = path / name
        allocation = read(path / f"allocation-{name}.json")
        assert allocation["returncode"] == 0
        assert (folder / "binary.sha256").read_text().split()[0] == cfg["binary_sha256"]
        assert (folder / "arguments.txt").read_bytes() == (path.parent / "phase04-arguments.txt").read_bytes()
        assert read(folder / "ready.json").get("ready") and read(folder / "ready.json").get("accepting")
        allocation_s[name] = allocation["elapsed_s"]
        lease = read(folder / "lease-after.json")
        lease_after[name] = clean_lease(lease) and all(
            lease[key] == holders_before[str(lease["physical_index"])][key]
            for key in ("pid", "start_ticks", "gpu")
        )
        if not (folder / "fault-exit-code").is_file():
            record = read(folder / "shutdown.json")
            shutdown[name] = zero(record) and not any(record["allocation"].values())
    holders_restored = all(
        clean_lease(holders_before[gpu]) and clean_lease(lease) and all(
            lease[key] == holders_before[gpu][key] for key in ("pid", "start_ticks", "gpu")
        )
        for gpu, lease in holders_after.items()
    )
    return {
        "leases_restored": holders_restored,
        "lease_after_each_generation": lease_after,
        "normal_shutdown_reclaimed": shutdown,
        "assigned_s": allocation_s,
    }


def aggregate(rows):
    good = [row for row in rows if row["correct"]]
    return {
        "submitted": len(rows),
        "correct": len(good),
        "cancelled": sum(row["cancelled"] for row in rows),
        "slo": sum(row["slo"] for row in rows),
        **{key: percentile([row[key] for row in good], .95) for key in ("first_ms", "last_ms", "gap_ms")},
    }


def peak_concurrency(intervals):
    active = maximum = 0
    events = [(start, 1) for start, _ in intervals] + [
        (end, -1) for _, end in intervals
    ]
    for _, change in sorted(events):
        active += change
        maximum = max(active, maximum)
    return maximum


def verify_soak(path, cfg):
    config = cfg["soak"]
    rows = sorted(lines(path / "rows.jsonl"), key=lambda row: row["index"])
    expected = plan(config)
    origin_receipt = read(path / "origin.json")
    origin = origin_receipt["scheduled_ns"]
    before = read(path / "measurement-start.json")
    after = read(path / "measurement-end.json")
    measured = lines(path / "samples.jsonl")
    samples = [before, *measured, after]
    ready = read(path / "ready.json")
    route = verify_routes(path, [row["work"] for row in rows], ready)
    release = releases(path, cfg, ready)
    statuses = collections.Counter()
    outcomes = []
    errors = []
    distribution = collections.Counter()
    prompt_tokens, output_tokens = [], []
    latencies = config["slo_ms"]
    for i, row in enumerate(rows):
        kind = "cancel" if i % 19 == 11 else "slow" if i % 17 == 12 else "normal"
        direct = i % 4 != 0
        tenant = "primary" if i * 7 % 5 else "secondary"
        assert row["tenant"] == tenant and row["index"] == i and row["kind"] == kind
        assert row["app_direct"] == direct
        assert row["scheduled_ns"] == origin + round(expected[i] * NS)
        work = row["work"]
        assert work["seed"] == config["seed_first"] + i
        assert work["history_entries"] == (0, 200, 50)[i % 3]
        assert work["document_pairs"] == (96 if i % 3 == 1 else 2)
        assert work["tool_delay_s"] == ((0.5 if i % 4 in (1, 2) else 0.01) if direct else (0.2 if i % 8 == 0 else 0.01))
        for turn in work["turns"]:
            if "route" in turn:
                statuses[str(turn.get("status", "transport_failure"))] += 1
        last = work["turns"][-1]
        cancelled = (
            kind == "cancel" and last["turn"] == 2 and "client_cancel_ns" in last
            and last["status"] == 200 and len(last["content_ns"]) == 4 and "done_ns" not in last
        )
        correct = result_is_correct(work)
        assert correct == work["ok"]
        outcome = {"tenant": tenant, "kind": kind, "offset": expected[i], "cancelled": cancelled,
                   "correct": correct, "lag_ms": (work["start_ns"] - row["scheduled_ns"]) / 1e6, "slo": False}
        distribution["app" if direct else "model"] += 1
        if correct:
            times = last["content_ns"]
            outcome["first_ms"] = (times[0] - row["scheduled_ns"]) / 1e6
            outcome["last_ms"] = (times[-1] - row["scheduled_ns"]) / 1e6
            outcome["gap_ms"] = percentile([(b - a) / 1e6 for a, b in zip(times, times[1:])], .95)
            outcome["slo"] = all(outcome[key + "_ms"] <= latencies[limit] for key, limit in (
                ("first", "first"), ("last", "last"), ("gap", "gap_p95"),
            ))
            prompt_tokens.append(last["usage"]["prompt_tokens"])
            output_tokens.append(last["usage"]["completion_tokens"])
        if not (outcome["slo"] or cancelled):
            errors.append({"index": i, "tenant": tenant, "kind": kind, "seed": work["seed"],
                           "correct": correct, "error": work.get("error"), "outcome": outcome})
        outcomes.append(outcome)
    overall = aggregate(outcomes)
    slices = {}
    for label in ("all", "primary", "secondary"):
        same_tenant = [row for row in outcomes if label == "all" or row["tenant"] == label]
        slices[label] = {
            "all": aggregate(same_tenant),
            "early": aggregate([r for r in same_tenant if r["offset"] < config["seconds"] / 3]),
            "late": aggregate([r for r in same_tenant if r["offset"] >= 2 * config["seconds"] / 3]),
        }
    groups = {
        "by_client": {label: aggregate([row for row in outcomes if row["kind"] == label]) for label in ("normal", "slow", "cancel")},
        "by_load": {
            "baseline": aggregate([row for row in outcomes if not config["peak_start_s"] <= row["offset"] % config["period_s"] < config["peak_start_s"] + config["peak_duration_s"]]),
            "burst": aggregate([row for row in outcomes if config["peak_start_s"] <= row["offset"] % config["period_s"] < config["peak_start_s"] + config["peak_duration_s"]]),
        },
    }
    holders = read(path / "holders-before.json")
    foreign = []
    listed = {}
    delta = collections.Counter()
    for name in ready:
        series = [sample["replicas"][name] for sample in samples]
        start, stop = series[0]["metrics"], series[-1]["metrics"]
        gauges = {key: max(reading["metrics"][key] for reading in series) for key in GAUGES}
        counters = {key: stop["counters"][key] - start["counters"][key] for key in stop["counters"]}
        delta.update(counters)
        listed[name] = {
            "peaks": gauges,
            "after_drain": {key: stop[key] for key in GAUGES},
            "retained_prefix_blocks_after_drain": stop["prefix_cache"]["retained_blocks"],
            "retained_prefix_blocks_peak": max(reading["metrics"]["prefix_cache"]["retained_blocks"] for reading in series),
            "allocation_bytes_observed": sorted({reading["metrics"]["allocation"]["device_live_bytes"] for reading in series}),
            "pinned_bytes_observed": sorted({reading["metrics"]["allocation"]["pinned_live_bytes"] for reading in series}),
            "host_rss_kib_median_first_minute": statistics.median(x["rss_kib"] for x in series[1:7]),
            "host_rss_kib_median_last_minute": statistics.median(x["rss_kib"] for x in series[-7:-1]),
            "host_rss_kib_max": max(x["rss_kib"] for x in series),
            "counter_deltas": counters,
        }
        expected_pids = {int(holders[str(ready[name]["gpu"])]["pid"]), ready[name]["pid"]}
        foreign.extend(
            {"ns": obs["ns"], "generation": name, "pid": pid}
            for obs, reading in zip(samples, series) for pid, _ in reading["apps"] if pid not in expected_pids
        )
    lag = percentile([r["lag_ms"] for r in outcomes], .95)
    times = [sample["ns"] for sample in samples]
    span = (after["ns"] - origin) / NS
    criteria = config["criteria"]
    ratios = {label: values["late"]["last_ms"] / values["early"]["last_ms"] for label, values in slices.items()}
    checks = {
        "registered_schedule_complete": len(rows) == len(expected) == criteria["expected"] and span >= config["seconds"],
        "all_noncancel_correct_and_slo": len(rows) - overall["cancelled"] == overall["correct"] == overall["slo"],
        "all_scheduled_cancels_observed": overall["cancelled"] == criteria["intended_cancels"],
        "no_http_or_scheduler_rejects": set(statuses) == {"200"} and delta["overloads"] == 0,
        "counter_deltas_match_cancelled": delta["disconnects"] == delta["cancellations"] == overall["cancelled"],
        "device_bytes_steady": all(len(value["allocation_bytes_observed"]) == 1 for value in listed.values()),
        "resource_gauges_returned_to_zero": all(zero(s["metrics"]) for s in after["replicas"].values()) and all(release["normal_shutdown_reclaimed"].values()),
        "holders_restored": release["leases_restored"] and all(release["lease_after_each_generation"].values()),
        "dispatch_lag_p95_within_limit": lag <= criteria["max_dispatch_lag_p95_ms"],
        "late_tenant_completion_p95_within_limit": all(ratios[label] <= criteria["late_completion_p95_over_early_max_ratio_each_tenant"] for label in ("primary", "secondary")),
        "no_external_gpu_apps_in_samples": not foreign,
    }
    assigned_s = sum(release["assigned_s"].values())
    return {
        "checks": checks, "passed": all(checks.values()), "outcomes": slices, **groups,
        "non_slo_noncancel_jobs": errors, "dispatch_lag_p95_ms": lag,
        "route": route, "http_statuses": dict(statuses), "workflows_by_tool_path": dict(distribution),
        "successful_final_input_tokens": [min(prompt_tokens), max(prompt_tokens)],
        "successful_final_output_tokens": [min(output_tokens), max(output_tokens)],
        "peak_client_workflows_in_flight": peak_concurrency([
            (row["work"]["start_ns"], row["work"]["end_ns"]) for row in rows
        ]),
        "late_over_early_last_p95": ratios, "observed_s": span, "sample_count": len(samples),
        "scheduled_epoch_ns": origin + origin_receipt["epoch_offset_ns"],
        "max_sample_gap_s": max((b - a) / NS for a, b in zip(times, times[1:])),
        "replica_observations": listed, "foreign_compute_receipts": foreign, "release": release,
        "all_assigned_gpu_seconds": assigned_s,
        "all_assigned_gpu_seconds_per_success": assigned_s / overall["correct"],
        "all_assigned_slo_goodput_per_gpu_hour": 3600 * overall["slo"] / assigned_s,
        "warm_slo_goodput_per_gpu_hour": 3600 * overall["slo"] / (len(GPU) * span),
    }


def operation_works(record):
    planned = record["planned"]
    for key in ("drained", "newly_routed", "while_waiting"):
        yield planned[key]
    yield from planned["after_rejoin"]
    for raw in record["faults"]:
        if raw["pre_alignment"]:
            yield raw["pre_alignment"]
        for key in ("interrupted", "recovered", "persisted_retry"):
            yield raw[key]
        yield from raw["after_rejoin"]


def verify_ops(path, cfg):
    record = read(path / "observations.json")
    planned = record["planned"]
    faults = record["faults"]
    assert [raw["scenario"] for raw in faults] == ["before-content", "partial-content", "completed-tool-call"]
    ready = dict(zip(("old-6", "peer-7"), record["initial"]))
    for raw in [planned, *faults]:
        ready[raw["replacement"]] = raw["replacement_ready"]
    route = verify_routes(path, operation_works(record), ready)
    release = releases(path, cfg, ready)
    limit = cfg["operations"]["criteria"]
    drained = planned["drained"]["turns"][-1]
    survivor = "peer-7"
    replacement = planned["replacement"]
    planned_checks = {
        "in_flight_completed_after_withdrawal": result_is_correct(planned["drained"])
        and drained["route"]["generation"] == planned["old"]
        and drained["content_ns"][0] < planned["withdrawn_ns"] < drained["content_ns"][-1] <= drained["done_ns"],
        "withdrawn_replica_retired": planned["old_closed"],
        "new_requests_routed_to_peer_only_during_drain_and_load": all(
            result_is_correct(work) and work["turns"][-1]["route"]["generation"] == survivor
            for work in (planned["newly_routed"], planned["while_waiting"])
        ) and planned["replacement_ready"]["start_ns"] <= planned["while_waiting"]["start_ns"] < planned["replacement_ready"]["ready_ns"]
        and planned["withdrawn_ns"] < planned["newly_routed"]["turns"][-1]["route"]["ns"] < drained["done_ns"],
        "dual_capacity_restored": all(result_is_correct(work) for work in planned["after_rejoin"])
        and {work["turns"][-1]["route"]["generation"] for work in planned["after_rejoin"]} == {survivor, replacement},
    }
    planned_ready_s = (ready[replacement]["ready_ns"] - ready[replacement]["start_ns"]) / NS
    planned_checks["replacement_ready_within_limit"] = planned_ready_s <= limit["replacement_ready_max_s"]
    database = sqlite3.connect(f"file:{path / 'actions.sqlite'}?mode=ro", uri=True)
    try:
        durable = collections.defaultdict(list)
        for workflow, turn, payload, result in database.execute("SELECT workflow,turn,payload,result FROM action ORDER BY workflow,turn"):
            durable[workflow].append((turn, json.loads(payload), json.loads(result)))
    finally:
        database.close()
    assessed = []
    for raw in faults:
        scenario = raw["scenario"]
        failed = raw["failed_generation"]
        peer = raw["peer_generation"]
        new = raw["replacement"]
        incomplete = raw["interrupted"]
        cut = incomplete["turns"][-1]
        cut_chunks = len(cut.get("content_ns", []))
        kill = raw["kill_epoch_ns"] - raw["clock"]["epoch_offset_ns"]
        recovered = raw["recovered"]
        post = raw["after_rejoin"]
        workflow = raw["logical_id"]
        start = raw["replacement_ready"]["start_ns"]
        replacement_ready_s = (ready[new]["ready_ns"] - start) / NS
        recovered_s = (recovered["turns"][-1]["done_ns"] - kill) / NS if "done_ns" in recovered["turns"][-1] else None
        full_capacity_ready_s = (raw["replacement_admitted_ns"] - kill) / NS
        full_capacity_proven_s = (max(w["end_ns"] for w in post) - kill) / NS
        expected_original_effects = [] if scenario == "completed-tool-call" else [True, True]
        expected_recovery_effects = [True, True] if scenario == "completed-tool-call" else [False, False]
        expected_commits = [expected_original_effects, expected_recovery_effects, [False, False]]
        _, _, docs = fixture(recovered["seed"], recovered["document_pairs"])
        saved = durable[workflow]
        expected_results = [fixture_tool_result(turn, docs) for turn in (0, 1)]
        stored_ok = saved == [
            (0, {"name": "list_reports", "arguments": {}}, expected_results[0]),
            (1, {"name": "read_reports", "arguments": {"first": "report-A", "second": "report-B"}}, expected_results[1]),
        ]
        reuse_ok = all(
            attempt["result_sha256"] == fingerprint(expected_results[attempt["turn"]])
            for wave in raw["tool_attempts"] for attempt in wave
        )
        boundary = {
            "before-content": cut["turn"] == 2 and cut_chunks == 0 and "done_ns" not in cut
            and raw["active_at_fault"] is not None
            and cut["request_written_ns"] <= raw["active_at_fault"]["observed_ns"] <= kill,
            "partial-content": cut["turn"] == 2 and cut_chunks >= 4 and "done_ns" not in cut
            and not cut.get("finish") and cut["content_ns"][3] <= kill,
            "completed-tool-call": cut["turn"] == 0 and cut.get("status") == 200 and cut.get("finish") in ("tool_calls", "stop")
            and cut.get("done_ns", kill + 1) <= raw["observed_before_fault"].get("call_validated_ns", 0) <= kill
            and cut.get("observed_calls") == [raw["observed_before_fault"].get("call")]
            and cut["call"]["function"]["name"] == "list_reports"
            and json.loads(cut["call"]["function"]["arguments"]) == {},
        }[scenario]
        checks = {
            "fault_really_stopped_process": raw["fault_exit"] == limit["fault_exit_code"]
            and int((path / failed / "fault-exit-code").read_text()) == limit["fault_exit_code"]
            and raw["failed_endpoint_closed"] and raw["marker_ns"] <= kill <= raw["withdrawn_ns"],
            "fault_boundary_and_failed_attempt": boundary and not incomplete["ok"] and cut["route"]["generation"] == failed,
            "correct_workflow_on_healthy_peer_before_rejoin": result_is_correct(recovered)
            and all(turn["route"]["generation"] == peer for turn in recovered["turns"] if "route" in turn)
            and recovered_s is not None and 0 <= recovered_s <= limit["correct_workflow_recovery_max_s"]
            and recovered["end_ns"] < raw["replacement_admitted_ns"],
            "tool_results_committed_once_and_reused": stored_ok and reuse_ok
            and [[attempt["committed"] for attempt in wave] for wave in raw["tool_attempts"]] == expected_commits
            and result_is_correct(raw["persisted_retry"])
            and all(turn["route"]["generation"] == peer for turn in raw["persisted_retry"]["turns"] if "route" in turn)
            and raw["persisted_retry"]["end_ns"] < raw["replacement_admitted_ns"],
            "full_capacity_restored": replacement_ready_s <= limit["replacement_ready_max_s"]
            and full_capacity_proven_s <= limit["full_capacity_max_s"]
            and all(result_is_correct(work) for work in post)
            and {work["turns"][-1]["route"]["generation"] for work in post} == {peer, new},
        }
        assessed.append({
            "scenario": scenario, "fault_gpu": ready[failed]["gpu"], "exit_code": raw["fault_exit"],
            "cut_content_chunks": cut_chunks, "cut_sse_done": "done_ns" in cut,
            "cut_turn": cut["turn"], "cut_http_status": cut.get("status"),
            "client_failure": incomplete.get("error"), "completion_recovery_s": recovered_s,
            "replacement_ready_s": replacement_ready_s, "full_capacity_ready_s": full_capacity_ready_s,
            "full_capacity_proven_s": full_capacity_proven_s, "tool_attempts_and_commits": [[len(wave), sum(t["committed"] for t in wave)] for wave in raw["tool_attempts"]],
            "checks": checks, "passed": all(checks.values()),
        })
    holder = read(path / "holders-before.json")
    monitor = {}
    foreign = []
    for gpu in GPU:
        readings = lines(path.parent / f"ops-gpu{gpu}.processes.jsonl")
        monitor[gpu] = len(readings)
        for reading in readings:
            foreign.extend(
                {"gpu": gpu, "epoch_ns": reading["time_ns"], "pid": app["pid"]}
                for app in reading["apps"]
                if app["pid"] != holder[str(gpu)]["pid"] and not app["runner_descendant"]
            )
    checks = {
        "planned": all(planned_checks.values()),
        "three_fault_boundaries": all(r["passed"] for r in assessed),
        "all_committed_effects_accounted_for": set(durable) == {raw["logical_id"] for raw in faults} and sum(map(len, durable.values())) == 6,
        "all_alignment_workflows_correct": all(result_is_correct(raw["pre_alignment"]) for raw in faults if raw["pre_alignment"]),
        "holders_restored": release["leases_restored"] and all(release["lease_after_each_generation"].values()),
        "all_normal_shutdowns_reclaimed": all(release["normal_shutdown_reclaimed"].values()),
        "no_external_gpu_apps_in_samples": not foreign and all(monitor.values()),
    }
    return {
        "checks": checks, "passed": all(checks.values()), "route": route,
        "planned": {"checks": planned_checks, "active_streams_drained": int(planned_checks["in_flight_completed_after_withdrawal"]),
                    "replacement_ready_s": planned_ready_s,
                    "withdrawal_to_final_sse_done_s": (drained["done_ns"] - planned["withdrawn_ns"]) / NS,
                    "withdrawal_to_two_replica_probe_success_s": (max(w["end_ns"] for w in planned["after_rejoin"]) - planned["withdrawn_ns"]) / NS,
                    "partial_or_lost_streams": int(not planned_checks["in_flight_completed_after_withdrawal"])},
        "faults": assessed, "durable_tool_effects": sum(map(len, durable.values())),
        "monitor_samples_by_gpu": monitor, "foreign_compute_receipts": foreign, "release": release,
    }


def verify_citation(path, cfg):
    config = read(path.parent / "citation-diagnostic-registration.json")
    samples = read(path / "cases.json")
    original = next(
        row["work"] for row in lines(path.parent / "soak" / "rows.jsonl")
        if row["index"] == config["original_submission_index"]
    )
    assert [sample["variant"] for sample in samples] == config["order"]
    assert original["seed"] == config["seed"] and not result_is_correct(original)
    base_hash = original["turns"][-1]["input_sha256"]
    ready = read(path / "ready.json")
    routes = verify_routes(path, [sample["work"] for sample in samples], ready)
    release = releases(path, cfg, ready)
    results = []
    for sample in samples:
        work = sample["work"]
        turn = work["turns"][-1]
        assert turn["unmodified_request_sha256"] == base_hash and work["seed"] == config["seed"]
        assert (turn["input_sha256"] == base_hash) == (sample["variant"] == "original")
        correct = result_is_correct(work)
        assert work["ok"] == correct
        answer = turn.get("answer", "").lower()
        results.append({
            "variant": sample["variant"], "correct": correct,
            "http": turn.get("status"), "done": "done_ns" in turn,
            "missing_citations": [doc for doc in ("report-A", "report-B") if doc.lower() not in answer],
        })
    return {"base_input_sha256": base_hash, "results": results, "routes": routes, "release": release}


if __name__ == "__main__":
    folder = Path(sys.argv[1])
    registration = read(folder / "phase05-registration.json")
    target = sys.argv[2] if len(sys.argv) > 2 else "both"
    output = {}
    if target == "both":
        checkpoint = read(folder / "phase04-checkpoint-receipt.json")
        assert (folder / "model-during-soak.txt").read_bytes() == (folder / "model-after.txt").read_bytes()
        assert (folder / "model-checks.txt").read_text().splitlines() == [
            file["path"] + ": OK" for file in checkpoint["files"]
        ]
        output["provenance"] = {
            "scope": registration["scope"],
            "policy": registration["policy"],
            "riley": (folder / "riley-version.txt").read_text().strip(),
            "binary_sha256": registration["binary_sha256"],
            "model": checkpoint["source_model"],
            "model_revision": checkpoint["source_revision"],
            "checkpoint_files_verified": len(checkpoint["files"]),
        }
    if target in ("soak", "both"):
        output["soak"] = verify_soak(folder / "soak", registration)
    if target in ("operations", "both"):
        output["operations"] = verify_ops(folder / "operations", registration)
    if target in ("citation", "both") and (folder / "citation-diagnostic" / "cases.json").is_file():
        output["citation_diagnostic"] = verify_citation(folder / "citation-diagnostic", registration)
    print(json.dumps(output, indent=2))
