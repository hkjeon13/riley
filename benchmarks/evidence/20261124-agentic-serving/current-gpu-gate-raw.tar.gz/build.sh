set -euo pipefail
cd -- "$(dirname -- "$0")"
root=$(realpath ../../..)
export PATH="$root/tools/rustup/toolchains/1.85.0-x86_64-unknown-linux-gnu/bin:/usr/local/cuda-12.4/bin:$PATH"
export CARGO_HOME="$root/tools/cargo" CUDA_HOME=/usr/local/cuda-12.4 CUDAToolkit_ROOT=/usr/local/cuda-12.4
export LD_LIBRARY_PATH=/usr/local/cuda-12.4/lib64 RILEY_CUDA_ARCHITECTURES=80
export CMAKE_BUILD_PARALLEL_LEVEL=3 CARGO_BUILD_JOBS=3 CUDA_VISIBLE_DEVICES=
export CARGO_TARGET_DIR="$PWD/target"
mkdir src
tar xzf src.tar.gz -C src
(cd src && taskset -c 24-29 cargo build --locked --offline --release -p riley-server --features server,cuda --bin riley)
cp target/release/riley current-riley
sha256sum src.tar.gz current-riley > build.sha256
ldd current-riley > ldd.log
! grep -q 'not found' ldd.log
./current-riley --version > version.log
