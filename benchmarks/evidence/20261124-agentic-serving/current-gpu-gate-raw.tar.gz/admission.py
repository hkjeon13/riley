import json
from pathlib import Path
from control import status
from holder import GPUS, admitted_process, gpu_processes
lease=Path("leases").resolve()
for index in (6,7):
    s=status(lease,index)
    rows=[dict(row,admitted=admitted_process(lease,index,row['pid'],row['memory_mib'])) for row in gpu_processes(GPUS[index]) if row['pid']!=s['pid']]
    print(json.dumps(dict(gpu=index,phase=s['phase'],holder=s['status'],other=rows,admissible=s['status']=='running' and s['phase']=='idle' and all(x['admitted'] for x in rows))))
