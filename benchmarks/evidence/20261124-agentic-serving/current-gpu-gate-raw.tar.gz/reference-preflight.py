import json
from importlib.metadata import version
from pathlib import Path
from vllm.entrypoints.cli.serve import ServeSubcommand
from vllm.utils.argparse_utils import FlexibleArgumentParser

root = Path.cwd()
cmd = json.loads((root/"reference-preflight/command.json").read_text())
historical = json.loads((root.parent/"coder-catalog-compare-20261125.y7oOA9ON/gpu6/vllm/command.json").read_text())
reference = list(cmd)
i = reference.index("--gpu-memory-utilization")
assert reference[i+1]=="0.75"
del reference[i:i+2]
reference[reference.index("--port")+1] = historical[historical.index("--port")+1]
assert reference == historical
parser=FlexibleArgumentParser()
ServeSubcommand().subparser_init(parser.add_subparsers())
args=parser.parse_args(cmd[1:])
assert args.max_model_len == 8192 and args.max_num_seqs==8 and args.block_size==16
assert args.dtype=="bfloat16" and args.gpu_memory_utilization==0.75 and args.kv_cache_memory_bytes==3758096384
print(json.dumps(dict(version=version("vllm"),dtype=args.dtype,model_length=args.max_model_len,active_sequences=args.max_num_seqs,block_size=args.block_size,kv_bytes=args.kv_cache_memory_bytes,reservation=args.gpu_memory_utilization,prior_reservation=0.92,historical_arguments_match_except_port_and_reservation=True)))
