"""Compare routing of dependent tool turns on two real, independently cached replicas."""

import argparse
import concurrent.futures
import http.client
import itertools
import json
import threading
import time
from pathlib import Path
from urllib.request import urlopen

from agent_workflow import fingerprint, percentile, replay, stream


class Router:
    def __init__(self, endpoints, policy, active_limits=None):
        if policy == "capacity" and (
            not active_limits
            or len(active_limits) != len(endpoints)
            or any(type(n) is not int or n <= 0 for n in active_limits)
        ):
            raise ValueError(
                "capacity routing needs a positive active limit for every replica"
            )
        self.active_limits = active_limits
        self.endpoints = endpoints
        self.policy = policy
        self.lock = threading.Lock()
        self.active = [0] * len(endpoints)
        self.credits = [{} for _ in endpoints]
        self.counter = itertools.count()

    def sender(self, session):
        def send(_, request, row, first_visible):
            begin = time.monotonic_ns()
            # Only predict reuse for previously completed requests with exactly
            # matching message history and presentation of tools. The engine's
            # token-level cached_tokens is the independent observation.
            layout = (
                request["model"],
                request["tool_choice"] == "none",
                request["tools"],
            )
            keys = [
                fingerprint([layout, request["messages"][:i]])
                for i in range(1, len(request["messages"]) + 1)
            ]
            estimated = len(json.dumps(request).encode()) / 4
            with self.lock:
                credits = [
                    max((cache.get(key, 0) for key in keys), default=0)
                    for cache in self.credits
                ]
                scores = [
                    60 * active + 0.09 * max(0, estimated - credit)
                    for active, credit in zip(self.active, credits)
                ]
                sequence = next(self.counter)
                if self.policy == "round-robin":
                    replica = sequence % len(self.endpoints)
                elif self.policy == "session":
                    replica = session % len(self.endpoints)
                elif self.policy == "capacity":
                    open_slots = [
                        i
                        for i, limit in enumerate(self.active_limits)
                        if self.active[i] < limit
                    ]
                    replica = min(
                        open_slots or range(len(scores)),
                        key=lambda i: (scores[i], (i - sequence) % len(scores)),
                    )
                else:
                    replica = min(
                        range(len(scores)),
                        key=lambda i: (scores[i], (i - sequence) % len(scores)),
                    )
                row["route"] = {
                    "replica": replica,
                    "active": self.active.copy(),
                    "estimated_tokens": estimated,
                    "eligible_estimate": credits,
                    "score_ms": scores,
                    "decision_ms": (time.monotonic_ns() - begin) / 1e6,
                }
                self.active[replica] += 1
            address, bearer = self.endpoints[replica]
            try:
                result = stream(address, request, row, first_visible, bearer=bearer)
                with self.lock:
                    self.credits[replica][keys[-1]] = max(
                        0, row["usage"]["prompt_tokens"] - 16
                    )
                return result
            finally:
                with self.lock:
                    self.active[replica] -= 1

        return send


def check_isolation(endpoints):
    probe = {
        "model": "m",
        "messages": [
            {"role": "user", "content": "Summarize this archived case. " * 200}
        ],
        "temperature": 0,
        "max_tokens": 4,
        "stream": True,
        "stream_options": {"include_usage": True},
    }
    rows = []
    for dest, principal in [(0, 0), (0, 0), (1, 0), (1, 1), (1, 1)]:
        row = {"replica": dest, "principal": principal}
        try:
            stream(endpoints[dest][0], probe, row, bearer=endpoints[principal][1])
        except ValueError:
            if row.get("status") != 401 or dest == principal:
                raise
        rows.append(row)
    if [r["status"] for r in rows] != [200, 200, 401, 200, 200]:
        raise ValueError("principal admission differs from registered cases")
    hits = [
        (r["usage"].get("prompt_tokens_details") or {}).get("cached_tokens", 0)
        for r in rows
        if r["status"] == 200
    ]
    if not (hits[0] == hits[2] == 0 and hits[1] > 0 and hits[3] > 0):
        raise ValueError(f"process isolation or same-principal reuse failed: {hits}")
    return rows


def run(
    endpoints,
    policy,
    *,
    model="m",
    waves=(1, 2, 4, 8),
    gpu_count=None,
    active_limits=None,
):
    router = Router(endpoints, policy, active_limits)
    result = []
    if gpu_count is None:
        gpu_count = len(endpoints)
    for wave, count in enumerate(waves):
        origin = time.monotonic() + 0.05

        def workflow(idx, origin=origin, wave=wave, count=count):
            time.sleep(max(0, origin + idx * 0.025 - time.monotonic()))
            session = wave * 10 + idx
            return replay(
                "",
                model,
                761 + session,
                96 if idx % 2 else 2,
                0.1,
                f"wave-{count}-{idx}",
                history=100,
                send=router.sender(session),
            )

        with concurrent.futures.ThreadPoolExecutor(count) as pool:
            records = list(pool.map(workflow, range(count)))
        elapsed = time.monotonic() - origin
        valid = [r for r in records if r["ok"]]
        good = sum(
            r["first_final_ms"] <= 10000
            and r["last_final_ms"] <= 18000
            and r["final_gap_p95_ms"] <= 150
            for r in valid
        )
        result.append(
            {
                "submitted": count,
                "correct": len(valid),
                "slo_completed": good,
                "window_s": elapsed,
                "warm_goodput_per_gpu_hour": good * 3600 / (gpu_count * elapsed),
                "first_p95_ms": percentile([r["first_final_ms"] for r in valid], 0.95),
                "last_p95_ms": percentile([r["last_final_ms"] for r in valid], 0.95),
                "records": records,
            }
        )
    return result


def tenant_burst(endpoints):
    """Flood tenant A after tenant B starts reading, then inspect cancellation recovery."""
    (busy, key), (other, other_key) = endpoints
    ready = threading.Event()

    def metrics():
        with urlopen(f"http://{busy}/metrics", timeout=5) as response:
            return json.load(response)

    def tenant_b(_, request, row, first_visible):
        return stream(other, request, row, first_visible, bearer=other_key)

    def flood(idx):
        req = {
            "model": "m",
            "messages": [
                {
                    "role": "user",
                    "content": f"Case {idx}. "
                    + "Read this latency measurement carefully. " * 300
                    + " Write a detailed long story.",
                }
            ],
            "max_tokens": 96,
            "temperature": 0,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        row = {"request": idx}
        if idx:
            try:
                stream(busy, req, row, bearer=key)
            except (ValueError, OSError, http.client.HTTPException) as exc:
                row["error"] = str(exc)
            return row
        # Disconnect the first admitted stream at its first visible chunk.
        host, port = busy.rsplit(":", 1)
        conn = http.client.HTTPConnection(host, int(port), timeout=30)
        try:
            conn.request(
                "POST",
                "/v1/chat/completions",
                json.dumps(req),
                {"Content-Type": "application/json", "Authorization": "Bearer " + key},
            )
            rsp = conn.getresponse()
            row["status"] = rsp.status
            if rsp.status == 200:
                for line in rsp:
                    if line.startswith(b"data:") and any(
                        c.get("delta", {}).get("content")
                        for c in json.loads(line[5:])["choices"]
                    ):
                        row["client_cancel_ns"] = time.monotonic_ns()
                        break
        finally:
            conn.close()
        return row

    before = metrics()
    with concurrent.futures.ThreadPoolExecutor(18) as pool:
        peer = pool.submit(
            replay, "", "m", 761, 2, 0, "protected", ready, None, 100, tenant_b
        )
        if not ready.wait(60):
            raise ValueError("protected tenant did not begin its final answer")
        begin = time.monotonic_ns()
        drops = [pool.submit(flood, 0)]
        time.sleep(0.02)
        drops.extend(pool.submit(flood, i) for i in range(1, 17))
        rows = [f.result() for f in drops]
        protected = peer.result()
    deadline = time.monotonic() + 10
    after = metrics()
    while time.monotonic() < deadline and any(
        after[k] for k in ("active_requests", "waiting_requests", "kv_allocated_blocks")
    ):
        time.sleep(0.1)
        after = metrics()
    return {
        "before": before,
        "after": after,
        "protected": protected,
        "burst_start_ns": begin,
        "submitted": len(rows),
        "requests": rows,
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("directory", type=Path)
    p.add_argument("credentials", type=Path)
    p.add_argument("policy", choices=["session", "round-robin", "cost"])
    a = p.parse_args()
    endpoints = [
        (
            (a.directory / f"gpu{i}" / "address").read_text().strip(),
            (a.credentials / str(i)).read_text().strip(),
        )
        for i in (6, 7)
    ]
    isolation = check_isolation(endpoints)
    (a.directory / "isolation.json").write_text(json.dumps(isolation, indent=2) + "\n")
    results = run(endpoints, a.policy)
    (a.directory / "capacity.json").write_text(json.dumps(results, indent=2) + "\n")

    burst = tenant_burst(endpoints)
    (a.directory / "tenant-burst.json").write_text(json.dumps(burst, indent=2) + "\n")


if __name__ == "__main__":
    main()
