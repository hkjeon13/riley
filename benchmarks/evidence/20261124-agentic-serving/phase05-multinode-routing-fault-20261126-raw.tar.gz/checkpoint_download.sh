#!/usr/bin/env bash
set -euo pipefail
here=$PWD
base=https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct/resolve/c03e6d358207e414f1eca0bb1891e29f1db0e242
date -Is > download-start.txt
cd model
pids=()
while read -r expected name; do
    case "$name" in
    *.safetensors)
        (
            curl --fail --location --silent --show-error --retry 2 --connect-timeout 12 --max-time 1800 \
                "$base/$name?download=true" --output "$name.download"
            printf '%s  %s\n' "$expected" "$name.download" | sha256sum -c -
            mv "$name.download" "$name"
        ) > "$here/$name.download.log" 2>&1 &
        pids+=("$!")
        ;;
    esac
done < "$here/model-registered.sha256"
rc=0
for pid in "${pids[@]}"; do wait "$pid" || rc=1; done
if [[ $rc == 0 ]]; then
    sha256sum -c "$here/model-registered.sha256" > "$here/model-verification.txt" || rc=$?
    sha256sum riley-checkpoint.json >> "$here/model-verification.txt"
fi
date -Is > "$here/download-end.txt"
printf '%s\n' "$rc" > "$here/download-exit.new"
mv "$here/download-exit.new" "$here/download-exit"
exit "$rc"
