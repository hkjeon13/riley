#!/usr/bin/env bash
set -euo pipefail
trial_mode=$1
run=$PWD/run
mkdir "$run"
key_file=$PWD/trial-key
RILEY_TRIAL_KEY=$(cat "$key_file")
rm -- "$key_file"
export RILEY_TRIAL_KEY RILEY_SHUTDOWN_METRICS_PATH="$run/shutdown.json"
if [[ "$trial_mode" = aws ]]; then
    export LD_LIBRARY_PATH="/usr/local/cuda-12.4/lib64:${LD_LIBRARY_PATH:-}"
    binary=$(cat "$PWD/binary-path.txt")
    model=$(cat "$PWD/model-path.txt")
    : "${RILEY_GPU_HOLDER_LEASE_DIR:?}" "${CUDA_VISIBLE_DEVICES:?}"
else
    export LD_LIBRARY_PATH="/data/cuda-12.8.1/targets/x86_64-linux/lib:${LD_LIBRARY_PATH:-}"
    binary="$PWD/riley"
    model=$(cat "$PWD/model-path.txt")
    export CUDA_VISIBLE_DEVICES=GPU-9087e425-6aca-b722-b8c9-cc0423b39fb0
    exec 9>"$HOME/.cache/riley-p05-rtx4090.lock"
    flock --nonblock 9
    nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-compute-apps=pid --format=csv,noheader > "$run/compute-before.txt"
    test ! -s "$run/compute-before.txt"
fi
sha256sum "$binary" > "$run/binary.sha256"
test "$(cut -d ' ' -f1 "$run/binary.sha256")" = 13b589df5c19a33c685ca1388398905f46a6cc566cbd1bed68f06b798080ca9f
hostname > "$run/host.txt"
sha256sum /proc/sys/kernel/random/boot_id | cut -d ' ' -f1 > "$run/boot-id.sha256"
nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-gpu=index,uuid,name,memory.total,driver_version --format=csv > "$run/device.csv"
sha256sum "$model/riley-checkpoint.json" > "$run/model-manifest.sha256"
ldd "$binary" > "$run/linkage.txt"
args=(serve --bind 127.0.0.1:0 --model "$model" --model-id m --inference-profile native-bf16-varlen-v1
  --max-weight-bytes 68719476736 --max-sequence-tokens 8192 --max-output-tokens 384
  --max-active-sequences 8 --max-waiting-requests 2 --kv-blocks 4096 --prefix-cache-blocks 1536
  --batch-token-budget 1024 --prefill-chunk-tokens 1024
  --batch-shape-buckets 1,2,4,8,16,24,32,48,64,80,96,112,128,144,160,176,192,208,224,240,256,512,1024
  --prefill-burst-steady-budget 256 --prefill-burst-max-decode-rows 0
  --prefill-burst-min-prompt-tokens 512 --api-key-env RILEY_TRIAL_KEY)
printf '%s\n' "${args[@]}" > "$run/arguments.txt"
date +%s%N > "$run/started-epoch-ns"
"$binary" "${args[@]}" > "$run/server.log" 2>&1 </dev/null &
pid=$!
printf '%s\n' "$pid" > "$run/pid"
cleanup() {
    if kill -0 "$pid" 2>/dev/null; then kill -TERM "$pid"; fi
    wait "$pid" || true
}
trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 143' TERM
deadline=$((SECONDS+360))
until address=$(sed -nE 's/.*listening on http:\/\/(127\.0\.0\.1:[0-9]+).*/\1/p' "$run/server.log") && [[ -n $address ]] && curl -fsS --max-time 3 "http://$address/readyz" > "$run/ready.json"; do
    kill -0 "$pid" && ((SECONDS < deadline)) || exit 1
    sleep .25
done
date +%s%N > "$run/ready-epoch-ns"
printf '%s\n' "$address" > "$run/address"
printf 'READY %s %s\n' "$address" "$pid"
deadline=$((SECONDS+1200))
while [[ ! -e $PWD/finish ]]; do
    kill -0 "$pid" && ((SECONDS < deadline)) || exit 1
    {
        date +%s%N
        nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-compute-apps=pid,used_memory --format=csv,noheader,nounits
    } >> "$run/gpu-samples.txt"
    sleep 3
done
curl -fsS --max-time 5 "http://$address/metrics" > "$run/metrics.json"
kill -TERM "$pid"
wait "$pid"
nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-compute-apps=pid,used_memory --format=csv,noheader,nounits > "$run/compute-after.txt"
printf 'FINISHED\n'
