"""Exercise round robin and scoped data-path loss on the authorized GPU hosts."""
import concurrent.futures
import contextlib
import http.client
import json
import re
import secrets
import shlex
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from agent_workflow import fingerprint, replay, stream
from process_qualification import Journal
from verify_agent_citations import with_citations


ROOT = Path(__file__).resolve().parent
LEASE = "/mnt/efs/nlp/psyche/riley-gap-20261102/evidence/w2-sm17-20261118.6UMfeHh2"
SSH = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10",
       "-o", "ControlMaster=no", "-o", "ControlPath=none"]


def write(file, data):
    file.write_text(json.dumps(data, indent=2) + "\n")


def stop(process):
    if process and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=6)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=6)


class Node:
    def __init__(self, label, descriptor, out):
        self.label = label
        self.alias = descriptor["alias"]
        self.directory = descriptor["directory"]
        self.index = descriptor["physical_index"]
        self.out = out
        self.key = secrets.token_hex(32)
        self.server = self.tunnel = None
        self.tunnel_index = 0

    def run(self, command, input=None):
        return subprocess.check_output([*SSH, self.alias, command], input=input, text=True, timeout=20)

    def start(self):
        directory = shlex.quote(self.directory)
        self.run(f"cd {directory}; umask 077; cat > trial-key", self.key)
        command = f"cd {directory} && bash remote_replica.sh {self.label}"
        if self.label == "aws":
            command = (
                f"cd {directory} && python3 -B {LEASE}/control.py "
                f"--lease-dir {LEASE}/leases --index {self.index} run -- bash remote_replica.sh aws"
            )
        self.log = self.out / f"{self.label}-controller.log"
        with self.log.open("wb") as sink:
            self.started = time.monotonic_ns()
            self.server = subprocess.Popen([*SSH, "-nT", self.alias, command], stdout=sink, stderr=subprocess.STDOUT)

    def ready_from_controller(self):
        deadline = time.monotonic() + 360
        while time.monotonic() < deadline:
            match = re.search(r"^READY (127\.0\.0\.1:[0-9]+) ([0-9]+)$", self.log.read_text(), re.MULTILINE)
            if match:
                self.address, self.pid = match.group(1), int(match.group(2))
                return time.monotonic_ns()
            if self.server.poll() is not None:
                raise RuntimeError(f"server exited early: {self.label}, code {self.server.returncode}")
            time.sleep(.1)
        raise TimeoutError(f"{self.label} readiness")

    def open_tunnel(self):
        with socket.socket() as temporary:
            temporary.bind(("127.0.0.1", 0))
            local_port = temporary.getsockname()[1]
        self.local = f"127.0.0.1:{local_port}"
        target = f"{self.local}:{self.address}"
        log_path = self.out / f"{self.label}-tunnel-{self.tunnel_index}.log"
        self.tunnel_index += 1
        with log_path.open("wb") as log:
            self.tunnel = subprocess.Popen(
                [*SSH, "-nNT", "-o", "ExitOnForwardFailure=yes", "-L", target, self.alias],
                stdout=log, stderr=subprocess.STDOUT,
            )
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            if self.tunnel.poll() is not None:
                raise RuntimeError(f"could not open data forward: {self.label}")
            probe = self.probe()
            if probe["ready"]:
                return probe
            time.sleep(.1)
        raise TimeoutError(f"data forward readiness: {self.label}")

    def probe(self):
        start = time.monotonic_ns()
        try:
            with urlopen(f"http://{self.local}/readyz", timeout=2) as response:
                state = json.load(response)
            return {"at_ns": time.monotonic_ns(), "start_ns": start, "ready": state["ready"] and state["accepting"], "response": state}
        except (OSError, http.client.HTTPException) as error:
            return {"at_ns": time.monotonic_ns(), "start_ns": start, "ready": False, "error": str(error)}

    def management_probe(self):
        directory = shlex.quote(self.directory)
        remote = self.run(
            f"cd {directory} && recorded=$(cat run/pid) && kill -0 \"$recorded\" "
            f"&& printf '%s\\n' \"$recorded\" && curl -fsS --max-time 3 http://{self.address}/readyz"
        )
        pid, response = remote.split("\n", 1)
        return {"pid": int(pid), "ready": json.loads(response)}

    def models_status(self, provided_key):
        request = Request(f"http://{self.local}/v1/models", headers={"Authorization": "Bearer " + provided_key})
        try:
            with urlopen(request, timeout=5) as response:
                body = json.load(response)
                return {"http": response.status, "models": [item["id"] for item in body["data"]]}
        except HTTPError as error:
            return {"http": error.code}

    def finish(self):
        stop(self.tunnel)
        if self.server is None or self.server.poll() is not None:
            return self.server.returncode if self.server else None
        try:
            self.run(f"touch {shlex.quote(self.directory)}/finish")
            return self.server.wait(timeout=75)
        finally:
            stop(self.server)


class Fleet:
    def __init__(self, nodes):
        self.nodes = nodes
        self.active = set()
        self.sequence = 0
        self.events = []
        self.lock = threading.Lock()

    def update(self, label, probe):
        with self.lock:
            changed = (label in self.active) != probe["ready"]
            if probe["ready"]:
                self.active.add(label)
            else:
                self.active.discard(label)
            now = time.monotonic_ns()
            self.events.append({"action": "ready" if probe["ready"] else "unavailable", "node": label,
                                "ns": now, "changed": changed, "observed": probe})
            return now

    def next_node(self):
        ready = sorted(self.active)
        return ready[self.sequence % len(ready)]

    def sender(self, work_id, on_content=None, on_headers=None):
        def send(_, request, row, visible):
            with self.lock:
                if not self.active:
                    raise ConnectionError("no ready replica")
                label = self.next_node()
                route = {"node": label, "eligible": sorted(self.active),
                         "seq": self.sequence, "ns": time.monotonic_ns()}
                self.sequence += 1
                row["route"] = route
                self.events.append({"action": "route", "id": work_id, "turn": row["turn"], **route})
                node = self.nodes[label]
            if row["turn"] == 2:
                row["original_request_sha256"] = fingerprint(request)
                request = with_citations(request)
            return stream(node.local, request, row, visible, bearer=node.key,
                          on_content=(lambda n: on_content(n, row)) if on_content else None,
                          on_headers=(lambda: on_headers(row)) if on_headers else None,
                          timeout_s=25)
        return send


def work(fleet, label, seed, *, direct=True, long=False, history=None,
         delay=.01, on_content=None, on_headers=None, on_tool_start=None, journal=None):
    def result(index, call, docs):
        value = journal.execute(index, call, docs)
        journal.attempts[-1]["result_sha256"] = fingerprint(value)
        return value

    return replay(
        "", "m", seed, 96 if long else 2, delay, label,
        history=(200 if long else 20) if history is None else history,
        send=fleet.sender(label, on_content=on_content, on_headers=on_headers),
        on_tool_start=on_tool_start, execute_tool=result if journal else None, dispatch_fixed_tools=direct,
    )


def waves(fleet, reg):
    receipt = []
    offset = 0
    for stage, size in enumerate(reg["load"]["waves"]):
        start = time.monotonic_ns() + 100_000_000

        def one(i):
            j = offset + i
            target = j % 4 != 0
            due = start + i * reg["load"]["wave_spacing_ms"] * 1_000_000
            time.sleep(max(0, due - time.monotonic_ns()) / 1e9)
            return {"scheduled_ns": due, "work": work(
                fleet, f"wave-{stage}-{i}", 7600 + j, direct=target,
                history=200 if target else 0, delay=.5 if target else .01,
            )}

        with concurrent.futures.ThreadPoolExecutor(size) as pool:
            tasks = list(pool.map(one, range(size)))
        receipt.append({"size": size, "jobs": tasks})
        offset += size
    return receipt


def fault(fleet, edge, target, n, out):
    label = f"logical-{n}-{edge}"
    node = fleet.nodes[target]
    assert len(fleet.active) == 2
    aligned = None
    if fleet.next_node() != target:
        aligned = work(fleet, f"align-{n}", 761)
    direct = edge != "completed-tool-call"
    journal_path = out / "effects.sqlite"
    journal = Journal(journal_path, label)
    trigger = {}

    def disconnect(row):
        assert not trigger and row["route"]["node"] == target
        trigger.update(start_ns=time.monotonic_ns(), turn=row["turn"], route=row["route"])
        stop(node.tunnel)
        trigger["closed_ns"] = time.monotonic_ns()

    def headers(row):
        if edge == "before-final-content" and row["turn"] == 2:
            disconnect(row)

    def content(chunks, row):
        if edge == "partial-final-content" and row["turn"] == 2 and chunks == 4:
            disconnect(row)

    def completed_tool(i, _, row):
        if edge == "completed-tool-call" and i == 0:
            disconnect(row)
            raise ValueError("data path disconnected after validated tool call and before its effect")

    options = {"direct": direct, "long": direct}
    interrupted = work(fleet, label, 761 + n, **options, journal=journal, on_content=content,
                       on_headers=headers, on_tool_start=completed_tool)
    assert trigger, (edge, interrupted)
    failed_probe = node.probe()
    assert not failed_probe["ready"]
    remove_ns = fleet.update(target, failed_probe)
    retry = Journal(journal_path, label)
    recovered = work(fleet, label, 761 + n, **options, journal=retry)
    again = Journal(journal_path, label)
    reread = work(fleet, label, 761 + n, **options, journal=again)
    management = node.management_probe()
    reopen = time.monotonic_ns()
    ready_probe = node.open_tunnel()
    readmit_ns = fleet.update(target, ready_probe)
    after = [work(fleet, f"after-{n}-{i}", seed) for i, seed in enumerate((761, 762))]
    return {
        "edge": edge, "target": target, "logical_id": label, "initial_pid": node.pid,
        "trigger": trigger, "router_removed_ns": remove_ns, "negative_probe": failed_probe,
        "aligned": aligned, "interrupted": interrupted, "recovered": recovered, "replayed": reread,
        "tool_attempts": [journal.attempts, retry.attempts, again.attempts],
        "management_during_cut": management, "reopen_ns": reopen, "readmit_ns": readmit_ns,
        "positive_probe": ready_probe, "after": after,
    }


def main(out):
    reg = json.loads((ROOT / "multinode-registration.json").read_text())
    descriptors = json.loads((ROOT / "node-inventory.json").read_text())
    out.mkdir()
    nodes = {key: Node(key, item, out) for key, item in descriptors.items()}
    fleet = Fleet(nodes)
    observed = {"initial": {}, "faults": []}
    try:
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            list(pool.map(Node.start, nodes.values()))
            seen = list(pool.map(Node.ready_from_controller, nodes.values()))
        for node, ready_ns in zip(nodes.values(), seen):
            probe = node.open_tunnel()
            observed["initial"][node.label] = {
                "pid": node.pid, "started_ns": node.started, "controller_ready_ns": ready_ns,
                "admitted_ns": fleet.update(node.label, probe),
            }
        observed["authentication"] = {
            label: {"own_key": node.models_status(node.key),
                    "other_key": node.models_status(nodes["rtx" if label == "aws" else "aws"].key)}
            for label, node in nodes.items()
        }
        observed["waves"] = waves(fleet, reg)
        write(out / "observations.json", observed)
        for n, (edge, target) in enumerate(zip(reg["faults"]["boundaries"], reg["faults"]["node_order"], strict=True), 1):
            observed["faults"].append(fault(fleet, edge, target, n, out))
            write(out / "observations.json", observed)
    finally:
        write(out / "routing-events.json", fleet.events)
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            close_codes = dict(zip(nodes, pool.map(Node.finish, nodes.values())))
        write(out / "cleanup.json", close_codes)


if __name__ == "__main__":
    main(Path(sys.argv[1]))
