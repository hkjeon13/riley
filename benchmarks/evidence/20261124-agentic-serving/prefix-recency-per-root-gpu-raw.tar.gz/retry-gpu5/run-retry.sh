#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
trial=$PWD
root=$(realpath ../../..)
private="$trial/gpu5-holder"
model="$root/models/Qwen2.5-7B-Instruct"
retry="$trial/retry-gpu5"
export LD_LIBRARY_PATH="/usr/local/cuda-12.4/lib64:${LD_LIBRARY_PATH:-}"
uuid5=$(nvidia-smi -i 5 --query-gpu=uuid --format=csv,noheader)
test "$uuid5" = GPU-73fc52fd-c417-684a-2fea-acf98cb889dc
nvidia-smi -i 5 --query-compute-apps=pid,used_memory --format=csv,noheader > "$retry/processes-before.csv"
test ! -s "$retry/processes-before.csv"
mkdir "$retry/leases"
control=(python3 -B "$private/control.py" --lease-dir "$retry/leases" --index 5)
CUDA_VISIBLE_DEVICES="$uuid5" "$root/tools/vllm-venv/bin/python" -B "$private/holder.py" --index 5 --lease-dir "$retry/leases" > "$retry/holder.log" 2>&1 &
holder=$!
child=
cleanup() {
    rc=$?
    trap - EXIT INT TERM
    if [[ -n $child ]] && kill -0 "$child" 2>/dev/null; then
        kill -TERM "$child" 2>/dev/null || true
        wait "$child" 2>/dev/null || true
    fi
    kill -TERM "$holder" 2>/dev/null || true
    wait "$holder" 2>/dev/null || true
    if [[ -f "$retry/leases/gpu5.status.json" ]]; then
        cp "$retry/leases/gpu5.status.json" "$retry/gpu5-released.json"
    fi
    nvidia-smi -i 5,6 --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader > "$retry/processes-after.csv"
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
for ((i=0;i<120;i++)); do
    if "${control[@]}" status > "$retry/gpu5-before.json" 2> "$retry/status.log"; then break; fi
    kill -0 "$holder"
    sleep 0.5
done
python3 -c 'import json; d=json.load(open("retry-gpu5/gpu5-before.json")); assert d["phase"]=="idle" and not d["other_processes"]'
echo "Retrying GPU5 control"
"${control[@]}" run -- python3 -B "$trial/per_root_gpu_trial.py" "$trial" "$model" --arm control --out "$retry/gpu5" > "$retry/controller.log" 2>&1 &
child=$!
wait "$child"
child=
"${control[@]}" status > "$retry/gpu5-lease-after.json"
echo "GPU5 control retry complete"
