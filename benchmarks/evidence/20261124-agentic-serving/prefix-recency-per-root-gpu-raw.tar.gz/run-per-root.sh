#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
trial=$PWD
repo=$(realpath ../../..)
model="$repo/models/Qwen2.5-7B-Instruct"
old="$repo/evidence/w2-sm17-20261118.6UMfeHh2"
private="$trial/gpu5-holder"
python="$repo/tools/vllm-venv/bin/python"
export LD_LIBRARY_PATH="/usr/local/cuda-12.4/lib64:${LD_LIBRARY_PATH:-}"
sha256sum -c artifacts.sha256
python3 -B per_root_gpu_trial.py "$trial" "$model" --out "$trial/prompt-profiles.json"
mkdir -p captures "$private/leases"
uuid5=$(nvidia-smi -i 5 --query-gpu=uuid --format=csv,noheader)
test "$uuid5" = GPU-73fc52fd-c417-684a-2fea-acf98cb889dc
test -z "$(nvidia-smi -i 5 --query-compute-apps=pid,used_memory --format=csv,noheader)"
python3 - "$old" "$private" "$uuid5" <<'PY'
from pathlib import Path
import re, sys
src, dst, uuid = sys.argv[1:]
src, dst = Path(src), Path(dst)
holder, n = re.subn(r"GPUS = \{[^}]+\}", f"GPUS = {{5: {uuid!r}}}", (src / "holder.py").read_text(), count=1)
assert n == 1
(dst / "holder.py").write_text(holder)
(dst / "control.py").write_bytes((src / "control.py").read_bytes())
PY
ctrl5=(python3 -B "$private/control.py" --lease-dir "$private/leases" --index 5)
ctrl6=(python3 -B "$old/control.py" --lease-dir "$old/leases" --index 6)
"${ctrl6[@]}" status > captures/gpu6-before.json
python3 -c 'import json; d=json.load(open("captures/gpu6-before.json")); assert d["phase"]=="idle" and not d["other_processes"]'
CUDA_VISIBLE_DEVICES="$uuid5" "$python" -B "$private/holder.py" --index 5 --lease-dir "$private/leases" > "$private/holder.log" 2>&1 &
holder_pid=$!
children=()
cleanup() {
    rc=$?
    trap - EXIT INT TERM
    for child in "${children[@]}"; do
        if kill -0 "$child" 2>/dev/null; then kill -TERM "$child" 2>/dev/null || true; fi
    done
    for child in "${children[@]}"; do wait "$child" 2>/dev/null || true; done
    if kill -0 "$holder_pid" 2>/dev/null; then kill -TERM "$holder_pid" 2>/dev/null || true; fi
    wait "$holder_pid" 2>/dev/null || true
    if [[ -e $private/leases/gpu5.status.json ]]; then
        cp "$private/leases/gpu5.status.json" captures/gpu5-released.json
    fi
    "${ctrl6[@]}" status > captures/gpu6-after.json
    nvidia-smi -i 5,6 --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader > captures/processes-after.csv
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
for ((i=0;i<120;i++)); do
    if "${ctrl5[@]}" status > captures/gpu5-before.json 2> "$private/status.log"; then break; fi
    kill -0 "$holder_pid"
    sleep 0.5
done
python3 -c 'import json; d=json.load(open("captures/gpu5-before.json")); assert d["phase"]=="idle" and not d["other_processes"]'
order5=(control candidate candidate control)
order6=(candidate control control candidate)
for block in 0 1 2 3; do
    stem="$trial/captures/block-$block"
    mkdir "$stem"
    echo "block $block: GPU5 ${order5[$block]}, GPU6 ${order6[$block]}"
    "${ctrl5[@]}" run -- python3 -B "$trial/per_root_gpu_trial.py" "$trial" "$model" --arm "${order5[$block]}" --out "$stem/gpu5" > "$stem/gpu5-controller.log" 2>&1 &
    children=("$!")
    "${ctrl6[@]}" run -- python3 -B "$trial/per_root_gpu_trial.py" "$trial" "$model" --arm "${order6[$block]}" --out "$stem/gpu6" > "$stem/gpu6-controller.log" 2>&1 &
    children+=("$!")
    result=0
    for child in "${children[@]}"; do wait "$child" || result=$?; done
    children=()
    "${ctrl5[@]}" status > "$stem/gpu5-lease-after.json"
    "${ctrl6[@]}" status > "$stem/gpu6-lease-after.json"
    if (( result != 0 )); then exit "$result"; fi
    echo "block $block complete"
done
