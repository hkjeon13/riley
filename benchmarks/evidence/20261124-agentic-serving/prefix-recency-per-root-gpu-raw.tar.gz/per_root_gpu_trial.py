"""Compare the KV prefix cache on one leased A100 with the 32K serving profile."""

import argparse
import concurrent.futures
import json
import os
import re
import secrets
import subprocess
import time
from pathlib import Path
from urllib.request import urlopen

from agent_workflow import fingerprint, stream
from recency_serving import requests


def long_requests():
    for phase in ("cold", "warm"):
        for tag in ("amber", "cobalt"):
            history = tag + " Routine latency measurements stayed stable." * 5000
            extra = (
                " The final measurements were checked again." if phase == "warm" else ""
            )
            yield (
                f"{phase}-{tag}",
                {
                    "model": "m",
                    "messages": [
                        {
                            "role": "system",
                            "content": f"Workflow {tag} dataset. Summarize accurately.",
                        },
                        {
                            "role": "user",
                            "content": history + extra + "\nSummarize in one sentence.",
                        },
                    ],
                    "max_tokens": 16,
                    "temperature": 0,
                    "stream": True,
                    "stream_options": {"include_usage": True},
                    "return_token_ids": True,
                },
            )


def inputs():
    return [*long_requests(), *requests()]


def profile(root, model):
    items = inputs()
    result = subprocess.run(
        [root / "profile", model],
        input="".join(json.dumps(body) + "\n" for _, body in items),
        text=True,
        capture_output=True,
        check=True,
    )
    profiles = {}
    first_blocks = {}
    long_cases = {case for case, _ in long_requests()}
    for (case, request), line in zip(items, result.stdout.splitlines(), strict=True):
        ids = json.loads(line)["ids"]
        if case in long_cases:
            assert 29_000 <= len(ids) < 32_752, (case, len(ids))
            first_blocks[case] = ids[:16]
        profiles[case] = {
            "input_sha256": fingerprint(request),
            "prompt_tokens": len(ids),
            "prompt_ids_sha256": fingerprint(ids),
        }
    for tag in ("amber", "cobalt"):
        assert first_blocks[f"cold-{tag}"] == first_blocks[f"warm-{tag}"]
    assert first_blocks["cold-amber"] != first_blocks["cold-cobalt"]
    return {"profiles": profiles, "first_blocks": first_blocks}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def fetch(address, endpoint):
    with urlopen(f"http://{address}/{endpoint}", timeout=5) as response:
        return json.load(response)


def wait_ready(process, log_path):
    deadline = time.monotonic() + 240
    while time.monotonic() < deadline:
        assert process.poll() is None, ("server exited", process.returncode)
        match = re.search(
            r"listening on http://(127\.0\.0\.1:\d+)", log_path.read_text()
        )
        if match:
            address = match.group(1)
            ready = fetch(address, "readyz")
            assert ready["ready"] and ready["accepting"]
            return address, ready
        time.sleep(0.25)
    raise TimeoutError("server readiness timed out")


def cold_pair(client, address, planned):
    samples = []
    with concurrent.futures.ThreadPoolExecutor(2) as pool:
        jobs = [pool.submit(client, planned[0])]
        deadline = time.monotonic() + 15
        while not jobs[0].done() and time.monotonic() < deadline:
            snapshot = fetch(address, "readyz")
            if snapshot["active_requests"] == 1:
                break
            time.sleep(0.025)
        else:
            raise RuntimeError("first cold request did not enter the engine")
        jobs.append(pool.submit(client, planned[1]))
        while not all(job.done() for job in jobs) and time.monotonic() < deadline:
            if (snapshot := fetch(address, "readyz"))["active_requests"] == 2:
                samples.append({"time_ns": time.monotonic_ns(), **snapshot})
                break
            time.sleep(0.025)
        rows = [job.result() for job in jobs]
    assert samples, "two cold requests were never concurrently active"
    assert max(r["request_written_ns"] for r in rows) < min(
        r["content_ns"][0] for r in rows
    )
    return rows, samples


def run(root, model, out, arm):
    out.mkdir()
    args = [
        str(root / f"server-{arm}"),
        "serve",
        "--bind",
        "127.0.0.1:0",
        "--model",
        str(model),
        "--model-id",
        "m",
        "--inference-profile",
        "native-bf16-prefix-32k-v1",
        "--max-weight-bytes",
        "68719476736",
        "--max-output-tokens",
        "384",
        "--kv-blocks",
        "4608",
        "--prefix-cache-blocks",
        "4096",
        "--request-timeout-ms",
        "180000",
        "--api-key-env",
        "RILEY_TRIAL_KEY",
    ]
    gpu = os.environ["CUDA_VISIBLE_DEVICES"]
    assert os.environ["RILEY_GPU_HOLDER_LEASE_DIR"]
    key = secrets.token_hex(32)
    env = dict(
        os.environ,
        RILEY_TRIAL_KEY=key,
        RILEY_SHUTDOWN_METRICS_PATH=str(out / "shutdown.json"),
    )
    env["LD_LIBRARY_PATH"] = "/usr/local/cuda-12.4/lib64:" + env.get(
        "LD_LIBRARY_PATH", ""
    )
    write(out / "launch.json", {"args": args, "uuid": gpu, "arm": arm})
    with (out / "device.csv").open("wb") as device:
        subprocess.run(
            [
                "nvidia-smi",
                "-i",
                gpu,
                "--query-gpu=uuid,name,driver_version",
                "--format=csv",
            ],
            stdout=device,
            check=True,
        )
    with (out / "binary.sha256").open("wb") as digest:
        subprocess.run(["sha256sum", args[0]], stdout=digest, check=True)
    log_path = out / "server.log"
    with log_path.open("wb") as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, env=env)
        try:
            address, ready = wait_ready(process, log_path)
            write(out / "ready.json", ready)
            write(out / "before.json", fetch(address, "metrics"))

            def client(item):
                label, request = item
                row = {"case": label}
                row["answer"], calls = stream(
                    address, request, row, bearer=key, timeout_s=185
                )
                assert not calls
                return row

            planned = inputs()
            rows, witnesses = cold_pair(client, address, planned[:2])
            write(out / "cold.json", rows)
            write(out / "overlap.json", witnesses)
            rows.extend(client(item) for item in planned[2:4])
            write(out / "long.json", rows)
            write(out / "after-long.json", fetch(address, "metrics"))
            rows.extend(client(item) for item in planned[4:])
            write(out / "requests.json", rows)
            write(out / "after.json", fetch(address, "metrics"))
        finally:
            if process.poll() is None:
                process.terminate()
            try:
                exit_code = process.wait(timeout=40)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
                raise
            write(out / "exit.json", {"returncode": exit_code})
    assert exit_code == 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("model", type=Path)
    parser.add_argument("--arm", choices=("control", "candidate"))
    parser.add_argument("--out", type=Path)
    options = parser.parse_args()
    if options.arm:
        run(options.root, options.model, options.out, options.arm)
    else:
        write(options.out, profile(options.root, options.model))
