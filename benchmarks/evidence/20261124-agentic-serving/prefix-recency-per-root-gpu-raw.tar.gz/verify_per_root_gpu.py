"""Verify paired token, cache and response evidence from the AWS A100 5/6 crossover."""

import argparse
import json
from hashlib import sha256
from pathlib import Path
from statistics import median

GPU_ORDER = {
    5: ["control", "candidate", "candidate", "control"],
    6: ["candidate", "control", "control", "candidate"],
}
LONG = ("cold-amber", "cold-cobalt", "warm-amber", "warm-cobalt")


def read(path):
    return json.loads(path.read_text())


def latency(row):
    t0 = row["sent_ns"]
    times = row["content_ns"]
    assert times and t0 < times[0] <= times[-1] <= row["done_ns"]
    return {
        "first_ms": (times[0] - t0) / 1e6,
        "last_content_ms": (times[-1] - t0) / 1e6,
        "http_done_ms": (row["done_ns"] - t0) / 1e6,
    }


def phase_delta(before, after):
    first = before["batch_shapes"]["by_phase"]
    last = after["batch_shapes"]["by_phase"]
    return {
        phase: {key: count - first[phase][key] for key, count in values.items()}
        for phase, values in last.items()
    }


def verify_retry(root, original_holder):
    captures = root / "captures"
    failed = captures / "block-3" / "gpu5"
    assert read(failed / "exit.json")["returncode"] == 1
    assert (
        not (failed / "ready.json").exists() and not (failed / "requests.json").exists()
    )
    assert "CUDA OutOfMemory" in (failed / "server.log").read_text()
    initial_lease = read(captures / "block-3" / "gpu5-lease-after.json")
    assert initial_lease["pid"] == original_holder["pid"]
    assert initial_lease["phase"] == "idle"
    (external,) = initial_lease["other_processes"]
    assert external["pid"] != original_holder["pid"] and external["memory_mib"] > 0

    retry = root / "retry-gpu5"
    assert (retry / "model-after.txt").read_bytes() == (
        root / "model-before.txt"
    ).read_bytes()
    assert not (retry / "processes-before.csv").read_text().strip()
    start = read(retry / "gpu5-before.json")
    released = read(retry / "gpu5-released.json")
    assert start["status"] == "running" and start["phase"] == "idle"
    assert not start["other_processes"] and start["gpu"] == original_holder["gpu"]
    assert start["pid"] != original_holder["pid"]
    assert (released["pid"], released["status"]) == (start["pid"], "stopped")
    assert all(
        not line.startswith(start["gpu"] + ",")
        for line in (retry / "processes-after.csv").read_text().splitlines()
    )
    return start, {
        "gpu": 5,
        "block": 3,
        "arm": "control",
        "failure": "CUDA out of memory during server preparation",
        "observed_other_process": external,
        "requests_served_in_failed_attempt": 0,
        "recovered_on_same_gpu": True,
    }


def checks(root):
    binaries = dict(
        line.split()[::-1]
        for line in (root / "artifacts.sha256").read_text().splitlines()
    )
    assert binaries["server-candidate"] != binaries["server-control"]
    src = {
        arm: (root / f"source-{arm}.sha256").read_text().split()[0]
        for arm in ("control", "candidate")
    }
    assert src["control"] != src["candidate"]
    models = (root / "model-before.txt").read_bytes()
    assert models == (root / "model-after.txt").read_bytes()
    checkpoint = root / "checkpoint-receipt.json"
    checkpoint_hash = sha256(checkpoint.read_bytes()).hexdigest()
    assert f"{checkpoint_hash}  riley-checkpoint.json".encode() in models.splitlines()
    model = read(checkpoint)
    assert (
        model["source_model"] == "Qwen/Qwen2.5-7B-Instruct" and model["dtype"] == "bf16"
    )
    profile_info = read(root / "prompt-profiles.json")
    profiles = profile_info["profiles"]
    heads = profile_info["first_blocks"]
    assert tuple(profiles)[:4] == LONG and len(profiles) == 17
    assert all(len(heads[k]) == 16 for k in LONG)
    assert heads[LONG[0]] != heads[LONG[1]]
    assert heads[LONG[0]] == heads[LONG[2]] and heads[LONG[1]] == heads[LONG[3]]

    captures = root / "captures"
    before = {i: read(captures / f"gpu{i}-before.json") for i in GPU_ORDER}
    assert before[5]["gpu"] != before[6]["gpu"]
    retry_start, startup_retry = verify_retry(root, before[5])
    arm_signature = None
    startup_cache = None
    identity = {}
    outputs = []
    for block in range(4):
        pair = captures / f"block-{block}"
        for gpu, order in GPU_ORDER.items():
            recovered = (block, gpu) == (3, 5)
            directory = (
                root / "retry-gpu5" / "gpu5" if recovered else pair / f"gpu{gpu}"
            )
            arm = order[block]
            launch = read(directory / "launch.json")
            arguments = launch["args"][1:]
            arm_signature = arm_signature or arguments
            assert arm_signature == arguments
            assert (launch["arm"], launch["uuid"]) == (arm, before[gpu]["gpu"])
            assert (directory / "binary.sha256").read_text().split()[0] == binaries[
                f"server-{arm}"
            ]
            assert before[gpu]["gpu"] in (directory / "device.csv").read_text()
            lease = read(directory.parent / f"gpu{gpu}-lease-after.json")
            assert lease["phase"] == "idle" and not lease["other_processes"]
            start = retry_start if recovered else before[gpu]
            assert lease["pid"] == start["pid"] and lease["physical_index"] == gpu
            assert read(directory / "ready.json")["ready"]
            assert read(directory / "exit.json")["returncode"] == 0

            zero = read(directory / "before.json")
            after_long = read(directory / "after-long.json")
            after = read(directory / "after.json")
            drained = read(directory / "shutdown.json")
            assert all(
                not snapshot["active_requests"] and not snapshot["waiting_requests"]
                for snapshot in (zero, after_long, after, drained)
            )
            assert drained["kv_allocated_blocks"] == 0
            start_cache = zero["prefix_cache"]
            startup_cache = startup_cache or start_cache
            assert start_cache == startup_cache and not start_cache["metrics_degraded"]
            assert all(
                not s["prefix_cache"]["metrics_degraded"]
                for s in (after_long, after, drained)
            )
            assert (
                after["prefix_cache"]["hit_tokens"]
                == drained["prefix_cache"]["hit_tokens"]
            )
            assert (
                after["prefix_cache"]["evicted_blocks"]
                == drained["prefix_cache"]["evicted_blocks"]
                > 0
            )
            assert after["counters"]["overloads"] == 0

            rows = read(directory / "requests.json")
            assert len(rows) == len(profiles)
            cold = rows[:2]
            assert cold == read(directory / "cold.json") and rows[:4] == read(
                directory / "long.json"
            )
            assert max(r["request_written_ns"] for r in cold) < min(
                r["content_ns"][0] for r in cold
            )
            (witness,) = read(directory / "overlap.json")
            assert witness["active_requests"] == 2 and witness["waiting_requests"] == 0
            assert (
                max(r["sent_ns"] for r in cold)
                <= witness["time_ns"]
                < min(r["content_ns"][0] for r in cold)
            )

            requests = {}
            for (case, prompt), row in zip(profiles.items(), rows, strict=True):
                assert (row["case"], row["status"]) == (case, 200)
                for field in ("input_sha256", "prompt_ids_sha256"):
                    assert row[field] == prompt[field], (case, field)
                usage = row["usage"]
                generated = row["generated_ids"]
                assert usage["prompt_tokens"] == prompt["prompt_tokens"]
                assert len(generated) == usage["completion_tokens"] > 0
                assert row["finish"] in ("length", "stop") and row["answer"]
                exact = {
                    k: row[k] for k in ("usage", "generated_ids", "finish", "answer")
                }
                assert identity.setdefault(case, exact) == exact, (gpu, block, case)
                hits = (usage.get("prompt_tokens_details") or {}).get(
                    "cached_tokens", 0
                )
                assert hits % 16 == 0
                if case in LONG[:2]:
                    assert hits == 0
                if case in LONG[2:]:
                    assert hits >= 29_000
                requests[case] = {
                    "prompt_tokens": prompt["prompt_tokens"],
                    "hit_tokens": hits,
                    "completion_tokens": len(generated),
                    **latency(row),
                }

            for subset, snapshot in ((LONG, after_long), (profiles, after)):
                tokens = sum(requests[case]["hit_tokens"] for case in subset)
                assert (
                    snapshot["prefix_cache"]["hit_tokens"] - start_cache["hit_tokens"]
                    == tokens
                )
                steps = phase_delta(zero, snapshot)
                assert sum(s["prefill_tokens"] for s in steps.values()) == sum(
                    requests[case]["prompt_tokens"] - requests[case]["hit_tokens"]
                    for case in subset
                )
            outputs.append(
                {
                    "block": block,
                    "gpu": gpu,
                    "arm": arm,
                    "recovered_from_startup_oom": recovered,
                    "prefix_cache": {
                        "hit_tokens": after["prefix_cache"]["hit_tokens"]
                        - start_cache["hit_tokens"],
                        "evicted_blocks": after["prefix_cache"]["evicted_blocks"]
                        - start_cache["evicted_blocks"],
                        "retained_blocks": after["prefix_cache"]["retained_blocks"],
                    },
                    "long_phase_steps": phase_delta(zero, after_long),
                    "requests": requests,
                }
            )
    assert all(row["prefix_cache"] == outputs[0]["prefix_cache"] for row in outputs)
    replaced = read(captures / "gpu5-released.json")
    retained = read(captures / "gpu6-after.json")
    assert (replaced["pid"], replaced["status"]) == (before[5]["pid"], "stopped")
    assert (retained["pid"], retained["phase"], retained["other_processes"]) == (
        before[6]["pid"],
        "idle",
        [],
    )
    recorded = {
        (uuid.strip(), int(pid))
        for uuid, pid, _ in (
            line.split(",")
            for line in (captures / "processes-after.csv").read_text().splitlines()
        )
    }
    assert (retained["gpu"], retained["pid"]) in recorded
    assert (before[5]["gpu"], before[5]["pid"]) not in recorded
    assert recorded <= {
        (retained["gpu"], retained["pid"]),
        (before[5]["gpu"], startup_retry["observed_other_process"]["pid"]),
    }
    results = {}
    for gpu in GPU_ORDER:
        results[gpu] = {}
        for category, cases in (
            ("cold", LONG[:2]),
            ("warm", LONG[2:]),
            ("shorter", tuple(profiles)[4:]),
        ):
            group = {}
            for arm in ("control", "candidate"):
                arm_runs = [r for r in outputs if r["gpu"] == gpu and r["arm"] == arm]
                group[arm] = {
                    key: [
                        median(r["requests"][c][key] for c in cases) for r in arm_runs
                    ]
                    for key in ("first_ms", "last_content_ms", "http_done_ms")
                }
            results[gpu][category] = group
    return {
        "date": "2026-11-26",
        "base_commit": (root / "base-commit.txt").read_text().strip(),
        "model": {
            "source": model["source_model"],
            "revision": model["source_revision"],
            "dtype": model["dtype"],
            "receipt_sha256": checkpoint_hash,
        },
        "model_manifest_sha256": sha256(models).hexdigest(),
        "binaries": {k: v for k, v in binaries.items() if k.startswith("server-")},
        "prefix_cache_source_sha256": src,
        "gpus": {i: row["gpu"] for i, row in before.items()},
        "requests_verified": len(outputs) * len(profiles),
        "startup_retry": startup_retry,
        "startup_prefix_cache": startup_cache,
        "prompt_profiles": profile_info,
        "median_ms_by_independent_run": results,
        "runs": outputs,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    print(json.dumps(checks(args.root), indent=2, allow_nan=False))
