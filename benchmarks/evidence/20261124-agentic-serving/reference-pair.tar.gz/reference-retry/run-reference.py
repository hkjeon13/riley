"""Run the frozen synthetic workflow against the installed vLLM on a held A100."""
import argparse
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("out", type=Path)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir()
    root = Path("/mnt/efs/nlp/psyche/riley-gap-20261102")
    executable = root / "tools/vllm-venv/bin/vllm"
    model = root / "models/Qwen2.5-7B-Instruct"
    if not os.environ.get("RILEY_GPU_HOLDER_LEASE_DIR") or not os.environ.get("CUDA_VISIBLE_DEVICES"):
        raise RuntimeError("expected a leased Riley GPU")
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    command = [str(executable), "serve", str(model), "--served-model-name", "m", "--host", "127.0.0.1",
               "--port", str(port), "--max-model-len", "8192", "--max-num-seqs", "8",
               "--dtype", "bfloat16", "--block-size", "16", "--kv-cache-memory-bytes", str(4096*917504),
               "--enable-prefix-caching", "--generation-config", "vllm", "--enable-auto-tool-choice",
               "--tool-call-parser", "hermes"]
    (out / "command.json").write_text(json.dumps(command, indent=2)+"\n")
    env = os.environ.copy()
    env.pop("LD_LIBRARY_PATH", None)
    env.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", VLLM_NO_USAGE_STATS="1",
               PATH=str(executable.parent)+":"+env["PATH"])
    version = subprocess.check_output([str(executable.parent / "python"), "-c",
                                      "from importlib.metadata import version; print(version('vllm'))"], env=env)
    (out / "version.txt").write_bytes(version)
    with (out/"server.log").open("xb") as log:
        server = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT,
                                  stdin=subprocess.DEVNULL, start_new_session=True)
        try:
            address = f"127.0.0.1:{port}"
            deadline = time.monotonic()+900
            while time.monotonic()<deadline and server.poll() is None:
                try:
                    with urllib.request.urlopen(f"http://{address}/v1/models", timeout=2) as response:
                        ready = json.load(response)
                    if any(m["id"]=="m" for m in ready["data"]):
                        (out/"ready.json").write_text(json.dumps(ready)+"\n")
                        break
                except (OSError, urllib.error.URLError):
                    pass
                time.sleep(1)
            else:
                raise RuntimeError(f"reference unavailable, process status {server.poll()}")
            for history in (0, 200):
                subprocess.run([sys.executable, "-B", str(Path(__file__).with_name("agent_workflow.py")),
                                address, "m", "--out", str(out/f"workflows-{history}.json"),
                                "--seed", str(args.seed), "--history-entries", str(history)], check=True)
        finally:
            if server.poll() is None:
                os.killpg(server.pid, signal.SIGTERM)
                try:
                    server.wait(60)
                except subprocess.TimeoutExpired:
                    os.killpg(server.pid, signal.SIGKILL)
                    server.wait()


if __name__ == "__main__":
    main()
