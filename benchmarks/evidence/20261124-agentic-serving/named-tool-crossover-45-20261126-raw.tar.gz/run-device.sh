#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
i=$1
root=$(realpath ../../..)
case "$i" in
    4) uuid=GPU-f54a172d-524d-3893-d116-a06d9a0abb53;;
    5) uuid=GPU-73fc52fd-c417-684a-2fea-acf98cb889dc;;
    *) exit 2;;
esac
test "$(nvidia-smi -i "$i" --query-gpu=uuid --format=csv,noheader)" = "$uuid"
while true; do
    apps=$(nvidia-smi -i "$i" --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader)
    printf '%s %s\n' "$(date -u -Is)" "$apps" >> "gpu$i.wait.log"
    if [[ -z $apps ]]; then break; fi
    sleep 8
done
nvidia-smi -i "$i" --query-compute-apps=pid --format=csv,noheader > "gpu$i.processes-before.csv"
test ! -s "gpu$i.processes-before.csv"
CUDA_VISIBLE_DEVICES="$uuid" "$root/tools/vllm-venv/bin/python" -B holder/holder.py --lease-dir holder/leases --index "$i" > "holder/gpu$i.log" 2>&1 &
hp=$!
cleanup() {
    rc=$?
    trap - EXIT
    kill -TERM "$hp" 2>/dev/null || true
    wait "$hp" 2>/dev/null || true
    if [[ -s holder/leases/gpu$i.status.json ]]; then cp "holder/leases/gpu$i.status.json" "gpu$i.released.json"; fi
    nvidia-smi -i "$i" --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader > "gpu$i.processes-after.csv"
    exit "$rc"
}
trap cleanup EXIT
for ((n=0;n<120;n++)); do
    if python3 -B holder/control.py --lease-dir holder/leases --index "$i" status > "gpu$i.preflight.json" 2> "holder/gpu$i.status.log"; then break; fi
    kill -0 "$hp"
    sleep .5
done
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); assert d["phase"]=="idle" and not d["other_processes"]' "gpu$i.preflight.json"
bash run-crossover.sh "$i" > "gpu$i.run.log" 2>&1 &
bench=$!
python3 -B observe_gpu.py "$i" "$bench" > "gpu$i.processes.jsonl" &
obs=$!
status=0
wait "$bench" || status=$?
wait "$obs"
cat "gpu$i.run.log"
exit "$status"
