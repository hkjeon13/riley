"""Acquire each owned lease through its controller and join both on every exit."""

import argparse
import concurrent.futures
import secrets
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from replica_process import serve


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("holder", type=Path)
    p.add_argument("directory", type=Path)
    p.add_argument("policy", choices=("round-robin", "session", "cost", "crossover"))
    args = p.parse_args()
    root = Path(__file__).resolve().parent
    pair = args.directory.resolve()
    if args.policy == "crossover":
        deadline = time.monotonic() + 1800
        while not (root.parent / "long-page" / "probe-released").exists():
            if time.monotonic() >= deadline:
                raise TimeoutError("long-context lease did not return")
            time.sleep(2)
    pair.mkdir()
    holder = args.holder.resolve()

    with (
        tempfile.TemporaryDirectory() as tmp,
        concurrent.futures.ThreadPoolExecutor(2) as pool,
    ):
        keydir = Path(tmp)
        for i in (6, 7):
            (keydir / str(i)).write_text(secrets.token_hex(32))
        futures = [pool.submit(serve, root, holder, pair, i, keydir) for i in (6, 7)]
        try:
            deadline = time.monotonic() + 340
            while not all((pair / f"gpu{i}" / "address").is_file() for i in (6, 7)):
                for future in futures:
                    if future.done():
                        future.result()
                        raise RuntimeError("replica exited before both ready")
                if time.monotonic() >= deadline:
                    raise TimeoutError("pair readiness timed out")
                time.sleep(1)
            driver = (
                "probe_replica_wait.py"
                if args.policy == "crossover"
                else "replica_workflow.py"
            )
            extra = [] if args.policy == "crossover" else [args.policy]
            subprocess.run(
                [
                    sys.executable,
                    "-B",
                    str(root / driver),
                    str(pair),
                    str(keydir),
                    *extra,
                ],
                check=True,
            )
        finally:
            (pair / "finished").touch()
        for future in futures:
            future.result()


if __name__ == "__main__":
    main()
