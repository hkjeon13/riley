#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
trap 'echo "$?" > followup.exit' EXIT
base=..
root=$(realpath ../../../..)
export PATH="$root/tools/rustup/toolchains/1.85.0-x86_64-unknown-linux-gnu/bin:$PATH"
export CARGO_HOME="$root/tools/cargo" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CUDA_VISIBLE_DEVICES=
test "$(cat ../build.exit)" = 0
cp tokenizer.rs ../src/crates/riley-model/src/tokenizer.rs
(cd ../src && nice -n 10 taskset -c 24-27 cargo build --offline --locked --release -p riley-server --features server --example qwen_prompt_profile) > build.log 2>&1
cp ../src/target/release/examples/qwen_prompt_profile candidate
sha256sum ../baseline candidate tokenizer.rs coder_piece_cost.py piece-cache-followup.json > study.sha256
export PYTHONPATH="$(realpath ..)"
nice -n 10 taskset -c 24 python3 -B coder_piece_cost.py "$(realpath ../baseline)" "$PWD/candidate" "$root/models/Qwen2.5-Coder-7B-Instruct" ../client.json ../source.txt result.json --followup
