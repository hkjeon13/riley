#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
trap 'echo "$?" > build.exit' EXIT
root=$(realpath ../../..)
export PATH="$root/tools/rustup/toolchains/1.85.0-x86_64-unknown-linux-gnu/bin:$PATH"
export CARGO_HOME="$root/tools/cargo" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CUDA_VISIBLE_DEVICES=
mkdir src
tar xzf src.tar.gz -C src
t=crates/riley-model/src/tokenizer.rs
cp "src/$t" candidate.rs
sha256sum *.py piece-cache-registration.json client.json baseline.rs candidate.rs source.txt src.tar.gz > study.sha256
for arm in baseline candidate; do
    cp "$arm.rs" "src/$t"
    (cd src && nice -n 10 taskset -c 24-27 cargo build --offline --locked --release -p riley-server --features server --example qwen_prompt_profile) > "$arm.log" 2>&1
    cp src/target/release/examples/qwen_prompt_profile "$arm"
done
sha256sum baseline candidate >bin.sha256
nice -n 10 taskset -c 24 python3 -B coder_piece_cost.py "$PWD/baseline" "$PWD/candidate" "$root/models/Qwen2.5-Coder-7B-Instruct" client.json source.txt result.json
