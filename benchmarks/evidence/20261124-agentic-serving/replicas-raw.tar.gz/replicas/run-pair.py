"""Acquire each owned lease through its controller and join both on every exit."""

import argparse
import concurrent.futures
import json
import secrets
import subprocess
import sys
import tempfile
import time
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("holder", type=Path)
    p.add_argument("directory", type=Path)
    p.add_argument("policy", choices=("round-robin", "session", "cost"))
    args = p.parse_args()
    root = Path(__file__).resolve().parent
    pair = args.directory.resolve()
    pair.mkdir()
    holder = args.holder.resolve()

    def serve(i, keydir):
        out = pair / f"gpu{i}"
        ctl = [
            sys.executable,
            str(holder / "control.py"),
            "--lease-dir",
            str(holder / "leases"),
            "--index",
            str(i),
        ]
        with (pair / f"controller-{i}.log").open("wb") as log:
            start = time.monotonic()
            child = subprocess.run(
                [
                    *ctl,
                    "run",
                    "--",
                    "bash",
                    str(root / "run-replica.sh"),
                    str(out),
                    str(pair),
                    str(keydir / str(i)),
                ],
                stdout=log,
                check=False,
                stderr=subprocess.STDOUT,
            )
            (pair / f"allocation-{i}.json").write_text(
                json.dumps(
                    {
                        "elapsed_s": time.monotonic() - start,
                        "returncode": child.returncode,
                    }
                )
                + "\n"
            )
            if child.returncode:
                raise RuntimeError(f"replica {i} failed; see controller log")
            (out / "lease-after.json").write_bytes(
                subprocess.check_output([*ctl, "status"])
            )

    with (
        tempfile.TemporaryDirectory() as tmp,
        concurrent.futures.ThreadPoolExecutor(2) as pool,
    ):
        keydir = Path(tmp)
        for i in (6, 7):
            (keydir / str(i)).write_text(secrets.token_hex(32))
        futures = [pool.submit(serve, i, keydir) for i in (6, 7)]
        try:
            deadline = time.monotonic() + 340
            while not all((pair / f"gpu{i}" / "address").is_file() for i in (6, 7)):
                for future in futures:
                    if future.done():
                        future.result()
                        raise RuntimeError("replica exited before both ready")
                if time.monotonic() >= deadline:
                    raise TimeoutError("pair readiness timed out")
                time.sleep(1)
            subprocess.run(
                [
                    sys.executable,
                    "-B",
                    str(root / "replica_workflow.py"),
                    str(pair),
                    str(keydir),
                    args.policy,
                ],
                check=True,
            )
        finally:
            (pair / "finished").touch()
        for future in futures:
            future.result()


if __name__ == "__main__":
    main()
