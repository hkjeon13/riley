"""Make the native HTTP worker limit selectable in the isolated old-server build."""
import sys
from pathlib import Path

path = Path(sys.argv[1]) / "crates" / "riley-server" / "src" / "main.rs"
source = path.read_text()
needle = """        worker_threads: options
            .max_active_sequences
            .max(ServerConfig::default().worker_threads),"""
replacement = """        worker_threads: std::env::var("RILEY_PHASE05_HTTP_WORKERS")
            .ok()
            .map(|value| value.parse::<std::num::NonZeroUsize>()
                .map_err(|_| "RILEY_PHASE05_HTTP_WORKERS must be positive".to_owned()))
            .transpose()?
            .map_or(
                options.max_active_sequences.max(ServerConfig::default().worker_threads),
                std::num::NonZeroUsize::get,
            ),"""
assert source.count(needle) == 1
path.write_text(source.replace(needle, replacement, 1))
