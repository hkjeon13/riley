"""Check same-input comparisons and reproduce reported timing results."""
import json
import sys
from pathlib import Path

from analyze_timed_8 import analyze
from verify_phase05 import lines, read


def launch_check(case, baseline_args, digest, manifest, holders):
    registration = read(case / "registration.json")
    reclaimed = {}
    names = {"aws":"ldccai-a100-02", "rtx":"psyche-MS-7D91"}
    boot_ids = set()
    for name in ("aws","rtx"):
        out = case/name/"run"
        assert (out/"host.txt").read_text().strip() == names[name]
        boot_ids.add((out/"boot-id.sha256").read_text().strip())
        assert (out/"binary.sha256").read_text().split()[0] == digest
        assert (out/"model-manifest.sha256").read_text().split()[0] == manifest
        assert int((out/"http-workers.txt").read_text()) == registration["workers"][name]
        if (out/"threads-at-ready.txt").is_file():
            worker_threads = sum(line.startswith("riley-http-") for line in (out/"threads-at-ready.txt").read_text().splitlines())
            assert worker_threads == registration["workers"][name]
        actual = (out/"arguments.txt").read_text().splitlines()
        expected = baseline_args.copy()
        expected[expected.index("--max-waiting-requests")+1] = str(registration["waiting"][name])
        expected[expected.index("--max-active-sequences")+1] = str(registration.get("active",{}).get(name,8))
        expected[expected.index("--model")+1] = actual[actual.index("--model")+1]
        assert actual == expected
        own = int((out/"pid").read_text())
        allowed = {own, holders["pid"]} if name=="aws" else {own}
        observed = {int(line.split(",")[0]) for line in (out/"gpu-samples.txt").read_text().splitlines() if "," in line}
        assert observed <= allowed and own in observed
        done = read(out/"shutdown.json")
        reclaimed[name] = all(done[k]==0 for k in ("active_requests","waiting_requests","kv_allocated_blocks"))
        reclaimed[name] &= not any(done["allocation"].values())
        if name=="rtx":
            reclaimed[name] &= not (out/"compute-after.txt").read_text().strip()
    assert len(boot_ids) == 2
    return reclaimed


def verify_pair(a,b):
    reg_a=read(a/"registration.json")
    reg_b=read(b/"registration.json")
    assert reg_a["seed"] == reg_b["seed"]
    for rate in (2,4,8):
        ra, rb = a/f"rate-{rate}", b/f"rate-{rate}"
        oa, ob = (read(x/"origin.json")["monotonic_ns"] for x in (ra,rb))
        if not all((x/"finished.json").is_file() for x in (ra,rb)):
            raise ValueError("scheduled wave did not finish")
        sort = lambda path: sorted(lines(path/"requests.jsonl"),key=lambda j:j["n"])
        for xa, xb in zip(sort(ra),sort(rb),strict=True):
            assert all(xa[k]==xb[k] for k in ("n","fixture_idx","tenant","kind"))
            if reg_a.get("force_fixed_tools",False) == reg_b.get("force_fixed_tools",False):
                assert xa["direct"] == xb["direct"]
            assert xa["scheduled_ns"]-oa == xb["scheduled_ns"]-ob
            p,q=xa["work"],xb["work"]
            keys=("seed","fixture_sha256","history_entries","document_pairs","tool_delay_s")
            assert all(p[k]==q[k] for k in keys)


def verify(folder):
    policy = read(folder/"campaign.json")
    digest = (folder/"expected.sha256").read_text().split()[0]
    args = (folder/"phase04-arguments.txt").read_text().splitlines()
    manifest="1ec4df22587ab4ebcbfb06fe0782fa881893b7ed3adb52a0e44008f145e978a9"
    holder = read(folder/"aws-holder-after.json")
    assert holder["phase"]=="idle" and not holder["other_processes"]
    assert (folder/"model-aws.txt").read_bytes() == (folder/"model-rtx.txt").read_bytes()
    cases = folder/"cases"
    data, reclamations = {}, {}
    for name in policy["cases"]:
        data[name] = analyze(cases/name)
        reclamations[name] = launch_check(cases/name, args, digest, manifest, holder)
        assert data[name]["cleanup"] == {"aws":0,"rtx":0}
        assert all(reclamations[name].values())
    for baseline, candidate in policy["paired_cases"]:
        verify_pair(cases/baseline,cases/candidate)
    selected = []
    for (before, after), identity in zip(policy["selected_comparisons"], ("a","b"), strict=True):
        prompt = read(folder/f"identity-{identity}.json")
        assert prompt["equal_final_token_pairs"] == 160 and not prompt["different_jobs"]
        a,b = [data[name]["rates"][8]["workflow"] for name in (before,after)]
        selected.append({
            "before": before, "after": after,
            "before_slo": a["overall"]["slo"], "after_slo": b["overall"]["slo"],
            "before_last_p95_ms": a["overall"]["p95_last_ms"],
            "after_last_p95_ms": b["overall"]["p95_last_ms"],
            "after_passed": b["passed"],
            "final_input_token_pairs_equal": prompt["equal_final_token_pairs"],
        })
    return {"registration":policy,"original_client_trace_audit":read(folder/"offline-client-8.json"),
            "timed_binary_sha256":digest,"per_case_reclamation":reclamations,"cases":data,
            "selected":selected,"selected_repeats_passed":all(row["after_passed"] for row in selected)}


if __name__=="__main__":
    print(json.dumps(verify(Path(sys.argv[1])),indent=2))
