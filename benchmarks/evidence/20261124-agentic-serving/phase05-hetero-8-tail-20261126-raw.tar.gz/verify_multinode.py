"""Recompute routing, scoped connection fault and durable workflow gates."""
import collections
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

from agent_workflow import fingerprint, fixture, fixture_tool_result, percentile
from verify_phase05 import read, result_is_correct


def workflow_list(result):
    for wave in result["waves"]:
        for row in wave["jobs"]:
            yield row["work"]
    for case in result["faults"]:
        if case["aligned"]:
            yield case["aligned"]
        for name in ("interrupted", "recovered", "replayed"):
            yield case[name]
        yield from case["after"]


def routing(receipt, works):
    active = set()
    used = {}
    decisions = collections.Counter()
    for event in receipt:
        node = event["node"]
        if event["action"] == "ready":
            assert event["observed"]["ready"] and event["observed"]["at_ns"] <= event["ns"]
            active.add(node)
        elif event["action"] == "unavailable":
            assert not event["observed"]["ready"] and event["observed"]["at_ns"] <= event["ns"]
            active.remove(node)
        else:
            assert event["seq"] == len(used)
            eligible = sorted(active)
            assert event["eligible"] == eligible and node == eligible[event["seq"] % len(eligible)]
            used[event["seq"]] = event
            decisions[node] += 1
    for work in works:
        for turn in work["turns"]:
            if "route" not in turn:
                continue
            route = turn["route"]
            saved = used.pop(route["seq"])
            assert all(saved[key] == value for key, value in route.items())
            assert saved["id"] == work["workflow_id"] and saved["turn"] == turn["turn"]
            assert saved["ns"] <= turn["sent_ns"]
    assert not used
    return {"all_http_requests_by_node": dict(decisions), "excluded_or_unready_admissions": 0}


def ready_path(works, node):
    return all(
        turn["route"]["node"] == node
        for work in works for turn in work["turns"] if "route" in turn
    )


def check_fault(raw, effects, bounds):
    end = raw["interrupted"]["turns"][-1]
    mode = raw["edge"]
    target = raw["target"]
    peer = "rtx" if target == "aws" else "aws"
    seen_chunks = len(end["content_ns"])
    trigger = raw["trigger"]
    if mode == "before-final-content":
        boundary = end["turn"] == 2 and seen_chunks == 0 and "done_ns" not in end and end["status"] == 200
    elif mode == "partial-final-content":
        boundary = end["turn"] == 2 and seen_chunks >= 4 and "done_ns" not in end and "finish" not in end
    else:
        boundary = (
            end["turn"] == 0 and "done_ns" in end and end["finish"] in ("tool_calls", "stop")
            and end["done_ns"] <= trigger["start_ns"]
            and json.loads(end["call"]["function"]["arguments"]) == {}
            and end["call"]["function"]["name"] == "list_reports"
        )
    recovered = raw["recovered"]
    replayed = raw["replayed"]
    recovery = (recovered["turns"][-1].get("done_ns", 0) - trigger["start_ns"]) / 1e9
    observed_loss = (raw["negative_probe"]["at_ns"] - trigger["start_ns"]) / 1e9
    readmission = (raw["readmit_ns"] - raw["reopen_ns"]) / 1e9
    complete_dual = (max(work["end_ns"] for work in raw["after"]) - raw["reopen_ns"]) / 1e9
    stage_attempts = raw["tool_attempts"]
    _, _, docs = fixture(recovered["seed"], recovered["document_pairs"])
    expected_results = [fixture_tool_result(i, docs) for i in (0, 1)]
    expected_effects = [
        (0, "list_reports", {}, expected_results[0]),
        (1, "read_reports", {"first": "report-A", "second": "report-B"}, expected_results[1]),
    ]
    expect_commits = [[], [True, True], [False, False]] if mode == "completed-tool-call" else [[True, True], [False, False], [False, False]]
    management = raw["management_during_cut"]
    checks = {
        "observed_requested_boundary": boundary and not raw["interrupted"]["ok"] and end["route"]["node"] == target,
        "data_path_detected_and_excluded": not raw["negative_probe"]["ready"] and (
            trigger["closed_ns"] <= raw["negative_probe"]["at_ns"] <= raw["router_removed_ns"]
        ) and observed_loss <= bounds["health_observe_max_s"],
        "survivor_success_before_rejoin": result_is_correct(recovered) and result_is_correct(replayed)
        and ready_path((recovered, replayed), peer) and 0 < recovery <= bounds["survivor_correct_max_s"]
        and replayed["end_ns"] < raw["readmit_ns"],
        "management_path_and_same_server_alive": management["pid"] == raw["initial_pid"]
        and management["ready"]["ready"] and management["ready"]["accepting"],
        "restored_only_after_ready_on_both_nodes": raw["positive_probe"]["ready"]
        and raw["reopen_ns"] <= raw["positive_probe"]["at_ns"] <= raw["readmit_ns"]
        and complete_dual <= bounds["both_runtime_paths_correct_after_reopen_max_s"]
        and all(result_is_correct(work) for work in raw["after"])
        and {work["turns"][-1]["route"]["node"] for work in raw["after"]} == {"aws", "rtx"},
        "durable_exact_results_no_duplicate_effect": effects == expected_effects and
        [[t["committed"] for t in stage] for stage in stage_attempts] == expect_commits
        and all(t["result_sha256"] == fingerprint(expected_results[t["turn"]]) for stage in stage_attempts for t in stage),
    }
    return {
        "case": mode, "interrupted_node": target, "chunks_in_interrupted_turn": seen_chunks,
        "sse_done": "done_ns" in end, "interrupted_turn": end["turn"],
        "connection_loss_observed_s": observed_loss,
        "workflow_recovered_on_peer_s": recovery,
        "ready_and_readmitted_after_reopen_s": readmission,
        "both_nodes_final_response_after_reopen_s": complete_dual,
        "recorded_effects": len(effects), "checks": checks, "passed": all(checks.values()),
    }


def read_hosts(root, cfg):
    reference = (root / "phase04-arguments.txt").read_text().splitlines()
    checkpoint = read(root / "phase04-checkpoint-receipt.json")
    expect = hashlib.sha256((root / "phase04-checkpoint-receipt.json").read_bytes()).hexdigest()
    holders = read(root / "aws-holder-after.json")
    info = {}
    shutdown = {}
    for name in ("aws", "rtx"):
        path = root / name / "run"
        opts = (path / "arguments.txt").read_text().splitlines()
        assert reference[:4] == opts[:4] and reference[5:] == opts[5:]
        assert (path / "binary.sha256").read_text().split()[0] == cfg["reference_binary_sha256"]
        assert (path / "model-manifest.sha256").read_text().split()[0] == expect
        assert (root / name / "model-verification.txt").read_text().splitlines()[:-1] == [
            item["path"] + ": OK" for item in checkpoint["files"]
        ]
        gauges = read(path / "shutdown.json")
        shutdown[name] = not any(gauges["allocation"].values()) and all(
            gauges[key] == 0 for key in ("active_requests", "waiting_requests", "kv_allocated_blocks")
        )
        pid = int((path / "pid").read_text())
        allowed = {pid}
        if name == "aws":
            allowed.add(holders["pid"])
        pids = {int(line.split(",")[0]) for line in (path / "gpu-samples.txt").read_text().splitlines() if "," in line}
        info[name] = {
            "physical_host": (path / "host.txt").read_text().strip(),
            "boot_identity_digest": (path / "boot-id.sha256").read_text().strip(),
            "device": (path / "device.csv").read_text().splitlines()[-1],
            "foreign_compute_pids": sorted(pids - allowed),
            "startup_through_ready_s": (
                int((path / "ready-epoch-ns").read_text()) - int((path / "started-epoch-ns").read_text())
            ) / 1e9,
        }
    identities = {value["boot_identity_digest"] for value in info.values()}
    assert [node["physical_host"] for node in info.values()] == cfg["physical_hosts"] and len(identities) == 2
    cleanup = all(shutdown.values()) and holders["phase"] == "idle" and not holders["other_processes"] and (
        root / "rtx" / "run" / "compute-after.txt"
    ).read_text().strip() == ""
    return info, cleanup


def analyze(folder):
    cfg = read(folder / "multinode-registration.json")
    out = folder / "session"
    result = read(out / "observations.json")
    host_info, host_clean = read_hosts(folder, cfg)
    routes = routing(read(out / "routing-events.json"), workflow_list(result))
    ready = []
    wave_counts = collections.Counter()
    for wave in result["waves"]:
        assert len(wave["jobs"]) == wave["size"]
        for row in wave["jobs"]:
            for turn in row["work"]["turns"]:
                if "route" in turn:
                    wave_counts[turn["route"]["node"]] += 1
        done = [row for row in wave["jobs"] if result_is_correct(row["work"])]
        ready.append({"size": wave["size"], "correct": len(done)})
    assert [w["size"] for w in ready] == cfg["load"]["waves"]
    db = sqlite3.connect(f"file:{out / 'effects.sqlite'}?mode=ro", uri=True)
    try:
        effects = collections.defaultdict(list)
        for logical, turn, payload, saved in db.execute(
            "SELECT workflow,turn,payload,result FROM action ORDER BY workflow,turn"
        ):
            call = json.loads(payload)
            effects[logical].append((turn, call["name"], call["arguments"], json.loads(saved)))
    finally:
        db.close()
    assert [case["edge"] for case in result["faults"]] == cfg["faults"]["boundaries"]
    faults = [check_fault(case, effects[case["logical_id"]], cfg["faults"]) for case in result["faults"]]
    checks = {
        "healthy_routing_workflow_correctness": all(w["correct"] == w["size"] for w in ready) and len(wave_counts) == 2 and
        abs(wave_counts["aws"] - wave_counts["rtx"]) <= 1,
        "separate_authenticated_endpoints": all(
            auth["own_key"] == {"http": 200, "models": ["m"]} and auth["other_key"]["http"] == 401
            for auth in result["authentication"].values()
        ) and set(result["authentication"]) == {"aws", "rtx"},
        "scoped_data_path_failure_recovered": all(case["passed"] for case in faults),
        "all_effects_accounted_for": len(effects) == 3 and sum(map(len, effects.values())) == 6,
        "gpu_cleanup_no_foreign_processes": host_clean and not any(node["foreign_compute_pids"] for node in host_info.values()) and
        read(out / "cleanup.json") == {"aws": 0, "rtx": 0},
    }
    return {
        "registration": cfg, "hosts": host_info, "routing": routes,
        "healthy_wave_requests_by_node": dict(wave_counts), "healthy_waves": ready,
        "faults": faults, "checks": checks, "passed": all(checks.values()),
    }


if __name__ == "__main__":
    print(json.dumps(analyze(Path(sys.argv[1])), indent=2))
