"""Reconstruct the actual final requests and check all tokenizer IDs."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

from agent_workflow import append_tool_result, fingerprint, fixture, history_messages, turn_request
from verify_agent_citations import with_citations
from verify_phase05 import lines


def final(row):
    work = row["work"]
    tools, prompt, docs = fixture(work["seed"], work["document_pairs"])
    messages = history_messages(work["seed"], work["history_entries"])
    messages.append({"role": "user", "content": prompt})
    for turn in work["turns"][:2]:
        append_tool_result(messages, [turn["call"]], docs, turn["turn"])
    body = with_citations(turn_request("m", messages, tools, None))
    assert fingerprint(body) == work["turns"][-1]["input_sha256"]
    return body


def receipt(profiler, tokenizer, cases):
    cases = [Path(path)/"rate-8"/"requests.jsonl" for path in cases]
    rows = [sorted(lines(c),key=lambda r:r["n"]) for c in cases]
    assert all(len(arm)==160 for arm in rows)
    prompts = [final(r) for arm in rows for r in arm]
    value = subprocess.run([profiler,tokenizer],input="".join(json.dumps(p)+"\n" for p in prompts),
                           text=True,capture_output=True,check=True)
    results = [json.loads(line)["ids"] for line in value.stdout.splitlines()]
    assert len(results) == 320
    output, differ = [], []
    for j,(p,q) in enumerate(zip(results[:160],results[160:],strict=True)):
        a,b = [arm[j] for arm in rows]
        assert a["n"]==b["n"] and a["work"]["fixture_sha256"]==b["work"]["fixture_sha256"]
        assert len(p)==a["work"]["turns"][-1]["usage"]["prompt_tokens"]
        assert len(q)==b["work"]["turns"][-1]["usage"]["prompt_tokens"]
        output.append({"index":a["n"],"tokens": [len(p),len(q)],"sha256":[fingerprint(p),fingerprint(q)]})
        if p!=q:
            differ.append(a["n"])
    sha=lambda file:hashlib.sha256(Path(file).read_bytes()).hexdigest()
    return {"equal_final_token_pairs":160-len(differ),"different_jobs":differ,"responses":output,
            "native_profiler_sha256":sha(profiler),
            "tokenizer_sha256":sha(Path(tokenizer)/"tokenizer.json"),
            "tokenizer_config_sha256":sha(Path(tokenizer)/"tokenizer_config.json")}


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("profiler")
    parser.add_argument("tokenizer")
    parser.add_argument("baseline")
    parser.add_argument("candidate")
    a=parser.parse_args()
    print(json.dumps(receipt(a.profiler,a.tokenizer,(a.baseline,a.candidate)),indent=2))
