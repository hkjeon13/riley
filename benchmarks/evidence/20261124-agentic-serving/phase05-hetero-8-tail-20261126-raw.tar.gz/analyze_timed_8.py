"""Join native, HTTP and client timestamps without equating cross-host clocks."""
import collections
import json
import sys
from pathlib import Path

from verify_hetero_load import capacity_plan, cell, percentile, read


NS_MS = 1_000_000


def logs(path):
    trace = {}
    for line in path.read_text().splitlines():
        if not line.startswith(("PHASE05_ENGINE ", "PHASE05_HTTP ", "PHASE05_REQUEST ")):
            continue
        tag, response, *fields = line.split()
        key = (tag, response)
        assert key not in trace, key
        trace[key] = list(map(int, fields))
    return trace


def timings(turn, trace):
    response = turn.get("response_id")
    get = lambda stage: trace.get((f"PHASE05_{stage}", response))
    if not (get("ENGINE") and get("HTTP") and get("REQUEST")):
        return None
    deq, wait, submit, admit = get("REQUEST")
    gen_first, gen_last, gen_count, gen_end = get("ENGINE")
    http_first, http_last, http_count, http_end = get("HTTP")
    assert deq <= submit <= admit and gen_first <= gen_last <= gen_end
    assert http_first <= http_last <= http_end
    accepted = deq - wait
    return {
        "worker_queue_ms": wait / NS_MS,
        "frame_and_render_ms": (submit-deq) / NS_MS,
        "backend_admission_ms": (admit-submit) / NS_MS,
        "worker_to_first_ms": (http_first-deq) / NS_MS if http_count else None,
        "admission_to_http_first_ms": (http_first-admit) / NS_MS if http_count else None,
        "http_text_span_ms": (http_last-http_first) / NS_MS if http_count else None,
        "engine_text_span_ms": (gen_last-gen_first) / NS_MS if gen_count else None,
        "server_accepted_to_first_ms": (http_first-accepted) / NS_MS if http_count else None,
        "server_accepted_to_terminal_ms": (http_end-accepted) / NS_MS,
        "server_text_count": http_count,
    }


def quantiles(rows, fields):
    return {
        k: {"p50": percentile(pool, .5), "p95": percentile(pool, .95)}
        for k in fields
        if (pool := [r[k] for r in rows if r.get(k) is not None])
    }


def decompose(raw, traced):
    joined, missing, workflows = [], [], []
    for job in raw:
        work = job["work"]
        parts = []
        for turn in work["turns"]:
            if "route" not in turn or turn.get("status") != 200:
                continue
            node = turn["route"]["node"]
            values = timings(turn, traced[node])
            if values is None:
                missing.append({"index":job["n"],"turn":turn["turn"],"id":turn.get("response_id"),"node":node})
                continue
            values.update(node=node, kind="final" if turn["turn"] == 2 else "tool",
                          index=job["n"], id=turn["response_id"])
            if turn.get("done_ns"):
                values["client_post_to_done_ms"]=(turn["done_ns"]-turn["sent_ns"])/NS_MS
                values["relay_and_client_post_to_done_ms"]=values["client_post_to_done_ms"]-values["server_accepted_to_terminal_ms"]
            if turn.get("content_ns") and turn["turn"] == 2:
                start, end = turn["content_ns"][0], turn["content_ns"][-1]
                values.update(client_post_to_first_ms=(start-turn["sent_ns"])/NS_MS,
                              client_text_span_ms=(end-start)/NS_MS)
                if values["server_accepted_to_first_ms"] is not None:
                    values["mixed_transport_before_first_ms"] = values["client_post_to_first_ms"]-values["server_accepted_to_first_ms"]
                if values["http_text_span_ms"] is not None:
                    values["relay_and_receiver_added_text_span_ms"] = values["client_text_span_ms"]-values["http_text_span_ms"]
            joined.append(values)
            parts.append(values)
        if work["ok"] and len(parts)==sum("route" in r for r in work["turns"]):
            last=work["turns"][-1]
            workflows.append({
                "index":job["n"],"node":last["route"]["node"],
                "branch":"app" if job["direct"] else "model",
                "schedule_to_first_ms":(last["content_ns"][0]-job["scheduled_ns"])/NS_MS,
                "schedule_to_last_ms":(last["content_ns"][-1]-job["scheduled_ns"])/NS_MS,
                "cum_worker_queue_ms":sum(p["worker_queue_ms"] for p in parts),
                "pre_final_worker_queue_ms":sum(p["worker_queue_ms"] for p in parts if p["kind"]=="tool"),
                "final_worker_queue_ms":parts[-1]["worker_queue_ms"],
                "final_engine_text_span_ms":parts[-1]["engine_text_span_ms"],
                "final_relay_and_receiver_added_text_span_ms":parts[-1].get("relay_and_receiver_added_text_span_ms"),
            })
    q={}
    for node in ("aws","rtx"):
        for kind in ("tool","final"):
            rows=[v for v in joined if v["node"]==node and v["kind"]==kind]
            q[node+"_"+kind]={"n":len(rows),"durations":quantiles(rows,(
                "worker_queue_ms","frame_and_render_ms","backend_admission_ms","admission_to_http_first_ms",
                "engine_text_span_ms","http_text_span_ms","client_text_span_ms",
                "mixed_transport_before_first_ms","relay_and_receiver_added_text_span_ms",
                "relay_and_client_post_to_done_ms",
            ))}
    by_workflow={}
    for branch in ("app","model","all"):
        items=[r for r in workflows if branch=="all" or r["branch"]==branch]
        by_workflow[branch]={"n":len(items),"durations":quantiles(items,(
            "schedule_to_first_ms","schedule_to_last_ms","cum_worker_queue_ms",
            "pre_final_worker_queue_ms","final_worker_queue_ms","final_engine_text_span_ms",
            "final_relay_and_receiver_added_text_span_ms",
        ))}
    return {"joined_http":len(joined),"missing_http":missing,"by_turn":q,
            "by_workflow":by_workflow,"tail_workflows":sorted(workflows,key=lambda row:row["schedule_to_last_ms"])[-10:]}


def check_routing(case, raw, info):
    ready = set()
    issued, running = {}, {}
    outstanding = collections.Counter()
    weighted = info.get("policy") == "weighted-inflight"
    counts = collections.Counter()
    for event in read(case / "routing-events.json"):
        label = event["node"]
        if event["action"] == "ready":
            assert event["observed"]["ready"] and event["observed"]["at_ns"] <= event["ns"]
            ready.add(label)
            continue
        seq = event["seq"]
        if event["action"] == "release":
            assert weighted and running.pop(seq) == (label,event["units"])
            outstanding[label] -= event["units"]
            assert outstanding[label] >= 0
            continue
        eligible = sorted(ready)
        assert event["action"] == "route" and event["eligible"] == eligible and seq == len(issued)
        if weighted:
            units = event["units"]
            assert units == (4 if event["turn"] == 2 else 1)
            assert event["pending"] == {name:outstanding[name] for name in eligible}
            rank = {name:(k-seq) % len(eligible) for k,name in enumerate(eligible)}
            expected = min(eligible, key=lambda name: (
                (outstanding[name]+units) * (6 // info["weights"][name]), rank[name]
            ))
            running[seq] = (label,units)
            outstanding[label] += units
        else:
            expected = eligible[seq % len(eligible)]
        assert label == expected
        issued[seq] = event
        counts[label] += 1
    assert not running and not any(outstanding.values())
    for row in raw:
        work = row["work"]
        for turn in work["turns"]:
            if "route" not in turn:
                continue
            route = turn["route"]
            recorded = issued.pop(route["seq"])
            assert recorded["id"] == work["workflow_id"] and recorded["turn"] == turn["turn"]
            assert all(recorded[key] == value for key,value in route.items())
            assert route["ns"] <= turn["sent_ns"]
    assert not issued
    return dict(counts)


def analyze(case):
    info = read(case / "registration.json")
    traced = {key:logs(case/key/"run"/"server.log") for key in ("aws","rtx")}
    levels = {}
    all_rows = []
    offset = 0
    for rate in info["rates"]:
        stats, rows, _ = cell(
            case/f"rate-{rate}", capacity_plan(rate,info["seconds_per_rate"],offset), info["seed"], ["aws","rtx"],
            {k:info[k] for k in ("first_ms","last_ms","gap_ms")}, False, info.get("force_fixed_tools",False),
        )
        for row in rows:
            assert all(t["route"]["eligible"]==["aws","rtx"] for t in row["work"]["turns"] if "route" in t)
        n=stats["overall"]
        stats["passed"]=(n["slo"]/n["submitted"]>=info["min_slo"] and n["rejected"]/n["submitted"]<=info["max_reject"] and not stats["unexpected"])
        levels[rate]={"workflow":stats,"timing":decompose(rows,traced)}
        all_rows.extend(rows)
        offset+=len(rows)
    return {"configuration":info,"rates":levels,"routes":check_routing(case,all_rows,info),
            "cleanup":read(case/"cleanup.json")}


if __name__=="__main__":
    print(json.dumps(analyze(Path(sys.argv[1])),indent=2))
