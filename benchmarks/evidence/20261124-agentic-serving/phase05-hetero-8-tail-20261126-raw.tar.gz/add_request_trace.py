"""Add HTTP worker and admission boundaries to the isolated diagnostic server."""
import sys
from pathlib import Path

path = Path(sys.argv[1]) / "crates/riley-server/src/service.rs"
source = path.read_text()
anchors = [
    ("struct ConnectionJob {", """struct ConnectionJob {
    enqueued_ns: u128,"""),
    ("sender.try_send(ConnectionJob {\n                    stream,", """sender.try_send(ConnectionJob {
                    enqueued_ns: crate::engine::phase05_clock(),
                    stream,"""),
    ("fn worker_loop(", """// Benchmark-wide diagnostics only. Each fixed HTTP worker handles one
// connection at a time, so the wait timestamp has request-local semantics.
thread_local! {
    static PHASE05_HTTP_DEQUEUE: std::cell::Cell<(u128, u64)> = const { std::cell::Cell::new((0, 0)) };
}

fn worker_loop("""),
    ("Ok(mut job) => {", """Ok(mut job) => {
                let dequeued_ns = crate::engine::phase05_clock();
                let wait_ns = u64::try_from(dequeued_ns - job.enqueued_ns).unwrap_or(u64::MAX);
                PHASE05_HTTP_DEQUEUE.set((dequeued_ns, wait_ns));"""),
    ("    let admission_started = Instant::now();\n    let submitted = match backend.submit(request) {", """    let enqueue_ns = crate::engine::phase05_clock();
    let admission_started = Instant::now();
    let submitted = match backend.submit(request) {"""),
    ("    let queue_wait = admission_started.elapsed();\n    let tracker = RequestTracker::new(", """    let admitted_ns = crate::engine::phase05_clock();
    let queue_wait = admission_started.elapsed();
    let (dequeued_ns, worker_wait_ns) = PHASE05_HTTP_DEQUEUE.get();
    eprintln!("PHASE05_REQUEST {} {dequeued_ns} {worker_wait_ns} {enqueue_ns} {admitted_ns}",
        submitted.metadata().request_id);
    let tracker = RequestTracker::new("""),
]
for anchor, replacement in anchors:
    assert source.count(anchor) == 1, anchor
    source = source.replace(anchor, replacement, 1)
source = source.replace(
    "#[allow(clippy::too_many_arguments)] // The borrowed worker state mirrors one connection lifecycle.\n// Benchmark-wide",
    "// Benchmark-wide",
    1,
)
source = source.replace("\nfn worker_loop(", "\n#[allow(clippy::too_many_arguments)]\nfn worker_loop(", 1)
path.write_text(source)
