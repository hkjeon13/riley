#!/usr/bin/env bash
set -euo pipefail
trap 'rc=$?; printf "%s\n" "$rc" > build-exit.new; mv build-exit.new build-exit' EXIT
root=$(realpath ../../..)
old="$(dirname "$PWD")/phase05-balanced-20261126.oZ6p5dKn"
test "$(sha256sum "$old/trace-server" | cut -d ' ' -f1)" = 32c87fdf027dcb56beec137c3dd518078353ecdffdb71fb5d777819fa28c58dc
if [[ ! -d src ]]; then
    cp -a "$old/trace-src" src
    python3 -B add_request_trace.py src
fi
python3 -B select_http_workers.py src
rc=0
diff -u --label a/crates/riley-server/src/service.rs --label b/crates/riley-server/src/service.rs \
    "$old/trace-src/crates/riley-server/src/service.rs" src/crates/riley-server/src/service.rs > request-timing.patch || rc=$?
test "$rc" = 1
rc=0
diff -u --label a/crates/riley-server/src/main.rs --label b/crates/riley-server/src/main.rs \
    "$old/trace-src/crates/riley-server/src/main.rs" src/crates/riley-server/src/main.rs > worker-config.patch || rc=$?
test "$rc" = 1
export PATH="$root/tools/rustup/toolchains/1.85.0-x86_64-unknown-linux-gnu/bin:/usr/local/cuda-12.4/bin:$PATH"
export CARGO_HOME="$root/tools/cargo" CUDA_HOME=/usr/local/cuda-12.4 CUDAToolkit_ROOT=/usr/local/cuda-12.4
export LD_LIBRARY_PATH=/usr/local/cuda-12.4/lib64 RILEY_CUDA_ARCHITECTURES=80
export CMAKE_BUILD_PARALLEL_LEVEL=2 CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CUDA_VISIBLE_DEVICES=
export CARGO_TARGET_DIR="$PWD/target"
(cd src; cargo build --locked --offline --release -p riley-server --features server,cuda --bin riley)
cp target/release/riley timed-server
sha256sum timed-server > timed-server.sha256
