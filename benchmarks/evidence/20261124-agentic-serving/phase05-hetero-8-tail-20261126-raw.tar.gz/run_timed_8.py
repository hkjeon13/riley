"""Boot a scoped pair and replay the original 2/4/8 per-second schedule."""
import argparse
import concurrent.futures
import contextlib
import json
import secrets
import shlex
import subprocess
import time
from pathlib import Path

from run_hetero_load import capacity_plan, run_cell
from run_multinode import Fleet, LEASE, Node, SSH, stop, write


ROOT = Path(__file__).resolve().parent


class TrialNode(Node):
    def __init__(self, label, desc, output, args):
        self.base = desc["directory"]
        self.trial = args.name
        self.workers = args.aws_workers if label == "aws" else args.rtx_workers
        self.waiting = args.aws_waiting if label == "aws" else args.rtx_waiting
        self.active_limit = args.active_sequences
        desc = {**desc, "directory": f"{self.base}/{args.name}"}
        super().__init__(label, desc, output)

    def remote(self, code, data=None):
        return subprocess.check_output([*SSH, self.alias, code], input=data, text=True, timeout=60)

    def start(self):
        base, directory = shlex.quote(self.base), shlex.quote(self.directory)
        self.remote(f"mkdir {directory} && cd {directory} && "
            f"cp {base}/remote_replica.sh {base}/binary-path.txt {base}/model-path.txt {base}/expected.sha256 . && "
            "umask 077; cat > trial-key", self.key)
        boot = f"bash remote_replica.sh {self.label} {self.workers} {self.waiting} {self.active_limit}"
        if self.label == "aws":
            boot = (f"python3 -B {LEASE}/control.py --lease-dir {LEASE}/leases --index {self.index} run -- {boot}")
        self.log = self.out / f"{self.label}-controller.log"
        self.started = time.monotonic_ns()
        with self.log.open("wb") as target:
            self.server = subprocess.Popen([*SSH, "-nT", self.alias, f"cd {directory} && {boot}"], stdout=target, stderr=subprocess.STDOUT)

    def finish(self):
        stop(self.tunnel)
        if self.server is None or self.server.poll() is not None:
            return self.server.returncode if self.server else None
        try:
            self.remote(f"touch {shlex.quote(self.directory)}/finish")
            return self.server.wait(timeout=200)
        finally:
            stop(self.server)


def main(args):
    descriptor = json.loads((ROOT / "trial-inventory.json").read_text())
    output = args.root / args.name
    output.mkdir()
    nodes = {label: TrialNode(label, definition, output, args) for label, definition in descriptor.items()}
    fleet = Fleet(nodes, args.policy)
    write(output / "registration.json", {
        "name": args.name, "seed": args.seed, "seconds_per_rate": 20, "rates": [2,4,8],
        "workers": {name: node.workers for name,node in nodes.items()},
        "waiting": {name: node.waiting for name,node in nodes.items()},
        "active": {name: node.active_limit for name,node in nodes.items()},
        "policy": args.policy,
        "weights": fleet.weights if args.policy == "weighted-inflight" else None,
        "force_fixed_tools": args.force_fixed_tools,
        "required_workflows": 160, "min_slo": .95, "max_reject": .05,
        "first_ms": 10000, "last_ms": 18000, "gap_ms": 150,
    })
    try:
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            list(pool.map(TrialNode.start, nodes.values()))
            boot = list(pool.map(TrialNode.ready_from_controller, nodes.values()))
            data = list(pool.map(TrialNode.open_tunnel, nodes.values()))
        ready = {}
        for node, boot_ns, health in zip(nodes.values(), boot, data, strict=True):
            ready[node.label] = {
                "pid": node.pid, "through_listen_ns": boot_ns - node.started,
                "admitted_ns": fleet.update(node.label, health),
            }
        write(output / "initial.json", ready)
        offset = 0
        for rate in (2,4,8):
            run_cell(fleet, output / f"rate-{rate}", capacity_plan(rate, 20, offset), 20, args.seed, False,
                     args.force_fixed_tools)
            offset += rate * 20
    finally:
        write(output / "routing-events.json", fleet.events)
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            pending = {name: pool.submit(node.finish) for name,node in nodes.items()}
            codes = {}
            for label, job in pending.items():
                try:
                    codes[label] = job.result()
                except Exception as error:
                    codes[label] = {"error": str(error)}
        write(output / "cleanup.json", codes)


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("root", type=Path)
    cli.add_argument("name", choices=("baseline-a","candidate-a","candidate-b","baseline-b","alternative-a","alternative-b","active-confirm","dispatch-a","dispatch-b","transport-a","transport-b"))
    cli.add_argument("--seed", type=int, required=True)
    cli.add_argument("--policy", choices=("round-robin","weighted-inflight"), default="round-robin")
    cli.add_argument("--active-sequences", type=int, default=8)
    cli.add_argument("--force-fixed-tools", action="store_true")
    for target in ("aws","rtx"):
        cli.add_argument(f"--{target}-workers", type=int, default=8)
        cli.add_argument(f"--{target}-waiting", type=int, default=2)
    main(cli.parse_args())
