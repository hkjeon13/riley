def workload_template(index):
    if index >= 840:
        return index - 840
    return index
