"""Decompose the archived 8/s client traces before the timing rerun."""
import json
import sys
from collections import Counter
from pathlib import Path

from agent_workflow import percentile


def analyze(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    result = []
    for job in rows:
        work = job["work"]
        if not work["ok"]:
            continue
        final = work["turns"][-1]
        marks = [job["scheduled_ns"], work["start_ns"], final["sent_ns"],
                 final["content_ns"][0], final["content_ns"][-1], final["done_ns"]]
        d = dict(zip(("dispatch","before_final_send","final_send_to_first",
                      "client_visible_span","last_to_done"),
                     [(b-a)/1e6 for a,b in zip(marks,marks[1:])],strict=True))
        d.update(
            total=(marks[4]-marks[0])/1e6,
            first=(marks[3]-marks[0])/1e6,
            gap=work["final_gap_p95_ms"],
            node=final["route"]["node"],
            branch="app" if job["direct"] else "model",
            index=job["n"],
        )
        result.append(d)
    profile={}
    for select in ("all","aws","rtx","app","model"):
        hits=[r for r in result if select=="all" or r["node"]==select or r["branch"]==select]
        profile[select] = {
            "n":len(hits),
            "quantiles":{name: {str(q):percentile([r[name] for r in hits],q) for q in (.50,.95)}
                         for name in ("before_final_send","final_send_to_first","client_visible_span","total")},
            "by_gate":dict(Counter(f"first:{r['first']<=10000},last:{r['total']<=18000},gap:{r['gap']<=150}" for r in hits)),
        }
    return {"groups":profile,"ten_slowest":sorted(result,key=lambda r:r["total"])[-10:]}


if __name__=="__main__":
    base=Path(sys.argv[1])/"performance"
    print(json.dumps({name:analyze(base/name/"requests.jsonl") for name in ("arm-1-rate-8","arm-2-rate-8")},indent=2))
