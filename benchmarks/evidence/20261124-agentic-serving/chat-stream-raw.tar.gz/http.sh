set -euo pipefail
root=$(realpath ../../..)
export PATH="$root/tools/rustup/toolchains/1.85.0-x86_64-unknown-linux-gnu/bin:$PATH" CARGO_HOME="$root/tools/cargo" CARGO_TARGET_DIR="$PWD/target" CARGO_BUILD_JOBS=3 CUDA_VISIBLE_DEVICES=
cp -R src socket-src
python3 chat_stream_http_overlay.py socket-src/crates/riley-server/src/service.rs
export RILEY_STREAM_CASES="$PWD/cases.json"
base="$PWD"
cd socket-src
taskset -c 30-32 cargo test --no-run --release --locked --offline -p riley-server --features server --lib --message-format=json > "$base/build-tests.jsonl"
bin=$(python3 -c 'import json,sys; print(next(v["executable"] for line in sys.stdin if (v:=json.loads(line)).get("executable") and v["target"]["name"]=="riley_server"))' < "$base/build-tests.jsonl")
for run in 0-old 1-new 2-new 3-old; do
    unset RILEY_STREAM_LEGACY
    if [[ $run == *old ]]; then export RILEY_STREAM_LEGACY=1; fi
    RILEY_STREAM_OUT="$base/http-$run.json" taskset -c 30-35 "$bin" service::tests::recorded_final_chat_streams_over_tcp --exact
done
