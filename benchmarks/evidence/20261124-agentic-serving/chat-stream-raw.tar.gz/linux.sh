set -euo pipefail
root=$(realpath ../../..)
export PATH="$root/tools/rustup/toolchains/1.85.0-x86_64-unknown-linux-gnu/bin:$PATH"
export CARGO_HOME="$root/tools/cargo" CARGO_TARGET_DIR="$PWD/target" CARGO_BUILD_JOBS=3 CUDA_VISIBLE_DEVICES=
mkdir src
tar xzf src.tar.gz -C src
cd src
taskset -c 30-32 cargo build --release --locked --offline -p riley-server --features server --example chat_stream_replay
cd ..
taskset -c 30 target/release/examples/chat_stream_replay 300 < cases.json > linux.json
