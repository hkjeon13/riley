"""Plan an optional chat preview inside a prompt-token budget using Riley's exact renderer."""

import json
import subprocess
import threading
from contextlib import AbstractContextManager

from agent_workflow import fingerprint


class PromptProfiler(AbstractContextManager):
    """Keep the checkpoint tokenizer warm across tool waits; serialize one request/response pair."""

    def __init__(self, executable, tokenizer, *, llama3=False):
        self.command = [executable, tokenizer, "--interactive"]
        if llama3:
            self.command.append("--llama3")
        self.lock = threading.Lock()

    def __enter__(self):
        self.proc = subprocess.Popen(
            self.command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True,
            encoding="utf-8",
        )
        return self

    def ids(self, req):
        with self.lock:
            self.proc.stdin.write(json.dumps(req, ensure_ascii=False) + "\n")
            self.proc.stdin.flush()
            line = self.proc.stdout.readline()
            if not line:
                raise ValueError(
                    "native chat profiler exited before returning token IDs"
                )
            return json.loads(line)["ids"]

    def __exit__(self, *exc):
        try:
            self.proc.stdin.close()
        except BrokenPipeError:
            pass
        try:
            self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait()
        finally:
            self.proc.stdout.close()


def budgeted_preview(request, budget, encode, *, cancelled=lambda: False):
    """Select a fitting known message prefix. A skip still permits the complete final call."""
    if type(budget) is not int or budget < 1:
        raise ValueError("preview budget must be a positive number of prompt tokens")
    receipt = {"budget_tokens": budget, "renders": 0}
    if cancelled():
        return None, {**receipt, "decision": "cancelled"}
    full = encode(request)
    receipt.update(renders=1, full_tokens=len(full))
    selection = None
    selected_ids = []
    shared = 0
    if len(full) <= budget:
        selection, selected_ids, shared = request, full, len(full)
    else:
        # The first user message can follow fixed system/developer instructions.
        # Preserve those verbatim. Avoid editing any tool data or structured content.
        messages = request["messages"]
        index = next(
            (
                i
                for i, m in enumerate(messages)
                if m["role"] not in ("system", "developer")
            ),
            len(messages),
        )
        if (
            index < len(messages)
            and messages[index]["role"] == "user"
            and isinstance(messages[index].get("content"), str)
        ):
            message = messages[index]
            content = message["content"]
            # Match the registered 512-character slices. Validate every accepted
            # candidate independently: BPE length need not be strictly monotonic.
            lo, hi = 1, (len(content) - 1) // 512
            while lo <= hi:
                if cancelled():
                    return None, {**receipt, "decision": "cancelled"}
                middle = (lo + hi) // 2
                partial = {
                    **request,
                    "messages": [
                        *messages[:index],
                        {**message, "content": content[: middle * 512]},
                    ],
                    "add_generation_prompt": False,
                }
                ids = encode(partial)
                receipt["renders"] += 1
                if len(ids) > budget:
                    hi = middle - 1
                else:
                    same = next(
                        (i for i, (x, y) in enumerate(zip(ids, full)) if x != y),
                        min(len(ids), len(full)),
                    )
                    if same > shared:
                        selection, selected_ids, shared = partial, ids, same
                    lo = middle + 1
    if cancelled():
        return None, {**receipt, "decision": "cancelled"}
    if shared < 16:
        return None, {**receipt, "decision": "no_matching_block"}
    receipt.update(
        decision="full" if selection is request else "partial",
        planned_tokens=len(selected_ids),
        known_shared_blocks=shared // 16,
        ids_sha256=fingerprint(selected_ids),
    )
    return selection, receipt
