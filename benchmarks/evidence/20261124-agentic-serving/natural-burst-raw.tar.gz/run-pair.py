"""Acquire each owned lease through its controller and join both on every exit."""

import argparse
import concurrent.futures
import json
import os
import secrets
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from replica_process import serve


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("holder", type=Path)
    p.add_argument("directory", type=Path)
    p.add_argument(
        "policy",
        choices=(
            "round-robin",
            "session",
            "cost",
            "crossover",
            "inventory",
            "cross-router",
            "natural-burst-0",
            "natural-burst-1",
            "multi-router-0",
            "multi-router-1",
            "readiness-burst",
            "protected-burst",
        ),
    )
    args = p.parse_args()
    root = Path(__file__).resolve().parent
    pair = args.directory.resolve()
    pair.mkdir()
    holder = args.holder.resolve()

    with (
        tempfile.TemporaryDirectory() as tmp,
        concurrent.futures.ThreadPoolExecutor(2) as pool,
    ):
        keydir = Path(tmp)
        for i in (6, 7):
            (keydir / str(i)).write_text(secrets.token_hex(32))
        multi_router = args.policy.startswith("multi-router-")
        natural_burst = args.policy.startswith("natural-burst-")
        launcher = (
            "run-cross-router-native.sh"
            if args.policy in ("cross-router", "readiness-burst", "protected-burst")
            or multi_router
            or natural_burst
            else "run-replica.sh"
        )
        futures = [
            pool.submit(serve, root, holder, pair, i, keydir, launcher=launcher)
            for i in (6, 7)
        ]
        try:
            deadline = time.monotonic() + 340
            while not all((pair / f"gpu{i}" / "address").is_file() for i in (6, 7)):
                for future in futures:
                    if future.done():
                        future.result()
                        raise RuntimeError("replica exited before both ready")
                if time.monotonic() >= deadline:
                    raise TimeoutError("pair readiness timed out")
                time.sleep(1)
            if (
                args.policy
                in ("inventory", "cross-router", "readiness-burst", "protected-burst")
                or multi_router
                or natural_burst
            ):
                manifest = pair / "inventory.json"
                members = []
                env = os.environ.copy()
                for idx in (6, 7):
                    name = f"AGENT_BENCH_{idx}"
                    address = (pair / f"gpu{idx}" / "address").read_text().strip()
                    members.append(
                        {
                            "node": "aws-a100",
                            "max_active_sequences": 8,
                            "gpu_count": 1,
                            "url": "http://" + address,
                            "bearer_env": name,
                        }
                    )
                    env[name] = (keydir / str(idx)).read_text()
                manifest.write_text(
                    json.dumps({"model": "m", "replicas": members}) + "\n"
                )
                if args.policy == "cross-router":
                    subprocess.run(
                        [
                            sys.executable,
                            "-B",
                            str(root / "cross_router_trial.py"),
                            str(manifest),
                            str(pair / "cross-router.json"),
                        ],
                        env=env,
                        check=True,
                    )
                if args.policy in ("readiness-burst", "protected-burst"):
                    subprocess.run(
                        [
                            sys.executable,
                            "-B",
                            str(root / "readiness_burst.py"),
                            str(manifest),
                            str(pair / "waves.json"),
                            *(
                                ["--protect-reader"]
                                if args.policy == "protected-burst"
                                else []
                            ),
                        ],
                        env=env,
                        check=True,
                    )
                elif natural_burst:
                    subprocess.run(
                        [
                            sys.executable,
                            "-B",
                            str(root / "natural_burst.py"),
                            str(manifest),
                            str(pair / "natural.json"),
                            args.policy[-1],
                        ],
                        env=env,
                        check=True,
                    )
                elif multi_router:
                    subprocess.run(
                        [
                            sys.executable,
                            "-B",
                            str(root / "multi_router_trial.py"),
                            str(manifest),
                            str(pair / "multi-router.json"),
                            args.policy[-1],
                        ],
                        env=env,
                        check=True,
                    )
                else:
                    subprocess.run(
                        [
                            sys.executable,
                            "-B",
                            str(root / "agent_fleet_replay.py"),
                            str(manifest),
                            str(pair / "inventory-replay.json"),
                            *(
                                ["--policy", "observed-capacity"]
                                if args.policy == "cross-router"
                                else []
                            ),
                            "--waves",
                            "1",
                            "2",
                            "4",
                        ],
                        env=env,
                        check=True,
                    )
                if args.policy == "inventory":
                    subprocess.run(
                        [
                            sys.executable,
                            "-B",
                            str(root / "probe_capacity_route.py"),
                            str(manifest),
                            str(pair / "capacity-route.json"),
                        ],
                        env=env,
                        check=True,
                    )
            else:
                driver = (
                    "probe_replica_wait.py"
                    if args.policy == "crossover"
                    else "replica_workflow.py"
                )
                extra = [] if args.policy == "crossover" else [args.policy]
                subprocess.run(
                    [
                        sys.executable,
                        "-B",
                        str(root / driver),
                        str(pair),
                        str(keydir),
                        *extra,
                    ],
                    check=True,
                )
        finally:
            (pair / "finished").touch()
        for future in futures:
            future.result()


if __name__ == "__main__":
    main()
