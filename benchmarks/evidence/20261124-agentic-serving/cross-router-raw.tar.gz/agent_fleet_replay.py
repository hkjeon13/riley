"""Measure agent workflow latency and capacity on a supplied inventory of Riley endpoints."""

import argparse
import json
import os
from pathlib import Path
from urllib.parse import urlsplit

from replica_workflow import run


def inventory(source):
    endpoints = []
    members = []
    addresses = set()
    for item in source["replicas"]:
        url = item["url"].rstrip("/")
        parts = urlsplit(url)
        if (
            parts.scheme not in ("http", "https")
            or not parts.hostname
            or parts.username is not None
            or parts.password is not None
            or parts.query
            or parts.fragment
            or url in addresses
        ):
            raise ValueError(
                "expected distinct HTTP(S) endpoint URLs without inline credentials or query parameters"
            )
        addresses.add(url)
        bearer = os.environ[item["bearer_env"]] if item.get("bearer_env") else None
        if item.get("bearer_env") and not bearer:
            raise ValueError("required bearer environment variable is empty")
        gpus = item["gpu_count"]
        if (
            type(gpus) is not int
            or gpus < 1
            or not isinstance(item["node"], str)
            or not item["node"].strip()
        ):
            raise ValueError(
                "each replica needs a node label and positive GPU allocation"
            )
        endpoints.append((url, bearer))
        members.append({"node": item["node"], "gpu_count": gpus})
    if not members or not source["model"]:
        raise ValueError("expected a model and at least one replica")
    return endpoints, members


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("inventory", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument(
        "--policy",
        choices=("round-robin", "session", "cost", "capacity", "observed-capacity"),
        default="round-robin",
    )
    p.add_argument("--waves", nargs="+", type=int, default=[1, 2, 4, 8])
    args = p.parse_args()
    if any(w < 1 for w in args.waves):
        p.error("wave sizes must be positive")
    source = json.loads(args.inventory.read_text())
    endpoints, members = inventory(source)
    with args.output.open("x") as file:
        results = run(
            endpoints,
            args.policy,
            model=source["model"],
            waves=args.waves,
            active_limits=[r.get("max_active_sequences") for r in source["replicas"]],
            gpu_count=sum(m["gpu_count"] for m in members),
        )
        json.dump(
            {
                "model": source["model"],
                "reported_topology": members,
                "policy": args.policy,
                "waves": results,
            },
            file,
            indent=2,
        )
        file.write("\n")
    if not any(
        t.get("status")
        for wave in results
        for work in wave["records"]
        for t in work["turns"]
    ):
        raise SystemExit(
            "no endpoint returned an HTTP response; see individual request errors"
        )


if __name__ == "__main__":
    main()
