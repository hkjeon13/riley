"""Replay dependent workflows in two clients with private routing state and a shared GPU pair."""

import argparse
import concurrent.futures
import json
import multiprocessing
import os
import time
from contextlib import nullcontext
from pathlib import Path

from agent_fleet_replay import inventory
from agent_workflow import replay
from replica_load import ReplicaLoad
from replica_workflow import Router


def client(endpoints, model, policy, client_id, wave, barrier):
    ctx = ReplicaLoad(endpoints) if policy == "observed-capacity" else nullcontext()
    with ctx as sampler:
        router = Router(endpoints, policy, [8, 8], sampler)
        barrier.wait(30)
        origin = time.monotonic() + 0.05

        def submit(index):
            time.sleep(max(0, origin + index * 0.025 - time.monotonic()))
            seed = 761 + 10 * wave + 20 * client_id + index
            return replay(
                "",
                model,
                seed,
                96 if index % 2 else 2,
                0.1,
                f"session-{seed}",
                history=100,
                send=router.sender(index),
            )

        with concurrent.futures.ThreadPoolExecutor(4) as workers:
            records = list(workers.map(submit, range(4)))
    return {"pid": os.getpid(), "scheduled_start_s": origin, "records": records}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("inventory", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("block", type=int, choices=[0, 1])
    args = p.parse_args()
    manifest = json.loads(args.inventory.read_text())
    endpoints, _ = inventory(manifest)
    ctx = multiprocessing.get_context("spawn")
    order = ["capacity", "observed-capacity"]
    if args.block:
        order.reverse()
    result = []
    for wave, policy in enumerate(order):
        with (
            ctx.Manager() as manager,
            concurrent.futures.ProcessPoolExecutor(2, mp_context=ctx) as pool,
        ):
            gate = manager.Barrier(2)
            peers = [
                pool.submit(client, endpoints, manifest["model"], policy, i, wave, gate)
                for i in (0, 1)
            ]
            result.append(
                {
                    "block": args.block,
                    "wave": wave,
                    "policy": policy,
                    "clients": [p.result() for p in peers],
                }
            )
        args.output.write_text(json.dumps(result) + "\n")


if __name__ == "__main__":
    main()
