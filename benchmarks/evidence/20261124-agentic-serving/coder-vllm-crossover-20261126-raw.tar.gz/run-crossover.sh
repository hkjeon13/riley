#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
i=$1
root=$(realpath ../../..)
h="$PWD/holder"
case "$i" in
    4) order=(vllm riley);;
    5) order=(riley vllm);;
    *) exit 2;;
esac
ctl=(python3 -B "$h/control.py" --lease-dir "$h/leases" --index "$i")
mkdir "gpu$i"
"${ctl[@]}" status > "gpu$i/lease-before.json"
python3 -c 'import sys,json; d=json.load(open(sys.argv[1])); assert d["phase"]=="idle" and not d["other_processes"]' "gpu$i/lease-before.json"
nvidia-smi -i "$i" --query-gpu=uuid,name,driver_version,memory.total --format=csv > "gpu$i/device.csv"
for arm in "${order[@]}"; do
    out="$PWD/gpu$i/$arm"
    case "$arm" in
        vllm) command=(python3 -B run-reference.py "$out" --seed 5091);;
        riley) command=(bash run-profile.sh "$out" stock 5091 wide);;
    esac
    echo "GPU$i $arm start"
    "${ctl[@]}" run -- "${command[@]}" > "$out.controller.log" 2>&1
    "${ctl[@]}" status > "$out/lease-after.json"
    echo "GPU$i $arm complete"
done
