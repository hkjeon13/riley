"""Check the resumed Coder-7B catalog and fixed-decode crossover from raw receipts."""

import argparse
import json
from hashlib import sha256
from pathlib import Path

from fixed_agent_decode import freeze
from verify_catalog_engines import application, fixed, summarize
from verify_coder_pressure import check_manifest, check_server, read

BINARY = "40a58069b66b2f76bfe20a0f3decc0bd1b4f7f2e2a3ae80d6fc519dc40690c7e"
NAMES = ("reader", "long")


def configs(args, fields):
    return {flag: args[args.index(flag) + 1] for flag in fields}


def check_isolation(root, index, d, before):
    assert (d / "device.csv").read_text().splitlines()[1].split(",")[0] == before["gpu"]
    events = [
        json.loads(row)
        for row in (root / f"gpu{index}.processes.jsonl").read_text().splitlines()
    ]
    seen_descendants = {
        app["pid"]
        for event in events
        for app in event["apps"]
        if app["runner_descendant"]
    }
    assert (
        before["phase"] == "idle" and not before["other_processes"] and seen_descendants
    )
    unexplained = {
        app["pid"]
        for event in events
        for app in event["apps"]
        if app["pid"] != before["pid"] and app["pid"] not in seen_descendants
    }
    return {
        "samples": len(events),
        "managed_pids": sorted(seen_descendants),
        "unexplained_pids": sorted(unexplained),
    }


def check_model(root):
    before = (root / "model-before.txt").read_bytes()
    assert before == (root / "model-after.txt").read_bytes()
    checkpoint = read(root / "checkpoint-receipt.json")
    assert checkpoint["source_model"] == "Qwen/Qwen2.5-Coder-7B-Instruct"
    assert checkpoint["dtype"] == "bf16"
    for name in ("config.json", "riley-checkpoint.json"):
        local = root / (
            "checkpoint-config.json"
            if name == "config.json"
            else "checkpoint-receipt.json"
        )
        assert (
            f"{sha256(local.read_bytes()).hexdigest()}  {name}".encode()
            in before.splitlines()
        )
    return {
        "source": checkpoint["source_model"],
        "revision": checkpoint["source_revision"],
        "dtype": checkpoint["dtype"],
        "manifest_sha256": sha256(before).hexdigest(),
    }


def timed_cache(folder):
    cases = {}
    for trial in read(folder / "fixed.json"):
        if trial["phase"] != "measured":
            continue
        for row in trial["rows"]:
            assert row["status"] == 200 and row["done_ns"]
            usage = row["usage"].get("prompt_tokens_details") or {}
            cases.setdefault(row["name"], []).append(usage.get("cached_tokens"))
    assert all(len(cases[name]) == 3 for name in NAMES)
    return cases


def verify(root):
    check_manifest(root)
    model = check_model(root)
    cfg = read(root / "coder-catalog-comparison.json")
    registered = read(root / "coder-catalog-comparison-registered.json")
    assert cfg["orders"] == {
        "4": registered["orders"]["6"],
        "5": registered["orders"]["7"],
    }
    assert {k: v for k, v in cfg.items() if k != "orders"} == {
        k: v for k, v in registered.items() if k != "orders"
    }
    assert not (root / "processes-before.csv").read_text().strip()
    requests = {
        n: freeze(w, "m")
        for n, w in zip(NAMES, read(root / "frozen.json"), strict=True)
    }
    results = {}
    for index, order in cfg["orders"].items():
        device = root / f"gpu{index}"
        before = read(device / "lease-before.json")
        assert before["physical_index"] == int(index)
        released = read(root / f"gpu{index}.released.json")
        assert (released["status"], released["pid"], released["gpu"]) == (
            "stopped",
            before["pid"],
            before["gpu"],
        )
        assert not any(
            line.startswith(before["gpu"] + ",")
            for line in (root / "processes-after.csv").read_text().splitlines()
        )
        isolation = check_isolation(root, index, device, before)
        log = (root / f"gpu{index}.run.log").read_text().splitlines()
        expected = [
            f"GPU{index} {arm} {action}"
            for arm in order
            for action in ("start", "complete")
        ]
        assert log == expected
        arms = {}
        for arm in order:
            d = device / arm
            after = read(d / "lease-after.json")
            assert (
                after["phase"],
                after["pid"],
                after["gpu"],
                after["other_processes"],
            ) == (
                "idle",
                before["pid"],
                before["gpu"],
                [],
            )
            assert read(d / "warm.json")["ok"]
            if arm == "riley":
                check_server(d, BINARY, index)
                assert read(d / "ready.json")["ready"]
                cli = (d / "server-arguments.txt").read_text().splitlines()
                assert configs(
                    cli,
                    (
                        "--max-sequence-tokens",
                        "--max-active-sequences",
                        "--kv-blocks",
                        "--inference-profile",
                        "--prefix-cache-blocks",
                        "--batch-token-budget",
                        "--prefill-chunk-tokens",
                        "--prefill-burst-steady-budget",
                    ),
                ) == {
                    "--max-sequence-tokens": "8192",
                    "--max-active-sequences": "8",
                    "--kv-blocks": "4096",
                    "--inference-profile": "native-bf16-varlen-v1",
                    "--prefix-cache-blocks": "1536",
                    "--batch-token-budget": "1024",
                    "--prefill-chunk-tokens": "1024",
                    "--prefill-burst-steady-budget": "256",
                }
                assert cli[cli.index("--model") + 1].endswith(
                    "/Qwen2.5-Coder-7B-Instruct"
                )
            else:
                assert (d / "version.txt").read_text().strip() == "0.27.1+cu129"
                assert any(row["id"] == "m" for row in read(d / "ready.json")["data"])
                cli = read(d / "command.json")
                assert cli[2].endswith("/Qwen2.5-Coder-7B-Instruct")
                assert configs(
                    cli,
                    (
                        "--max-model-len",
                        "--max-num-seqs",
                        "--block-size",
                        "--kv-cache-memory-bytes",
                        "--dtype",
                        "--gpu-memory-utilization",
                        "--tool-call-parser",
                        "--generation-config",
                    ),
                ) == {
                    "--max-model-len": "8192",
                    "--max-num-seqs": "8",
                    "--block-size": "16",
                    "--kv-cache-memory-bytes": "3758096384",
                    "--dtype": "bfloat16",
                    "--gpu-memory-utilization": "0.75",
                    "--tool-call-parser": "hermes",
                    "--generation-config": "vllm",
                }
                assert {
                    "--enable-prefix-caching",
                    "--exclude-tools-when-tool-choice-none",
                } <= set(cli)
            waves = application(read(d / "waves.json"), cfg)
            cells = fixed(d, requests)
            assert "failure" not in cells, cells
            hits = timed_cache(d)
            for name in NAMES:
                cells[name]["timed_cached_tokens"] = hits[name]
            arms[arm] = {
                "high": summarize(waves[2:]),
                "by_wave": [summarize([w]) for w in waves],
                "fixed": cells,
                "launch": cli,
            }
        r, v = [arms[a]["high"] for a in ("riley", "vllm")]
        app_gates = {
            "slo_count": r["slo"] >= v["slo"],
            "goodput": r["warm_slo_per_gpu_hour"] >= v["warm_slo_per_gpu_hour"],
            "last_p95": r["last_p95_ms"] <= 1.05 * v["last_p95_ms"],
            "preserved_valid": set(r["failed_basic"]) <= set(v["failed_basic"]),
        }
        cells = {}
        for name in NAMES:
            x, y = [arms[a]["fixed"][name] for a in ("riley", "vllm")]
            same_prompt = (
                x["tokens"] == y["tokens"] and x["prompt_ids"] == y["prompt_ids"]
            )
            same_cache = x["timed_cached_tokens"] == y["timed_cached_tokens"] and all(
                type(n) is int and n > 0 for n in x["timed_cached_tokens"]
            )
            ratios = {k: x[k] / y[k] for k in ("median_tpot_ms", "gap_p95_ms")}
            comparable = (
                same_prompt and same_cache and not isolation["unexplained_pids"]
            )
            cells[name] = {
                "same_prompt_ids": same_prompt,
                "matched_warm_cache": same_cache,
                "comparable": comparable,
                "ratios_riley_vllm": ratios,
                "passes_registered_1_05": comparable and max(ratios.values()) <= 1.05,
                "same_generated_ids": x["output_ids_hash"] == y["output_ids_hash"],
            }
        results[index] = {
            "order": order,
            "gpu_uuid": before["gpu"],
            "isolation": isolation,
            "arms": arms,
            "natural_gates": app_gates,
            "decode": cells,
        }
    return {
        "date": "2026-11-26",
        "model": model,
        "riley_sha256": BINARY,
        "devices": results,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    print(json.dumps(verify(parser.parse_args().root), indent=2, allow_nan=False))
