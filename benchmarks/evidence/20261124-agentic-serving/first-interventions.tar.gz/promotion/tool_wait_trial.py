"""Submit final-format prefix work during a real tool wait and measure the full chain."""

import argparse
import concurrent.futures
import json
import threading
import time
from pathlib import Path

from agent_workflow import replay, stream


def measure(address, enabled, label, seed, delay, peer_seed=None):
    visible = threading.Event()
    prefix_row = {}
    preview = None
    with concurrent.futures.ThreadPoolExecutor(2) as pool:
        peer = None
        if peer_seed is not None:
            # Keep the peer at its final call until the target's second tool starts.
            release = threading.Event()
            peer = pool.submit(
                replay, address, "m", peer_seed, 2, 0, "reader", visible, release, 200
            )

        def start(index, request, row):
            nonlocal preview
            if index != 1:
                return
            if peer is not None:
                release.set()
                if not visible.wait(45):
                    raise ValueError("reader did not start streaming")
            row["tool_wait_begin_ns"] = time.monotonic_ns()
            if enabled:
                # The orchestrator knows the observed messages but not the pending
                # tool result. Snapshot the list before the live replay appends it.
                prepared = {
                    **request,
                    "messages": list(request["messages"]),
                    "tool_choice": "none",
                    "max_tokens": 1,
                }
                preview = pool.submit(stream, address, prepared, prefix_row)

        target = replay(
            address, "m", seed, 96, delay, label, history=200, on_tool_start=start
        )
        if peer is not None and not release.is_set():
            release.set()
        if preview is not None:
            try:
                preview.result()
            except (OSError, ValueError) as error:
                prefix_row["error"] = str(error)
        result = {
            "case": label,
            "enabled": enabled,
            "target": target,
            "prefix": prefix_row,
        }
        if peer is not None:
            result["peer"] = peer.result()
        return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("address")
    p.add_argument("mode", choices=["on", "off"])
    p.add_argument("out", type=Path)
    args = p.parse_args()
    # Seeds repeat only for the deliberate warm exact-history control.
    cases = [
        ("zero", 1901, 0, None),
        ("short", 1918, 0.1, None),
        ("long", 1935, 0.5, None),
        ("warm", 1935, 0.5, None),
        ("overlap", 1952, 0.5, 1969),
    ]
    data = []
    for spec in cases:
        data.append(measure(args.address, args.mode == "on", *spec))
        args.out.write_text(json.dumps(data, indent=2) + "\n")


if __name__ == "__main__":
    main()
