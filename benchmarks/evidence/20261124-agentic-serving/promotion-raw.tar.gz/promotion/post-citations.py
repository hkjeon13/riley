"""Compatibility entry point for the already running launch's frozen shell script."""
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
address, out, registration = sys.argv[1:]
subprocess.run([sys.executable, "-B", str(root/"citation-study.py"), address, out, registration], check=True)
if Path(out).name == "pair-3-wide":
    subprocess.run([sys.executable, "-B", str(root/"qualified_tool_wait.py"), address, out, "wait-policy-registration.json"], check=True)
