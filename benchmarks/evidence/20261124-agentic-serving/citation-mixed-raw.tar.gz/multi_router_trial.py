"""Replay dependent workflows in two clients with private routing state and a shared GPU pair."""

import argparse
import concurrent.futures
import json
import multiprocessing
import os
import time
from contextlib import nullcontext
from pathlib import Path

from agent_fleet_replay import inventory
from agent_workflow import replay
from replica_load import ReplicaLoad
from replica_workflow import SAMPLED_POLICIES, Router


def client(
    endpoints,
    model,
    policy,
    client_id,
    wave,
    barrier,
    seed_stride=10,
    final_citations=False,
    seed_offset=0,
):
    ctx = ReplicaLoad(endpoints) if policy in SAMPLED_POLICIES else nullcontext()
    with ctx as sampler:
        router = Router(endpoints, policy, [8, 8], sampler)
        barrier.wait(30)
        origin = time.monotonic() + 0.05

        def submit(index):
            time.sleep(max(0, origin + index * 0.025 - time.monotonic()))
            seed = 761 + seed_offset + seed_stride * wave + 20 * client_id + index
            return replay(
                "",
                model,
                seed,
                96 if index % 2 else 2,
                0.1,
                f"session-{seed}",
                final_citations=final_citations,
                history=100,
                send=router.sender(index),
            )

        with concurrent.futures.ThreadPoolExecutor(4) as workers:
            records = list(workers.map(submit, range(4)))
    return {"pid": os.getpid(), "scheduled_start_s": origin, "records": records}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("inventory", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("block", type=int, choices=[0, 1, 2])
    p.add_argument("--defer-mixed", action="store_true")
    p.add_argument("--citation-mixed", action="store_true")
    args = p.parse_args()
    manifest = json.loads(args.inventory.read_text())
    endpoints, _ = inventory(manifest)
    ctx = multiprocessing.get_context("spawn")
    order = ["capacity", "observed-capacity"]
    if args.citation_mixed:
        if args.block == 2 or args.defer_mixed:
            p.error("citation crossover accepts blocks 0 and 1")
        order = ["round-robin"] * 8
    elif args.defer_mixed:
        policies = ["round-robin", "observed-capacity", "defer-cold-prefill"]
        order = [policies[(args.block + offset) % 3] for offset in (0, 1, 2, 2, 1, 0)]
    elif args.block == 1:
        order.reverse()
    elif args.block:
        p.error("block 2 requires --defer-mixed")
    result = []
    for wave, policy in enumerate(order):
        with (
            ctx.Manager() as manager,
            concurrent.futures.ProcessPoolExecutor(2, mp_context=ctx) as pool,
        ):
            gate = manager.Barrier(2)
            peers = [
                pool.submit(
                    client,
                    endpoints,
                    manifest["model"],
                    policy,
                    i,
                    wave,
                    gate,
                    40 if args.defer_mixed or args.citation_mixed else 10,
                    args.citation_mixed and (args.block + wave) % 2 == 1,
                    23760 if args.citation_mixed and wave >= 6 else 0,
                )
                for i in (0, 1)
            ]
            result.append(
                {
                    "block": args.block,
                    "wave": wave,
                    "policy": policy,
                    "clients": [p.result() for p in peers],
                }
            )
        args.output.write_text(json.dumps(result) + "\n")


if __name__ == "__main__":
    main()
