"""Fetch the public pinned shards into a private staging directory and verify bytes."""
import concurrent.futures
import hashlib
import os
from pathlib import Path

from huggingface_hub import hf_hub_download


ROOT = Path.cwd()
REVISION = "c03e6d358207e414f1eca0bb1891e29f1db0e242"
REPO = "Qwen/Qwen2.5-Coder-7B-Instruct"


def checksum(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def download(item):
    digest, name = item
    already = ROOT / "model" / name
    if already.is_file() and checksum(already) == digest:
        return name
    fetched = Path(hf_hub_download(REPO, name, revision=REVISION, token=False, local_dir=ROOT / "xet-stage"))
    if checksum(fetched) != digest:
        raise ValueError(f"wrong sha256 for {name}")
    os.replace(fetched, already)
    print(f"Verified {name}", flush=True)
    return name


if __name__ == "__main__":
    items = [line.split() for line in (ROOT / "model-registered.sha256").read_text().splitlines()]
    shards = [item for item in items if item[1].endswith(".safetensors")]
    with concurrent.futures.ThreadPoolExecutor(3) as pool:
        list(pool.map(download, shards))
    result = []
    for digest, name in items:
        if checksum(ROOT / "model" / name) != digest:
            raise ValueError(f"wrong sha256 for {name}")
        result.append(f"{name}: OK")
    digest = checksum(ROOT / "model" / "riley-checkpoint.json")
    result.append(f"{digest}  riley-checkpoint.json")
    (ROOT / "xet-model-verification.new").write_text("\n".join(result) + "\n")
    (ROOT / "xet-model-verification.new").replace(ROOT / "model-verification.txt")
