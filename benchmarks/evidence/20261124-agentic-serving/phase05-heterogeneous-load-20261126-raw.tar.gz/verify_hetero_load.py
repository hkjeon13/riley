"""Independently score the approved heterogeneous capacity and soak cells."""
import collections
import sys
from pathlib import Path

from agent_workflow import append_tool_result, fingerprint, fixture, history_messages, turn_request
from run_hetero_load import capacity_plan, soak_plan
from verify_agent_citations import with_citations
from verify_multinode import read_hosts
from verify_phase05 import lines, percentile, read, result_is_correct


G = 1_000_000_000
MS = 1_000_000


def routes(out, cells):
    ready = set()
    staged = {}
    totals = collections.Counter()
    for item in read(out / "routing-events.json"):
        name = item["node"]
        kind = item["action"]
        if kind == "ready":
            assert item["observed"]["ready"] and item["observed"]["at_ns"] <= item["ns"]
            ready.add(name)
        elif kind == "disabled":
            ready.remove(name)
        else:
            eligible = sorted(ready)
            seq = item["seq"]
            assert kind == "route" and len(staged) == seq
            assert item["eligible"] == eligible and name == eligible[seq % len(eligible)]
            totals[name] += 1
            staged[seq] = item
    for job in [j for cell in cells for j in cell]:
        work = job["work"]
        for turn in work["turns"]:
            if "route" not in turn:
                continue
            route = turn["route"]
            item = staged.pop(route["seq"])
            assert item["id"] == work["workflow_id"] and item["turn"] == turn["turn"]
            assert all(item[k] == v for k, v in route.items())
            assert route["ns"] <= turn["sent_ns"]
    assert not staged
    return dict(totals)


def check_requests(work, current):
    tools, prompt, docs = fixture(work["seed"], work["document_pairs"])
    assert work["fixture_sha256"] == fingerprint([prompt, docs])
    messages = history_messages(work["seed"], work["history_entries"]) + [{"role": "user", "content": prompt}]
    for turn, name in zip(work["turns"], ("list_reports", "read_reports", None)):
        base = turn_request("m", messages, tools, name)
        if name is None:
            assert turn["original_request_sha256"] == fingerprint(base)
            assert turn["input_sha256"] == fingerprint(with_citations(base))
        elif current["direct"]:
            assert turn["planned_request_sha256"] == fingerprint(base)
        else:
            assert turn["input_sha256"] == fingerprint(base)
        if "tool_ready_ns" in turn:
            append_tool_result(messages, [turn["call"]], docs, turn["turn"])


def aggregate(group):
    ok = [r for r in group if r["correct"]]
    return {
        "submitted": len(group), "correct": len(ok), "slo": sum(r["slo"] for r in group),
        "cancelled": sum(r["cancelled"] for r in group), "rejected": sum(r["rejected"] for r in group),
        **{f"p95_{key}": percentile([r[key] for r in ok], .95) for key in ("first_ms", "last_ms", "gap_ms")},
    }


def cell(path, stage_plan, seed, active, threshold, cancels):
    origin = read(path / "origin.json")["monotonic_ns"]
    end = read(path / "finished.json")["drained_ns"]
    rows = sorted(lines(path / "requests.jsonl"), key=lambda row: row["n"])
    plan = list(stage_plan)
    assert len(rows) == len(plan)
    data, unexpected = [], []
    status_by_node = {node: collections.Counter() for node in ("aws", "rtx")}
    cancelled_by_node = collections.Counter()
    for row, (offset, n, i) in zip(rows, plan, strict=True):
        kind = "cancel" if cancels and i % 19 == 11 else "slow" if i % 17 == 12 else "normal"
        assert row["n"] == n and row["fixture_idx"] == i and row["scheduled_ns"] == origin + round(offset * G)
        assert row["kind"] == kind and row["direct"] == (i % 4 != 0)
        assert row["tenant"] == ("primary" if i % 5 else "secondary")
        work = row["work"]
        assert work["seed"] == seed + i
        assert work["history_entries"] == (0, 200, 50)[i % 3]
        assert work["document_pairs"] == (96 if i % 3 == 1 else 2)
        check_requests(work, row)
        turned = [t for t in work["turns"] if "route" in t]
        for t in turned:
            assert t["route"]["eligible"] == sorted(active)
            status_by_node[t["route"]["node"]][str(t.get("status", "transport"))] += 1
        last = work["turns"][-1]
        final_node = last["route"]["node"] if last.get("route") else None
        cancelled = (kind == "cancel" and last["turn"] == 2 and last.get("status") == 200
                     and "client_cancel_ns" in last and len(last["content_ns"]) == 4 and "done_ns" not in last)
        if cancelled:
            cancelled_by_node[final_node] += 1
        rejected = any(r.get("status") == 429 for r in turned)
        correct = result_is_correct(work)
        assert work["ok"] == correct
        details = {"n": n, "offset": offset, "tenant": row["tenant"], "kind": kind, "node": final_node,
                   "cancelled": cancelled, "rejected": rejected, "correct": correct, "slo": False,
                   "lag_ms": (work["start_ns"] - row["scheduled_ns"]) / MS}
        if correct:
            visible = last["content_ns"]
            details.update(first_ms=(visible[0] - row["scheduled_ns"]) / MS,
                           last_ms=(visible[-1] - row["scheduled_ns"]) / MS,
                           gap_ms=percentile([(b-a) / MS for a,b in zip(visible, visible[1:])], .95))
            details["slo"] = all(details[k] <= v for k, v in threshold.items())
        elif not (rejected or cancelled):
            unexpected.append({"n": n, "seed": work["seed"], "node": final_node, "reason": work.get("error")})
        data.append(details)
    first = read(path / "start-sample.json")["nodes"]
    last = read(path / "end-sample.json")["nodes"]
    metrics = {}
    collected = list(lines(path / "samples.jsonl"))
    for name in ("aws", "rtx"):
        series = [sample["nodes"][name] for sample in collected]
        valid = [item for item in [first[name], *series, last[name]] if "metrics_error" not in item]
        before, after = first[name], last[name]
        counters = {}
        if "counters" in before and "counters" in after:
            counters = {k: after["counters"][k] - before["counters"][k] for k in ("cancellations", "disconnects", "overloads")}
        keys = ("active_requests", "waiting_requests", "kv_allocated_blocks")
        metrics[name] = {
            "missed_samples": len(series) + 2 - len(valid),
            "peak": {k: max((item[k] for item in valid), default=None) for k in keys},
            "after": {k: after.get(k) for k in keys},
            "device_bytes": sorted({item["allocation"]["device_live_bytes"] for item in valid}),
            "retained_prefix_blocks_after": after.get("prefix_cache", {}).get("retained_blocks"),
            "counters_delta": counters,
        }
    outcome = aggregate(data)
    span = (end - origin) / G
    report = {
        "overall": outcome,
        "by_tenant": {k: aggregate([r for r in data if r["tenant"] == k]) for k in ("primary", "secondary")},
        "by_final_target": {k: aggregate([r for r in data if r["node"] == k]) for k in ("aws", "rtx")},
        "status_by_node": {key: dict(value) for key, value in status_by_node.items()},
        "unexpected": unexpected, "intended_cancellations_by_node": dict(cancelled_by_node),
        "metrics": metrics, "observed_s": span,
        "scheduled_utc_ns": read(path / "origin.json")["unix_time_ns"],
        "dispatch_lag_p95_ms": percentile([r["lag_ms"] for r in data], .95),
        "slo_goodput_per_s": outcome["slo"] / span,
        "slo_goodput_per_routed_gpu_hour": 3600 * outcome["slo"] / (span * len(active)),
        "slo_goodput_per_reserved_gpu_hour": 3600 * outcome["slo"] / (span * 2),
    }
    return report, rows, data


def verify(base):
    config = read(base / "load-registration.json")
    original = read(base / "multinode-registration.json")
    out = base / "performance"
    host_info, host_cleanup = read_hosts(base, original)
    allocation = {}
    for node in ("aws", "rtx"):
        run = base / node / "run"
        allocation[node] = (int((run / "stopped-epoch-ns").read_text()) - int((run / "started-epoch-ns").read_text())) / G
    outcome, mixed, data = cell(out / "mixed-soak", soak_plan(config["soak"]), 5300, ["aws","rtx"], config["criteria"], True)
    width = config["soak"]["paired_window_s"]
    duration = config["soak"]["seconds"]
    boundaries = {
        tenant: [aggregate([r for r in scope if r["tenant"] == tenant])
                 for scope in ([r for r in data if r["offset"] < width], [r for r in data if r["offset"] >= duration - width])]
        for tenant in ("primary", "secondary")
    }
    ratios = {}
    for key, (early, late) in boundaries.items():
        before, after = early["p95_last_ms"], late["p95_last_ms"]
        ratios[key] = after / before if before and after is not None else None
    totals = outcome["overall"]
    checks = {
        "registered_duration_and_count": totals["submitted"] == config["soak"]["submitted"] and outcome["observed_s"] >= duration,
        "all_noncancelled_correct_and_slo": totals["correct"] == totals["slo"] == totals["submitted"] - config["soak"]["scheduled_cancel"],
        "all_planned_cancels_no_http_reject": totals["cancelled"] == config["soak"]["scheduled_cancel"] and totals["rejected"] == 0,
        "reported_cancel_and_disconnect_delta_matches": all(
            v["counters_delta"].get("cancellations") == v["counters_delta"].get("disconnects") == outcome["intended_cancellations_by_node"].get(node, 0)
            for node, v in outcome["metrics"].items()
        ),
        "each_tenant_under_p95_growth_limit": all(
            v is not None and v <= config["soak"]["max_late_over_early_p95"] for v in ratios.values()
        ),
        "steady_device_bytes_and_post_soak_request_resources": all(len(v["device_bytes"]) == 1 and all(k == 0 for k in v["after"].values()) for v in outcome["metrics"].values()),
        "dispatch_lag_within_50_ms_p95": outcome["dispatch_lag_p95_ms"] <= 50,
    }
    for i in range(config["soak"]["paired_first_and_last_jobs"]):
        early = mixed[i]
        late = mixed[config["soak"]["late_start_index"] + i]
        assert early["work"]["fixture_sha256"] == late["work"]["fixture_sha256"] and early["fixture_idx"] == late["fixture_idx"]

    capacity = config["capacity"]
    records, observations = {}, {}
    for i, arm in enumerate(capacity["arms"]):
        offset, duration = 0, capacity["seconds_per_rate"]
        for rate in capacity["rates"]:
            stats, rows, _ = cell(out / f"arm-{i}-rate-{rate}", capacity_plan(rate, duration, offset),
                                  arm["seed"], arm["nodes"], config["criteria"], False)
            records[(i, rate)] = rows
            offset += len(rows)
            count = stats["overall"]
            stats["passes"] = (
                count["slo"] / count["submitted"] >= capacity["min_slo_fraction"]
                and count["rejected"] / count["submitted"] <= capacity["max_reject_fraction"]
                and not stats["unexpected"]
            )
            stats.update(arm=i, label=arm["label"], rate=rate)
            observations[(i, rate)] = stats
    for rate in capacity["rates"]:
        for a, b in ((0, 1), (2, 3)):
            for x, y in zip(records[(a, rate)], records[(b, rate)], strict=True):
                assert x["fixture_idx"] == y["fixture_idx"] and x["work"]["fixture_sha256"] == y["work"]["fixture_sha256"]
    totals_per_node = routes(out, [mixed, *records.values()])
    auth = read(out / "authentication.json")
    assert all(setting["own"] == {"http": 200, "models": ["m"]} and setting["foreign"]["http"] == 401 for setting in auth.values())
    if (out / "cleanup.json").is_file():
        cleanup_receipt = {"automatic": read(out / "cleanup.json")}
        control_finished = cleanup_receipt["automatic"] == {"aws": 0, "rtx": 0}
    else:
        manual = read(out / "cleanup-recovery.json")
        cleanup_receipt = {"recovered": manual}
        control_finished = (
            manual["rtx_finish_command_timeout_s"] == 20
            and "FINISHED" in (out / "aws-controller.log").read_text().splitlines()
            and "finish" in (out / "rtx-manual-finish.log").read_text()
            and "wrote verified shutdown metrics" in (base / "rtx" / "run" / "server.log").read_text()
        )
    cleanup = host_cleanup and control_finished and not any(node["foreign_compute_pids"] for node in host_info.values())
    whole_success = totals["slo"] + sum(result["overall"]["slo"] for result in observations.values())
    passing = {}
    for arms in ("aws-only", "dual", "rtx-only"):
        passing[arms] = [rate for rate in capacity["rates"] if all(
            v["passes"] for v in observations.values() if v["label"] == arms and v["rate"] == rate
        )]
    return {
        "registration": config, "hosts": host_info, "allocation_s_by_host": allocation, "cleanup_passed": cleanup,
        "cleanup_control_receipt": cleanup_receipt,
        "requests_by_node_total": totals_per_node, "unready_or_disabled_admissions": 0,
        "full_run_slo_per_allocated_gpu_hour": 3600 * whole_success / sum(allocation.values()),
        "soak": {"counts": outcome, "paired_tenants": boundaries, "p95_late_over_early": ratios, "checks": checks, "passed": all(checks.values())},
        "capacity": {"highest_pass_per_configuration_tested": {k: max(v, default=None) for k,v in passing.items()},
                     "rates_passing": passing, "cells": list(observations.values())},
    }


if __name__ == "__main__":
    import json

    print(json.dumps(verify(Path(sys.argv[1])), indent=2))
