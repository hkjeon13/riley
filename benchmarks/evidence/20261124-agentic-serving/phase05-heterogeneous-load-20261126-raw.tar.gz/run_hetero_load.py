"""Measure heterogeneous rate and soak behavior over private SSH data channels."""
import concurrent.futures
import json
import sys
import threading
import time
from pathlib import Path
from urllib.request import urlopen

from agent_workflow import replay
from run_multinode import Fleet, Node, write


ROOT = Path(__file__).resolve().parent
NS = 1_000_000_000


def append(file, row):
    file.write(json.dumps(row, separators=(",", ":")) + "\n")
    file.flush()


def switch(fleet, nodes):
    requested = set(nodes)
    for removed in sorted(fleet.active - requested):
        with fleet.lock:
            fleet.active.remove(removed)
            fleet.events.append({"action": "disabled", "node": removed, "ns": time.monotonic_ns()})
    for added in sorted(requested - fleet.active):
        receipt = fleet.nodes[added].probe()
        assert receipt["ready"], (added, receipt)
        fleet.update(added, receipt)


def gauges(node):
    try:
        with urlopen(f"http://{node.local}/metrics", timeout=3) as response:
            data = json.load(response)
        keys = ("active_requests", "waiting_requests", "kv_allocated_blocks", "prefix_cache", "allocation", "counters")
        return {key: data[key] for key in keys}
    except OSError as error:
        return {"metrics_error": str(error)}


def sampling(fleet, names, which):
    return {"ns": time.monotonic_ns(), "stage": which,
            "nodes": {name: gauges(fleet.nodes[name]) for name in names}}


def measure(fleet, logical, n, fixture_idx, seed, scheduled, cancellations):
    kind = "cancel" if cancellations and fixture_idx % 19 == 11 else "slow" if fixture_idx % 17 == 12 else "normal"
    direct = fixture_idx % 4 != 0

    def receive(chunks, row):
        if row["turn"] != 2:
            return
        if kind == "cancel" and chunks == 4:
            row["client_cancel_ns"] = time.monotonic_ns()
            raise ValueError("scheduled client cancellation")
        if kind == "slow":
            time.sleep(.03)

    receipt = replay(
        "", "m", seed + fixture_idx, 96 if fixture_idx % 3 == 1 else 2,
        (.5 if fixture_idx % 4 in (1, 2) else .01) if direct else (.2 if fixture_idx % 8 == 0 else .01),
        f"{logical}-{n}", history=(0, 200, 50)[fixture_idx % 3], dispatch_fixed_tools=direct,
        send=fleet.sender(f"{logical}-{n}", on_content=receive),
    )
    return {"n": n, "fixture_idx": fixture_idx, "scheduled_ns": scheduled,
            "kind": kind, "tenant": "primary" if fixture_idx % 5 else "secondary",
            "direct": direct, "work": receipt}


def soak_plan(cfg):
    i = 0
    offset = 0.0
    while offset < cfg["seconds"]:
        yield offset, i, i if i < cfg["late_start_index"] else i - cfg["late_start_index"]
        state = offset % cfg["period_s"]
        peak = cfg["burst_start_s"] <= state < cfg["burst_start_s"] + cfg["burst_duration_s"]
        offset += 1 / (cfg["burst_rate"] if peak else cfg["base_rate"])
        i += 1


def capacity_plan(rate, seconds, start):
    for i in range(rate * seconds):
        yield i / rate, start + i, start + i


def run_cell(fleet, path, plan, duration, seed, cancellations):
    path.mkdir()
    names = sorted(fleet.nodes)
    write(path / "start-sample.json", sampling(fleet, names, "before"))
    origin = time.monotonic_ns() + 500_000_000
    stop = threading.Event()

    def observe(sink):
        interval = 10 if cancellations else 1
        tick = origin
        while not stop.wait(max(0, tick - time.monotonic_ns()) / NS):
            append(sink, sampling(fleet, names, "load"))
            tick = max(tick + interval * NS, time.monotonic_ns())

    write(path / "origin.json", {"monotonic_ns": origin, "unix_time_ns": time.time_ns() + origin - time.monotonic_ns()})
    with ((path / "samples.jsonl").open("x") as monitoring,
          (path / "requests.jsonl").open("x") as rows,
          concurrent.futures.ThreadPoolExecutor(130) as pool):
        meter = pool.submit(observe, monitoring)
        pending = set()
        try:
            for offset, i, fixture_idx in plan:
                due = origin + round(offset * NS)
                time.sleep(max(0, due - time.monotonic_ns()) / NS)
                pending.add(pool.submit(measure, fleet, path.name, i, fixture_idx, seed, due, cancellations))
                completed = {job for job in pending if job.done()}
                pending -= completed
                for work in completed:
                    append(rows, work.result())
            time.sleep(max(0, origin + duration * NS - time.monotonic_ns()) / NS)
            for work in concurrent.futures.as_completed(pending):
                append(rows, work.result())
        finally:
            stop.set()
            meter.result()
    drained = time.monotonic_ns()
    write(path / "end-sample.json", sampling(fleet, names, "after"))
    write(path / "finished.json", {"drained_ns": drained})


def main(out):
    cfg = json.loads((ROOT / "load-registration.json").read_text())
    descriptors = json.loads((ROOT / "load-inventory.json").read_text())
    out.mkdir()
    nodes = {key: Node(key, value, out) for key, value in descriptors.items()}
    fleet = Fleet(nodes)
    try:
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            list(pool.map(Node.start, nodes.values()))
            readiness = list(pool.map(Node.ready_from_controller, nodes.values()))
            probes = list(pool.map(Node.open_tunnel, nodes.values()))
        initial = {}
        for node, boot, probe in zip(nodes.values(), readiness, probes, strict=True):
            initial[node.label] = {"pid": node.pid, "start_ns": node.started,
                                   "ready_ns": boot, "routed_ns": fleet.update(node.label, probe)}
        write(out / "initial.json", initial)
        auth = {}
        for label, node in nodes.items():
            other = nodes["rtx" if label == "aws" else "aws"]
            auth[label] = {"own": node.models_status(node.key), "foreign": node.models_status(other.key)}
        write(out / "authentication.json", auth)
        soak = cfg["soak"]
        run_cell(fleet, out / "mixed-soak", soak_plan(soak), soak["seconds"], 5300, True)
        capacity = cfg["capacity"]
        for i, arm in enumerate(capacity["arms"]):
            switch(fleet, arm["nodes"])
            offset = 0
            for rate in capacity["rates"]:
                seconds = capacity["seconds_per_rate"]
                run_cell(fleet, out / f"arm-{i}-rate-{rate}",
                         capacity_plan(rate, seconds, offset), seconds, arm["seed"], False)
                offset += rate * seconds
    finally:
        write(out / "routing-events.json", fleet.events)
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            codes = dict(zip(nodes, pool.map(Node.finish, nodes.values()), strict=True))
        write(out / "cleanup.json", codes)
        write(out / "whole-run-end.json", {"ns": time.monotonic_ns()})


if __name__ == "__main__":
    main(Path(sys.argv[1]))
