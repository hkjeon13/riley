"""Verify the registered named-tool crossover on AWS A100 6 and 7."""

import argparse
import json
from hashlib import sha256
from pathlib import Path

from verify_named_burst import verify as score


def read(path):
    return json.loads(path.read_text())


def check_isolation(root, gpu, order):
    directory = root / f"gpu{gpu}"
    before = read(directory / "lease-before.json")
    released = read(root / f"gpu{gpu}.released.json")
    device = (directory / "device.csv").read_text().splitlines()[1].split(",")[0]
    assert (before["gpu"], before["physical_index"], before["phase"]) == (
        device,
        int(gpu),
        "idle",
    )
    assert not before["other_processes"]
    assert (
        released["gpu"],
        released["pid"],
        released["status"],
        released["phase"],
    ) == (
        device,
        before["pid"],
        "running",
        "idle",
    )
    assert not released["other_processes"]
    for mark in ("before", "after"):
        processes = {
            int(pid)
            for uuid, pid, _ in (
                line.split(",")
                for line in (root / f"processes-{mark}.csv").read_text().splitlines()
            )
            if uuid == device
        }
        assert processes == {before["pid"]}
    expected = [
        f"GPU{gpu} {arm} {action}" for arm in order for action in ("start", "complete")
    ]
    assert (root / f"gpu{gpu}.run.log").read_text().splitlines() == expected
    overloads = {}
    for arm in order:
        path = directory / arm
        after = read(path / "lease-after.json")
        assert (
            after["phase"],
            after["gpu"],
            after["pid"],
            after["other_processes"],
        ) == (
            "idle",
            device,
            before["pid"],
            [],
        )
        assert read(path / "ready.json")["ready"]
        metrics = read(path / "metrics.json")
        overloads[arm] = metrics["counters"]["overloads"]
    samples = [
        json.loads(line)
        for line in (root / f"gpu{gpu}.processes.jsonl").read_text().splitlines()
    ]
    owned = {
        app["pid"] for s in samples for app in s["apps"] if app["runner_descendant"]
    }
    unknown = (
        {app["pid"] for s in samples for app in s["apps"]} - owned - {before["pid"]}
    )
    assert len(owned) == 2
    matched = {arm: set() for arm in order}
    if unknown:
        clock = read(root / "clock-receipt-before.json")
        clock_after = read(root / "clock-receipt-after.json")
        offsets = [c["time_ns"] - c["monotonic_ns"] for c in (clock, clock_after)]
        lo = min(offsets) - 50_000_000
        hi = max(offsets) + 50_000_000
        windows = {}
        for arm in order:
            path = directory / arm
            windows[arm] = (
                read(path / "warm.json")["start_ns"],
                read(path / "waves.json")[-1]["drained_ns"],
            )
        for i, sample in enumerate(samples):
            observed = {app["pid"] for app in sample["apps"]} & unknown
            if not observed:
                continue
            left = samples[max(0, i - 1)]["time_ns"] - hi
            right = samples[min(len(samples) - 1, i + 1)]["time_ns"] - lo
            for arm, (begin, end) in windows.items():
                if left <= end and right >= begin:
                    matched[arm].update(observed)
    return {
        "samples": len(samples),
        "owned_server_pids": sorted(owned),
        "foreign_pids_observed": sorted(unknown),
        "foreign_pids_overlapping_measurement": {
            arm: sorted(pids) for arm, pids in matched.items()
        },
        "eligible_comparison": not any(matched.values()),
        "overloads": overloads,
        "uuid": device,
    }


def verify(root, profiler, tokenizer):
    cfg = read(root / "named-burst-registration.json")
    original = read(root / "named-burst-registration-original.json")
    assert cfg == original
    assert cfg["orders"] == {
        "6": ["model", "application"],
        "7": ["application", "model"],
    }
    before = (root / "model-before.txt").read_bytes()
    assert before == (root / "model-after.txt").read_bytes()
    for f in ("tokenizer.json", "tokenizer_config.json"):
        assert (
            f"{sha256((tokenizer / f).read_bytes()).hexdigest()}  {f}".encode()
            in before.splitlines()
        )
    metadata = root / "checkpoint-receipt.json"
    model = read(metadata)
    assert model["source_model"] == "Qwen/Qwen2.5-Coder-7B-Instruct"
    assert (
        f"{sha256(metadata.read_bytes()).hexdigest()}  riley-checkpoint.json".encode()
        in before.splitlines()
    )
    assert model["dtype"] == "bf16"
    source = score(root, profiler, tokenizer)
    result = {}
    for gpu, order in cfg["orders"].items():
        row = source[gpu]
        isolation = check_isolation(root, gpu, order)
        cli = (
            (root / f"gpu{gpu}" / order[0] / "server-arguments.txt")
            .read_text()
            .splitlines()
        )
        for k, expected in [
            ("--inference-profile", "native-bf16-varlen-v1"),
            ("--max-sequence-tokens", "8192"),
            ("--max-active-sequences", "8"),
            ("--kv-blocks", "4096"),
            ("--prefix-cache-blocks", "1536"),
            ("--batch-token-budget", "1024"),
            ("--prefill-chunk-tokens", "1024"),
            ("--prefill-burst-steady-budget", "256"),
        ]:
            assert cli[cli.index(k) + 1] == expected
        arms = {name: row[name] for name in order}
        result[gpu] = {
            "order": order,
            "isolation": isolation,
            "args": cli,
            "paired_prompt_ids": row["paired_prompt_ids"],
            "gates": row["gates"],
            "arms": arms,
        }
    return {
        "date": "2026-11-26",
        "checkpoint": {
            "model": model["source_model"],
            "revision": model["source_revision"],
            "dtype": model["dtype"],
        },
        "devices": result,
        "passes_registered_gates": (
            all(all(row["gates"].values()) for row in result.values())
            if all(row["isolation"]["eligible_comparison"] for row in result.values())
            else None
        ),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("root", "profiler", "tokenizer"):
        parser.add_argument(name, type=Path)
    args = parser.parse_args()
    print(
        json.dumps(
            verify(args.root, args.profiler, args.tokenizer), indent=2, allow_nan=False
        )
    )
