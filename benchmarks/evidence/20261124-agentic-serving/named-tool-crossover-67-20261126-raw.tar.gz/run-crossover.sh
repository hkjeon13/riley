#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
i=$1
holder="$(realpath ../../..)/evidence/w2-sm17-20261118.6UMfeHh2"
case "$i" in
    6) order=(model application);;
    7) order=(application model);;
    *) exit 2;;
esac
ctl=(python3 -B "$holder/control.py" --lease-dir "$holder/leases" --index "$i")
mkdir "gpu$i"
"${ctl[@]}" status > "gpu$i/lease-before.json"
python3 -c 'import sys,json; d=json.load(open(sys.argv[1])); assert d["phase"]=="idle" and not d["other_processes"]' "gpu$i/lease-before.json"
nvidia-smi -i "$i" --query-gpu=uuid,name,driver_version,memory.total --format=csv > "gpu$i/device.csv"
for mode in "${order[@]}"; do
    out="$PWD/gpu$i/$mode"
    export CODER_NAMED_MODE="$mode"
    echo "GPU$i $mode start"
    "${ctl[@]}" run -- bash run-profile.sh "$out" stock 5091 wide > "$out.controller.log" 2>&1
    "${ctl[@]}" status > "$out/lease-after.json"
    echo "GPU$i $mode complete"
done
