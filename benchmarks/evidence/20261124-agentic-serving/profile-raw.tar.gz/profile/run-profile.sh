#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
out=$1
binary=$2
seed=$3
mkdir "$out"
model=/mnt/efs/nlp/psyche/riley-gap-20261102/models/Qwen2.5-7B-Instruct
image=sha256:67efe6fbdaebcc8a088eaa9626f1adb43cf1af3e673ccae2d9af076fa99bdd24
opts=(--user "$(id -u):$(id -g)" --gpus "device=$CUDA_VISIBLE_DEVICES" --publish 127.0.0.1::8080)
opts+=(--mount "type=bind,source=$model,target=/models,readonly")
if [[ $binary != stock ]]; then
    opts+=(--mount "type=bind,source=$binary,target=/opt/riley/bin/riley,readonly")
fi
opts+=(--env RILEY_SHUTDOWN_METRICS_PATH=/tmp/exit.json)
server=(serve --model /models --model-id m --inference-profile native-bf16-varlen-v1)
server+=(--max-sequence-tokens 8192 --max-output-tokens 384 --max-active-sequences 8 --kv-blocks 4096)
server+=(--prefix-cache-blocks 1536 --batch-token-budget 256 --prefill-chunk-tokens 256)
container=$(docker create --pull=never "${opts[@]}" "$image" "${server[@]}")
cleanup() {
    docker stop -t 30 "$container" >/dev/null
    docker logs "$container" > "$out/server.log" 2>&1
    docker cp "$container:/tmp/exit.json" "$out/shutdown.json" || echo 'shutdown receipt unavailable' >&2
    docker rm "$container" > /dev/null
}
trap cleanup EXIT
docker start "$container" >/dev/null
address=$(docker port "$container" 8080/tcp)
for ((i=0; i<300; i++)); do
    if curl -fsS --max-time 1 "http://$address/readyz" > "$out/ready.json" 2>/dev/null; then break; fi
    [[ $(docker inspect -f '{{.State.Running}}' "$container") == true ]] || exit 1
    sleep 1
done
curl -fsS "http://$address/readyz" > "$out/ready.json"
docker exec "$container" sha256sum /proc/1/exe > "$out/binary.sha256"
docker exec "$container" nvidia-smi --query-gpu=uuid,name,driver_version --format=csv > "$out/device.csv"
for history in 0 200; do
    curl -fsS "http://$address/metrics" > "$out/before-$history.json"
    python3 -B agent_workflow.py "$address" m --seed "$((seed + history))" --history-entries "$history" --out "$out/workflows-$history.json"
    curl -fsS "http://$address/metrics" > "$out/after-$history.json"
done
