"""Run matched open-loop rate cells against one and two stock A100 replicas."""
import concurrent.futures
import json
import sys
import threading
import time
from pathlib import Path

from agent_workflow import replay
from run_phase05_soak import Pair, write, append, sample, wait_scheduled
from verify_agent_citations import with_citations


def workflow(pair, n, seed, name, scheduled):
    direct = n % 4 != 0
    slow = n % 17 == 12

    def receive(_, row):
        if slow and row["turn"] == 2:
            time.sleep(.03)

    route = pair.sender(name, on_content=receive)

    def send(address, body, row, visible):
        return route(address, with_citations(body) if row["turn"] == 2 else body, row, visible)

    work = replay("", "m", seed, 96 if n % 3 == 1 else 2,
        (.5 if n % 4 in (1, 2) else .01) if direct else (.2 if n % 8 == 0 else .01),
        name, history=(0, 200, 50)[n % 3], dispatch_fixed_tools=direct, send=send)
    return {"index": n, "scheduled_ns": scheduled, "slow": slow, "tenant": "primary" if n % 5 else "secondary", "work": work}


def rate_cell(pair, path, n_arm, rate, seconds, seed, offset):
    path.mkdir()
    origin = time.monotonic_ns() + 500_000_000
    names = [f"gpu{gpu}" for gpu in (6, 7)]
    end = threading.Event()

    def observe(sink):
        while not end.is_set():
            append(sink, sample(pair, names, "cell"))
            end.wait(1)

    write(path / "before.json", sample(pair, names, "before"))
    with concurrent.futures.ThreadPoolExecutor(128) as pool, (path / "samples.jsonl").open("x") as samples:
        meter = pool.submit(observe, samples)
        jobs = []
        try:
            for i in range(rate * seconds):
                n = offset + i
                scheduled = origin + round(i * 1e9 / rate)
                wait_scheduled(scheduled)
                jobs.append(pool.submit(workflow, pair, n, seed + n, f"arm-{n_arm}-{n}", scheduled))
            wait_scheduled(origin + seconds * 1_000_000_000)
            rows = [future.result() for future in jobs]
        finally:
            end.set()
            meter.result()
    closed = time.monotonic_ns()
    write(path / "observations.json", {"origin_ns": origin, "closed_ns": closed, "rows": rows, "rate": rate})
    time.sleep(.5)
    write(path / "after.json", sample(pair, names, "after"))


def run(path):
    cfg = json.loads((Path(__file__).parent / "capacity-registration.json").read_text())
    with Pair(path) as pair:
        for gpu in (6, 7):
            pair.start(gpu, f"gpu{gpu}")
        for gpu in (6, 7):
            pair.ready(f"gpu{gpu}")
        write(path / "ready.json", {name: {key: value[key] for key in ("gpu", "ready_ns", "start_ns", "pid")}
                                  for name, value in pair.generations.items()})
        for index, arm in enumerate(cfg["arms"]):
            desired = set(arm["gpus"])
            for gpu, name in list(pair.active.items()):
                if gpu not in desired:
                    pair.withdraw(name)
            for gpu in sorted(desired - set(pair.active)):
                pair.admit(f"gpu{gpu}")
            offset = 0
            for rate in cfg["rates"]:
                rate_cell(pair, path / f"arm-{index}-rate-{rate}", index, rate, cfg["seconds_per_rate"], arm["seed"], offset)
                offset += rate * cfg["seconds_per_rate"]


if __name__ == "__main__":
    run(Path(sys.argv[1]))
