"""Independently score the matched single-host A100 rate trials."""
import collections
import json
import sys
from pathlib import Path

from verify_phase05 import lines, percentile, read, releases, result_is_correct, verify_routes


def latency(work, scheduled_ns):
    timestamps = work["turns"][-1]["content_ns"]
    gaps = [(b - a) / 1e6 for a, b in zip(timestamps, timestamps[1:])]
    return {
        "first_ms": (timestamps[0] - scheduled_ns) / 1e6,
        "last_ms": (timestamps[-1] - scheduled_ns) / 1e6,
        "gap_ms": percentile(gaps, .95),
    }


def summarize_cell(path, record, settings, arm, rate, offset):
    rows = record["rows"]
    started = record["origin_ns"]
    config = settings["arms"][arm]
    gates = settings["gates"]
    assert len(rows) == rate * settings["seconds_per_rate"]
    data, errors = [], []
    statuses = collections.Counter()
    cached = collections.Counter()
    for i, row in enumerate(rows):
        assert row["index"] == offset + i and row["scheduled_ns"] == started + round(i * 1e9 / rate)
        work = row["work"]
        assert work["seed"] == config["seed"] + row["index"]
        shapes = (0, 200, 50)
        assert work["history_entries"] == shapes[row["index"] % len(shapes)]
        http = [turn for turn in work["turns"] if "route" in turn]
        for turn in http:
            assert turn["route"]["gpu"] in config["gpus"]
            statuses[str(turn.get("status", "transport_failure"))] += 1
        rejected = any(turn.get("status") == 429 for turn in http)
        correct = result_is_correct(work)
        assert correct == work["ok"]
        if correct:
            measured = latency(work, row["scheduled_ns"])
            slo = all(measured[key] <= gates[key] for key in ("first_ms", "last_ms", "gap_ms"))
            cached[work["turns"][-1]["usage"]["prompt_tokens_details"]["cached_tokens"]] += 1
        else:
            measured = {}
            slo = False
            if not rejected:
                errors.append({"index": row["index"], "seed": work["seed"], "error": work.get("error")})
        data.append({
            "correct": correct, "rejected": rejected, "slo": slo, "tenant": row["tenant"],
            "lag_ms": (work["start_ns"] - row["scheduled_ns"]) / 1e6,
            **measured,
        })
    before = read(path / "before.json")
    after = read(path / "after.json")
    snapshots = [before, *lines(path / "samples.jsonl"), after]
    peaks = {}
    misses = {}
    for reading in before["replicas"]:
        peaks[reading] = {}
        valid = [snap["replicas"][reading]["metrics"] for snap in snapshots
                 if "metrics" in snap["replicas"][reading]]
        misses[reading] = len(snapshots) - len(valid)
        for key in ("active_requests", "waiting_requests", "kv_allocated_blocks"):
            peaks[reading][key] = max(values[key] for values in valid)
    totals = {}
    for label in ("all", "primary", "secondary"):
        group = [row for row in data if label == "all" or label == row["tenant"]]
        ok = [row for row in group if row["correct"]]
        totals[label] = {
            "submitted": len(group), "correct": len(ok), "slo": sum(row["slo"] for row in group),
            "rejected": sum(row["rejected"] for row in group),
            **{"p95_" + k: percentile([row[k] for row in ok], .95) for k in ("first_ms", "last_ms", "gap_ms")},
        }
    all_rows = totals["all"]
    span = (record["closed_ns"] - started) / 1e9
    return {
        "arm": arm, "topology": config["topology"], "gpus": config["gpus"],
        "arrival_rate": rate, "wall_s": span, "counts": totals,
        "http_status": dict(statuses), "client_p95_dispatch_lag_ms": percentile([r["lag_ms"] for r in data], .95),
        "unexpected_failures": errors,
        "slo_goodput_per_s": all_rows["slo"] / span,
        "slo_goodput_per_hour_per_routed_gpu": 3600 * all_rows["slo"] / (span * len(config["gpus"])),
        "replica_gauge_peaks": peaks,
        "replica_metrics_missed_samples": misses,
        "cached_prompt_tokens_histogram": dict(sorted(cached.items())),
        "passes_rate": all_rows["slo"] / len(rows) >= gates["min_slo_fraction"]
        and all_rows["rejected"] / len(rows) <= gates["max_reject_fraction"]
        and len(errors) <= gates["unexpected_failures"],
    }


def verify(folder):
    settings = read(folder / "capacity-registration.json")
    main = read(folder / "phase05-registration.json")
    path = folder / "capacity"
    ready = read(path / "ready.json")
    data, results = {}, []
    for arm in range(len(settings["arms"])):
        offset = 0
        for rate in settings["rates"]:
            trial = path / f"arm-{arm}-rate-{rate}"
            receipt = read(trial / "observations.json")
            data[(arm, rate)] = receipt
            results.append(summarize_cell(trial, receipt, settings, arm, rate, offset))
            offset += rate * settings["seconds_per_rate"]
    for rate in settings["rates"]:
        for a, b in [(0, 1), (2, 3)]:
            control, comparison = data[(a, rate)], data[(b, rate)]
            for lhs, rhs in zip(control["rows"], comparison["rows"], strict=True):
                assert lhs["index"] == rhs["index"]
                assert lhs["scheduled_ns"] - control["origin_ns"] == rhs["scheduled_ns"] - comparison["origin_ns"]
                assert lhs["work"]["fixture_sha256"] == rhs["work"]["fixture_sha256"]
    route = verify_routes(path, [r["work"] for receipt in data.values() for r in receipt["rows"]], ready)
    cleanup = releases(path, main, ready)
    holder = read(path / "holders-before.json")
    foreign = []
    for trial in sorted(path.glob("arm-*-rate-*")):
        snapshots = lines(trial / "samples.jsonl")
        for row in snapshots:
            for name, node in row["replicas"].items():
                allowed = {ready[name]["pid"], holder[str(node["gpu"])]["pid"]}
                foreign.extend((trial.name, name, pid) for pid, _ in node["apps"] if pid not in allowed)
    model = read(folder / "phase04-checkpoint-receipt.json")
    assert (folder / "model-checks.txt").read_text().splitlines() == [v["path"] + ": OK" for v in model["files"]]
    rates_passed = {
        topo: [
            rate for rate in settings["rates"]
            if all(item["passes_rate"] for item in results if item["topology"] == topo and item["arrival_rate"] == rate)
        ]
        for topo in ("single", "dual")
    }
    return {
        "registration": settings, "cells": results, "both_arms_rates_meeting_gates": rates_passed,
        "route": route, "cleanup": cleanup, "foreign_gpu_samples": foreign,
        "full_run_goodput_per_allocated_gpu_hour": (
            3600 * sum(r["counts"]["all"]["slo"] for r in results) / sum(cleanup["assigned_s"].values())
        ),
    }


if __name__ == "__main__":
    print(json.dumps(verify(Path(sys.argv[1])), indent=2))
