//! Render and encode Qwen or Llama 3 chat requests from JSON lines for offline prefix audits.
use std::error::Error;
use std::io::{self, BufRead, Write};
use std::path::PathBuf;
use std::time::Instant;

use riley_model::{
    ChatTemplateSource, EncodeOptions, LoadLimits, Qwen2Tokenizer, SmolLm2Tokenizer, Tokenizer,
};
use riley_server::chat::{ChatTemplate, normalize_chat_request};
use riley_server::domain::RequestLimits;
use serde_json::json;

fn main() -> Result<(), Box<dyn Error>> {
    let dir = PathBuf::from(
        std::env::args_os()
            .nth(1)
            .ok_or("expected model directory")?,
    );
    let mut source = ChatTemplateSource::from_tokenizer_config(&std::fs::read(
        dir.join("tokenizer_config.json"),
    )?)?;
    let standalone = dir.join("chat_template.jinja");
    if standalone.try_exists()? {
        source.template = std::fs::read_to_string(standalone)?;
    }
    let template = ChatTemplate::compile(&source)?;
    let bytes = std::fs::read(dir.join("tokenizer.json"))?;
    let tokenizer: Box<dyn Tokenizer> = match std::env::args().nth(2).as_deref() {
        None => Box::new(Qwen2Tokenizer::from_json_slice(&bytes)?),
        Some("--llama3") => Box::new(SmolLm2Tokenizer::from_llama3_json_slice_with_limits(
            &bytes,
            LoadLimits::default(),
        )?),
        Some(_) => return Err("expected tokenizer directory and optional --llama3".into()),
    };
    let mut stdout = io::BufWriter::new(io::stdout().lock());
    for line in io::stdin().lock().lines() {
        let incoming = serde_json::from_str(&line?)?;
        let started = Instant::now();
        let request = normalize_chat_request(incoming, &template, RequestLimits::default())
            .map_err(|err| format!("invalid request: {err:?}"))?;
        let normalized = Instant::now();
        let ids = tokenizer.encode(
            &request.prompt,
            EncodeOptions {
                add_special_tokens: request.add_special_tokens,
            },
        )?;
        let encoded = Instant::now();
        serde_json::to_writer(
            &mut stdout,
            &json!({
                "normalize_ns": (normalized-started).as_nanos(),
                "encode_ns": (encoded-normalized).as_nanos(),
                "ids": ids,
            }),
        )?;
        writeln!(stdout)?;
    }
    stdout.flush()?;
    Ok(())
}
