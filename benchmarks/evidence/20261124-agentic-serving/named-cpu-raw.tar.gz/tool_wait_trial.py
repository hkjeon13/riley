"""Submit final-format prefix work during a real tool wait and measure the full chain."""

import argparse
import concurrent.futures
import json
import threading
import time
from pathlib import Path

from agent_workflow import replay, stream


def prepare_prefix(request, completed_call, *, include_completed_call=False):
    """Snapshot the final-turn prefix while the actual tool result is pending."""
    messages = list(request["messages"])
    if include_completed_call:
        messages.extend(
            [
                {"role": "assistant", "content": None, "tool_calls": [completed_call]},
                {"role": "tool", "tool_call_id": completed_call["id"], "content": ""},
            ]
        )
    return {**request, "messages": messages, "tool_choice": "none", "max_tokens": 1}


def measure(
    address,
    enabled,
    label,
    seed,
    delay,
    peer_seed=None,
    *,
    policy=None,
    estimated_wait_ms=None,
    include_completed_call=False,
):
    visible = threading.Event()
    prefix_row = {}
    preview = None
    decision = "forced_on" if enabled else "control_off"
    context_key = ("m", seed, 200)
    with concurrent.futures.ThreadPoolExecutor(2) as pool:
        peer = None
        if peer_seed is not None:
            # Keep the peer at its final call until the target's second tool starts.
            release = threading.Event()
            peer = pool.submit(
                replay, address, "m", peer_seed, 2, 0, "reader", visible, release, 200
            )

        def start(index, request, row):
            nonlocal preview, decision
            if index != 1:
                return
            if peer is not None:
                release.set()
                if not visible.wait(45):
                    raise ValueError("reader did not start streaming")
            row["tool_wait_begin_ns"] = time.monotonic_ns()
            if enabled and policy is not None:
                decision = policy.reserve(
                    context_key, estimated_wait_ms, row["usage"]["prompt_tokens"]
                )
            if enabled and decision in ("forced_on", "submit"):
                prepared = prepare_prefix(
                    request, row["call"], include_completed_call=include_completed_call
                )
                preview = pool.submit(stream, address, prepared, prefix_row)

        target = replay(
            address, "m", seed, 96, delay, label, history=200, on_tool_start=start
        )
        if peer is not None and not release.is_set():
            release.set()
        if preview is not None:
            try:
                preview.result()
            except (OSError, ValueError) as error:
                prefix_row["error"] = str(error)
            finally:
                if policy is not None:
                    policy.finish(
                        context_key,
                        "done_ns" in prefix_row and "error" not in prefix_row,
                    )
        result = {
            "case": label,
            "decision": decision,
            "estimated_wait_ms": estimated_wait_ms,
            "enabled": enabled,
            "target": target,
            "prefix": prefix_row,
        }
        if peer is not None:
            result["peer"] = peer.result()
        return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("address")
    p.add_argument("mode", choices=["on", "off"])
    p.add_argument("out", type=Path)
    p.add_argument(
        "--include-completed-call",
        action="store_true",
        help="Include the validated tool call and an empty tool result in the preview.",
    )
    args = p.parse_args()
    # Seeds repeat only for the deliberate warm exact-history control.
    cases = [
        ("zero", 1901, 0, None),
        ("short", 1918, 0.1, None),
        ("long", 1935, 0.5, None),
        ("warm", 1935, 0.5, None),
        ("overlap", 1952, 0.5, 1969),
    ]
    data = []
    for spec in cases:
        data.append(
            measure(
                args.address,
                args.mode == "on",
                *spec,
                include_completed_call=args.include_completed_call,
            )
        )
        args.out.write_text(json.dumps(data, indent=2) + "\n")


if __name__ == "__main__":
    main()
