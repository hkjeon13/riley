"""Loopback SSE reference for the real Coder checkpoint, used only to check final-answer delivery."""

import json
import os
import subprocess
import threading
from functools import partial
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from agent_workflow import fingerprint, replay, stream
from coder_catalog_trial import tool_output


def main():
    import torch
    import transformers
    from transformers import AutoModelForCausalLM, AutoTokenizer, TextStreamer

    root = Path.cwd()
    reg = json.loads((root / "named-cpu-registration.json").read_text())
    checkpoint = root.parents[2] / "models" / reg["checkpoint"]
    profiler = root.parent / reg["native_profiler"]
    assert not os.environ.get("CUDA_VISIBLE_DEVICES") and not torch.cuda.is_available()
    torch.set_num_threads(len(os.sched_getaffinity(0)))
    torch.set_num_interop_threads(1)
    tokenizer = AutoTokenizer.from_pretrained(checkpoint, local_files_only=True)
    model = AutoModelForCausalLM.from_pretrained(
        checkpoint,
        dtype=torch.float32,
        device_map="cpu",
        attn_implementation="sdpa",
        local_files_only=True,
    ).eval()
    assert next(model.parameters()).device.type == "cpu"
    observations = []

    class Reference(BaseHTTPRequestHandler):
        def do_POST(self):
            assert self.path == "/v1/chat/completions"
            req = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            assert (
                req["tool_choice"] == "none"
                and req["stream"]
                and req["temperature"] == 0
            )
            texts = [m for m in req["messages"] if m.get("role") == "tool"]
            assert len(texts) == 2
            # Use the native tokenizer and renderer from the earlier Riley source build.
            encoded = subprocess.run(
                [profiler, checkpoint],
                input=json.dumps(req) + "\n",
                text=True,
                capture_output=True,
                check=True,
            )
            ids = json.loads(encoded.stdout)["ids"]
            inputs = torch.tensor([ids], dtype=torch.long)
            rid = f"cpu-{len(observations)}"
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()

            def emit(obj):
                self.wfile.write(("data: " + json.dumps(obj) + "\n\n").encode())
                self.wfile.flush()

            class SSE(TextStreamer):
                def on_finalized_text(self, text, stream_end=False):
                    if text:
                        emit(
                            {
                                "id": rid,
                                "choices": [{"index": 0, "delta": {"content": text}}],
                            }
                        )

            with torch.inference_mode():
                result = model.generate(
                    inputs,
                    attention_mask=torch.ones_like(inputs),
                    do_sample=False,
                    use_cache=True,
                    max_new_tokens=req["max_tokens"],
                    pad_token_id=tokenizer.eos_token_id,
                    streamer=SSE(
                        tokenizer,
                        skip_prompt=True,
                        skip_special_tokens=True,
                        clean_up_tokenization_spaces=False,
                    ),
                )
            generated = result[0, len(ids) :].tolist()
            eos = model.generation_config.eos_token_id
            if isinstance(eos, int):
                eos = [eos]
            finish = "stop" if generated[-1] in eos else "length"
            usage = {
                "prompt_tokens": len(ids),
                "completion_tokens": len(generated),
                "total_tokens": len(ids) + len(generated),
            }
            observations.append(
                {
                    "id": rid,
                    "input_sha256": fingerprint(req),
                    "prompt_ids_sha256": fingerprint(ids),
                    "output_ids": generated,
                    "decoded": tokenizer.decode(
                        generated,
                        skip_special_tokens=True,
                        clean_up_tokenization_spaces=False,
                    ),
                    "finish": finish,
                    "usage": usage,
                }
            )
            emit(
                {
                    "id": rid,
                    "choices": [{"index": 0, "delta": {}, "finish_reason": finish}],
                    "usage": usage,
                }
            )
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()

    server = HTTPServer(("127.0.0.1", 0), Reference)
    serving = threading.Thread(target=server.serve_forever, daemon=True)
    serving.start()
    (root / "ready.json").write_text(
        json.dumps(
            {
                "torch": torch.__version__,
                "transformers": transformers.__version__,
                "threads": torch.get_num_threads(),
                "dtype": str(next(model.parameters()).dtype),
                "device": "cpu",
            }
        )
        + "\n"
    )
    rows = []
    try:
        for seed, history in reg["jobs"]:
            receipts = []
            invocations = []

            def execute(index, call, docs):
                invocations.append(
                    {"index": index, "id": call["id"], "function": call["function"]}
                )
                return tool_output("selected", False, seed, receipts, index, call, docs)

            work = replay(
                f"127.0.0.1:{server.server_port}",
                "m",
                seed,
                2,
                reg["delay_s"],
                f"cpu-{seed}",
                history=history,
                execute_tool=execute,
                dispatch_fixed_tools=True,
                send=partial(stream, timeout_s=600),
            )
            rows.append(
                {"work": work, "receipts": receipts, "invocations": invocations}
            )
            (root / "client.json").write_text(json.dumps(rows) + "\n")
            (root / "inference.json").write_text(json.dumps(observations) + "\n")
    finally:
        server.shutdown()
        serving.join()
        server.server_close()


if __name__ == "__main__":
    main()
