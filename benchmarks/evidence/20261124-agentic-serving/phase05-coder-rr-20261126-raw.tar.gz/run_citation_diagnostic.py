"""Replay the observed seed-6143 citation failure as an independent diagnostic."""
import json
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from agent_workflow import fingerprint, replay
from run_phase05_soak import Pair, write
from verify_agent_citations import with_citations


def diagnose(out):
    config = json.loads((out.parent / "citation-diagnostic-registration.json").read_text())
    with (out.parent / "soak" / "rows.jsonl").open() as source:
        original = next(
            row["work"] for row in map(json.loads, source)
            if row["index"] == config["original_submission_index"]
        )
    assert original["seed"] == config["seed"] and not original["ok"]
    calls = [
        SimpleNamespace(hex=turn["call"]["id"].removeprefix("call-"))
        for turn in original["turns"][:2]
    ]
    with Pair(out) as pair:
        generation = "citation-gpu7"
        pair.start(7, generation)
        receipt = pair.ready(generation)
        pair.admit(generation)
        ready = {generation: {key: receipt[key] for key in ("gpu", "start_ns", "ready_ns", "pid")}}
        write(out / "ready.json", ready)
        cases = []
        for i, variant in enumerate(config["order"]):
            name = f"citation-{i}"
            send = pair.sender(name)

            def request(address, body, row, first):
                row["unmodified_request_sha256"] = fingerprint(body)
                if variant == "explicit":
                    body = with_citations(body)
                return send(address, body, row, first)

            with patch("uuid.uuid4", side_effect=calls):
                result = replay(
                    "", "m", config["seed"], 2, .01, name,
                    send=request, dispatch_fixed_tools=True,
                )
            assert result["turns"][-1]["unmodified_request_sha256"] == original["turns"][-1]["input_sha256"]
            cases.append({"variant": variant, "work": result})
        write(out / "cases.json", cases)


if __name__ == "__main__":
    diagnose(Path(sys.argv[1]))
