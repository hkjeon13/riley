"""Test planned drain and three process-fault boundaries on phase-05 replicas."""
import concurrent.futures
import contextlib
import socket
import sys
import threading
import time
from pathlib import Path

from agent_workflow import fingerprint, replay
from process_qualification import Journal
from run_phase05_soak import CFG, GPU, Pair, metrics, sample, write
from verify_agent_citations import with_citations


def run_work(pair, name, seed, *, content=None, connect=None, tool_start=None, journal=None, direct=True, long=False):
    send = pair.sender(name, on_content=content, on_connect=connect)

    def request(address, body, row, visible):
        if row["turn"] == 2:
            body = with_citations(body)
        return send(address, body, row, visible)

    def tool_result(index, call, docs):
        result = journal.execute(index, call, docs)
        journal.attempts[-1]["result_sha256"] = fingerprint(result)
        return result

    return replay(
        "", "m", seed, 96 if long else 2, .01, name, history=200 if long else 20,
        send=request, dispatch_fixed_tools=direct, on_tool_start=tool_start,
        execute_tool=tool_result if journal else None,
    )


def ready_receipt(pair, name):
    generation = pair.generations[name]
    return {key: generation[key] for key in ("gpu", "start_ns", "ready_ns", "pid")}


def endpoint_closed(address):
    host, port = address.split(":")
    try:
        with socket.create_connection((host, int(port)), timeout=3):
            return False
    except ConnectionRefusedError:
        return True


def wait_until(predicate, seconds, description):
    deadline = time.monotonic() + seconds
    while not predicate():
        if time.monotonic() > deadline:
            raise TimeoutError(description)
        time.sleep(.01)


def planned(pair, workloads):
    first = threading.Event()

    def on_content(n, row):
        if row["turn"] == 2 and n == 1:
            first.set()

    old = "old-6"
    reply = workloads.submit(run_work, pair, "drained", 761, content=on_content, long=True)
    if not first.wait(30):
        raise RuntimeError(f"drain test did not see first content: {reply.result(timeout=30)}")
    withdrawn = pair.withdraw(old)
    newly_routed = run_work(pair, "after-withdraw", 762)
    drained = reply.result(timeout=30)
    pair.retire(old)
    old_closed = endpoint_closed(pair.generations[old]["address"])

    replacement = "replacement-6"
    pair.start(6, replacement)
    while_waiting = run_work(pair, "during-replacement-load", 783)
    pair.ready(replacement)
    admitted = pair.admit(replacement)
    return {
        "old": old, "replacement": replacement, "withdrawn_ns": withdrawn,
        "old_closed": old_closed, "drained": drained, "newly_routed": newly_routed,
        "while_waiting": while_waiting,
        "replacement_ready": ready_receipt(pair, replacement),
        "replacement_admitted_ns": admitted,
        "after_rejoin": probe_pool(pair, "after-planned-rejoin"),
    }


def probe_pool(pair, label):
    return [run_work(pair, f"{label}-{i}", seed) for i, seed in enumerate((761, 762))]


def fault(pair, workloads, scenario, fault_gpu, seed, ordinal):
    name = f"logical-{ordinal}-{scenario}"
    failed_name = pair.active[fault_gpu]
    peer_gpu = next(gpu for gpu in GPU if gpu != fault_gpu)
    peer = pair.active[peer_gpu]
    pre_alignment = None
    if GPU[pair.sequence % len(GPU)] != fault_gpu:
        pre_alignment = run_work(pair, f"align-{ordinal}", 761)

    ready_to_fault = threading.Event()
    first_turn = {}
    fault_marker = pair.path / failed_name / "fault-scenario"
    exit_code = pair.path / failed_name / "fault-exit-code"
    journal_file = pair.path / "actions.sqlite"
    journal = Journal(journal_file, name)
    partial_observed = {}
    clock = {"epoch_offset_ns": time.time_ns() - time.monotonic_ns()}

    def on_connect(row):
        if scenario == "before-content" and row["turn"] == 2:
            first_turn["row"] = row
            ready_to_fault.set()
        return {}

    def on_content(n, row):
        if scenario == "partial-content" and row["turn"] == 2 and n == 4:
            partial_observed["fourth_ns"] = row["content_ns"][-1]
            ready_to_fault.set()

    def on_tool_start(index, _, row):
        if scenario == "completed-tool-call" and index == 0:
            partial_observed["call_validated_ns"] = time.monotonic_ns()
            partial_observed["call"] = row["call"]
            ready_to_fault.set()
            wait_until(exit_code.is_file, 20, "completed tool call fault")
            raise ValueError("replica fault after validated tool call, before executing effect")

    result = workloads.submit(
        run_work, pair, name, seed, content=on_content, connect=on_connect,
        tool_start=on_tool_start, journal=journal,
        direct=scenario != "completed-tool-call", long=scenario in ("before-content", "partial-content"),
    )
    if not ready_to_fault.wait(30):
        raise RuntimeError(f"fault trigger {scenario} did not occur: {result.result(timeout=30)}")
    active_at_fault = None
    if scenario == "before-content":
        generation = pair.generations[failed_name]

        def active():
            nonlocal active_at_fault
            if "request_written_ns" not in first_turn["row"]:
                return False
            reading = metrics(generation["address"])
            if not reading["active_requests"]:
                return False
            active_at_fault = {"active": reading["active_requests"], "observed_ns": time.monotonic_ns()}
            return True

        wait_until(active, 5, "faulted generation active before first visible final content")

    marker_ns = time.monotonic_ns()
    fault_marker.write_text(scenario + "\n")
    wait_until(exit_code.is_file, 20, "owned replica exit status")
    withdrawn = pair.withdraw(failed_name)
    replacement = f"fault-{ordinal}-restart-{fault_gpu}"
    interrupted = result.result(timeout=30)
    pair.generations[failed_name]["task"].result(timeout=100)
    closed = endpoint_closed(pair.generations[failed_name]["address"])
    pair.start(fault_gpu, replacement)

    retry = Journal(journal_file, name)
    recovered = run_work(
        pair, name, seed, journal=retry, direct=scenario != "completed-tool-call",
        long=scenario in ("before-content", "partial-content"),
    )
    persisted_retry = Journal(journal_file, name)
    verification = run_work(
        pair, name, seed, journal=persisted_retry, direct=scenario != "completed-tool-call",
        long=scenario in ("before-content", "partial-content"),
    )
    pair.ready(replacement)
    admitted = pair.admit(replacement)
    rejoined = probe_pool(pair, f"after-fault-{ordinal}-rejoin")
    return {
        "logical_id": name, "scenario": scenario, "failed_generation": failed_name,
        "peer_generation": peer, "replacement": replacement, "pre_alignment": pre_alignment,
        "clock": clock, "marker_ns": marker_ns,
        "kill_epoch_ns": int((pair.path / failed_name / "fault-epoch-ns").read_text()),
        "fault_exit": int(exit_code.read_text()), "withdrawn_ns": withdrawn,
        "active_at_fault": active_at_fault, "observed_before_fault": partial_observed,
        "failed_endpoint_closed": closed, "interrupted": interrupted, "recovered": recovered,
        "persisted_retry": verification,
        "tool_attempts": [journal.attempts, retry.attempts, persisted_retry.attempts],
        "replacement_ready": ready_receipt(pair, replacement), "replacement_admitted_ns": admitted,
        "after_rejoin": rejoined,
    }


def main(out):
    with Pair(out) as pair, concurrent.futures.ThreadPoolExecutor(3) as workloads:
        names = ["old-6", "peer-7"]
        observed = {}
        for gpu, name in zip(GPU, names):
            pair.start(gpu, name)
        for name in names:
            pair.ready(name)
            pair.admit(name)
        observed["initial"] = [ready_receipt(pair, name) for name in names]
        write(out / "measurement-start.json", sample(pair, names, "before"))
        observed["planned"] = planned(pair, workloads)
        observed["faults"] = []
        write(out / "observations.json", observed)
        for ordinal, (scenario, gpu, seed) in enumerate((
            ("before-content", 7, 761),
            ("partial-content", 6, 762),
            ("completed-tool-call", 7, 783),
        ), 1):
            receipt = fault(pair, workloads, scenario, gpu, seed, ordinal)
            observed["faults"].append(receipt)
            write(out / "observations.json", observed)
        write(out / "measurement-end.json", sample(pair, list(pair.active.values()), "after"))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
