#!/usr/bin/env bash
set -euo pipefail
root="$(realpath ../../..)"
model="$root/models/Qwen2.5-Coder-7B-Instruct"
manifest="$PWD/phase04-checkpoint-receipt.json"
python3 - "$manifest" <<'PY' > model-registered.sha256
import json
import sys

for file in json.load(open(sys.argv[1]))["files"]:
    print(f'{file["sha256"]}  {file["path"]}')
PY
(
    cd "$model"
    stat --printf '%n %s %i %Y\n' ./model-*.safetensors
    sha256sum config.json tokenizer.json tokenizer_config.json model.safetensors.index.json riley-checkpoint.json
) > model-after.txt
cmp model-during-soak.txt model-after.txt
(
    cd "$model"
    sha256sum -c "$(dirname "$manifest")/model-registered.sha256"
) > model-checks.txt
