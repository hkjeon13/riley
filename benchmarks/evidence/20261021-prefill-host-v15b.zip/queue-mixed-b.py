from pathlib import Path
import json,time,subprocess,os,traceback
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');old=w.parent/'riley-qkv-gateup-v214-20261019';state=dict(phase='waiting-body',started_ns=time.time_ns())
def save():(w/'mixed-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  a=json.loads((w/'extra-accuracy-state.json').read_text())
  if a['phase'] in ['complete','failed']:assert a['phase']=='complete',a;break
  time.sleep(2)
 state['phase']='mixed';save()
 with(w/'advanced-prepare.outer.log').open('x')as f:r=subprocess.run(['python3',str(w/'prepare-advanced-teacher-b.py')],stdout=f,stderr=f)
 assert r.returncode==0
 state['phase']='mixed-no-output';save()
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'teacher-mixed-no-output'),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES='32',RILEY_TEACHER_SHRINK='',RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH='segments-v1',RILEY_OWNED_BATCH='native-prefill-sm80-v5',RILEY_MIXED_NO_OUTPUT_PREFILL='1')
 a=json.loads((w/'teacher-mixed.argv.json').read_text());a[a.index('--out')+1]=str(w/'observed-teacher-mixed-no-output');(w/'teacher-mixed-no-output.argv.json').write_text(json.dumps(a,indent=2))
 with(w/'teacher-mixed-no-output.launch.log').open('x')as f:r=subprocess.run(a,env=env,stdout=f,stderr=f)
 assert r.returncode==0
 with(w/'mixed-audit.outer.log').open('x')as f:r=subprocess.run(['python3',str(w/'audit-mixed-b.py')],stdout=f,stderr=f)
 assert r.returncode==0
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
