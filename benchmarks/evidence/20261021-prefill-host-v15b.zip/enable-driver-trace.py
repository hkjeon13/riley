from pathlib import Path
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');p=w/'measure-profile.py';s=p.read_text();a="'--cuda-graph-trace=node']";assert a in s;s=s.replace(a,"'--cuda-graph-trace=node','--cuda-trace-all-apis=true']",1);p.write_text(s)
