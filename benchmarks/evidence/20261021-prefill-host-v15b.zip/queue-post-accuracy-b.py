from pathlib import Path
import json,time,subprocess,os,traceback
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';state=dict(phase='waiting-mixed',started_ns=time.time_ns())
def save():(w/'post-accuracy-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  a=json.loads((w/'mixed-state.json').read_text())
  if a['phase']in ['complete','failed']:assert a['phase']=='complete',a;break
  time.sleep(3)
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'research/post-accuracy-output'))
 base=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','24-31','python3',str(w/'observe-finite.py'),'--out']
 for name,command in [('ledger-gpu',['python3',str(w/'run-ledger-gpu.py')]),('prefill-inplace',[str(w/'research/prefill-probe-inplace')])]:
  state.update(phase='running',current=name);save();a=base+[str(w/('observed-'+name)),'--']+command;(w/(name+'.argv.json')).write_text(json.dumps(a,indent=2))
  with(w/(name+'.launch.log')).open('x')as f:c=subprocess.run(a,env=env,stdout=f,stderr=f)
  assert c.returncode==0,(name,c.returncode)
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
