from pathlib import Path
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021')
s=(w/'prepare-mixed-teacher.py').read_text()
marker="(W/'teacher-mixed.rs').write_text(s)"
assert marker in s
changes=[]
changes.append(('owner.warm_owned_qwen_decode_graphs(true,&mut stream)?;','owner.warm_owned_qwen_decode_graphs(false,&mut stream)?;'))
changes.append(('            let case=model_case',r'''            // A bad prefill must be rejected before the valid decode partition
            // can run, without replacing the last successful shape or outputs.
            let snapshot=owner.last_shape_observation();let stats=owner.owned_mlp_graph_stats();
            let invalid=[model.spec().embedding().vocabulary_size() as u32];let good=[0u32];
            let (db,dv)=table(129)?;let pb=[64u32];let pv=[1u16];
            let bad_rows=[LlamaBatchRow::new(90001,LlamaBatchRowKind::Decode,&good,129,LlamaBatchBlockTable::new(BLOCK_TABLE_V1_VERSION,&db,&dv,129),Some(0)),
                LlamaBatchRow::new(90002,LlamaBatchRowKind::Prefill,&invalid,1,LlamaBatchBlockTable::new(BLOCK_TABLE_V1_VERSION,&pb,&pv,1),Some(1))];
            let err=owner.execute(&bad_rows,&mut stream).expect_err("whole-batch token admission must fail");
            assert!(matches!(err,riley_runtime::llama::LlamaBatchExecutorError::TokenOutOfRange{..}));
            assert!(!owner.is_poisoned());assert_eq!(owner.last_shape_observation(),snapshot);assert_eq!(owner.owned_mlp_graph_stats(),stats);assert_eq!(c.allocation_stats()?,stable);
            println!("RILEY_SPLIT_PREFLIGHT invalid_prefill_rejected=true shape_unchanged=true owner_reusable=true output_not_published=true");
            let no_output_prefill=std::env::var("RILEY_MIXED_NO_OUTPUT_PREFILL").as_deref()==Ok("1");
            let case=model_case'''))
changes.append(('Some((active-idx-1)as u32)',r'''if no_output_prefill&&tick==copy {None}else{Some(order.iter().enumerate().filter(|(j,r)|*j>idx&&(!no_output_prefill||tick!=**r)).count()as u32)}'''))
changes.append(('bytes.resize(row_bytes*active,0)', 'bytes.resize(row_bytes*order.iter().filter(|&&r|!no_output_prefill||tick!=r).count(),0)'))
changes.append(('for (idx,&copy)in order.iter().enumerate(){let step=tick-copy;let slot=active-idx-1;',r'''for (idx,&copy)in order.iter().enumerate(){if no_output_prefill&&tick==copy {continue;}let step=tick-copy;let slot=order.iter().enumerate().filter(|(j,r)|*j>idx&&(!no_output_prefill||tick!=**r)).count();'''))
changes.append(('assert_eq!(rows.len(),1024);','assert_eq!(rows.len(),if no_output_prefill{992}else{1024});'))
changes.append(('"id":"staggered-natural128","mixed_steps":mixed','"id":"staggered-natural128","no_output_prefill":no_output_prefill,"mixed_steps":mixed'))
code='\n'
for old,new in changes:code+='assert '+repr(old)+' in s\ns=s.replace('+repr(old)+','+repr(new)+')\n'
s=s.replace(marker,code+'\n'+marker)
(w/'prepare-advanced-mixed-generated.py').write_text(s)
import subprocess
with(w/'teacher-advanced.outer.log').open('x')as f:r=subprocess.run(['python3',str(w/'prepare-advanced-mixed-generated.py')],stdout=f,stderr=f)
assert r.returncode==0
