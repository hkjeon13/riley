from pathlib import Path
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');d=w.parent/'riley-structural-v14d-20261021';(w/'observe-finite-v15.py').write_text((d/'observe-finite.py').read_text())
s=(w/'audit-teachers-e.py').read_text()
for n in ['final-teacher-C1-eager','final-teacher-allR-Graph','teacher-body-allR']:s=s.replace(n,n+'-resource-r2')
s=s.replace("p/'final-teacher-audit.json'","p/'final-teacher-resource-audit.json'");(w/'audit-teachers-resource-r2.py').write_text(s)
s=(w/'audit-mixed-b.py').read_text();s=s.replace("('teacher-mixed','teacher-mixed-output',1024),('teacher-mixed-no-output','teacher-mixed-no-output',992)","('teacher-mixed-resource-r2','teacher-mixed-output-resource-r2',1024),('teacher-mixed-no-output-resource-r2','teacher-mixed-no-output-resource-r2',992)")
s=s.replace("w/'mixed-byte-audit.json'","w/'mixed-byte-resource-audit.json'");(w/'audit-mixed-resource-r2.py').write_text(s)
