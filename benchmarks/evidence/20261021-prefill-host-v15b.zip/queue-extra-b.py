from pathlib import Path
import json,time,subprocess,traceback
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');state=dict(phase='waiting-basic-teachers',started_ns=time.time_ns())
def save():(w/'extra-accuracy-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  p=w/'final-teacher-state.json'
  if p.exists():
   a=json.loads(p.read_text())
   if a['status']!='running':assert a['status']=='complete',a;break
  time.sleep(2)
 state['phase']='body';save()
 with(w/'body-prepare.outer.log').open('x')as f:r=subprocess.run(['python3',str(w/'prepare-body-teacher.py')],stdout=f,stderr=f)
 assert r.returncode==0
 while True:
  p=w/'observed-teacher-body-allR.json'
  if p.exists():
   a=json.loads(p.read_text())
   if a['status']!='running':assert a['status']=='complete'and a['returncode']==0,a;break
  time.sleep(2)
 with(w/'teacher-audit.outer.log').open('x')as f:r=subprocess.run(['python3',str(w/'audit-teachers-e.py')],stdout=f,stderr=f)
 assert r.returncode==0
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
