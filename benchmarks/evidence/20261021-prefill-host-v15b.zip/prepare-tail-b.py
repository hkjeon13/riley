from pathlib import Path
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');d=w.parent/'riley-structural-v14d-20261021';s=(d/'audit-tail-d.py').read_text().replace(str(d),str(w));(w/'audit-tail-b.py').write_text(s)
