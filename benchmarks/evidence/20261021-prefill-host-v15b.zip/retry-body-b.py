from pathlib import Path
import json,subprocess,os,time
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');old=w.parent/'riley-qkv-gateup-v214-20261019'
a=json.loads((w/'teacher-body-allR.argv.json').read_text());assert a[a.index('--index')+1]=='7';a[a.index('--index')+1]='6';(w/'teacher-body-allR-r2.argv.json').write_text(json.dumps(a,indent=2))
env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'teacher-body-allR'),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES='32',RILEY_TEACHER_SHRINK='',RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH='segments-v1',RILEY_OWNED_BATCH='native-prefill-sm80-v5');env.pop('CUBLAS_WORKSPACE_CONFIG',None)
with(w/'teacher-body-allR-r2.launch.log').open('x')as f:r=subprocess.run(a,env=env,stdout=f,stderr=f)
assert r.returncode==0
