from pathlib import Path
import os,subprocess,json,time
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';state=dict(phase='running',started_ns=time.time_ns());p=w/'post-inplace-state.json';p.write_text(json.dumps(state,indent=2))
env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'research/prefill-inplace-r3-output'))
a=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','24-31','python3',str(w/'observe-finite-v15.py'),'--out',str(w/'observed-prefill-inplace-r3'),'--',str(w/'research/prefill-probe-inplace')]
with(w/'prefill-inplace-r3.launch.log').open('x')as f:c=subprocess.run(a,env=env,stdout=f,stderr=f)
state.update(phase='complete'if c.returncode==0 else'failed',returncode=c.returncode,finished_ns=time.time_ns());p.write_text(json.dumps(state,indent=2));assert c.returncode==0
