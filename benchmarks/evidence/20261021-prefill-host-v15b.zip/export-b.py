from pathlib import Path
import hashlib,json,time,zipfile,subprocess
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((w/'normal-analysis-state.json').read_text())['phase']=='complete'
assert json.loads((w/'resource-r2-state.json').read_text())['phase']=='complete'
assert json.loads((w/'post-inplace-state.json').read_text())['phase']=='complete'
a=json.loads((w/'independent-audit.json').read_text());assert len(a['arms'])==35
m=json.loads((w/'source-manifest.json').read_text());assert len(m)==936 and all(sha(w/'source'/f)==h for f,h in m.items());lineage=json.loads((w/'source-lineage.json').read_text());assert sha(w/'riley-prefill-host-v15b')==lineage['binary_sha256']
resource=[]
for n in ['final-teacher-C1-eager','final-teacher-allR-Graph','teacher-body-allR','teacher-mixed','teacher-mixed-no-output']:
 name=n+'-resource-r2';r=json.loads((w/('observed-'+name+'.json')).read_text());assert r['status']=='complete'and r['returncode']==0
 samples=[json.loads(s)for s in(w/('observed-'+name+'.samples.jsonl')).read_text().splitlines()];peak=max(s['device_memory_mib']for s in samples);assert 0<peak<=22528;resource.append(dict(name=name,samples=len(samples),whole_device_peak_MiB=peak,receipt_sha256=sha(w/('observed-'+name+'.json'))))
r=json.loads((w/'observed-prefill-inplace-r4.json').read_text());assert r['status']=='complete'and r['returncode']==0
samples=[json.loads(s)for s in(w/'observed-prefill-inplace-r4.samples.jsonl').read_text().splitlines()];resource.append(dict(name='prefill-inplace-r4',samples=len(samples),whole_device_peak_MiB=max(s['device_memory_mib']for s in samples),verified_before_sampling=r['early_verified_owned_start_ticks']))
(w/'resource-audit-final.json').write_text(json.dumps(dict(time_ns=time.time_ns(),resource_reruns=resource,source936_verified=True,binary_sha256=lineage['binary_sha256'],normal_and_profile_arms=35,stored_SSE_verified=a['total_full_SSE_values_verified'],normal_and_profile_peak_MiB=max(r['peak_whole_device_MiB']for r in a['arms'])),indent=2))
stock=[]
for p in(w/'runs').glob('*/c*-vllm/server.log'):
 s=p.read_text();assert 'FLASH_ATTN'in s and 'FULL_AND_PIECEWISE'in s and ('version 2'in s or 'version=2'in s),p
 stock.append(dict(log=str(p),sha256=sha(p),FLASH_ATTN=True,FULL_AND_PIECEWISE=True,version2=True))
assert len(stock)==11
(w/'stock-startup-proof.json').write_text(json.dumps(stock,indent=2))
(w/'adoption-decision.json').write_text(json.dumps(dict(time_ns=time.time_ns(),adopted=False,reasons=['C32 repeat2 TPOTp99 +2.397697% requires additional paired validation','General unaligned query/output BF16 span eligibility must retain original layout; addressed in final C candidate'],default_runtime='v13B retained at this checkpoint',next='C alignment guard plus same native/SSE/resource gates and fresh C16/C32 five-repeat stock comparison'),indent=2))
heavy={};skip={'source','target','tmp','cache','vllm-cache','ipc6','ipc7','__pycache__','torch_compile_cache','torchinductor_cache'}
for p in w.rglob('*'):
 if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
 if p.suffix=='.bf16' or p.suffix in ['.sqlite','.nsys-rep']or (p.stat().st_size>4 and p.open('rb').read(4)==b'\x7fELF'):
  heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p))
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2))
allowed={'.json','.jsonl','.log','.txt','.py','.sh','.stdout','.stderr','.cu','.cuh','.cpp','.sse','.h','.hpp','.exit','.sha256'}
files=[p for p in w.rglob('*')if p.is_file()and not any(x in skip for x in p.relative_to(w).parts)and p.suffix in allowed and p.name!='evidence-archive-receipt.json'];manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)}
z=w/'evidence-archive-v15b.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as f:
 for p in sorted(files):f.write(p,str(p.relative_to(w)))
 f.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
(w/'evidence-archive-receipt.json').write_text(json.dumps(dict(time_ns=time.time_ns(),archive=str(z),bytes=z.stat().st_size,entries=len(files)+1,sha256=sha(z),heavy_files=len(heavy)),indent=2));print((w/'evidence-archive-receipt.json').read_text())
