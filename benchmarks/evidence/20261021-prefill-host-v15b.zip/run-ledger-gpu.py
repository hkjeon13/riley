from pathlib import Path
import subprocess,json,hashlib,time
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');rows=[]
for line in(w/'ledger-gpu-build.jsonl').read_text().splitlines():
 try:a=json.loads(line)
 except ValueError:continue
 if a.get('reason')=='compiler-artifact'and a.get('executable')and a['target']['name']in ['host_runtime_gpu','memory_gpu','owned_hf_command_batch_gpu']:rows.append(a)
assert len(rows)==3,[(r['target']['name'])for r in rows]
proof=[]
for r in rows:
 n=r['target']['name'];p=Path(r['executable']);a=[str(p),'--ignored','--nocapture','--test-threads=1']
 if n!='owned_hf_command_batch_gpu':a+=['command_batch']
 with(w/(n+'.ledger.log')).open('x')as f:c=subprocess.run(a,stdout=f,stderr=f)
 assert c.returncode==0,n;proof.append(dict(name=n,argv=a,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),returncode=c.returncode))
(w/'ledger-gpu-tests.json').write_text(json.dumps(dict(time_ns=time.time_ns(),tests=proof),indent=2))
