from pathlib import Path
import json,time,subprocess,traceback,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');state=dict(phase='waiting-normal',started_ns=time.time_ns())
def save():(w/'profile-queue-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  a=json.loads((w/'campaign-state.json').read_text())
  if a['phase']in ['complete','failed']:assert a['phase']=='complete',a;break
  time.sleep(3)
 assert (w/'pointer-inspection.so').is_file()
 for name in ['profile-c16','profile-c32']:
  state.update(phase='profiling',current=name);save()
  with(w/(name+'.outer.log')).open('x')as f:r=subprocess.run(['python3',str(w/'run-job.py'),name],stdout=f,stderr=f)
  assert r.returncode==0,(name,r.returncode)
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
