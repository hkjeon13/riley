from pathlib import Path
import json,time,subprocess,os,traceback,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';state=dict(phase='waiting-resource-r2',started_ns=time.time_ns())
def save():(w/'post-accuracy-r2-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  a=json.loads((w/'resource-r2-state.json').read_text())
  if a['phase']in ['complete','failed']:assert a['phase']=='complete',a;break
  time.sleep(3)
 artifacts=[]
 for line in(w/'ledger-gpu-build.jsonl').read_text().splitlines():
  try:a=json.loads(line)
  except ValueError:continue
  if a.get('reason')=='compiler-artifact'and a.get('executable')and a['target']['name']in ['host_runtime_gpu','memory_gpu','owned_hf_command_batch_gpu']:artifacts.append(a)
 assert len(artifacts)==3
 jobs=[]
 for a in artifacts:
  n=a['target']['name'];args=[a['executable'],'--ignored','--nocapture','--test-threads=1']
  if n!='owned_hf_command_batch_gpu':args+=['command_batch']
  jobs.append((n+'-ledger-r2',args))
 jobs.append(('prefill-inplace-r2',[str(w/'research/prefill-probe-inplace')]))
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/'research/post-accuracy-r2-output'))
 base=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','24-31','python3',str(w/'observe-finite-v15.py'),'--out'];proof=[]
 for name,command in jobs:
  state.update(phase='running',current=name);save();a=base+[str(w/('observed-'+name)),'--']+command;(w/(name+'.argv.json')).write_text(json.dumps(a,indent=2))
  with(w/(name+'.launch.log')).open('x')as f:p=subprocess.run(a,env=env,stdout=f,stderr=f)
  assert p.returncode==0,(name,p.returncode)
  receipt=json.loads((w/('observed-'+name+'.json')).read_text());samples=[json.loads(s)for s in(w/('observed-'+name+'.samples.jsonl')).read_text().splitlines()];peak=max(s['device_memory_mib']for s in samples);assert 0<peak<=22528
  proof.append(dict(name=name,argv=a,binary_sha256=hashlib.sha256(Path(command[0]).read_bytes()).hexdigest(),whole_device_peak_MiB=peak,receipt=receipt))
 (w/'post-accuracy-r2-audit.json').write_text(json.dumps(proof,indent=2));state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
