from pathlib import Path
import json,subprocess,sqlite3,collections,re,time,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');assert json.loads((w/'profile-queue-state.json').read_text())['phase']=='complete';paths=sorted((w/'runs').glob('profile-c*/c*/trace.sqlite'));assert len(paths)==5
for script,args in [('attribute-graphs.py',[str(p)for p in paths if 'vllm'not in str(p)]),('analyze-profile-v15.py',[str(p)for p in paths]),('audit-complete.py',[])]:
 with(w/(script+'.final.log')).open('x')as f:p=subprocess.run(['python3',str(w/script)]+args,stdout=f,stderr=f)
 assert p.returncode==0,(script,p.returncode)
proof=[]
for p in paths:
 d=sqlite3.connect(p);d.row_factory=sqlite3.Row;s=dict(d.execute('select id,value from StringIds'));rows=d.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL').fetchall();counts={}
 for token in ['hf_sm80_compact_prefill','hf_q_gather','hf_output_rows','hf_scale_mask_tile','hf_scatter_bf16_tile']:
  selected=[r for r in rows if token in s[r['demangledName']]];counts[token]=dict(count=len(selected),ms=sum(r['end']-r['start']for r in selected)/1e6)
 nvtx=[]
 for r in d.execute('select * from NVTX_EVENTS'):
  r=dict(r);label=r.get('text')or s.get(r.get('textId'),'')
  if '/BatchedEx/'in label:nvtx.append(label)
 if 'owned-after'in str(p):assert counts['hf_sm80_compact_prefill']['count']>0 and nvtx;assert counts['hf_q_gather']['count']==counts['hf_output_rows']['count']==counts['hf_scale_mask_tile']['count']==counts['hf_scatter_bf16_tile']['count']==0
 if 'owned-before'in str(p):assert counts['hf_sm80_compact_prefill']['count']==0 and not nvtx
 labels=collections.Counter(nvtx)
 proof.append(dict(trace=str(p),role=p.parent.name,kernels=counts,pointer_batched_NVTX_ranges=len(nvtx),pointer_batched_geometry=dict(labels),trace_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),analysis=json.loads(Path(str(p)+'.v15-analysis.json').read_text())))
(w/'prefill-and-host-profile-proof.json').write_text(json.dumps(dict(time_ns=time.time_ns(),scope='Separate192-keep Nsight diagnostics; all APIs requested, driver calls are in unified RUNTIME table. Does not replace normal throughput.',traces=proof),indent=2))
print([(r['role'],r['kernels']['hf_sm80_compact_prefill']['count'],r['pointer_batched_NVTX_ranges'])for r in proof])
