from pathlib import Path
import json,time,os,subprocess,traceback,hashlib
w=Path('/mnt/efs/nlp/psyche/riley-prefill-host-v15b-20261021');r=w.parent/'riley-w0-a100-gpu67-20261019';old=w.parent/'riley-qkv-gateup-v214-20261019';state=dict(phase='starting',started_ns=time.time_ns())
def save():(w/'resource-r2-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 for name,binary,copies,graph,shrink,no_output in [('final-teacher-C1-eager','teacher-probe-final','1','off','',False),('final-teacher-allR-Graph','teacher-probe-final','32','segments-v1','all-v1',False),('teacher-body-allR','teacher-body','32','segments-v1','',False),('teacher-mixed','teacher-mixed','32','segments-v1','',False),('teacher-mixed-no-output','teacher-mixed','32','segments-v1','',True)]:
  tag=name+'-resource-r2';folder=tag if name!='teacher-mixed'else'teacher-mixed-output-resource-r2';state.update(phase='running',current=tag);save()
  env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-031a7f9d-5789-04b8-c9d6-63f55ee1e6a7',LD_LIBRARY_PATH='/usr/local/cuda-12.4/lib64',TMPDIR=str(w/'tmp'),RILEY_DIVERGENCE_FIXTURE_ROOT=str(old/'qwen3-4b-fresh-A100-HF-v222'),RILEY_DIVERGENCE_NATIVE_OUTPUT=str(w/folder),RILEY_DIVERGENCE_COMPLETION='iteration-batch',RILEY_TEACHER_COPIES=copies,RILEY_TEACHER_SHRINK=shrink,RILEY_TEACHER_CHUNK_PREFILL='v1',RILEY_OWNED_GRAPH=graph,RILEY_OWNED_BATCH='native-prefill-sm80-v5')
  env.pop('CUBLAS_WORKSPACE_CONFIG',None)
  if no_output:env['RILEY_MIXED_NO_OUTPUT_PREFILL']='1'
  a=['python3',str(r/'control.py'),'--lease-dir',str(r/'leases-v2'),'--index','6','run','--','taskset','-c','24-31','python3',str(w/'observe-finite-v15.py'),'--out',str(w/('observed-'+tag)),'--',str(w/binary),'--ignored','--exact','owned_batch_teacher_forced_logits_are_finite_and_reported','--nocapture','--test-threads=1'];(w/(tag+'.argv.json')).write_text(json.dumps(a,indent=2))
  with(w/(tag+'.launch.log')).open('x')as f:p=subprocess.run(a,env=env,stdout=f,stderr=f)
  assert p.returncode==0,(tag,p.returncode)
 for name in ['audit-teachers-resource-r2.py','audit-mixed-resource-r2.py']:
  with(w/(name+'.log')).open('x')as f:p=subprocess.run(['python3',str(w/name)],stdout=f,stderr=f)
  assert p.returncode==0,name
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
