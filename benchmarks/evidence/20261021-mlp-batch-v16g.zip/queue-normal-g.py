from pathlib import Path
import json,time,subprocess,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16g-20261021');state=dict(phase='waiting-accuracy',started_ns=time.time_ns())
def save():(w/'campaign-state.json').write_text(json.dumps(state,indent=2))
try:
 save()
 while True:
  p=w/'accuracy-r3-state.json';a=json.loads(p.read_text())if p.exists()else{}
  assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 state['phase']='waiting-bounded576';save()
 while True:
  p=w/'bounded576-state.json';a=json.loads(p.read_text())if p.exists()else{};assert a.get('phase')!='failed',a
  if a.get('phase')=='complete':break
  time.sleep(3)
 with(w/'freeze-g.log').open('x')as f:r=subprocess.run(['python3',str(w/'freeze-g.py')],stdout=f,stderr=f)
 assert r.returncode==0
 for name in ['final-c16','final-c32']:
  state.update(phase='measuring',current=name);save()
  with(w/(name+'.orchestrator.log')).open('x')as f:r=subprocess.run(['python3',str(w/'run-job.py'),name],stdout=f,stderr=f)
  assert r.returncode==0,(name,r.returncode)
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
