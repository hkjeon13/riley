from pathlib import Path
import argparse,hashlib,json,time,zipfile
p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('--adopt',action='store_true');a=p.parse_args();w=Path(a.root);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['campaign-state','normal-analysis-state','accuracy-r3-state','diagnostics-state','bounded576-state']:
 assert json.loads((w/(n+'.json')).read_text())['phase']=='complete',n
m=json.loads((w/'source-manifest.json').read_text());assert len(m)==937 and all(sha(w/'source'/f)==h for f,h in m.items())
l=json.loads((w/'source-lineage.json').read_text());assert sha(Path(l['binary']))==l['binary_sha256']
assert all(sha(Path(f))==h for f,h in l['normal_inputs_sha256'].items())
assert sha(w/'observe-finite.py')=='c0aad9d71eab4071eefb1f94d809c17ced2652d571e662e2af16bab765097947'
import difflib,re
v=w.parent/'riley-prefill-host-v15c-20261021'
patch=''.join(''.join(difflib.unified_diff((v/'source'/f).read_text().splitlines(True),(w/'source'/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f))for f in l['changed_sources']);(w/'candidate.patch').write_text(patch)
teacher=json.loads((w/'final-teacher-r3-audit.json').read_text())['runs'];mixed=json.loads((w/'mixed-byte-r3-audit.json').read_text())['runs'];bounded=json.loads((w/'bounded576-byte-audit.json').read_text())
assert sum(r['files']for r in teacher)+sum(r['rows']for r in mixed)==4480
assert all(r['all_bytes_equal_to_original_native_and_HF']for r in teacher)
assert all(r['all_literal_equal_to_original_native_and_HF']for r in mixed)
assert bounded['files']==2048 and bounded['all_equal_to_original_native_and_HF']
functions=0
for name in ['memory_gpu','owned_hf_command_batch_gpu','host_runtime_gpu','sm80_prefill_alignment_gpu']:
 functions+=int(re.search(r'test result: ok\. (\d+) passed',(w/('observed-'+name+'.stdout')).read_text()).group(1))
assert functions==6
regression=(w/'native-kv-regression.log').read_text();cpu=[tuple(map(int,m))for m in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',regression)]
assert tuple(sum(r[i]for r in cpu)for i in range(3))==(520,4,40)
c02=json.loads((w/'recheck-c02.py.outer.log').read_text());assert c02['all_passed'] and len(c02['tests'])==4 and all(t['returncode']==0 for t in c02['tests'])
assert m==json.loads((w/'pre-build-source.json').read_text())['source_sha256']

proof=json.loads((w/'actual-coalesced-dispatch-proof.json').read_text());assert len(proof)==2 and all(any(r>130 for r in p['actual_merged_rows'])for p in proof)
assert json.loads((w/'final-holder-audit.json').read_text())['passed']
import sqlite3
pv_geometry=[]
for c in [16,32]:
 for mode in ['before','after']:
  trace=w/f'runs/profile-c{c}/c{c}-r0-owned-{mode}/trace.sqlite';db=sqlite3.connect(trace)
  query="SELECT k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ,count(*),sum(k.end-k.start)/1e6 FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.demangledName WHERE s.value LIKE '%sm80_batched_pv_dispatch%' GROUP BY 1,2,3,4,5,6"
  rows=[dict(grid=list(r[:3]),block=list(r[3:6]),count=r[6],kernel_sum_ms=r[7])for r in db.execute(query)];db.close()
  expected=(8,32)if mode=='before'else(2,128);assert rows and all((r['grid'][0],r['block'][0])==expected for r in rows),(trace,rows)
  pv_geometry.append(dict(concurrency=c,mode=mode,trace=str(trace),trace_sha256=sha(trace),query=query,rows=rows,scope='Separate64keep profile dispatch geometry only; timing sums/counts differ, not normal HTTP or fixed-work speedup'))
(w/'actual-pv-dispatch-proof.json').write_text(json.dumps(pv_geometry,indent=2))

(w/'extended-accuracy-audit.json').write_text(json.dumps(dict(original_files=4480,extra_serving_capacity576_files=2048,total_literal_BF16_files=6528,original_reference_and_tolerance_unchanged=True,GPU_contract_functions=functions,new_merged_raw_cases=66,existing_alignment_cases=120,CPU_passed=524,CPU_ignored=40),indent=2))
stats=json.loads((w/'final-statistics.json').read_text());audit=json.loads((w/'independent-audit.json').read_text());normal=[x for x in audit['arms']if x['run']in ['final-c16','final-c32']];assert len(normal)==30
if a.adopt:assert all(not c['tail_over_two_percent_flags'] and c['median_percent_change']['output_tok_s']>0 for c in stats['cells'])
res=[]
for n in ['final-teacher-C1-eager-r3','final-teacher-allR-Graph-r3','teacher-body-allR-r3','teacher-mixed-r3','teacher-mixed-no-output-r3','memory_gpu','owned_hf_command_batch_gpu','host_runtime_gpu','sm80_prefill_alignment_gpu','bounded576']:
 r=json.loads((w/('observed-'+n+'.json')).read_text());assert r['status']=='complete'and r['returncode']==0
 ss=[json.loads(x)for x in(w/('observed-'+n+'.samples.jsonl')).read_text().splitlines()];peak=max(s['device_memory_mib']for s in ss);assert 0<peak<=22528
 res.append(dict(name=n,samples=len(ss),whole_device_peak_MiB=peak,receipt_sha256=sha(w/('observed-'+n+'.json'))))
(w/'resource-audit-final.json').write_text(json.dumps(dict(time_ns=time.time_ns(),resource_runs=res,source937_verified=True,binary_sha256=l['binary_sha256'],normal_arms=30,normal_profile_arms=len(audit['arms']),stored_SSE_verified=audit['total_full_SSE_values_verified'],normal_profile_peak_MiB=max(r['peak_whole_device_MiB']for r in audit['arms']),GPU6_foreign_work_preserved=True,all_finite_GPU_jobs_on_GPU7=True),indent=2))
stock=[]
for p in(w/'runs').glob('final-*/c*-vllm/server.log'):
 s=p.read_text();assert 'FLASH_ATTN'in s and 'FULL_AND_PIECEWISE'in s and ('version 2'in s or'version=2'in s),p
 stock.append(dict(log=str(p),sha256=sha(p),FLASH_ATTN=True,FULL_AND_PIECEWISE=True,version2=True))
assert len(stock)==10;(w/'stock-startup-proof.json').write_text(json.dumps(stock,indent=2))
(w/'adoption-decision.json').write_text(json.dumps(dict(time_ns=time.time_ns(),adopted=a.adopt,accuracy_threshold_changed=False,normal_completed_arms_excluded=0,tail_flags={str(c['concurrency']):c['tail_over_two_percent_flags']for c in stats['cells']},throughput_changes={str(c['concurrency']):c['median_percent_change']['output_tok_s']for c in stats['cells']},scope='Same native/HF literal BF16 and lifetime/lease contracts; matched five fresh before/after/stock runs per concurrency; profiles separate',reason='Adopt only with positive both-concurrency throughput and original tail gates; no hardware-counter or broad model claims'),indent=2))
skip={'source','target','tmp','cache','vllm-cache','ipc6','ipc7','__pycache__','torch_compile_cache','torchinductor_cache'};heavy={};files=[]
allowed={'.json','.jsonl','.log','.txt','.py','.sh','.stdout','.stderr','.cu','.cuh','.cpp','.sse','.h','.hpp','.exit','.sha256','.rs','.patch'}
for p in w.rglob('*'):
 if not p.is_file()or any(x in skip for x in p.relative_to(w).parts):continue
 with p.open('rb')as f:magic=f.read(4)
 if p.suffix in ['.bf16','.sqlite','.nsys-rep','.safetensors']or magic==b'\x7fELF':heavy[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));continue
 if p.suffix in allowed and p.name not in ['evidence-archive-receipt.json','heavy-evidence-index.json']:files.append(p)
(w/'heavy-evidence-index.json').write_text(json.dumps(heavy,indent=2));files.append(w/'heavy-evidence-index.json')
manifest={str(p.relative_to(w)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)};z=w/'evidence-archive.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as f:
 for p in sorted(files):f.write(p,str(p.relative_to(w)))
 f.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2))
r=dict(time_ns=time.time_ns(),archive=str(z),bytes=z.stat().st_size,entries=len(files)+1,sha256=sha(z),heavy_files=len(heavy));(w/'evidence-archive-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
