from pathlib import Path
import json,time,subprocess,sys
w=Path(sys.argv[1]);r=w.parent/'riley-w0-a100-gpu67-20261019';rows=[]
for _ in range(3):
 s=dict(time_ns=time.time_ns(),gpus=[])
 for i,pid,ticks in [(6,2027914,'6083215119'),(7,2027915,'6083215121')]:
  h=json.loads((r/f'leases-v2/gpu{i}.status.json').read_text());assert h['phase']=='idle'and h['allocation_bytes']==21474836480 and h['pid']==pid and h['start_ticks']==ticks
  assert Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]==ticks
  assert time.time_ns()-h['updated_ns']<10**10
  raw=subprocess.check_output(['nvidia-smi','-i',str(i),'--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'],text=True)
  ps=[dict(pid=int(l.split(',')[0]),MiB=float(l.split(',')[1]))for l in raw.splitlines()if l.strip()];assert pid in [p['pid']for p in ps]
  if i==7:assert len(ps)==1,ps
  s['gpus'].append(dict(index=i,holder=h,processes=ps,foreign_pids=[p['pid']for p in ps if p['pid']!=pid]))
 rows.append(s);time.sleep(.8)
(w/'final-holder-audit.json').write_text(json.dumps(dict(time_ns=time.time_ns(),passed=True,samples=rows,context_restart_or_release=False,scope='Original holder PID/start ticks/context maintained, three fresh idle20GiB samples, GPU7 finite jobs complete; GPU6 foreign work observed and untouched, no expanded admission'),indent=2))
