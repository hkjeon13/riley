from pathlib import Path
import json,time,subprocess,traceback,hashlib,shutil
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16g-20261021');state=dict(phase='waiting-normal',started_ns=time.time_ns())
def save():(w/'normal-analysis-state.json').write_text(json.dumps(state,indent=2))
def run(script,args=[]):
 with(w/(script+'.normal-analysis.log')).open('x')as f:r=subprocess.run(['python3',str(w/script)]+args,stdout=f,stderr=f)
 assert r.returncode==0,(script,r.returncode)
try:
 save()
 while True:
  a=json.loads((w/'campaign-state.json').read_text())
  if a['phase']in ['complete','failed']:assert a['phase']=='complete',a;break
  time.sleep(3)
 state['phase']='auditing';save();run('audit-complete.py',['--partial']);a=json.loads((w/'audit-partial.json').read_text());shutil.copy2(w/'audit-partial.json',w/'normal-independent-audit.json');normal=[r for r in a['arms']if r['run']in ['final-c16','final-c32']];assert len(normal)==30
 matrix=[]
 for c in [16,32]:
  rows=[dict(**r['record'],campaign=r['run'])for r in normal if r['record']['concurrency']==c];assert len(rows)==15 and all(sum(r['mode']==m for r in rows)==5 for m in ['owned-before','owned-after','vllm']);matrix.append(dict(concurrency=c,records=rows))
 (w/'primary-matrix-audit.json').write_text(json.dumps(matrix,indent=2));run('analyze-final.py');run('audit-tail-b.py')
 sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((w/'source-manifest.json').read_text());assert len(m)==937 and all(sha(w/'source'/f)==v for f,v in m.items());lineage=json.loads((w/'source-lineage.json').read_text());assert sha(w/'riley-mlp-batch-v16g')==lineage['binary_sha256']
 (w/'normal-input-stability.json').write_text(json.dumps(dict(source937_all_equal=True,binary_sha256=lineage['binary_sha256'],normal_runner_sha256=sha(w/'measure-matched.py'),normal_arm_count=30),indent=2))
 state.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
