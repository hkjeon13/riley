from pathlib import Path
import json,time,subprocess,traceback
w=Path('/mnt/efs/nlp/psyche/riley-mlp-batch-v16g-20261021');s=dict(phase='waiting-diagnostics',started_ns=time.time_ns())
def save():(w/'export-state.json').write_text(json.dumps(s,indent=2))
try:
 save()
 for name in ['diagnostics-state.json','normal-analysis-state.json']:
  while True:
   p=w/name;a=json.loads(p.read_text())if p.exists()else{};assert a.get('phase')!='failed',a
   if a.get('phase')=='complete':break
   time.sleep(3)
 stats=json.loads((w/'final-statistics.json').read_text());adopt=all(not c['tail_over_two_percent_flags']and c['median_percent_change']['output_tok_s']>0 for c in stats['cells'])
 s.update(phase='audit-export',adopt=adopt);save()
 for argv,name in [(['python3',str(w/'audit-holders.py'),str(w)],'holder-audit.outer.log'),(['python3',str(w/'finish-g.py'),str(w)]+(['--adopt']if adopt else[]),'export-evidence.outer.log')]:
  with(w/name).open('x')as out:r=subprocess.run(argv,stdout=out,stderr=out)
  assert r.returncode==0,(argv,r.returncode)
 s.update(phase='complete',finished_ns=time.time_ns());save()
except BaseException as err:s.update(phase='failed',error=repr(err),traceback=traceback.format_exc());save();raise
