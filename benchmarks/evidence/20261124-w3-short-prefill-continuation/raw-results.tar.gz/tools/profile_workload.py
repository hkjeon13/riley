"""Run fixed W3 request cohorts and anchor optional Nsight windows."""
import argparse
import asyncio
import ctypes
import json
import os
from pathlib import Path
import random
import signal
import subprocess
import time
import urllib.request

from replay import load_cell


def save(path, data):
    with path.open("x", encoding="utf-8") as output:
        json.dump(data, output, indent=2, allow_nan=False)
        output.write("\n")


def nvtx_clock():
    library = ctypes.CDLL("libnvToolsExt.so.1")
    mark = library.nvtxMarkA
    mark.argtypes = (ctypes.c_char_p,)
    mark.restype = None
    mark(b"W3_NVTX_INITIALIZE")

    def anchor(name):
        tag = f"RILEY_W3_CLOCK_{name}"
        before = time.perf_counter_ns()
        mark(tag.encode("ascii"))
        after = time.perf_counter_ns()
        return {"name": tag, "before_ns": before, "after_ns": after}

    return anchor


def run(plan_path):
    out = plan_path.absolute().parent
    plan = json.loads(plan_path.read_bytes())
    anchor = nvtx_clock() if plan["profile"] else None

    def interrupt(_signal, _frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, interrupt)
    signal.signal(signal.SIGINT, interrupt)
    with (out / "server.log").open("xb") as logfile:
        server = subprocess.Popen(plan["server"], env={**os.environ, **plan["env"]}, stdin=subprocess.DEVNULL,
                                  stdout=logfile, stderr=subprocess.STDOUT)
        try:
            (out / "server.pid").write_text(str(server.pid) + "\n")
            deadline = time.monotonic() + 550
            while True:
                if server.poll() is not None:
                    raise RuntimeError(f"server startup exit={server.returncode}")
                try:
                    with urllib.request.urlopen(plan["ready"], timeout=1) as response:
                        if response.status == 200:
                            break
                except OSError:
                    pass
                if time.monotonic() > deadline:
                    raise TimeoutError("server readiness")
                time.sleep(1)

            server_affinity = sorted(os.sched_getaffinity(server.pid))
            if server_affinity != sorted(os.sched_getaffinity(0)):
                raise RuntimeError("vLLM server CPU affinity differs")
            save(out / "cpu-placement.json", {"server_cpu_affinity": server_affinity})
            for name, cell in plan["cells"].items():
                anchors = [anchor(name + "_begin")] if anchor else []
                result = asyncio.run(load_cell(plan["address"], cell))
                if anchor:
                    anchors.append(anchor(name + "_end"))
                result["anchors"] = anchors
                save(out / (name + ".json"), result)
                if not result["measured"]:
                    raise RuntimeError(f"invalid completion or warmup in {name}")
                print(name, result["statistics"]["ttft_p95_ms"], flush=True)
        finally:
            if server.poll() is None:
                server.terminate()
                try:
                    server.wait(timeout=70)
                except subprocess.TimeoutExpired:
                    server.kill()
                    server.wait()
    save(out / "server-exit.json", {"exit": server.returncode})
    if server.returncode not in (0, -signal.SIGTERM):
        raise RuntimeError(f"graceful server shutdown exit={server.returncode}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("plan", type=Path)
    run(parser.parse_args().plan)
