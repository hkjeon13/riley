#include "probe-kernels.cuh"
#include "mma-backend.cuh"
#include "packed-kernels.cuh"
#define CU(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"CUDA line%d %s\n",__LINE__,cudaGetErrorString(e));return 2;}}while(0)
__global__ void fill(U*p,size_t n,int st){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n){uint32_t z=uint32_t(i)*1664525u+1013904223u+st*1237;float v=float(int(z%2047)-1023)/32768.f;if(st%6==1)v*=8;if(st%6==2)v*=.0078125f;if(st%6==3)v=i%7?0:v;if(st%6==4)v=i%2?-v:v;if(st%6==5)v*=32;p[i]=__float2bfloat16_rn(v);}}
__global__ void cmp(const U*a,const U*b,size_t n,unsigned*p){size_t i=size_t(blockIdx.x)*256+threadIdx.x;if(i<n&&__bfloat16_as_ushort(a[i])!=__bfloat16_as_ushort(b[i]))atomicAdd(p,1u);}

#include <cublasLt.h>
#define BL(x) do{auto e=(x);if(e!=CUBLAS_STATUS_SUCCESS){fprintf(stderr,"BL line%d status%d\n",__LINE__,int(e));throw std::runtime_error("cublas");}}while(0)
struct CurrentLt {
 cublasLtHandle_t h{};cublasLtMatmulDesc_t op{};cublasLtMatrixLayout_t w{},a[33]{},c[33]{};cublasLtMatmulAlgo_t algo{};void*ws{};
 CurrentLt(int n,int k,bool down){
  if(cublasLtGetVersion()!=120405)throw std::runtime_error("wrong Lt version");
  BL(cublasLtCreate(&h));BL(cublasLtMatmulDescCreate(&op,CUBLAS_COMPUTE_32F,CUDA_R_32F));cublasOperation_t trans=CUBLAS_OP_T;BL(cublasLtMatmulDescSetAttribute(op,CUBLASLT_MATMUL_DESC_TRANSA,&trans,sizeof(trans)));BL(cublasLtMatrixLayoutCreate(&w,CUDA_R_16BF,k,n,k));
  BL(cublasLtMatmulAlgoInit(h,CUBLAS_COMPUTE_32F,CUDA_R_32F,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,CUDA_R_16BF,31,&algo));
  const cublasLtMatmulAlgoConfigAttributes_t attrs[]={CUBLASLT_ALGO_CONFIG_TILE_ID,CUBLASLT_ALGO_CONFIG_STAGES_ID,CUBLASLT_ALGO_CONFIG_SPLITK_NUM,CUBLASLT_ALGO_CONFIG_REDUCTION_SCHEME,CUBLASLT_ALGO_CONFIG_CTA_SWIZZLING,CUBLASLT_ALGO_CONFIG_CUSTOM_OPTION};
  const uint32_t vals[]={15,down?18u:17u,down?2u:0u,down?4u:0u,down?1u:0u,0};
  for(int i=0;i<6;i++){BL(cublasLtMatmulAlgoConfigSetAttribute(&algo,attrs[i],&vals[i],sizeof(vals[i])));uint32_t got=0;size_t sz=0;BL(cublasLtMatmulAlgoConfigGetAttribute(&algo,attrs[i],&got,sizeof(got),&sz));if(got!=vals[i]||sz!=sizeof(got))throw std::runtime_error("algo metadata");}
  for(int r=2;r<=32;r++){BL(cublasLtMatrixLayoutCreate(&a[r],CUDA_R_16BF,k,r,k));BL(cublasLtMatrixLayoutCreate(&c[r],CUDA_R_16BF,n,r,n));cublasLtMatmulHeuristicResult_t check{};BL(cublasLtMatmulAlgoCheck(h,op,w,a[r],c[r],c[r],&algo,&check));BL(check.state);if(check.workspaceSize>4u*1024u*1024u)throw std::runtime_error("workspace bound");}
  if(cudaMalloc(&ws,4u*1024u*1024u)!=cudaSuccess)throw std::runtime_error("workspace alloc");
 }
 void run(const U*weight,const U*x,U*y,int r,cudaStream_t stream){float alpha=1,beta=0;BL(cublasLtMatmul(h,op,&alpha,weight,w,x,a[r],&beta,y,c[r],y,c[r],&algo,ws,4u*1024u*1024u,stream));}
 ~CurrentLt(){cudaFree(ws);for(int r=2;r<=32;r++){cublasLtMatrixLayoutDestroy(a[r]);cublasLtMatrixLayoutDestroy(c[r]);}cublasLtMatrixLayoutDestroy(w);cublasLtMatmulDescDestroy(op);cublasLtDestroy(h);}
};
__global__ void current_silu(const U*raw,U*y,int rows){int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<rows*9728){int r=i/9728,j=i%9728;float g=__bfloat162float(raw[r*19456+j]),u=__bfloat162float(raw[r*19456+9728+j]);float activated=__bfloat162float(__float2bfloat16_rn(g/(1.0f+expf(-g))));y[i]=__float2bfloat16_rn(activated*u);}}
#include "compressed.cuh"

int main(int argc,char**argv){if(argc!=2)return 8;cudaStream_t stream;CU(cudaStreamCreate(&stream));auto alloc=[](size_t n){void*p;auto e=cudaMalloc(&p,n);if(e)throw std::runtime_error("alloc");return p;};U*wg=(U*)alloc(19456ul*2560*2),*wu=wg+9728ul*2560,*wd=(U*)alloc(2560ul*9728*2),*x=(U*)alloc(32ul*9728*2),*gold=(U*)alloc(32ul*9728*2),*y=(U*)alloc(32ul*9728*2),*raw=(U*)alloc(32ul*19456*2),*pg=(U*)alloc(19456ul*2560*2),*pd=(U*)alloc(2560ul*9728*2);float*parts=(float*)alloc(4*32*2560*4);unsigned*bad=(unsigned*)alloc(4);CurrentLt current_down(2560,9728,true),current_gate(19456,2560,false);
 for(int layer:{0,17,35}){
  auto load=[&](const char*which,U*p,size_t n){std::string path=std::string(argv[1])+"/layer"+std::to_string(layer)+"-"+which+".bf16";FILE*f=fopen(path.c_str(),"rb");if(!f)throw std::runtime_error("open weight");std::vector<uint16_t>v(n);if(fread(v.data(),2,n,f)!=n||fgetc(f)!=EOF)throw std::runtime_error("weight length");fclose(f);if(cudaMemcpy(p,v.data(),n*2,cudaMemcpyHostToDevice))throw std::runtime_error("weight copy");return v;};
  auto g=load("gate",wg,9728ul*2560),u=load("up",wu,9728ul*2560),down=load("down",wd,2560ul*9728);
  auto cg=encode<64,64>(g.data(),u.data(),true),cd=encode<64,32>(down.data(),nullptr,false),cd2=encode<32,32>(down.data(),nullptr,false);
  for(auto item:{std::make_pair(0,&cg),std::make_pair(1,&cd),std::make_pair(2,&cd2)})printf("{\"kind\":\"packing\",\"layer\":%d,\"format\":%d,\"tiles\":%zu,\"fallback_tiles\":%zu,\"bytes\":%zu,\"host_pack_ms\":%.4f,\"host_bit_reconstruction\":true}\n",layer,item.first,item.second->tiles,item.second->fallback,item.second->data.size(),item.second->ms);
  auto upload=[&](const Encoded&e){auto*p=(unsigned char*)alloc(e.data.size());if(cudaMemcpy(p,e.data.data(),e.data.size(),cudaMemcpyHostToDevice))throw std::runtime_error("packed upload");return p;};auto*cgpu=upload(cg),*dcgpu=upload(cd),*dc2gpu=upload(cd2);
  pack_gate_kmajor<<<(19456ul*2560+255)/256,256,0,stream>>>(wg,wu,pg);pack_down_kmajor<<<(2560ul*9728+255)/256,256,0,stream>>>(wd,pd);CU(cudaGetLastError());CU(cudaStreamSynchronize(stream));
  for(int rows:{2,8,16,32})for(int st=0;st<6;st++){
   fill<<<(32ul*9728+255)/256,256,0,stream>>>(x,32ul*9728,st+2);
   auto run=[&](int op,int v){
    if(op==0){if(v==0){if(rows<=16)sm80_fused_gateup<4,16,16,2><<<304,128,0,stream>>>(wg,wu,x,y,rows);else{current_gate.run(wg,x,raw,rows,stream);current_silu<<<(rows*9728+255)/256,256,0,stream>>>(raw,y,rows);}}
     else if(v==1){if(rows<=16)kmajor_gate<4,16,16,2><<<304,128,0,stream>>>(pg,pg,x,y,rows);else kmajor_gate<4,32,8,2><<<304,128,0,stream>>>(pg,pg,x,y,rows);}
     else {if(rows<=16)compressed_projection<4,16,16,2,true><<<304,128,0,stream>>>(wg,wu,cgpu,x,y,parts,rows);else compressed_projection<4,32,8,2,true><<<304,128,0,stream>>>(wg,wu,cgpu,x,y,parts,rows);}
    }else if(v==0){current_down.run(wd,x,y,rows,stream);}else{
     if(v==1){if(rows<=16)kmajor_down<4,16,8,4><<<dim3(40,1,4),128,0,stream>>>(pd,x,parts,rows);else kmajor_down<4,32,16,4><<<dim3(40,1,4),128,0,stream>>>(pd,x,parts,rows);}
     else if(v==2){if(rows<=16)compressed_projection<4,16,8,4,false><<<dim3(40,1,4),128,0,stream>>>(wd,wd,dcgpu,x,y,parts,rows);else compressed_projection<4,32,16,4,false><<<dim3(40,1,4),128,0,stream>>>(wd,wd,dcgpu,x,y,parts,rows);}
     else {if(rows<=16)compressed_projection<2,16,8,4,false><<<dim3(80,1,4),64,0,stream>>>(wd,wd,dc2gpu,x,y,parts,rows);else compressed_projection<2,32,16,4,false><<<dim3(80,1,4),64,0,stream>>>(wd,wd,dc2gpu,x,y,parts,rows);}
     sm80_v9_down_reduce<<<(rows*2560+255)/256,256,0,stream>>>(parts,y,rows*2560);
    }
   };
   for(int op=0;op<2;op++){size_t n=rows*(op==0?9728:2560);run(op,0);CU(cudaGetLastError());CU(cudaMemcpyAsync(gold,y,n*2,cudaMemcpyDeviceToDevice,stream));
    for(int v=1;v<=(op==0?2:3);v++){run(op,v);CU(cudaGetLastError());CU(cudaMemsetAsync(bad,0,4,stream));cmp<<<(n+255)/256,256,0,stream>>>(gold,y,n,bad);unsigned count;CU(cudaMemcpyAsync(&count,bad,4,cudaMemcpyDeviceToHost,stream));CU(cudaStreamSynchronize(stream));printf("{\"kind\":\"case\",\"layer\":%d,\"rows\":%d,\"state\":%d,\"op\":%d,\"variant\":%d,\"mismatch\":%u",layer,rows,st,op,v,count);
     if(st==0&&count==0){printf(",\"pairs\":[");for(int rep=0;rep<5;rep++){float us[2];for(int turn=0;turn<2;turn++){int z=(turn+rep)%2;cudaGraph_t graph;cudaGraphExec_t exe;CU(cudaStreamBeginCapture(stream,cudaStreamCaptureModeThreadLocal));for(int i=0;i<32;i++)run(op,z?v:0);CU(cudaStreamEndCapture(stream,&graph));CU(cudaGraphInstantiate(&exe,graph,0));for(int i=0;i<3;i++)CU(cudaGraphLaunch(exe,stream));cudaEvent_t a,b;CU(cudaEventCreate(&a));CU(cudaEventCreate(&b));CU(cudaEventRecord(a,stream));for(int i=0;i<8;i++)CU(cudaGraphLaunch(exe,stream));CU(cudaEventRecord(b,stream));CU(cudaEventSynchronize(b));float ms;CU(cudaEventElapsedTime(&ms,a,b));us[z]=ms*1000/256;CU(cudaEventDestroy(a));CU(cudaEventDestroy(b));CU(cudaGraphExecDestroy(exe));CU(cudaGraphDestroy(graph));}printf("%s[%.4f,%.4f]",rep?",":"",us[0],us[1]);}printf("]");}puts("}");fflush(stdout);
    }
   }
  }
  CU(cudaFree(cgpu));CU(cudaFree(dcgpu));CU(cudaFree(dc2gpu));
 }
 return 0;
}
