#include <numeric>
#include <chrono>
// BF16 sign+mantissa bytes, 4-bit tile exponent dictionary, per-eight escape
// prefix and up to64 exact exponent escapes. No floating-point conversion.
struct Encoded {std::vector<unsigned char> data;size_t tiles=0,fallback=0;double ms=0;};
template<int N,int K> Encoded encode(const uint16_t*g,const uint16_t*u,bool gate){
 constexpr int Count=N*K,Prefix=Count/8,Dict=Count+Count/2+Prefix,Esc=Dict+16,Payload=(Esc+64+31)/32*32;
 int tiles=gate?40*(9728/(N/2)):4*76*(2560/N);Encoded out;out.tiles=tiles;out.data.resize(size_t(tiles)*Payload);auto start=std::chrono::steady_clock::now();
 for(int tile=0;tile<tiles;tile++){
  int nt=gate?tile%(9728/(N/2)):tile%(2560/N),it=gate?tile/(9728/(N/2)):tile/(2560/N)%76,part=gate?0:tile/(2560/N)/76;
  std::vector<uint16_t>raw(Count);int hist[256]{};for(int row=0;row<N;row++)for(int k=0;k<K;k++){
   int col=nt*(gate?N/2:N);auto b=gate?(row<N/2?g:u)[size_t(col+row%(N/2))*2560+it*64+k]:g[size_t(col+row)*9728+(part/2)*4864+(part%2)*32+it*64+k];raw[row*K+k]=b;hist[(b>>7)&255]++;
  }
  int order[256];std::iota(order,order+256,0);std::partial_sort(order,order+15,order+256,[&](int a,int b){return hist[a]!=hist[b]?hist[a]>hist[b]:a<b;});int codes[256];std::fill(codes,codes+256,15);auto*p=out.data.data()+size_t(tile)*Payload;
  for(int i=0;i<15;i++){codes[order[i]]=i;p[Dict+i]=order[i];}
  int count=0;for(int i=0;i<Count;i++)count+=codes[(raw[i]>>7)&255]==15;
  if(count>64){p[Count+Count/2]=128;out.fallback++;continue;}
  int cursor=0;for(int group=0;group<Count/8;group++){
   p[Count+Count/2+group]=cursor;for(int j=0;j<8;j++){int i=group*8+j;uint16_t b=raw[i];int e=(b>>7)&255,code=codes[e];p[i]=(b&127)|((b>>8)&128);p[Count+i/2]|=code<<((i%2)*4);if(code==15)p[Esc+cursor++]=e;}
  }
  if(cursor!=count)throw std::runtime_error("escape count");
  // Exhaustive host bit reconstruction independently checks the serialized format.
  for(int group=0;group<Count/8;group++){int ix=p[Count+Count/2+group];for(int j=0;j<8;j++){int i=group*8+j,code=(p[Count+i/2]>>((i%2)*4))&15;int e=code<15?p[Dict+code]:p[Esc+ix++];uint16_t b=(p[i]&127)|((p[i]&128)<<8)|(e<<7);if(b!=raw[i])throw std::runtime_error("lossless reconstruction mismatch");}}
 }
 out.ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return out;
}

template<int W,int R,int P,int S,bool Gate>struct CompGeometry{
 static constexpr int N=W*16,K=Gate?64:32,L=K+P,Count=N*K,Dict=Count+Count/2+Count/8,Esc=Dict+16,Payload=(Esc+64+31)/32*32,SB=Payload+R*L*2;
 static constexpr int Work=(N*L>W*(R/16)*256*2?N*L:W*(R/16)*256*2);
};
template<int W,int R,int P,int S,bool Gate>__device__ __forceinline__ void compressed_stage(unsigned char*dst,const unsigned char*packed,const U*x,int rows,int first,int it){
 using G=CompGeometry<W,R,P,S,Gate>;int tile=Gate?it*304+blockIdx.x:(blockIdx.z*76+it)*(2560/G::N)+blockIdx.x;bool active=it<(Gate?40:76);const unsigned char*src=active?packed+size_t(tile)*G::Payload:packed;
 for(int i=threadIdx.x*16;i<G::Payload;i+=W*32*16)sm80_down_copy16(dst+i,src+i,active);
 auto*b=reinterpret_cast<U*>(dst+G::Payload);int kb=Gate?it*64:(blockIdx.z/2)*4864+(blockIdx.z%2)*32+it*64;
 for(int i=threadIdx.x;i<R*(G::K/8);i+=W*32){int row=i/(G::K/8),k=i%(G::K/8)*8;bool valid=active&&first+row<rows;sm80_down_copy16(b+row*G::L+k,valid?x+(first+row)*(Gate?2560:9728)+kb+k:x,valid);}
 asm volatile("cp.async.commit_group;");
}
template<int W,int R,int P,int S,bool Gate>__global__ void compressed_projection(const U*wg,const U*wu,const unsigned char*packed,const U*x,U*y,float*parts,int rows){
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__>=800
 using namespace nvcuda;using G=CompGeometry<W,R,P,S,Gate>;constexpr int RB=R/16,C=Gate?2:1;
 __shared__ __align__(32)unsigned char stages[G::SB*S];__shared__ __align__(32)U work[G::Work];
 int first=blockIdx.y*R,col=blockIdx.x*(Gate?G::N/2:G::N),warp=threadIdx.x/32,lane=threadIdx.x%32;
 wmma::fragment<wmma::matrix_a,16,16,16,U,wmma::row_major>a;wmma::fragment<wmma::matrix_b,16,16,16,U,wmma::col_major>b;wmma::fragment<wmma::accumulator,16,16,16,float>c[RB][C];
 #pragma unroll
 for(int rb=0;rb<RB;rb++)for(int cc=0;cc<C;cc++)wmma::fill_fragment(c[rb][cc],0.f);
 #pragma unroll
 for(int st=0;st<S;st++)compressed_stage<W,R,P,S,Gate>(stages+st*G::SB,packed,x,rows,first,st);
 for(int it=0;it<(Gate?40:76);it++){
  asm volatile("cp.async.wait_group %0;"::"n"(S-1));__syncthreads();auto*t=stages+(it%S)*G::SB;
  if(t[G::Count+G::Count/2]&128){
   int kb=Gate?it*64:(blockIdx.z/2)*4864+(blockIdx.z%2)*32+it*64;
   for(int i=threadIdx.x;i<G::Count/8;i+=W*32){int row=i/(G::K/8),k=i%(G::K/8)*8;const U*src=Gate?(row<G::N/2?wg:wu)+size_t(col+row%(G::N/2))*2560+kb+k:wg+size_t(col+row)*9728+kb+k;sm80_down_copy16(work+row*G::L+k,src,true);}asm volatile("cp.async.commit_group;");asm volatile("cp.async.wait_group 0;");
  }else{
   for(int group=threadIdx.x;group<G::Count/8;group+=W*32){
    int cursor=t[G::Count+G::Count/2+group];uint32_t nib=*reinterpret_cast<const uint32_t*>(t+G::Count+group*4);uint2 low=*reinterpret_cast<const uint2*>(t+group*8);uint4 result{};auto*z=reinterpret_cast<uint32_t*>(&result);
    #pragma unroll
    for(int j=0;j<8;j++){unsigned byte=(j<4?low.x:low.y)>>(8*(j%4))&255,code=nib>>(4*j)&15;unsigned e=code<15?t[G::Dict+code]:t[G::Esc+cursor++];unsigned bits=(byte&127)|((byte&128)<<8)|(e<<7);z[j/2]|=bits<<((j%2)*16);}
    int row=group/(G::K/8),k=group%(G::K/8)*8;*reinterpret_cast<uint4*>(work+row*G::L+k)=result;
   }
  }
  __syncthreads();auto*bx=reinterpret_cast<U*>(t+G::Payload);
  #pragma unroll
  for(int j=0;j<G::K/16;j++){
   wmma::load_matrix_sync(a,work+warp*16*G::L+j*16,G::L);
   #pragma unroll
   for(int rb=0;rb<RB;rb++){wmma::load_matrix_sync(b,bx+rb*16*G::L+j*16,G::L);wmma::mma_sync(c[rb][Gate?j/2:0],a,b,c[rb][Gate?j/2:0]);}
  }
  __syncthreads();compressed_stage<W,R,P,S,Gate>(t,packed,x,rows,first,it+S);
 }
 asm volatile("cp.async.wait_group 0;");__syncthreads();auto results=reinterpret_cast<float(*)[RB][256]>(work);
 if constexpr(Gate){
  #pragma unroll
  for(int rb=0;rb<RB;rb++){for(int i=0;i<c[rb][0].num_elements;i++)c[rb][0].x[i]=__fadd_rn(c[rb][0].x[i],c[rb][1].x[i]);wmma::store_matrix_sync(results[warp][rb],c[rb][0],16,wmma::mem_col_major);}__syncthreads();
  if(warp<W/2){
   #pragma unroll
   for(int rb=0;rb<RB;rb++)for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows){float g=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp][rb][i],0.f))),u=__bfloat162float(__float2bfloat16_rn(__fmaf_rn(1.f,results[warp+W/2][rb][i],0.f)));float activated=__bfloat162float(__float2bfloat16_rn(g/(1.f+expf(-g))));y[row*9728+col+warp*16+i%16]=__float2bfloat16_rn(__fmul_rn(activated,u));}}
  }
 }else{
  #pragma unroll
  for(int rb=0;rb<RB;rb++){float*out=reinterpret_cast<float*>(work)+(warp*RB+rb)*256;wmma::store_matrix_sync(out,c[rb][0],16,wmma::mem_col_major);__syncwarp();for(int i=lane;i<256;i+=32){int row=first+rb*16+i/16;if(row<rows)parts[(blockIdx.z*rows+row)*2560+col+warp*16+i%16]=out[i];}}
 }
#endif
}
